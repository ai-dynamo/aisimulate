# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Separate main integration, removed frozen pricing and memory effects before refresh."""

from __future__ import annotations

import argparse
import copy
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[3]
HOST = {"wall_time_ms", "processed_tokens_per_s", "processed_output_tokens_per_s", "prediction_provenance"}


def run(source, raw):
    with tempfile.TemporaryDirectory(prefix="afd-round3-delta-") as tmp:
        config = Path(tmp) / "config.yaml"
        output = Path(tmp) / "out"
        config.write_text(yaml.safe_dump(raw))
        command = [
            sys.executable,
            "-m",
            "aisimulate",
            "predict",
            "--stack",
            "engine",
            "--config",
            str(config),
            "--format",
            "json",
            "--output-dir",
            str(output),
        ]
        result = subprocess.run(
            command,
            cwd=source,
            env={**os.environ, "PYTHONPATH": str(source / "python/aisimulate/src")},
            text=True,
            capture_output=True,
        )
        if result.returncode:
            raise RuntimeError(result.stderr)
        result = json.loads((output / "prediction.json").read_text())
        return {k: v for k, v in result.get("summary", result).items() if k not in HOST}


def changes(left, right):
    import math

    return {
        k: {"before": v, "after": right.get(k)}
        for k, v in left.items()
        if k not in HOST
        and (
            not math.isclose(v, right[k], rel_tol=1e-9, abs_tol=1e-9)
            if isinstance(v, (int, float)) and isinstance(right.get(k), (int, float))
            else v != right.get(k)
        )
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    fixture = json.loads((ROOT / "crates/core/parity_tests/perfmodel/goldens/afd_e2e.json").read_text())
    result = {"cases": {}, "scope": "All requests and token totals must remain equal before any Golden refresh."}
    for name, record in fixture["cases"].items():
        raw = yaml.safe_load((ROOT / record["config"]).read_text())
        old = run(args.baseline, raw)
        dynamic = copy.deepcopy(raw)
        dynamic["engine"]["estimator_config"] = {"afd": {"frozen_decode_identity": False}}
        base_dynamic = run(args.baseline, dynamic)
        candidate = run(ROOT, raw)
        for key in ["completed_requests", "total_input_tokens", "total_output_tokens"]:
            assert old[key] == base_dynamic[key] == candidate[key] == record["summary"][key], (name, key)
        result["cases"][name] = {
            "historical_to_integrated_default": changes(record["summary"], old),
            "integrated_frozen_to_dynamic": changes(old, base_dynamic),
            "dynamic_memory_and_integration_corrections": changes(base_dynamic, candidate),
            "summaries": {"baseline_default": old, "baseline_dynamic": base_dynamic, "candidate": candidate},
        }
        args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
        print(name, "verified", flush=True)


if __name__ == "__main__":
    main()
