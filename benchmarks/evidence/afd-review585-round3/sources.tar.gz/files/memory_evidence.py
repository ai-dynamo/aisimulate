# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Compare the reported prefill geometry's complete memory diagnostics."""

import argparse
import copy
import json
import os
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--baseline", type=Path, required=True)
parser.add_argument("--worker", action="store_true")
parser.add_argument("--output", type=Path)
args = parser.parse_args()
if args.worker:
    from aisimulate.compiler import prediction_to_replay_spec
    from aisimulate.config import CorePredictionConfig
    from aisimulate.runner import EngineReplayRunnerFactory
    from aisimulate.sweeper.replay import ReplayOutputRequirements

    raw = json.load(sys.stdin)
    try:
        report = (
            EngineReplayRunnerFactory()
            .create(0)
            .run(
                prediction_to_replay_spec(CorePredictionConfig.model_validate(raw)),
                output_requirements=ReplayOutputRequirements(capture_memory_diagnostics=True),
            )
        )
        result = {"metrics": report.metrics, "memory": report.metadata["native_report"]["afd_memory"]}
    except RuntimeError as error:
        result = {"error": str(error)}
    print(json.dumps(result))
else:
    raw = yaml.safe_load((ROOT / "crates/core/parity_tests/perfmodel/configs/afd-predict-pure.yaml").read_text())
    raw["engine"]["context_length"] = 4352
    raw["engine"]["workers"]["aggregated"]["afd"].update(n_a_nodes=2, n_f_nodes=4, a_batch_size=64, num_microbatches=3)
    raw["traffic"]["source"].update(input_tokens=4096, output_tokens=128)
    raw["traffic"]["stop"] = {"requests": 1}
    results = {"configuration": raw}
    for arm, source in [("baseline", args.baseline), ("candidate", ROOT)]:
        config = copy.deepcopy(raw)
        if arm == "baseline":
            config["engine"]["estimator_config"] = {"afd": {"frozen_decode_identity": False}}
        output = subprocess.check_output(
            [sys.executable, str(Path(__file__).resolve()), "--baseline", str(args.baseline), "--worker"],
            input=json.dumps(config),
            text=True,
            env={**os.environ, "PYTHONPATH": str(source / "python/aisimulate/src")},
            cwd=source,
        )
        results[arm] = json.loads(output)
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    assert "out_of_memory" in results["baseline"]["error"]
    assert results["candidate"]["metrics"]["completed_requests"] == 1
    assert results["candidate"]["metrics"]["total_input_tokens"] == 4096
    assert results["candidate"]["metrics"]["total_output_tokens"] == 128
    args.output.write_text(json.dumps(results, indent=2) + "\n")
