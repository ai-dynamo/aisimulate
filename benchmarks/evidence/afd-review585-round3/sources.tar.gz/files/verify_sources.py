# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Verify the immutable source archive and loaded binary for both benchmark arms."""

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
EVIDENCE = Path(__file__).resolve().parent


def verify_sources(baseline):
    identities = {}
    for arm, source in [("baseline", baseline), ("candidate", ROOT)]:
        command = """
import importlib.util, json, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location('afd_verifier', sys.argv[1])
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.ROOT = Path(sys.argv[2])
result = m._verified_build(Path(sys.argv[3]))
print(json.dumps({k: result[k] for k in ('source_snapshot_sha256', 'source_inventory_sha256', 'binary_sha256')}))
"""
        result = subprocess.check_output(
            [
                sys.executable,
                "-c",
                command,
                str(ROOT / "scripts/afd_parity.py"),
                str(source),
                str(EVIDENCE / f"{arm}-manifest.json"),
            ],
            env={**os.environ, "PYTHONPATH": str(source / "python/aisimulate/src")},
            cwd=source,
            text=True,
        )
        identities[arm] = json.loads(result)
    return identities
