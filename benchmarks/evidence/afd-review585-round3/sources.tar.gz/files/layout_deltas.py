# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Qualify execution-plan Golden changes against explicit dynamic baseline runs."""

import argparse
import copy
import json
import sys
import tempfile
from pathlib import Path

from modeling_deltas import ROOT, changes, run

sys.path.insert(0, str(ROOT / "scripts"))
import afd_parity

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--baseline", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
fixture = json.loads((ROOT / "crates/core/parity_tests/perfmodel/goldens/afd_execution_plan.json").read_text())
result = {}
for name, record in fixture["cases"].items():
    with tempfile.TemporaryDirectory(prefix="afd-round3-layout-") as tmp:
        raw = afd_parity.layout_config(record, Path(tmp))
        dynamic = copy.deepcopy(raw)
        dynamic["engine"]["estimator_config"] = {"afd": {"frozen_decode_identity": False}}
        integrated_default = run(args.baseline, raw)
        baseline = run(args.baseline, dynamic)
        candidate = run(ROOT, raw)
    differences = changes({k: baseline[k] for k in record["expected"]}, candidate)
    assert not differences, (name, differences)
    for field in ["completed_requests", "total_input_tokens", "total_output_tokens"]:
        assert baseline[field] == candidate[field]
    result[name] = {
        "historical_expected": record["expected"],
        "main_integration_changes": changes(record["expected"], integrated_default),
        "removed_frozen_changes": changes({k: integrated_default[k] for k in record["expected"]}, baseline),
        "verified_dynamic_expected": {k: candidate[k] for k in record["expected"]},
        "dynamic_baseline_differences": differences,
        "counts": {k: candidate[k] for k in ["completed_requests", "total_input_tokens", "total_output_tokens"]},
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(name, "verified", flush=True)
