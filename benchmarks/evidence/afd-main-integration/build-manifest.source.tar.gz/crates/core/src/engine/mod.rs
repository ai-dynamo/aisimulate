// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Runtime-neutral mock inference schedulers and attention-DP composition.

pub(crate) mod belady;
mod cache;
mod common;
mod config;
pub(crate) mod g3_offload;
pub mod generalized;
mod handoff;
mod host_offload;
mod kv_manager;
pub(crate) mod kvcr;
mod launch;
mod offload_lru;
pub(crate) mod offload_transfer;
mod protocol;
mod runtime;
mod scheduler;
mod timing;
mod trace;

pub use host_offload::SharedG2Pool;
pub(crate) use host_offload::{
    G2Binding, G2Registry, HostBlockKey, HostOffloadObservation, HostOffloadObservationData,
    HostOffloadObserver,
};
pub use launch::EngineLaunchConfig;

pub use belady::KvEvictionPolicy;
pub(crate) use common::hashing::{
    block_hashes_with_salt, cache_salt_seed, compute_block_hash_for_tokens,
    compute_next_sequence_hash,
};
pub use common::running_mean::RunningMean;
pub use common::speculative::normalize_conditional_accept_rates;
pub(crate) use config::afd_total_gpus;
pub use config::{AfdAPoolConfig, AfdEngineConfig, AfdFPoolConfig};
pub use config::{
    Backend, EngineConfig, FrontendConfig, FrontendStage, G2Connector, G2Scope, G3OffloadConfig,
    G3Scope, KvcrConfig, NativeHostOffloadConfig, PreemptionMode, SglangConfig,
    SglangHiCacheConfig, SglangHiCacheWritePolicy, SglangSchedulePolicy, StateCacheConfig,
    TrtllmCapacityPolicy, TrtllmConfig, WorkerType,
};
pub use g3_offload::{G3IoStats, G3Stats};
pub use handoff::{
    HandoffId, HandoffTransferTiming, TransferTimingMode, prefill_handoff_delay_ms,
    transfer_delay_ms,
};
pub use kvcr::{KvcrPullCounts, KvcrStats};
pub use protocol::{
    Admission, CacheTierAttribution, Command, CommandEffects, CommandResult, DecodeAcceptance,
    EncoderShape, ForwardPassMetrics, HostCacheMetrics, ImageSpec, KvBlock, KvEvent, KvEventData,
    KvEventTier, KvHintSource, LifecycleEvent, Metrics, Output, PassCompletionEffects,
    PassStartEffects, PrefixCacheLookupCounts, PressureEvent, PressureKind, PressureState, Request,
    StoredBlocks, TtftMilestone,
};
pub use runtime::{Engine, EngineFactory};
pub use scheduler::SchedulerRank;
#[cfg(feature = "python")]
pub(crate) use scheduler::afd::timing::AfdTimingModel;
#[cfg(test)]
pub(crate) use scheduler::afd::timing::tests::provider_for as afd_timing_provider_for;
#[cfg(all(test, feature = "python"))]
pub(crate) use timing::tests::assert_phase_bits;
pub use timing::{
    DecodeWork, IterationMs, MixedPassMs, PrefillTotals, PrefillWork, RankWork,
    TimingEvidenceSource, TimingEvidenceSummary, TimingModel, TimingModelConfig,
    TimingOperationEvidence, TimingPhaseEvidence, VisionShape,
};
#[cfg(feature = "python")]
pub(crate) use timing::{TimingEvidenceAccumulator, ValidatedTimingPhase, mean_prefill_shape};

#[doc(hidden)]
pub use protocol::PendingPass;
pub(in crate::engine) use timing::{modeled_duration_ms, predict_group_iteration_ms};
#[doc(hidden)]
pub use trace::g1_parent_chain_events;
