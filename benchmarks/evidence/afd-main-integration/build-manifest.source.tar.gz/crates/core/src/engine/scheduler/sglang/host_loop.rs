// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-FileCopyrightText: Copyright 2023-2024 SGLang Team
// SPDX-License-Identifier: Apache-2.0
// Modified event-cadence adaptation of SGLang v0.5.20; see THIRD_PARTY_NOTICES.md.
// Source: https://github.com/sgl-project/sglang/tree/94602c9c2b7cbdb8efd5c52802dac6a1c180089e

//! Iteration structure that turns one AIS pass into one SGLang loop iteration.
//!
//! Behavioral model of the SGLang overlap scheduler loop (`Scheduler.event_loop_overlap`,
//! `Scheduler.run_batch`, `SchedulerRequestReceiver.recv_requests`,
//! `process_batch_result_prefill`) as of sgl-project/sglang v0.5.19 (`0bcd822`,
//! `python/sglang/srt/managers/scheduler.py`,
//! `python/sglang/srt/managers/scheduler_components/request_receiver.py`,
//! `python/sglang/srt/managers/scheduler_components/batch_result_processor.py`).
//! Re-implemented in Rust from the observed semantics; no SGLang source is copied.
//!
//! Each iteration drains the requests that reached the scheduler since the last
//! drain, selects and launches this iteration's batch, and only then waits for
//! the previous forward and processes its result. The GPU is one stream: a
//! forward starts when it is launched and the previous forward has finished.
//! Consequently the outputs, terminals, and KV release of batch `k` become
//! visible at the end of iteration `k+1`, and a request that finished in batch
//! `k` retains KV until that result is processed. The core filters aggregated
//! non-speculative rows finishing by length before batch `k+1`, following
//! SGLang v0.5.22; PD decode can still run those ghost rows. Everything a forward
//! produces for the scheduler's bookkeeping travels with the batch: its output
//! tokens and the prefix-cache commits of `maybe_cache_unfinished_req` become
//! visible together when the batch is observed. Retraction or cancellation
//! discards the request's outputs while the device work stays charged; a
//! cancelled running request retains its KV until that observation cleans it up.
//!
//! The scheduler thread itself is modeled as free: request preparation is
//! priced in the frontend stages ahead of the inbox, and batch selection,
//! kernel launch, and result processing are not charged. With a free thread a
//! DECODE launch, which synchronizes with the previous forward before its
//! kernels start, and an EXTEND launch, which does not, produce the same
//! timeline, and the observation of a forward lands where that forward ends.

use std::collections::VecDeque;

use uuid::Uuid;

use crate::engine::common::protocols::OutputSignal;

use super::request::SglangRequest;

/// Scheduler-thread timeline of one iteration.
#[cfg(test)]
#[derive(Debug, Clone, Copy, PartialEq)]
pub(super) struct IterationTiming {
    /// Modeled completion of this iteration's forward, if it launched one.
    pub(super) gpu_end_ms: Option<f64>,
    /// The scheduler thread returns to the top of its loop.
    pub(super) end_ms: f64,
}

/// What a forward produced for the scheduler, held back until it is observed.
#[derive(Debug, Default)]
pub(super) struct ForwardOutputs {
    /// The observed batch selects the KV-event publication cadence.
    pub(super) prefill: bool,
    pub(super) output_signals: Vec<OutputSignal>,
    /// Requests whose prefix the radix cache learns when this batch is observed,
    /// with the sequence length the forward materialized for them.
    pub(super) cache_commits: Vec<(Uuid, usize)>,
    /// Cancelled running requests whose KV cannot be cached or released before observation.
    pub(super) cancelled_requests: Vec<SglangRequest>,
}

impl ForwardOutputs {
    /// Drop everything owed to `uuid`; returns how many output tokens that was.
    fn discard_request(&mut self, uuid: Uuid) -> usize {
        let tokens = self
            .output_signals
            .iter()
            .filter(|signal| signal.uuid == uuid && signal.token_id.is_some())
            .count();
        self.output_signals.retain(|signal| signal.uuid != uuid);
        self.cache_commits.retain(|(request, _)| *request != uuid);
        tokens
    }
}

/// A launched batch whose result the scheduler has not observed yet.
#[derive(Debug)]
struct InFlightBatch {
    gpu_end_ms: f64,
    outputs: ForwardOutputs,
}

#[derive(Debug, Default)]
pub(super) struct HostLoop {
    /// Requests delivered to the scheduler and waiting for the next `recv_requests`.
    inbox: VecDeque<SglangRequest>,
    in_flight: Option<InFlightBatch>,
    gpu_free_ms: f64,
}

impl HostLoop {
    pub(super) fn new() -> Self {
        Self::default()
    }

    /// Whether the loop owns no delivered request and no unobserved batch.
    pub(super) fn is_idle(&self) -> bool {
        self.inbox.is_empty() && self.in_flight.is_none()
    }

    pub(super) fn unobserved_output_tokens(&self) -> usize {
        self.in_flight.as_ref().map_or(0, |batch| {
            batch
                .outputs
                .output_signals
                .iter()
                .filter(|signal| signal.token_id.is_some())
                .count()
        })
    }

    /// Requests delivered but not yet received.
    #[cfg(test)]
    pub(super) fn request_ids(&self) -> impl Iterator<Item = Uuid> + '_ {
        self.inbox.iter().map(|request| request.uuid)
    }

    /// Deliver a request to the scheduler process. It is received at the next
    /// iteration start, never inside the running iteration.
    pub(super) fn submit(&mut self, request: SglangRequest) {
        self.inbox.push_back(request);
    }

    /// Remove a delivered request before the scheduler receives it.
    pub(super) fn take_request(&mut self, uuid: Uuid) -> Option<SglangRequest> {
        let index = self.inbox.iter().position(|request| request.uuid == uuid)?;
        self.inbox.remove(index)
    }

    /// Drain the whole inbox, mirroring the non-blocking drain at the top of the loop.
    pub(super) fn take_received(&mut self) -> Vec<SglangRequest> {
        self.inbox.drain(..).collect()
    }

    /// Forget what the forward in flight would deliver for `uuid`, returning the
    /// number of output tokens it had sampled for it. The device work stays
    /// charged: the batch already ran with the request.
    pub(super) fn discard_request(&mut self, uuid: Uuid) -> usize {
        self.in_flight
            .as_mut()
            .map_or(0, |batch| batch.outputs.discard_request(uuid))
    }

    pub(super) fn contains_request(&self, uuid: Uuid) -> bool {
        self.in_flight.as_ref().is_some_and(|batch| {
            batch.outputs.output_signals.iter().any(|s| s.uuid == uuid)
                || batch
                    .outputs
                    .cache_commits
                    .iter()
                    .any(|(id, _)| *id == uuid)
        })
    }

    /// Keep a cancelled request's KV until the current forward is observed.
    /// Return it for immediate cleanup when no forward is in flight.
    pub(super) fn defer_cancelled_request(
        &mut self,
        request: SglangRequest,
    ) -> Option<SglangRequest> {
        let Some(batch) = &mut self.in_flight else {
            return Some(request);
        };
        batch.outputs.cancelled_requests.push(request);
        None
    }

    /// Lay this iteration's forward and result observation on the GPU timeline.
    /// `forward` is the launched batch's modeled device time and what it
    /// produces for the scheduler; they are held back and returned by the next
    /// call, which observes them. The returned outputs are `None` when no batch
    /// was in flight.
    #[cfg(test)]
    pub(super) fn plan(
        &mut self,
        selected_ms: f64,
        forward: Option<(f64, ForwardOutputs)>,
    ) -> (IterationTiming, Option<ForwardOutputs>) {
        let (end_ms, observed) = self.observe(selected_ms);
        let gpu_end_ms = self.launch(selected_ms, forward);
        (IterationTiming { gpu_end_ms, end_ms }, observed)
    }

    /// Wait for and take the previous iteration's forward: the scheduler
    /// thread returns at the returned time with that forward's outputs, `None`
    /// when no batch was in flight. Neither depends on the forward this
    /// iteration launches.
    pub(super) fn observe(&mut self, selected_ms: f64) -> (f64, Option<ForwardOutputs>) {
        let observed = self.in_flight.take();
        // `copy_done.synchronize()` on the previous batch is the only point where
        // the scheduler thread waits for the GPU.
        let end_ms = observed
            .as_ref()
            .map_or(selected_ms, |previous| selected_ms.max(previous.gpu_end_ms));
        (end_ms, observed.map(|previous| previous.outputs))
    }

    /// Launch this iteration's forward, selected at `selected_ms`, after
    /// [`Self::observe`]: it starts when the previous forward has finished and
    /// runs for its modeled device time. Returns its completion, `None` when
    /// the iteration launched no forward.
    pub(super) fn launch(
        &mut self,
        selected_ms: f64,
        forward: Option<(f64, ForwardOutputs)>,
    ) -> Option<f64> {
        debug_assert!(
            self.in_flight.is_none(),
            "observe the previous forward first"
        );
        let (gpu_ms, outputs) = forward?;
        let gpu_end_ms = self.forward_start_ms(selected_ms) + gpu_ms;
        self.gpu_free_ms = gpu_end_ms;
        self.in_flight = Some(InFlightBatch {
            gpu_end_ms,
            outputs,
        });
        Some(gpu_end_ms)
    }

    pub(super) fn forward_start_ms(&self, selected_ms: f64) -> f64 {
        self.gpu_free_ms.max(selected_ms)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn signal(uuid: Uuid) -> OutputSignal {
        OutputSignal {
            uuid,
            token_id: Some(1),
            completed: false,
            rejected: false,
            cached_tokens: None,
            handoff_delay_ms: None,
        }
    }

    fn outputs(signals: Vec<OutputSignal>) -> ForwardOutputs {
        ForwardOutputs {
            output_signals: signals,
            ..Default::default()
        }
    }

    #[test]
    fn a_forward_is_observed_when_the_next_iteration_synchronizes_with_it() {
        let mut host = HostLoop::new();
        let (timing, observed) = host.plan(0.0, Some((20.0, outputs(vec![signal(Uuid::nil())]))));
        assert!(observed.is_none());
        // No previous batch: the free loop returns at once while the GPU keeps running.
        assert_eq!(
            timing,
            IterationTiming {
                gpu_end_ms: Some(20.0),
                end_ms: 0.0
            }
        );

        // Launched at 5 while the first forward runs: the GPU serves it 20..30 and
        // the loop returns when the first forward is observed, at 20.
        let (timing, observed) = host.plan(5.0, Some((10.0, ForwardOutputs::default())));
        assert_eq!(
            observed.map(|outputs| outputs.output_signals.len()),
            Some(1)
        );
        assert_eq!(
            timing,
            IterationTiming {
                gpu_end_ms: Some(30.0),
                end_ms: 20.0
            }
        );
    }

    #[test]
    fn a_discarded_request_leaves_the_forward_in_flight_without_its_outputs() {
        let mut host = HostLoop::new();
        let cancelled = Uuid::from_u128(7);
        host.plan(
            0.0,
            Some((
                20.0,
                ForwardOutputs {
                    output_signals: vec![signal(cancelled), signal(Uuid::nil())],
                    cache_commits: vec![(cancelled, 4), (Uuid::nil(), 4)],
                    ..Default::default()
                },
            )),
        );
        assert_eq!(host.discard_request(cancelled), 1);
        let (timing, observed) = host.plan(5.0, None);
        let observed = observed.expect("the batch is still observed");
        assert_eq!(observed.output_signals.len(), 1);
        assert_eq!(observed.cache_commits, vec![(Uuid::nil(), 4)]);
        // The batch that ran with the request is still waited for.
        assert_eq!(timing.end_ms, 20.0);
    }

    #[test]
    fn an_iteration_without_a_batch_only_observes_the_previous_forward() {
        let mut host = HostLoop::new();
        host.plan(0.0, Some((30.0, ForwardOutputs::default())));
        let (timing, observed) = host.plan(12.0, None);
        assert!(observed.is_some());
        assert_eq!(
            timing,
            IterationTiming {
                gpu_end_ms: None,
                end_ms: 30.0
            }
        );
        assert!(host.is_idle());
    }
}
