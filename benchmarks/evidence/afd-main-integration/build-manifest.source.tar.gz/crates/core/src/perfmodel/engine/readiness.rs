// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Construction-time table availability. Shape, slice and interpolation-domain
//! coverage remains a query-time check; no synthetic workload is queried here.

use std::collections::HashMap;

use crate::AicError;
use crate::common::enums::{
    ComputeDtype, DatabaseMode, GemmQuantMode, KvCacheQuantMode, MoeQuantMode, QuantMapping,
    TransferKind,
};
use crate::config::PerfSource;
use crate::operators::Op;
use crate::operators::fpm_forward::{FpmForwardOp, FpmInterpolation, FpmPhase};
use crate::perf_database::moe::MoeKernel;
use crate::perf_database::{PerfDatabase, kernel_source_ok, parquet_loader::PerfReader};

pub(super) fn validate<'a>(
    db: &PerfDatabase,
    ops: impl Iterator<Item = &'a Op>,
) -> Result<(), AicError> {
    let mut check = Availability {
        db,
        tables: HashMap::new(),
    };
    for op in ops {
        check.op(op)?;
    }
    Ok(())
}

pub(super) fn validate_fpm(db: &PerfDatabase, fpm: &FpmForwardOp) -> Result<(), AicError> {
    // FPM profiles may have no original SOL ops. Check the preserved compute
    // identity before selecting a measured cell, independently of data presence.
    for (field, value) in crate::perf_database::fpm_forward::FPM_CELL_MATCH_COLUMNS
        .iter()
        .zip(&fpm.match_identity)
    {
        let quant = match *field {
            "gemm_quant_mode" => serde_json::from_value::<GemmQuantMode>(value.clone().into())
                .ok()
                .map(GemmQuantMode::mapping),
            "moe_quant_mode" => serde_json::from_value::<MoeQuantMode>(value.clone().into())
                .ok()
                .map(MoeQuantMode::mapping),
            _ => None,
        };
        if let Some(quant) = quant {
            validate_compute_capability(db, quant)?;
        }
    }
    let cell = db
        .fpm_forward
        .select_cell(&fpm.match_identity, &fpm.model_path, fpm.dcp_size)?;
    fpm.reject_speculative_on_ar_cell(cell)?;
    if fpm.interpolation == FpmInterpolation::Direct
        && match fpm.phase {
            FpmPhase::Prefill => cell.direct_prefill.is_empty(),
            FpmPhase::Decode => cell.direct_decode.is_empty(),
        }
    {
        let phase = fpm.phase.as_str();
        return Err(AicError::PerfDatabase(format!(
            "direct FPM {phase} interpolation has no genuine measurements for {:?} at {}. \
             Collect genuine {phase} FPM rows for this model and identity, or provide a \
             systems root containing them.",
            fpm.model_path,
            db.data_root.display(),
        )));
    }
    Ok(())
}

fn validate_compute_capability(db: &PerfDatabase, quant: QuantMapping) -> Result<(), AicError> {
    // FP8 tensor-core compute starts at SM89 (Ada). Weight-only formats
    // that dequantize to BF16 must not be rejected by their storage name.
    // https://docs.nvidia.com/cuda/archive/12.9.0/ada-tuning-guide/index.html
    if quant.compute_dtype == Some(ComputeDtype::Fp8)
        && let Some(sm) = db.system_spec.gpu.sm_version
        && sm < 89
    {
        return Err(AicError::InvalidEngineConfig(format!(
            "GPU {} (SM{sm}) does not support FP8 tensor-core compute required by quant mode '{}'. \
             AISimulate does not model FP8 weight-only (Marlin) execution on pre-SM89 GPUs. \
             Use a BF16 checkpoint on this GPU, or select an FP8-capable GPU such as h100_sxm or h200_sxm \
             with matching backend performance data.",
            db.system, quant.name,
        )));
    }
    Ok(())
}

/// Hopper FP8 KV requires a runtime that implements the GLM IndexPool path.
/// vLLM 0.32.0 fixes the SM90 FlashInfer plan dtype (#55222, c37f86e5721f),
/// and SGLang 0.5.22 enables CUDA TileLang FP8 KV (#42957, 9336681310c7).
/// The latter requires TileLang for both DSA prefill and decode. These are
/// runtime restrictions, not a hardware prohibition or measured-data coverage.
/// Sources: https://github.com/vllm-project/vllm/pull/55222
///          https://github.com/sgl-project/sglang/pull/42957
fn validate_glm53_kv_capability(
    db: &PerfDatabase,
    op: &crate::operators::glm53flash::Glm53AttentionOp,
) -> Result<(), AicError> {
    if op.layer_kind == "sparse_mla"
        && op.kv_cache_dtype == KvCacheQuantMode::Fp8
        && let Some(sm) = db.system_spec.gpu.sm_version
        && (90..100).contains(&sm)
    {
        let minimum = match op.backend.as_str() {
            "vllm" => "0.32.0",
            "sglang" => "0.5.22",
            _ => return Ok(()),
        };
        if db
            .version
            .parse::<pep440_rs::Version>()
            .is_ok_and(|version| version >= minimum.parse::<pep440_rs::Version>().unwrap())
        {
            return Ok(());
        }
        return Err(AicError::InvalidEngineConfig(format!(
            "GLM-5.3-Flash on GPU {} (SM{sm}) cannot use FP8 sparse-MLA KV with {}: the \
             requested backend_version={} requires {} >= {}. Select a supported runtime \
             (SGLang requires TileLang DSA prefill and decode), or pass \
             kvcache_quant_mode=\"bfloat16\".",
            db.system, op.backend, db.version, op.backend, minimum,
        )));
    }
    Ok(())
}

/// Sources of one GLM-consumed table, refusing any borrowed file. The
/// generic readers merge every resolved source into one table, so with the
/// shared layer on a nearest-earlier or cross-backend file could answer a
/// GLM lookup with another runtime's row, labelled silicon.
fn glm53_exact_sources(
    db: &PerfDatabase,
    name: &str,
) -> Result<Vec<crate::perf_database::source_resolution::PrioritizedSource>, AicError> {
    let sources = db
        .source_resolver
        .prioritized_sources_for(name, &db.data_root)?;
    if let Some(borrowed) = sources.iter().find(|source| {
        !matches!(source.channel, "primary" | "declared_reuse") && source.source.path().is_file()
    }) {
        return Err(AicError::PerfDatabase(format!(
            "GLM-5.3-Flash SILICON reads {name} only from the exact runtime {}/{}, but \
             the shared layer also loads {} ({} channel, version {}); set \
             enable_shared_layer=False",
            db.backend,
            db.version,
            borrowed.source.path().display(),
            borrowed.channel,
            borrowed.version,
        )));
    }
    Ok(sources)
}

/// Generic tables a GLM-5.3-Flash op reads in SILICON.
fn glm53_tables(op: &Op, tables: &mut std::collections::BTreeSet<&'static str>) {
    use Op::*;
    let measured = match op {
        Glm53Mhc(_) => {
            tables.insert("mhc_module_perf.parquet");
            return;
        }
        Glm53Attention(o) => &o.measured,
        Glm53Ffn(o) => &o.measured,
        Glm53Primitive(o) => &o.measured,
        TokenScale(o) => return glm53_tables(&o.op, tables),
        Overlap(o) => {
            for child in o.group_a.iter().chain(&o.group_b) {
                glm53_tables(child, tables);
            }
            return;
        }
        Fallback(o) => {
            glm53_tables(&o.primary, tables);
            for child in &o.fallback {
                glm53_tables(child, tables);
            }
            return;
        }
        _ => return,
    };
    for child in measured {
        match child {
            Gemm(_) => tables.insert("gemm_perf.parquet"),
            Moe(_) => tables.insert("moe_perf.parquet"),
            Kda(_) => tables.insert("kda_perf.parquet"),
            Mhc(_) => tables.insert("mhc_module_perf.parquet"),
            CustomAllReduce(comm) if comm.tp_size > 1 => {
                tables.insert("custom_allreduce_perf.parquet")
            }
            _ => false,
        };
    }
}

/// Engine-construction guard shared by every entry point (forward-pass model,
/// `EngineHandle`, `InferenceSession`, CLI) in every database mode: applies
/// the SM90 GLM-5.3-Flash sparse-KV rule to every attention op, including
/// ops nested in token-scale, overlap, fallback, FPM (`sol_ops`) and DSV4.1
/// stage wrappers. No table is read.
pub(super) fn validate_glm53_kv<'a>(
    db: &PerfDatabase,
    ops: impl Iterator<Item = &'a Op>,
) -> Result<(), AicError> {
    fn visit(db: &PerfDatabase, op: &Op) -> Result<(), AicError> {
        match op {
            Op::Glm53Attention(attention) => validate_glm53_kv_capability(db, attention),
            Op::TokenScale(o) => visit(db, &o.op),
            Op::Overlap(o) => o
                .group_a
                .iter()
                .chain(&o.group_b)
                .try_for_each(|c| visit(db, c)),
            Op::Fallback(o) => {
                visit(db, &o.primary)?;
                o.fallback.iter().try_for_each(|c| visit(db, c))
            }
            // The FPM rewrite keeps the original phase graph as its SOL
            // anchor, and DSV4.1 stages hold child ops; both are traversed.
            Op::FpmForward(o) => o.sol_ops.iter().try_for_each(|c| visit(db, c)),
            Op::Dsv41Stage(o) => o.children.iter().try_for_each(|c| visit(db, c)),
            _ => Ok(()),
        }
    }
    ops.into_iter().try_for_each(|op| visit(db, op))
}

/// Engine-construction guard shared by every entry point (forward-pass model,
/// `InferenceSession`, CLI): a SILICON engine containing GLM-5.3-Flash ops
/// must not load any of their tables from a borrowed source. Other models
/// and other modes are untouched.
pub(super) fn validate_glm53_sources<'a>(
    db: &PerfDatabase,
    ops: impl Iterator<Item = &'a Op>,
) -> Result<(), AicError> {
    if db.database_mode != DatabaseMode::Silicon {
        return Ok(());
    }
    let mut tables = std::collections::BTreeSet::new();
    for op in ops {
        glm53_tables(op, &mut tables);
    }
    for name in tables {
        glm53_exact_sources(db, name)?;
    }
    Ok(())
}

struct Availability<'a> {
    db: &'a PerfDatabase,
    tables: HashMap<String, bool>,
}

impl Availability<'_> {
    fn has(&mut self, name: &str) -> Result<bool, AicError> {
        if let Some(found) = self.tables.get(name) {
            return Ok(*found);
        }
        if name == "moe_perf.parquet" {
            let found = match self.db.moe.available_quants(MoeKernel::Standard) {
                Ok(quants) => !quants.is_empty(),
                Err(error) if error.is_missing_perf_data() => false,
                Err(error) => return Err(error),
            };
            self.tables.insert(name.to_owned(), found);
            return Ok(found);
        }
        let sources = match name {
            "nccl_perf.parquet" => self
                .db
                .communication
                .nccl_root()
                .map(|root| vec![PerfSource(root.join(name), None)])
                .unwrap_or_default(),
            "oneccl_perf.parquet" => self
                .db
                .communication
                .oneccl_root()
                .map(|root| vec![PerfSource(root.join(name), None)])
                .unwrap_or_default(),
            "dsv4_megamoe_module_perf.parquet" => {
                vec![PerfSource(
                    self.db.dsv4_megamoe.primary_path().to_owned(),
                    None,
                )]
            }
            _ => self
                .db
                .source_resolver
                .sources_for(name, &self.db.data_root)?,
        };
        let mut found = false;
        for source in sources {
            if !source.path().is_file() {
                continue;
            }
            let reader = PerfReader::open(source.path())?;
            let kernel = reader.col_optional("kernel_source");
            for row in reader.rows()? {
                if kernel_source_ok(source.kernel_sources(), kernel, &row?)? {
                    found = true;
                    break;
                }
            }
            if found {
                break;
            }
        }
        self.tables.insert(name.to_owned(), found);
        Ok(found)
    }

    fn any(&mut self, names: &[&str]) -> Result<(), AicError> {
        for name in names {
            if self.has(name)? {
                return Ok(());
            }
        }
        Err(AicError::PerfDatabase(format!(
            "required op-level data unavailable for {:?}: no rows in {} at {}",
            self.db.database_mode,
            names.join(" or "),
            self.db.data_root.display(),
        )))
    }

    /// GLM tables must come from the exact requested runtime: the primary
    /// file of this system/backend/version or an explicitly declared
    /// `reuse.yaml` donor. Nearest-earlier siblings and cross-backend fill
    /// are not admitted for GLM SILICON: the generic readers merge every
    /// resolved source into one table, so a borrowed source (shared layer
    /// on) is rejected by [`glm53_exact_sources`].
    fn exact(&mut self, name: &str) -> Result<(), AicError> {
        let key = format!("exact:{name}");
        if let Some(found) = self.tables.get(&key) {
            return if *found {
                Ok(())
            } else {
                Err(self.exact_miss(name))
            };
        }
        let sources = glm53_exact_sources(self.db, name)?;
        let mut found = false;
        for source in sources {
            if !matches!(source.channel, "primary" | "declared_reuse")
                || !source.source.path().is_file()
            {
                continue;
            }
            let reader = PerfReader::open(source.source.path())?;
            let kernel = reader.col_optional("kernel_source");
            for row in reader.rows()? {
                if kernel_source_ok(source.source.kernel_sources(), kernel, &row?)? {
                    found = true;
                    break;
                }
            }
            if found {
                break;
            }
        }
        self.tables.insert(key, found);
        if found {
            Ok(())
        } else {
            Err(self.exact_miss(name))
        }
    }

    fn exact_miss(&self, name: &str) -> AicError {
        AicError::PerfDatabase(format!(
            "GLM-5.3-Flash SILICON requires {name} measured on the exact runtime {}/{} \
             (primary or declared reuse.yaml donor) under {}; earlier-version and \
             cross-backend tables are not admitted",
            self.db.backend,
            self.db.version,
            self.db.data_root.display(),
        ))
    }

    fn glm53_silicon(&mut self, op: &Op) -> Result<(), AicError> {
        use Op::*;
        let (name, measured) = match op {
            Glm53Attention(o) if o.layer_kind == "sparse_mla" => {
                use crate::perf_database::glm53flash::BASENAME;
                if !self
                    .db
                    .glm53_attention
                    .primary_path()
                    .is_some_and(|path| path.is_file())
                {
                    return Err(self.exact_miss(BASENAME));
                }
                // Load and validate the table, then require this op's exact
                // geometry so a missing TP/checkpoint/phase fails here rather
                // than on the first step.
                return if self.db.glm53_attention.covers(o)? {
                    Ok(())
                } else {
                    Err(AicError::PerfDatabase(format!(
                        "GLM-5.3-Flash SILICON has no {BASENAME} rows for {} \
                         (tp_size={}, checkpoint_format={}, is_context={}) on the exact \
                         runtime {}/{} under {}",
                        o.name,
                        o.tp_size,
                        o.checkpoint_format,
                        o.is_context,
                        self.db.backend,
                        self.db.version,
                        self.db.data_root.display(),
                    )))
                };
            }
            // mHC reads GLM-tagged mhc_module_perf rows directly (GLM role
            // semantics); another model's rows of the same shape never count.
            Glm53Mhc(o) => {
                use crate::operators::glm53flash::MHC_ARCHITECTURE;
                self.exact("mhc_module_perf.parquet")?;
                return if self.db.mhc.has_architecture_rows(
                    MHC_ARCHITECTURE,
                    &o.role,
                    o.hc_mult,
                    o.hidden_size,
                )? {
                    Ok(())
                } else {
                    Err(AicError::PerfDatabase(format!(
                        "GLM-5.3-Flash SILICON has no {MHC_ARCHITECTURE} mhc_module_perf rows \
                         for role {} (hc_mult={}, hidden_size={}) on the exact runtime {}/{} \
                         under {}",
                        o.role,
                        o.hc_mult,
                        o.hidden_size,
                        self.db.backend,
                        self.db.version,
                        self.db.data_root.display(),
                    )))
                };
            }
            Glm53Attention(o) => (&o.name, &o.measured),
            Glm53Ffn(o) => (&o.name, &o.measured),
            Glm53Primitive(o) => (&o.name, &o.measured),
            _ => {
                return Err(AicError::PerfDatabase(format!(
                    "{} is a GLM-5.3-Flash analytical child without measured data",
                    op.name()
                )));
            }
        };
        if measured.is_empty() {
            return Err(AicError::PerfDatabase(format!(
                "GLM-5.3-Flash {name} has no measured generic composition"
            )));
        }
        for child in measured {
            self.op(child)?;
            match child {
                Gemm(_) => self.exact("gemm_perf.parquet")?,
                Moe(_) => self.exact("moe_perf.parquet")?,
                Kda(_) => self.exact("kda_perf.parquet")?,
                Mhc(_) => self.exact("mhc_module_perf.parquet")?,
                CustomAllReduce(comm) if comm.tp_size > 1 => {
                    self.exact("custom_allreduce_perf.parquet")?
                }
                _ => {}
            }
        }
        Ok(())
    }

    fn op(&mut self, op: &Op) -> Result<(), AicError> {
        use Op::*;
        let quant = match op {
            Gemm(gemm) => Some(gemm.quant_mode.mapping()),
            Moe(moe) => Some(moe.quant_mode.mapping()),
            _ => None,
        };
        if let Some(quant) = quant {
            validate_compute_capability(self.db, quant)?;
        }
        if let Glm53Attention(attention) = op {
            validate_glm53_kv_capability(self.db, attention)?;
        }
        // CSA context parallelism consumes both sparse correction tables even
        // when its base module uses the analytic SOL. HCA never consumes them.
        if let Dsv4Context(module) = op
            && module.cp_size > 1
            && module.attn_kind == crate::perf_database::dsv4::AttnKind::Csa
        {
            self.any(&["dsv4_paged_mqa_logits_module_perf.parquet"])?;
            self.any(&["dsv4_csa_topk_calib_perf.parquet"])?;
        }
        let sol = matches!(
            self.db.database_mode,
            DatabaseMode::Sol | DatabaseMode::SolFull
        );
        match op {
            Dsv41Stage(stage) => {
                for child in &stage.children {
                    self.op(child)?;
                }
                return Ok(());
            }
            Overlap(group) => {
                for child in group.group_a.iter().chain(&group.group_b) {
                    self.op(child)?;
                }
                return Ok(());
            }
            Fallback(group) => {
                let primary = if self.db.database_mode == DatabaseMode::Hybrid {
                    validate(&self.db.silicon_view(), [&*group.primary].into_iter())
                } else {
                    self.op(&group.primary)
                };
                match primary {
                    Ok(()) => return Ok(()),
                    Err(error)
                        if error.is_missing_perf_data() || matches!(error, AicError::Io { .. }) =>
                    {
                        for child in &group.fallback {
                            self.op(child)?;
                        }
                        return Ok(());
                    }
                    Err(error) => return Err(error),
                }
            }
            TokenScale(scale) => return self.op(&scale.op),
            FpmForward(fpm) => return validate_fpm(self.db, fpm),
            // These families have no analytic/empirical implementation.
            MoeAllToAll(_) | MoeExpertCompute(_) | Dsv4MegaMoe(_)
                if !matches!(
                    self.db.database_mode,
                    DatabaseMode::Silicon | DatabaseMode::Hybrid
                ) =>
            {
                return Err(AicError::UnsupportedModel(format!(
                    "{} requires silicon data; {:?} is unsupported",
                    op.name(),
                    self.db.database_mode,
                )));
            }
            _ if sol => return Ok(()),
            _ => {}
        }
        match op {
            Gemm(gemm) => {
                self.any(&["gemm_perf.parquet"])?;
                if gemm.quant_mode == GemmQuantMode::Fp8Static {
                    self.any(&["computescale_perf.parquet"])?;
                    if gemm.low_precision_input {
                        self.any(&["scale_matrix_perf.parquet"])?;
                    }
                }
                Ok(())
            }
            ContextAttention(_) => self.any(&["context_attention_perf.parquet"]),
            GenerationAttention(_) => self.any(&["generation_attention_perf.parquet"]),
            EncoderAttention(_) => self.any(&["encoder_attention_perf.parquet"]),
            ContextMla(_) => self.any(&["context_mla_perf.parquet"]),
            GenerationMla(_) => self.any(&["generation_mla_perf.parquet"]),
            MlaModuleContext(_) => self.any(&["mla_context_module_perf.parquet"]),
            MlaModuleGeneration(_) => self.any(&["mla_generation_module_perf.parquet"]),
            MlaBmm(_) => self.any(&["mla_bmm_perf.parquet"]),
            Moe(moe) => {
                let found = match moe.moe_kernel_source.as_deref() {
                    Some(source) => !self
                        .db
                        .moe
                        .available_quants_for_kernel_source(source)?
                        .is_empty(),
                    None => {
                        self.has("moe_perf.parquet")?
                            || (moe.is_gated
                                && moe.quant_mode == MoeQuantMode::Nvfp4
                                && self.db.moe.low_latency_available()?)
                    }
                };
                if found {
                    Ok(())
                } else {
                    Err(AicError::PerfDatabase(format!(
                        "required MoE data unavailable for kernel_source={:?} at {}",
                        moe.moe_kernel_source,
                        self.db.data_root.display()
                    )))
                }
            }
            // State-space kernels explicitly fall back to their analytic SOL
            // on missing tables in every database mode.
            Mamba2(_) | Gdn(_) | Kda(_) => Ok(()),
            MeasuredComposite(op) => {
                op.validate()?;
                op.validate_database(self.db)
            }
            Mhc(_) => self.any(&["mhc_module_perf.parquet"]),
            WideEpContextMla(_) => self.any(&["wideep_context_mla_perf.parquet"]),
            WideEpGenerationMla(_) => self.any(&["wideep_generation_mla_perf.parquet"]),
            DsaContext(module) => {
                self.any(&["dsa_context_module_perf.parquet"])?;
                if module.cp_size > 1 {
                    let prefix =
                        crate::perf_database::dsa::dsa_sparse_file_prefix(&module.architecture);
                    self.any(&[&format!("{prefix}_mqa_logits_module_perf.parquet")])?;
                    self.any(&[&format!("{prefix}_topk_module_perf.parquet")])?;
                }
                Ok(())
            }
            DsaGeneration(_) => self.any(&["dsa_generation_module_perf.parquet"]),
            MsaContext(_) | MsaGeneration(_) => {
                let phase = if matches!(op, MsaContext(_)) {
                    "context"
                } else {
                    "generation"
                };
                let own = format!("msa_{phase}_module_perf.parquet");
                if self.db.database_mode != DatabaseMode::Empirical && self.has(&own)? {
                    return Ok(());
                }
                if self.db.database_mode != DatabaseMode::Silicon
                    && self.db.transfer_policy.contains(TransferKind::XOp)
                {
                    return self.any(&[&format!("dsa_{phase}_module_perf.parquet")]);
                }
                self.any(&[&own])
            }
            Dsv4Context(module) | Dsv4Generation(module) => {
                use crate::perf_database::dsv4::AttnKind;
                let kind = match module.attn_kind {
                    AttnKind::Csa => "csa",
                    AttnKind::Hca => "hca",
                };
                let phase = if matches!(op, Dsv4Context(_)) {
                    "context"
                } else {
                    "generation"
                };
                self.any(&[&format!("dsv4_{kind}_{phase}_module_perf.parquet")])
            }
            Dsv4MegaMoe(_) => self.any(&["dsv4_megamoe_module_perf.parquet"]),
            MoeAllToAll(_) => self.any(&[
                "moe_a2a_perf.parquet",
                "wideep_deepep_ll_perf.parquet",
                "wideep_deepep_normal_perf.parquet",
                "trtllm_alltoall_perf.parquet",
            ]),
            MoeExpertCompute(_) => self.any(&[
                "moe_expert_compute_perf.parquet",
                "wideep_context_moe_perf.parquet",
                "wideep_generation_moe_perf.parquet",
                "wideep_moe_perf.parquet",
                "moe_perf.parquet",
            ]),
            CustomAllReduce(comm) if comm.tp_size > 1 => {
                if self.db.system_spec.node.num_gpus_per_node == 72
                    && comm.tp_size > 4
                    && matches!(
                        self.db.database_mode,
                        DatabaseMode::Silicon | DatabaseMode::Hybrid
                    )
                {
                    self.any(&["nccl_perf.parquet", "oneccl_perf.parquet"])
                } else {
                    self.any(&["custom_allreduce_perf.parquet"])
                }
            }
            Nccl(comm) if comm.num_gpus > 1 => {
                self.any(&["nccl_perf.parquet", "oneccl_perf.parquet"])
            }
            // Dispatch chooses its comm legs from topology at query time. A
            // single-rank graph needs no communication table.
            MoeDispatch(dispatch) if dispatch.moe_tp_size * dispatch.moe_ep_size > 1 => {
                self.any(&[
                    "custom_allreduce_perf.parquet",
                    "nccl_perf.parquet",
                    "oneccl_perf.parquet",
                    "trtllm_alltoall_perf.parquet",
                ])
            }
            Vision(_) => {
                self.any(&["gemm_perf.parquet"])?;
                self.any(&["encoder_attention_perf.parquet"])
            }
            Embedding(_) | Elementwise(_) | P2P(_) | CustomAllReduce(_) | Nccl(_)
            | MoeDispatch(_) => Ok(()),
            Glm53Attention(_) | Glm53Mhc(_) | Glm53Router(_) | Glm53Ffn(_) | Glm53Primitive(_) => {
                match self.db.database_mode {
                    DatabaseMode::Silicon => self.glm53_silicon(op),
                    DatabaseMode::Empirical => Err(AicError::EmpiricalNotImplemented(
                        "GLM-5.3-Flash has no empirical anchor".into(),
                    )),
                    _ => Ok(()),
                }
            }
            Dsv41Attention(_) | Dsv41Mhc(_) | Dsv41Engram(_) | Dsv41Linear(_) => {
                match self.db.database_mode {
                    DatabaseMode::Silicon => self.any(&["dsv41_module_perf.parquet"]),
                    DatabaseMode::Empirical => Err(AicError::EmpiricalNotImplemented(format!(
                        "DeepSeek-V4.1 {} has no empirical anchor",
                        op.name()
                    ))),
                    _ => Ok(()),
                }
            }
            // AFD comm ops compose the standard P2P/NCCL/ElementWise twins:
            // transfer and combine need no table of their own; the F-node
            // collectives need the NCCL table exactly when the twin
            // collective is active (multi-GPU node + one-to-one mapping) —
            // the same condition as the `Nccl` arm.
            AfdFAllGather(comm) | AfdFReduceScatter(comm)
                if comm.f_gpus_in_node() > 1
                    && comm.rank_mapping == crate::operators::AfdRankMapping::OneToOne =>
            {
                self.any(&["nccl_perf.parquet", "oneccl_perf.parquet"])
            }
            AfdTransfer(_) | AfdFAllGather(_) | AfdFReduceScatter(_) | AfdCombine(_) => Ok(()),
            Overlap(_) | Fallback(_) | TokenScale(_) | FpmForward(_) | Dsv41Stage(_) => Ok(()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::common::enums::TransferPolicy;
    use crate::config::PerfDbSources;
    use crate::operators::dsv4::{Dsv4MegaMoeOp, Dsv4ModuleOp};
    use crate::operators::op::{FallbackOp, OverlapOp};
    use crate::operators::{EmbeddingOp, GemmOp};
    use crate::perf_database::energy_test_fixtures::{Col, write_parquet};
    use crate::perfmodel::engine::{Engine, spec::EngineSpec};
    use std::sync::Arc;

    fn systems() -> tempfile::TempDir {
        let root = tempfile::tempdir().unwrap();
        let spec = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../python/aisimulate/src/aisimulate_core/systems/b200_sxm.yaml");
        std::fs::copy(spec, root.path().join("b200_sxm.yaml")).unwrap();
        std::fs::create_dir_all(root.path().join("data/b200_sxm/vllm/0.24.0")).unwrap();
        root
    }

    fn engine_readiness(db: PerfDatabase, op: Op) -> Result<(), AicError> {
        let config = serde_json::from_value(serde_json::json!({
            "schema_version": crate::ENGINE_CONFIG_SCHEMA_VERSION,
            "model_name": "readiness-fixture",
            "system_name": "b200_sxm", "backend": "vllm", "backend_version": "0.24.0",
            "tp_size": 1, "pp_size": 1, "database_mode": db.database_mode,
        }))
        .unwrap();
        let (context, generation) = if matches!(op, Op::Dsv4Generation(_)) {
            (vec![], vec![op])
        } else {
            (vec![op], vec![])
        };
        Engine::build(EngineSpec::new(config, context, generation), Arc::new(db))?
            .validate_forward_pass_readiness(crate::ForwardPassWorkerType::Aggregated)
    }

    fn dsv4_op(kind: &str, context: bool, cp: u32) -> Op {
        let module: Dsv4ModuleOp = serde_json::from_value(serde_json::json!({
            "name": "attention", "scale_factor": 1.0, "attn_kind": kind,
            "num_heads": 64, "native_heads": 64, "tp_size": 1, "cp_size": cp,
            "kv_cache_dtype": "bfloat16", "fmha_quant_mode": "bfloat16",
            "gemm_quant_mode": "bfloat16", "architecture": "DeepseekV4ForCausalLM",
        }))
        .unwrap();
        if context {
            Op::Dsv4Context(module)
        } else {
            Op::Dsv4Generation(module)
        }
    }

    fn table(path: &std::path::Path) {
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        write_parquet(path, &[Col::Str("kernel_source", vec!["fixture"])]);
    }

    #[test]
    fn fp8_compute_capability_is_checked_before_tables_and_sol() {
        let root = systems();
        for mode in [DatabaseMode::Silicon, DatabaseMode::Sol] {
            for sm in [Some(80), Some(86), Some(89), Some(90), None] {
                let path = root.path().join("b200_sxm.yaml");
                let mut spec: serde_yaml::Value =
                    serde_yaml::from_str(&std::fs::read_to_string(&path).unwrap()).unwrap();
                spec["gpu"]["sm_version"] = serde_yaml::to_value(sm).unwrap();
                std::fs::write(path, serde_yaml::to_string(&spec).unwrap()).unwrap();
                let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                    .unwrap()
                    .with_mode(mode, TransferPolicy::ALL);
                let op = Op::Gemm(GemmOp::new("gemm", 16, 16, GemmQuantMode::Fp8Block));
                let result = validate(&db, [&op].into_iter());
                if sm.is_some_and(|value| value < 89) {
                    assert!(matches!(result, Err(AicError::InvalidEngineConfig(_))));
                } else {
                    assert!(!matches!(result, Err(AicError::InvalidEngineConfig(_))));
                }
                let op = Op::Gemm(GemmOp::new("gemm", 16, 16, GemmQuantMode::W4a16Nvfp4));
                assert!(!matches!(
                    validate(&db, [&op].into_iter()),
                    Err(AicError::InvalidEngineConfig(_))
                ));
            }
        }
    }

    #[test]
    fn a100_fpm_precision_is_checked_before_table_readiness() {
        use crate::perf_database::fpm_forward::tests::default_identity;
        let root = systems();
        let source = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../python/aisimulate/src/aisimulate_core/systems/a100_sxm.yaml");
        std::fs::copy(source, root.path().join("a100_sxm.yaml")).unwrap();
        std::fs::create_dir_all(root.path().join("data/a100_sxm/vllm/0.24.0")).unwrap();
        let db = PerfDatabase::load(root.path(), "a100_sxm", "vllm", "0.24.0").unwrap();
        for (gemm, moe, rejected) in [
            ("fp8_block", "bfloat16", true),
            ("bfloat16", "fp8", true),
            ("w4a16_nvfp4", "w4a16_nvfp4", false),
            ("bfloat16", "bfloat16", false),
        ] {
            let mut identity = default_identity(4);
            identity[0] = gemm.into();
            identity[1] = moe.into();
            let op = FpmForwardOp {
                name: "fpm_forward_decode".into(),
                phase: FpmPhase::Decode,
                model_path: "org/model-a".into(),
                match_identity: identity,
                weight_bytes: 0.0,
                verify_width: 1,
                interpolation: FpmInterpolation::Direct,
                sol_ops: vec![],
                original_fmha_quant_mode: None,
                dcp_size: None,
            };
            let error = validate_fpm(&db, &op).unwrap_err();
            assert_eq!(matches!(error, AicError::InvalidEngineConfig(_)), rejected);
            if rejected {
                assert!(
                    error
                        .to_string()
                        .contains("GPU a100_sxm (SM80) does not support FP8")
                );
            }
        }
    }

    #[test]
    fn glm53_hopper_fp8_kv_admission_tracks_runtime_fixes() {
        let root = systems();
        let path = root.path().join("b200_sxm.yaml");
        let mut spec: serde_yaml::Value =
            serde_yaml::from_str(&std::fs::read_to_string(&path).unwrap()).unwrap();
        spec["gpu"]["sm_version"] = serde_yaml::to_value(90).unwrap();
        std::fs::write(path, serde_yaml::to_string(&spec).unwrap()).unwrap();

        // Stable upstream release boundaries; prereleases of the first fixed
        // version and unknown labels do not establish that the fix is present.
        for (backend, version, supported) in [
            ("vllm", "0.31.0", false),
            ("vllm", "0.32.0rc1", false),
            ("vllm", "0.32.0", true),
            ("vllm", "0.32.0+cu130", true),
            ("vllm", "0.33.0", true),
            ("sglang", "0.5.20", false),
            ("sglang", "0.5.21", false),
            ("sglang", "0.5.22.dev1", false),
            ("sglang", "0.5.22", true),
            ("sglang", "0.5.22.post1", true),
            ("sglang", "main", false),
        ] {
            for mode in [
                DatabaseMode::Silicon,
                DatabaseMode::Hybrid,
                DatabaseMode::Sol,
            ] {
                let mut db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                    .unwrap()
                    .with_mode(mode, TransferPolicy::ALL);
                db.tables_mut().version = version.into();
                let mut sparse = crate::operators::glm53flash::tests::attention("sparse_mla");
                sparse.backend = backend.into();
                sparse.checkpoint_format = "fp8".into();
                let op = Op::TokenScale(crate::operators::op::TokenScaleOp {
                    op: Box::new(Op::Glm53Attention(sparse.clone())),
                    numerator: 1,
                    denominator: 1,
                });
                let result = validate_glm53_kv(&db, [&op].into_iter());
                assert_eq!(result.is_ok(), supported, "{backend} {version}: {result:?}");
                if supported {
                    let ready = validate(&db, [&op].into_iter());
                    if mode == DatabaseMode::Silicon {
                        // Reopening the runtime path must not supply missing
                        // measurements or silently switch the FP8 identity.
                        assert!(matches!(ready, Err(AicError::PerfDatabase(_))), "{ready:?}");
                    } else {
                        ready.unwrap();
                    }
                }
                sparse.kv_cache_dtype = KvCacheQuantMode::Bfloat16;
                validate_glm53_kv_capability(&db, &sparse).unwrap();
            }
        }
    }

    #[test]
    fn glm53_fp8_sparse_kv_is_rejected_on_sm90_in_every_mode() {
        let root = systems();
        for (sm, rejected) in [
            (Some(90), true),
            (Some(100), false),
            (Some(103), false),
            (None, false),
        ] {
            let path = root.path().join("b200_sxm.yaml");
            let mut spec: serde_yaml::Value =
                serde_yaml::from_str(&std::fs::read_to_string(&path).unwrap()).unwrap();
            spec["gpu"]["sm_version"] = serde_yaml::to_value(sm).unwrap();
            std::fs::write(path, serde_yaml::to_string(&spec).unwrap()).unwrap();
            for mode in [
                DatabaseMode::Silicon,
                DatabaseMode::Hybrid,
                DatabaseMode::Sol,
            ] {
                let mut db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                    .unwrap()
                    .with_mode(mode, TransferPolicy::ALL);
                for backend in ["vllm", "sglang"] {
                    db.tables_mut().version = match backend {
                        "vllm" => "0.31.0",
                        _ => "0.5.20",
                    }
                    .into();
                    let mut sparse = crate::operators::glm53flash::tests::attention("sparse_mla");
                    sparse.backend = backend.into();
                    sparse.checkpoint_format = "fp8".into();
                    let mut bf16 = sparse.clone();
                    bf16.kv_cache_dtype = KvCacheQuantMode::Bfloat16;
                    let kda = crate::operators::glm53flash::tests::attention("kda");
                    let fp8 = Op::Glm53Attention(sparse);
                    let result = validate(&db, [&fp8].into_iter());
                    let wrapped = Op::TokenScale(crate::operators::op::TokenScaleOp {
                        op: Box::new(fp8.clone()),
                        numerator: 1,
                        denominator: 1,
                    });
                    let nested = validate(&db, [&wrapped].into_iter());
                    if rejected {
                        for error in [result.unwrap_err(), nested.unwrap_err()] {
                            assert!(matches!(error, AicError::InvalidEngineConfig(_)), "{error}");
                            let text = error.to_string();
                            assert!(text.contains("SM90") && text.contains("bfloat16"), "{text}");
                        }
                    } else {
                        assert!(!matches!(result, Err(AicError::InvalidEngineConfig(_))));
                        assert!(!matches!(nested, Err(AicError::InvalidEngineConfig(_))));
                    }
                    // BF16 latent KV and KDA layers are never refused here.
                    for op in [Op::Glm53Attention(bf16), Op::Glm53Attention(kda.clone())] {
                        assert!(!matches!(
                            validate(&db, [&op].into_iter()),
                            Err(AicError::InvalidEngineConfig(_))
                        ));
                    }
                }
            }
        }
    }

    #[test]
    fn glm53_fp8_sparse_kv_is_rejected_by_every_engine_build_on_sm90() {
        // Engine::build is shared by EngineHandle, InferenceSession and the
        // forward-pass model, so the rule holds without readiness validation.
        let root = systems();
        for (sm, rejected) in [(Some(90), true), (Some(100), false), (None, false)] {
            let path = root.path().join("b200_sxm.yaml");
            let mut spec: serde_yaml::Value =
                serde_yaml::from_str(&std::fs::read_to_string(&path).unwrap()).unwrap();
            spec["gpu"]["sm_version"] = serde_yaml::to_value(sm).unwrap();
            std::fs::write(path, serde_yaml::to_string(&spec).unwrap()).unwrap();
            for mode in [DatabaseMode::Hybrid, DatabaseMode::Sol] {
                let build = |kv| {
                    let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                        .unwrap()
                        .with_mode(mode, TransferPolicy::ALL);
                    let config = serde_json::from_value(serde_json::json!({
                        "schema_version": crate::ENGINE_CONFIG_SCHEMA_VERSION,
                        "model_name": "glm-fixture",
                        "system_name": "b200_sxm", "backend": "vllm", "backend_version": "0.24.0",
                        "tp_size": 2, "pp_size": 1, "database_mode": mode,
                    }))
                    .unwrap();
                    let mut sparse = crate::operators::glm53flash::tests::attention("sparse_mla");
                    sparse.checkpoint_format = "fp8".into();
                    sparse.kv_cache_dtype = kv;
                    let mut decode = sparse.clone();
                    decode.is_context = false;
                    // Generation op nested in a token-scale wrapper.
                    let generation = Op::TokenScale(crate::operators::op::TokenScaleOp {
                        op: Box::new(Op::Glm53Attention(decode)),
                        numerator: 1,
                        denominator: 1,
                    });
                    Engine::build(
                        EngineSpec::new(config, vec![Op::Glm53Attention(sparse)], vec![generation]),
                        Arc::new(db),
                    )
                };
                match build(KvCacheQuantMode::Fp8) {
                    Err(error) => {
                        assert!(rejected, "{sm:?} {mode:?}: {error}");
                        assert!(matches!(error, AicError::InvalidEngineConfig(_)), "{error}");
                        assert!(error.to_string().contains("bfloat16"), "{error}");
                    }
                    Ok(_) => assert!(!rejected, "{sm:?} {mode:?}"),
                }
                build(KvCacheQuantMode::Bfloat16).unwrap();
            }
        }
    }

    #[test]
    fn glm53_fp8_sparse_kv_nested_in_fpm_sol_ops_is_rejected_at_engine_build_on_sm90() {
        use crate::perf_database::fpm_forward::tests::default_identity;
        let root = systems();
        let path = root.path().join("b200_sxm.yaml");
        let mut spec: serde_yaml::Value =
            serde_yaml::from_str(&std::fs::read_to_string(&path).unwrap()).unwrap();
        spec["gpu"]["sm_version"] = serde_yaml::to_value(Some(90)).unwrap();
        std::fs::write(path, serde_yaml::to_string(&spec).unwrap()).unwrap();
        let build = |kv| {
            let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                .unwrap()
                .with_mode(DatabaseMode::Sol, TransferPolicy::ALL);
            let config = serde_json::from_value(serde_json::json!({
                "schema_version": crate::ENGINE_CONFIG_SCHEMA_VERSION,
                "model_name": "glm-fixture",
                "system_name": "b200_sxm", "backend": "vllm", "backend_version": "0.24.0",
                "tp_size": 2, "pp_size": 1, "database_mode": DatabaseMode::Sol,
            }))
            .unwrap();
            let mut sparse = crate::operators::glm53flash::tests::attention("sparse_mla");
            sparse.checkpoint_format = "fp8".into();
            sparse.kv_cache_dtype = kv;
            let fpm = |phase: FpmPhase, sparse: crate::operators::glm53flash::Glm53AttentionOp| {
                Op::FpmForward(FpmForwardOp {
                    name: format!("fpm_forward_{}", phase.as_str()),
                    phase,
                    model_path: "org/model-a".into(),
                    match_identity: default_identity(2),
                    weight_bytes: 0.0,
                    verify_width: 1,
                    interpolation: FpmInterpolation::Sol,
                    sol_ops: vec![Op::TokenScale(crate::operators::op::TokenScaleOp {
                        op: Box::new(Op::Glm53Attention(sparse)),
                        numerator: 1,
                        denominator: 1,
                    })],
                    original_fmha_quant_mode: None,
                    dcp_size: None,
                })
            };
            let mut decode = sparse.clone();
            decode.is_context = false;
            Engine::build(
                EngineSpec::new(
                    config,
                    vec![fpm(FpmPhase::Prefill, sparse)],
                    vec![fpm(FpmPhase::Decode, decode)],
                ),
                Arc::new(db),
            )
        };
        let error = build(KvCacheQuantMode::Fp8)
            .err()
            .expect("SM90 FP8 KV in sol_ops");
        assert!(matches!(error, AicError::InvalidEngineConfig(_)), "{error}");
        let text = error.to_string();
        for needle in ["SM90", "sparse-MLA KV", "bfloat16"] {
            assert!(text.contains(needle), "{needle}: {text}");
        }
        build(KvCacheQuantMode::Bfloat16).expect("BF16 KV in sol_ops builds on SM90");
    }

    #[test]
    fn glm53_silicon_admits_only_exact_runtime_generic_tables() {
        const RUNTIME: &str = "0.31.0";
        let root = systems();
        let data = root.path().join("data/b200_sxm");
        // Earlier runtime rows exist; the requested GLM runtime has only GEMM.
        table(&data.join("mhc/vllm/0.24.0/mhc_module_perf.parquet"));
        table(&data.join("glm53_attention/vllm/0.24.0/glm53_attention_module_perf.parquet"));
        table(&data.join(format!("gemm/vllm/{RUNTIME}/gemm_perf.parquet")));
        let mhc: Op = serde_json::from_value(serde_json::json!({"Glm53Mhc": {
            "name": "mhc_pre_attn_1", "role": "pre", "backend": "vllm",
            "checkpoint_format": "fp8", "tp_size": 2, "is_context": true,
            "hidden_size": 4096, "hc_mult": 4, "sinkhorn_iters": 20,
        }}))
        .unwrap();
        let mut sparse_op = crate::operators::glm53flash::tests::attention("sparse_mla");
        sparse_op.checkpoint_format = "fp8".into();
        let sparse = Op::Glm53Attention(sparse_op.clone());
        let load_shared = |mode, shared| {
            PerfDatabase::load_resolved(
                root.path(),
                "b200_sxm",
                "vllm",
                RUNTIME,
                shared,
                false,
                false,
            )
            .unwrap()
            .with_mode(mode, TransferPolicy::ALL)
        };
        let load = |mode| load_shared(mode, true);
        for op in [&mhc, &sparse] {
            let error = validate(&load(DatabaseMode::Silicon), [op].into_iter()).unwrap_err();
            assert!(error.to_string().contains("exact runtime"), "{error}");
            // HYBRID stays constructible; its fallbacks are labelled per query.
            validate(&load(DatabaseMode::Hybrid), [op].into_iter()).unwrap();
            validate(&load(DatabaseMode::Sol), [op].into_iter()).unwrap();
        }
        let mhc_table = data.join(format!("mhc/vllm/{RUNTIME}/mhc_module_perf.parquet"));
        std::fs::create_dir_all(mhc_table.parent().unwrap()).unwrap();
        let mhc_rows = |architecture| {
            [
                Col::Str("architecture", vec![architecture; 2]),
                Col::Str("op_name", vec!["pre"; 2]),
                Col::I64("num_tokens", vec![16, 1024]),
                Col::I64("hc_mult", vec![4; 2]),
                Col::I64("hidden_size", vec![4096; 2]),
                Col::F64("latency", vec![0.02, 0.04]),
                Col::Str("kernel_source", vec!["fixture"; 2]),
            ]
        };
        // Same-shape rows from another model are not GLM mHC evidence.
        write_parquet(&mhc_table, &mhc_rows("DeepseekV4ForCausalLM"));
        let error = validate(
            &load_shared(DatabaseMode::Silicon, false),
            [&mhc].into_iter(),
        )
        .unwrap_err();
        assert!(error.to_string().contains("for role pre"), "{error}");
        write_parquet(
            &mhc_table,
            &mhc_rows(crate::operators::glm53flash::MHC_ARCHITECTURE),
        );
        let attention_table = data.join(format!(
            "glm53_attention/vllm/{RUNTIME}/glm53_attention_module_perf.parquet"
        ));
        // A present but invalid GLM attention table fails readiness through
        // the loader's validation instead of passing on row count.
        table(&attention_table);
        let error = validate(
            &load_shared(DatabaseMode::Silicon, false),
            [&sparse].into_iter(),
        )
        .unwrap_err();
        assert!(matches!(error, AicError::InvalidPerfData(_)), "{error}");
        write_parquet(
            &attention_table,
            &crate::perf_database::glm53flash::tests::rows(
                &sparse_op,
                &[(1, 0, 512, 1.0), (1, 0, 4096, 6.0)],
                "n/a",
            ),
        );
        // Valid rows for another geometry do not cover a TP4 or decode op.
        let mut tp4 = sparse_op.clone();
        tp4.tp_size = 4;
        tp4.num_heads = 16;
        let mut decode = sparse_op.clone();
        decode.is_context = false;
        for uncovered in [tp4, decode] {
            let error = validate(
                &load_shared(DatabaseMode::Silicon, false),
                [&Op::Glm53Attention(uncovered)].into_iter(),
            )
            .unwrap_err();
            assert!(
                error.to_string().contains("rows for") && error.to_string().contains("exact"),
                "{error}"
            );
        }
        // The exact tables exist, but the shared layer would merge the
        // earlier runtime's mHC rows into the same reader.
        let error = validate(&load(DatabaseMode::Silicon), [&mhc].into_iter()).unwrap_err();
        assert!(
            error.to_string().contains("enable_shared_layer=False"),
            "{error}"
        );
        validate(
            &load_shared(DatabaseMode::Silicon, false),
            [&mhc, &sparse].into_iter(),
        )
        .unwrap();
        // A GLM boundary without a generic composition cannot be SILICON.
        let bare = Op::Glm53Attention(crate::operators::glm53flash::tests::attention("kda"));
        let error = validate(
            &load_shared(DatabaseMode::Silicon, false),
            [&bare].into_iter(),
        )
        .unwrap_err();
        assert!(
            error
                .to_string()
                .contains("no measured generic composition"),
            "{error}"
        );
    }

    #[test]
    fn glm53_silicon_rejects_shared_layer_rows_from_another_runtime() {
        // Review probe: vLLM 0.31.0 has only a `post` mHC row and 0.30.0 a
        // 14 ms `pre` row with the same (hc_mult, hidden_size) key. With the
        // shared layer on, the generic reader answers GLM `pre` with the
        // borrowed row (7 ms per site, labelled silicon); readiness must
        // refuse that database, and without sharing the lookup must miss.
        use crate::operators::glm53flash::tests::{ctx, mhc_site};
        let root = tempfile::tempdir().unwrap();
        let systems = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../python/aisimulate/src/aisimulate_core/systems");
        std::fs::copy(systems.join("gb300.yaml"), root.path().join("gb300.yaml")).unwrap();
        let data = root.path().join("data/gb300/mhc/vllm");
        for (version, role, latency) in [("0.31.0", "post", 0.03), ("0.30.0", "pre", 14.0)] {
            let dir = data.join(version);
            std::fs::create_dir_all(&dir).unwrap();
            write_parquet(
                &dir.join("mhc_module_perf.parquet"),
                &[
                    Col::Str(
                        "architecture",
                        vec![crate::operators::glm53flash::MHC_ARCHITECTURE; 2],
                    ),
                    Col::Str("op_name", vec![role; 2]),
                    Col::I64("num_tokens", vec![16, 1024]),
                    Col::I64("hc_mult", vec![4; 2]),
                    Col::I64("hidden_size", vec![4096; 2]),
                    Col::F64("latency", vec![latency; 2]),
                    Col::Str("kernel_source", vec!["fixture"; 2]),
                ],
            );
        }
        let load = |shared| {
            PerfDatabase::load_resolved(
                root.path(),
                "gb300",
                "vllm",
                "0.31.0",
                shared,
                false,
                false,
            )
            .unwrap()
            .with_mode(DatabaseMode::Silicon, TransferPolicy::ALL)
        };
        let mut pre = mhc_site("pre");
        pre.backend = "vllm".into();
        let c = ctx(1024, 1, 0, false);
        let shared = load(true);
        let borrowed = pre.query(&shared, &c).unwrap();
        assert_eq!(borrowed.latency_ms, 7.0);
        let op = Op::Glm53Mhc(pre.clone());
        let error = validate(&shared, [&op].into_iter()).unwrap_err();
        assert!(
            error.to_string().contains("enable_shared_layer=False"),
            "{error}"
        );
        assert!(error.to_string().contains("0.30.0"), "{error}");
        let exact = load(false);
        // Without sharing, the exact runtime has no GLM `pre` row: readiness
        // and the lookup both miss.
        let error = validate(&exact, [&op].into_iter()).unwrap_err();
        assert!(error.to_string().contains("for role pre"), "{error}");
        assert!(pre.query(&exact, &c).is_err());
        // Every public entry point (forward-pass model, InferenceSession, CLI)
        // builds its engine through Engine::build, which enforces the same
        // restriction before any query.
        let build = |db: PerfDatabase| {
            let config = serde_json::from_value(serde_json::json!({
                "schema_version": crate::ENGINE_CONFIG_SCHEMA_VERSION,
                "model_name": "glm53-borrowed-mhc", "system_name": "gb300", "backend": "vllm",
                "backend_version": "0.31.0", "tp_size": 2, "pp_size": 1,
                "database_mode": DatabaseMode::Silicon,
            }))
            .unwrap();
            Engine::build(
                EngineSpec::new(config, vec![op.clone()], vec![]),
                Arc::new(db),
            )
        };
        let error = build(load(true)).err().unwrap();
        assert!(
            error.to_string().contains("enable_shared_layer=False"),
            "{error}"
        );
        build(load(false)).unwrap();
        let hybrid = load(true).with_mode(DatabaseMode::Hybrid, TransferPolicy::ALL);
        validate_glm53_sources(&hybrid, [&op].into_iter()).unwrap();
    }

    #[test]
    fn direct_fpm_readiness_requires_genuine_rows_only_for_requested_phases() {
        use crate::perf_database::fpm_forward::tests::{RowSpec, default_identity, write_pair};

        for missing_phase in [FpmPhase::Prefill, FpmPhase::Decode] {
            for fake_only in [false, true] {
                let root = systems();
                let data = root.path().join("data/b200_sxm/vllm/0.25.1");
                std::fs::create_dir_all(&data).unwrap();
                let present_phase = match missing_phase {
                    FpmPhase::Prefill => FpmPhase::Decode,
                    FpmPhase::Decode => FpmPhase::Prefill,
                };
                let row = |phase: FpmPhase, regime| RowSpec {
                    workload_kind: phase.as_str(),
                    total_prefill_tokens: if phase == FpmPhase::Prefill { 8 } else { 0 },
                    kv_seed_regime: Some(regime),
                    ..RowSpec::default()
                };
                let mut rows = vec![row(present_phase, "real_kv")];
                if fake_only {
                    rows.push(row(missing_phase, "fake_fallback"));
                }
                write_pair(&data, &rows);
                let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.25.1").unwrap();
                let op = |phase: FpmPhase| {
                    Op::FpmForward(FpmForwardOp {
                        dcp_size: None,
                        name: format!("fpm_forward_{}", phase.as_str()),
                        phase,
                        model_path: "org/model-a".into(),
                        match_identity: default_identity(4),
                        weight_bytes: 0.0,
                        verify_width: 1,
                        interpolation: FpmInterpolation::Direct,
                        sol_ops: vec![],
                        original_fmha_quant_mode: None,
                    })
                };
                let present = op(present_phase);
                let missing = op(missing_phase);
                // A single-phase operation requires only its own measurements.
                validate(&db, [&present].into_iter()).unwrap();
                for requested in [vec![&missing], vec![&present, &missing]] {
                    let error = validate(&db, requested.into_iter())
                        .unwrap_err()
                        .to_string();
                    assert!(error.contains(missing_phase.as_str()), "{error}");
                    assert!(error.contains("no genuine measurements"), "{error}");
                    assert!(error.contains("Collect genuine"), "{error}");
                    assert!(error.contains(data.to_str().unwrap()), "{error}");
                }
            }
        }
    }

    #[test]
    fn dsv41_stage_requires_measured_module_for_silicon() {
        use crate::operators::dsv41::{Dsv41LinearOp, Dsv41StageOp};
        let root = systems();
        let stage = Op::Dsv41Stage(Dsv41StageOp {
            name: "stage".into(),
            is_context: true,
            decoder_replay: true,
            bounded: true,
            window_size: 128,
            children: vec![Op::Dsv41Linear(Dsv41LinearOp {
                name: "projection".into(),
                n: 16,
                k: 16,
                quant_mode: GemmQuantMode::Fp8Block,
            })],
        });
        for mode in [
            DatabaseMode::Silicon,
            DatabaseMode::Empirical,
            DatabaseMode::Hybrid,
            DatabaseMode::Sol,
            DatabaseMode::SolFull,
        ] {
            let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                .unwrap()
                .with_mode(mode, TransferPolicy::ALL);
            assert_eq!(
                validate(&db, [&stage].into_iter()).is_ok(),
                !matches!(mode, DatabaseMode::Silicon | DatabaseMode::Empirical)
            );
        }
        table(
            &root
                .path()
                .join("data/b200_sxm/vllm/0.24.0/dsv41_module_perf.parquet"),
        );
        let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
            .unwrap()
            .with_mode(DatabaseMode::Silicon, TransferPolicy::ALL);
        assert!(validate(&db, [&stage].into_iter()).is_ok());
    }

    #[test]
    fn dsv4_requires_its_phase_module_not_an_auxiliary_table() {
        for kind in ["Csa", "Hca"] {
            for context in [true, false] {
                let root = systems();
                let data = root.path().join("data/b200_sxm/vllm/0.24.0");
                table(&data.join("dsv4_paged_mqa_logits_module_perf.parquet"));
                let load =
                    || PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0").unwrap();
                let phase = if context { "context" } else { "generation" };
                let required = format!("dsv4_{}_{phase}_module_perf.parquet", kind.to_lowercase());
                let error = engine_readiness(load(), dsv4_op(kind, context, 1)).unwrap_err();
                assert!(error.to_string().contains(&required), "{error}");
                table(&data.join(required));
                engine_readiness(load(), dsv4_op(kind, context, 1)).unwrap();
            }
        }
    }

    #[test]
    fn csa_context_parallel_requires_both_sparse_tables() {
        let mqa = "dsv4_paged_mqa_logits_module_perf.parquet";
        let topk = "dsv4_csa_topk_calib_perf.parquet";
        for mode in [
            DatabaseMode::Silicon,
            DatabaseMode::Hybrid,
            DatabaseMode::Empirical,
            DatabaseMode::Sol,
        ] {
            for present in [vec![], vec![mqa], vec![topk], vec![mqa, topk]] {
                let root = systems();
                let data = root.path().join("data/b200_sxm/vllm/0.24.0");
                if mode != DatabaseMode::Sol {
                    table(&data.join("dsv4_csa_context_module_perf.parquet"));
                    table(&data.join("dsv4_hca_context_module_perf.parquet"));
                }
                for name in &present {
                    table(&data.join(name));
                }
                let load = || {
                    PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                        .unwrap()
                        .with_mode(mode, TransferPolicy::ALL)
                };
                assert_eq!(
                    engine_readiness(load(), dsv4_op("Csa", true, 2)).is_ok(),
                    present.len() == 2,
                    "{mode:?}, {present:?}"
                );
                engine_readiness(load(), dsv4_op("Hca", true, 2)).unwrap();
            }
        }
    }

    #[test]
    fn megamoe_readiness_uses_only_the_resolved_primary() {
        let root = systems();
        let name = "dsv4_megamoe_module_perf.parquet";
        let family = root.path().join("data/b200_sxm/moe/vllm/0.24.0").join(name);
        table(&family);
        let op = || {
            Op::Dsv4MegaMoe(Dsv4MegaMoeOp {
                name: "megamoe".into(),
                scale_factor: 1.0,
                hidden_size: 4096,
                inter_size: 2048,
                topk: 8,
                num_experts: 256,
                moe_tp_size: 1,
                moe_ep_size: 8,
                quant_mode: crate::common::enums::MoeQuantMode::Fp8,
                workload_distribution: "balanced".into(),
                is_context: true,
                source_policy: "primary".into(),
                pre_dispatch: "none".into(),
                num_fused_shared_experts: 0,
                kernel_source: "fixture".into(),
                kernel_dtype: "fp8".into(),
            })
        };
        let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0").unwrap();
        assert_eq!(db.dsv4_megamoe.primary_path(), family);
        engine_readiness(db, op()).unwrap();

        let custom = root.path().join("custom.parquet");
        table(&custom);
        for primary in [&custom, &root.path().join("missing.parquet")] {
            // MegaMoE ignores row filters and additional sources at query time.
            let sources = PerfDbSources::from([(
                name.into(),
                vec![
                    PerfSource(primary.clone(), Some(vec!["excluded".into()])),
                    PerfSource(family.clone(), None),
                ],
            )]);
            let db = PerfDatabase::load_with_sources(
                root.path(),
                "b200_sxm",
                "vllm",
                "0.24.0",
                &sources,
            )
            .unwrap();
            assert_eq!(db.dsv4_megamoe.primary_path(), primary);
            assert_eq!(engine_readiness(db, op()).is_ok(), primary == &custom);
        }
    }

    #[test]
    fn absent_tables_respect_modes_and_composite_fallbacks() {
        let root = systems();
        let gemm = Op::Gemm(GemmOp::new("gemm", 16, 16, GemmQuantMode::Bfloat16));
        for mode in [
            DatabaseMode::Silicon,
            DatabaseMode::Hybrid,
            DatabaseMode::Empirical,
            DatabaseMode::Sol,
        ] {
            let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0")
                .unwrap()
                .with_mode(mode, TransferPolicy::ALL);
            assert_eq!(
                validate(&db, [&gemm].into_iter()).is_ok(),
                mode == DatabaseMode::Sol
            );
            let fallback = Op::Fallback(FallbackOp::new(
                "fallback",
                gemm.clone(),
                vec![Op::Embedding(EmbeddingOp::new(
                    "embedding",
                    16,
                    16,
                    GemmQuantMode::Bfloat16,
                ))],
            ));
            validate(&db, [&fallback].into_iter()).unwrap();
            let overlap = Op::Overlap(OverlapOp::new(
                "overlap",
                vec![fallback],
                vec![gemm.clone()],
            ));
            assert_eq!(
                validate(&db, [&overlap].into_iter()).is_ok(),
                mode == DatabaseMode::Sol
            );
        }
    }

    #[test]
    fn table_presence_honors_source_filters_and_empty_tables() {
        let root = systems();
        let data = root
            .path()
            .join("data/b200_sxm/vllm/0.24.0/gemm_perf.parquet");
        let gemm = Op::Gemm(GemmOp::new("gemm", 16, 16, GemmQuantMode::Bfloat16));
        for rows in [vec![], vec!["allowed"]] {
            write_parquet(&data, &[Col::Str("kernel_source", rows.clone())]);
            for filter in ["allowed", "excluded"] {
                let sources = PerfDbSources::from([(
                    "gemm_perf.parquet".into(),
                    vec![PerfSource(data.clone(), Some(vec![filter.into()]))],
                )]);
                let db = PerfDatabase::load_with_sources(
                    root.path(),
                    "b200_sxm",
                    "vllm",
                    "0.24.0",
                    &sources,
                )
                .unwrap();
                assert_eq!(
                    validate(&db, [&gemm].into_iter()).is_ok(),
                    !rows.is_empty() && filter == "allowed"
                );
            }
        }
    }

    #[test]
    fn moe_readiness_requires_eligible_or_exact_source_rows() {
        use crate::common::enums::MoeQuantMode;
        use crate::operators::MoeOp;

        let root = systems();
        let data = root
            .path()
            .join("data/b200_sxm/vllm/0.24.0/moe_perf.parquet");
        for eligibility in [None, Some(true), Some(false)] {
            let mut columns = vec![
                Col::Str("moe_dtype", vec!["fp8_block"]),
                Col::I64("num_tokens", vec![32]),
                Col::I64("hidden_size", vec![8192]),
                Col::I64("inter_size", vec![2048]),
                Col::I64("topk", vec![8]),
                Col::I64("num_experts", vec![256]),
                Col::I64("moe_tp_size", vec![1]),
                Col::I64("moe_ep_size", vec![1]),
                Col::Str("distribution", vec!["uniform"]),
                Col::Str("kernel_source", vec!["exact"]),
                Col::F64("latency", vec![0.25]),
            ];
            if let Some(eligible) = eligibility {
                columns.push(Col::Bool("default_eligible", vec![eligible]));
            }
            write_parquet(&data, &columns);
            for source in [None, Some("exact")] {
                let db = PerfDatabase::load(root.path(), "b200_sxm", "vllm", "0.24.0").unwrap();
                let mut op = MoeOp::new(
                    "moe",
                    8192,
                    2048,
                    8,
                    256,
                    1,
                    1,
                    MoeQuantMode::Fp8Block,
                    "uniform",
                );
                op.moe_kernel_source = source.map(str::to_owned);
                let expected = source.is_some() || eligibility != Some(false);
                assert_eq!(engine_readiness(db, Op::Moe(op)).is_ok(), expected);
            }
        }
    }
}
