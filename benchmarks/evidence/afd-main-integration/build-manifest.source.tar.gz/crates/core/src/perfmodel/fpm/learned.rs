// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0
// Feature definitions adapted from (re-implemented; no upstream source copied):
// - SGLang simulator `MLTimePredictor.FEATURE_NAMES` (18 batch features),
//   revision 59799a368793b9f795baf59b067233a65ad8e38e,
//   path tools/sglang-simulator/src/sglang_simulator/time_predictor/ml.py,
//   https://github.com/sgl-project/sglang/blob/59799a368793b9f795baf59b067233a65ad8e38e/tools/sglang-simulator/src/sglang_simulator/time_predictor/ml.py,
//   copyright the SGLang project contributors, Apache-2.0.
// - HiSim (Alibaba tair-kvcache) XGBoost predictor (32 present/past/extend slots),
//   revision 85402f1a012fb4279be5bb4b57613bb0a067d361,
//   path hisim/src/hisim/time_predictor/aiconfigurator.py,
//   https://github.com/alibaba/tair-kvcache/blob/85402f1a012fb4279be5bb4b57613bb0a067d361/hisim/src/hisim/time_predictor/aiconfigurator.py,
//   copyright Alibaba Group, Apache-2.0.
// Modified: names, ordering and formulas adapted to AISimulate FPM fields.
// See THIRD_PARTY_NOTICES.md.

//! Learned forward-pass model: an offline-trained tree ensemble over
//! `ForwardPassMetrics` batch-composition features.
//!
//! Training data is the per-iteration FPM telemetry recorded by a real
//! deployment (Dynamo `DYN_FPM_TRACE`), so the model learns the deployed
//! engine's actual step time as a function of the scheduled batch. The
//! artifact is a plain JSON file written by
//! `aisimulate_core.sdk.fpm_learned` (Python, scikit-learn); this module
//! is the pure-Rust inference half so the simulation hot path never re-enters
//! Python.
//!
//! Artifact contract (`schema = "aic_fpm_learned_forward_perf"`, version 1):
//!
//! ```json
//! {
//!   "schema": "aic_fpm_learned_forward_perf",
//!   "schema_version": 1,
//!   "worker_type": "decode",
//!   "target": "log_ms",
//!   "features": ["num_decode_requests", "sum_decode_kv_tokens", "..."],
//!   "stores": {
//!     "pure_decode": {
//!       "baseline": 2.7,
//!       "trees": [{"left": [1, -1, -1], "right": [2, -1, -1], "feature": [0, -1, -1],
//!                  "threshold": [4.5, 0.0, 0.0], "value": [0.0, -0.1, 0.2],
//!                  "missing_left": [true, true, true]}]
//!     }
//!   },
//!   "metadata": {}
//! }
//! ```
//!
//! `features` is the ordered feature ABI: every name must be one of
//! [`feature_names`], and the trainer computes the same named quantities from
//! the same FPM fields (`fpm_learned.compute_features`). Each store is one
//! additive tree ensemble bound to a regression workload kind; a query whose
//! workload kind has no store returns `None`, mirroring an unready regression
//! store. Prediction is `baseline + sum(leaf values)`, exponentiated when
//! `target == "log_ms"`.

use std::collections::BTreeMap;
use std::path::Path;

use serde::{Deserialize, Serialize};

use super::metrics::ForwardPassMetrics;
use super::model::{ForwardPassRegressionWorkloadKind, ForwardPassWorkerType};
use crate::AicError;

pub const LEARNED_SCHEMA_NAME: &str = "aic_fpm_learned_forward_perf";
pub const LEARNED_SCHEMA_VERSION: u32 = 1;

/// Aggregate iteration features derivable from FPM v1 scheduled fields.
///
/// Sums run over all attention-DP ranks; `max_rank_*` and variances take the
/// per-rank maximum, mirroring the "heaviest rank sets the step time"
/// lockstep rule used by the correction path.
pub const AGGREGATE_FEATURE_NAMES: [&str; 21] = [
    "num_active_ranks",
    "num_prefill_requests",
    "sum_prefill_tokens",
    "sum_prefill_kv_tokens",
    "var_prefill_length",
    "num_decode_requests",
    "sum_decode_kv_tokens",
    "var_decode_kv_tokens",
    "max_rank_prefill_tokens",
    "max_rank_decode_kv_tokens",
    "max_rank_num_decode_requests",
    "mean_prefill_chunk",
    "mean_prefill_kv",
    "prefill_attention_pairs",
    "mean_decode_kv",
    "sum_decode_kv_squared",
    "log1p_sum_prefill_tokens",
    "log1p_sum_prefill_kv_tokens",
    "log1p_sum_decode_kv_tokens",
    "log1p_prefill_attention_pairs",
    "log1p_sum_decode_kv_squared",
];

/// Number of `fpm5` features (`fpm_learned.FEATURE_PRESETS["fpm5"]`).
pub(crate) const FPM5_FEATURE_COUNT: usize = 17;

/// Positions of the `fpm5` preset in [`AGGREGATE_FEATURE_NAMES`], in preset
/// order: every aggregate computable from the five FPM v1 counts and sums,
/// dropping `var_prefill_length`, `var_decode_kv_tokens` and the decode sum of
/// squares that is recovered from a variance (and its `log1p`).
pub(crate) const FPM5_AGGREGATE_INDICES: [usize; FPM5_FEATURE_COUNT] =
    [0, 1, 2, 3, 5, 6, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19];

/// Per-request features over the iteration's `(extend, past)` list (all ranks
/// concatenated). These are the 18 features of the SGLang simulator
/// `MLTimePredictor` (`tools/sglang-simulator/.../time_predictor/ml.py`),
/// prefixed `req_`. They are NaN when the producer did not emit
/// `extend_lengths` / `past_kv_lengths`; tree models route NaN through
/// `missing_left`.
pub const REQUEST_FEATURE_NAMES: [&str; 18] = [
    "req_batch_size",
    "req_sum_extend",
    "req_max_extend",
    "req_min_extend",
    "req_sum_past",
    "req_max_past",
    "req_min_past",
    "req_sum_extend_x_past",
    "req_sum_extend_squared",
    "req_sum_past_squared",
    "req_sum_attn_flops",
    "req_sum_extend_x_max_past",
    "req_log1p_sum_past",
    "req_log1p_sum_attn_flops",
    "req_batch_size_x_sum_extend",
    "req_max_past_minus_min_past",
    "req_is_decode",
    "req_is_prefill",
];

/// Number of HiSim-style request slots. Requests are sorted by past KV
/// descending; slot `i` exposes `(present, past, extend)` like the padded
/// `(max_bs, 2)` feature of HiSim's decode XGBoost ratio model
/// (`hisim/time_predictor/aiconfigurator.py::_build_xgb_feature_maxbs_2`),
/// extended with the request's extend length so prefill chunks are covered too.
/// Requests beyond the last slot fold into the aggregate/`req_*` features only.
pub const SLOT_COUNT: usize = 32;

/// Full ordered feature table: aggregates, per-request, then
/// `slot{i}_present`, `slot{i}_past`, `slot{i}_extend` for `i < SLOT_COUNT`.
pub fn feature_names() -> Vec<String> {
    let mut names: Vec<String> = AGGREGATE_FEATURE_NAMES
        .iter()
        .chain(REQUEST_FEATURE_NAMES.iter())
        .map(|name| name.to_string())
        .collect();
    for slot in 0..SLOT_COUNT {
        names.push(format!("slot{slot}_present"));
        names.push(format!("slot{slot}_past"));
        names.push(format!("slot{slot}_extend"));
    }
    names
}

/// Total feature count (`feature_names().len()`).
pub const FEATURE_COUNT: usize =
    AGGREGATE_FEATURE_NAMES.len() + REQUEST_FEATURE_NAMES.len() + 3 * SLOT_COUNT;

fn feature_index(name: &str) -> Option<usize> {
    if let Some(index) = AGGREGATE_FEATURE_NAMES
        .iter()
        .position(|known| *known == name)
    {
        return Some(index);
    }
    if let Some(index) = REQUEST_FEATURE_NAMES
        .iter()
        .position(|known| *known == name)
    {
        return Some(AGGREGATE_FEATURE_NAMES.len() + index);
    }
    let rest = name.strip_prefix("slot")?;
    let (slot, kind) = rest.split_once('_')?;
    let slot: usize = slot.parse().ok()?;
    if slot >= SLOT_COUNT {
        return None;
    }
    let offset = match kind {
        "present" => 0,
        "past" => 1,
        "extend" => 2,
        _ => return None,
    };
    Some(AGGREGATE_FEATURE_NAMES.len() + REQUEST_FEATURE_NAMES.len() + 3 * slot + offset)
}

const MIN_POSITIVE_PREDICTION_MS: f64 = 1e-6;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub(crate) enum LearnedTarget {
    LogMs,
    Ms,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub(crate) struct LearnedTree {
    pub(crate) left: Vec<i32>,
    pub(crate) right: Vec<i32>,
    pub(crate) feature: Vec<i32>,
    pub(crate) threshold: Vec<f64>,
    pub(crate) value: Vec<f64>,
    #[serde(default)]
    pub(crate) missing_left: Vec<bool>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub(crate) struct LearnedStore {
    pub(crate) baseline: f64,
    pub(crate) trees: Vec<LearnedTree>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub(crate) struct LearnedArtifact {
    pub(crate) schema: String,
    pub(crate) schema_version: u32,
    pub(crate) worker_type: ForwardPassWorkerType,
    pub(crate) target: LearnedTarget,
    pub(crate) features: Vec<String>,
    pub(crate) stores: BTreeMap<ForwardPassRegressionWorkloadKind, LearnedStore>,
    #[serde(default)]
    pub(crate) metadata: serde_json::Value,
}

/// Validated, query-ready learned model.
#[derive(Clone, Debug)]
pub(crate) struct LearnedForwardPassModel {
    worker_type: ForwardPassWorkerType,
    target: LearnedTarget,
    feature_indices: Vec<usize>,
    feature_names: Vec<String>,
    stores: BTreeMap<ForwardPassRegressionWorkloadKind, LearnedStore>,
    metadata: serde_json::Value,
}

fn invalid(message: impl Into<String>) -> AicError {
    AicError::InvalidEngineConfig(format!("learned forward-pass model: {}", message.into()))
}

impl LearnedForwardPassModel {
    pub(crate) fn artifact(&self) -> LearnedArtifact {
        LearnedArtifact {
            schema: LEARNED_SCHEMA_NAME.to_owned(),
            schema_version: LEARNED_SCHEMA_VERSION,
            worker_type: self.worker_type,
            target: self.target.clone(),
            features: self.feature_names.clone(),
            stores: self.stores.clone(),
            metadata: self.metadata.clone(),
        }
    }

    pub(crate) fn to_json(&self) -> Result<String, AicError> {
        serde_json::to_string(&self.artifact()).map_err(|e| invalid(e.to_string()))
    }

    pub(crate) fn target(&self) -> LearnedTarget {
        self.target.clone()
    }

    pub(crate) fn store(&self, kind: ForwardPassRegressionWorkloadKind) -> Option<&LearnedStore> {
        self.stores.get(&kind)
    }

    pub(crate) fn replace_store(
        &mut self,
        kind: ForwardPassRegressionWorkloadKind,
        store: LearnedStore,
    ) {
        self.stores.insert(kind, store);
    }

    /// Install a validated, previously absent online store without copying the
    /// existing forests. The caller owns compatibility and duplicate checks.
    pub(crate) fn append_store_from(
        &mut self,
        mut seed: Self,
        kind: ForwardPassRegressionWorkloadKind,
        rows: usize,
    ) {
        self.stores.insert(
            kind,
            seed.stores.remove(&kind).expect("validated appended store"),
        );
        let name = serde_json::to_value(kind).expect("store kind serializes");
        if self.metadata.is_object() {
            if !self.metadata["train_rows"].is_object() {
                self.metadata["train_rows"] = serde_json::json!({});
            }
            self.metadata["train_rows"][name.as_str().expect("store kind string")] = rows.into();
        }
    }

    pub(crate) fn selected_features(&self, features: &IterationFeatureVector) -> Vec<f64> {
        self.feature_indices
            .iter()
            .map(|&i| features.values[i])
            .collect()
    }

    pub(crate) fn from_path(path: &Path) -> Result<Self, AicError> {
        let text = std::fs::read_to_string(path).map_err(|source| AicError::Io {
            path: path.to_path_buf(),
            source,
        })?;
        Self::from_json(&text)
    }

    pub(crate) fn from_json(text: &str) -> Result<Self, AicError> {
        let artifact: LearnedArtifact =
            serde_json::from_str(text).map_err(|e| invalid(format!("invalid JSON: {e}")))?;
        Self::from_artifact(artifact)
    }

    pub(crate) fn from_artifact(artifact: LearnedArtifact) -> Result<Self, AicError> {
        if artifact.schema != LEARNED_SCHEMA_NAME {
            return Err(invalid(format!(
                "schema {:?} != {LEARNED_SCHEMA_NAME:?}",
                artifact.schema
            )));
        }
        if artifact.schema_version != LEARNED_SCHEMA_VERSION {
            return Err(invalid(format!(
                "schema_version {} != {LEARNED_SCHEMA_VERSION}",
                artifact.schema_version
            )));
        }
        if artifact.features.is_empty() {
            return Err(invalid("features list is empty"));
        }
        // Names must be known and unique, which also bounds the list by
        // FEATURE_COUNT, the size of the prediction buffer in `predict_ms`.
        let mut feature_indices = Vec::with_capacity(artifact.features.len());
        for name in &artifact.features {
            let index =
                feature_index(name).ok_or_else(|| invalid(format!("unknown feature {name:?}")))?;
            if feature_indices.contains(&index) {
                return Err(invalid(format!("duplicate feature {name:?}")));
            }
            feature_indices.push(index);
        }
        if artifact.stores.is_empty() {
            return Err(invalid("no stores"));
        }
        let allowed = allowed_workload_kinds(artifact.worker_type);
        for (kind, store) in &artifact.stores {
            if !allowed.contains(kind) {
                return Err(invalid(format!(
                    "store {kind:?} is not valid for worker_type {:?}",
                    artifact.worker_type
                )));
            }
            if !store.baseline.is_finite() {
                return Err(invalid(format!("store {kind:?} baseline is not finite")));
            }
            for (tree_index, tree) in store.trees.iter().enumerate() {
                validate_tree(tree, artifact.features.len())
                    .map_err(|e| invalid(format!("store {kind:?} tree {tree_index}: {e}")))?;
            }
        }
        Ok(Self {
            worker_type: artifact.worker_type,
            target: artifact.target,
            feature_indices,
            feature_names: artifact.features,
            stores: artifact.stores,
            metadata: if artifact.metadata.is_null() {
                serde_json::json!({})
            } else {
                artifact.metadata
            },
        })
    }

    pub(crate) fn worker_type(&self) -> ForwardPassWorkerType {
        self.worker_type
    }

    pub(crate) fn feature_names(&self) -> &[String] {
        &self.feature_names
    }

    pub(crate) fn metadata(&self) -> &serde_json::Value {
        &self.metadata
    }

    pub(crate) fn has_store(&self, kind: ForwardPassRegressionWorkloadKind) -> bool {
        self.stores.contains_key(&kind)
    }

    pub(crate) fn store_kinds(&self) -> Vec<ForwardPassRegressionWorkloadKind> {
        self.stores.keys().copied().collect()
    }

    /// `true` when the artifact reads any HiSim request slot (`slot*`), which is the
    /// only consumer of the sorted per-request list.
    pub(crate) fn needs_slot_features(&self) -> bool {
        self.feature_names
            .iter()
            .any(|name| name.starts_with("slot"))
    }

    /// `true` when the artifact uses any per-request (`req_*`) or slot feature
    /// and therefore needs `extend_lengths` / `past_kv_lengths` on the input.
    pub(crate) fn needs_request_features(&self) -> bool {
        self.feature_names
            .iter()
            .any(|name| name.starts_with("req_") || name.starts_with("slot"))
    }

    /// Prediction in milliseconds; `Ok(None)` when the artifact has no store
    /// for `kind`, `Err` when the trees produce a non-finite value.
    pub(crate) fn predict_ms(
        &self,
        kind: ForwardPassRegressionWorkloadKind,
        features: &IterationFeatureVector,
    ) -> Result<Option<f64>, AicError> {
        let mut buf = [f64::NAN; FEATURE_COUNT];
        for (slot, &index) in self.feature_indices.iter().enumerate() {
            buf[slot] = features.values[index];
        }
        self.predict_selected_ms(kind, &buf[..self.feature_indices.len()])
    }

    /// Prediction from this artifact's already-projected feature ABI. Combined
    /// feedback shares this projection between both experts and the retained row.
    pub(crate) fn predict_selected_ms(
        &self,
        kind: ForwardPassRegressionWorkloadKind,
        x: &[f64],
    ) -> Result<Option<f64>, AicError> {
        debug_assert_eq!(x.len(), self.feature_indices.len());
        let Some(store) = self.stores.get(&kind) else {
            return Ok(None);
        };
        let mut raw = store.baseline;
        for tree in &store.trees {
            raw += tree_leaf_value(tree, x);
        }
        let ms = match self.target {
            LearnedTarget::LogMs => raw.exp(),
            LearnedTarget::Ms => raw,
        };
        if !ms.is_finite() {
            return Err(AicError::InvalidForwardPassMetrics(format!(
                "learned forward-pass prediction for {kind:?} is not finite ({raw} before the link)"
            )));
        }
        Ok(Some(ms.max(MIN_POSITIVE_PREDICTION_MS)))
    }
}

fn allowed_workload_kinds(
    worker_type: ForwardPassWorkerType,
) -> &'static [ForwardPassRegressionWorkloadKind] {
    super::model::workload_kinds_for(worker_type)
}

pub(super) fn validate_tree(tree: &LearnedTree, n_features: usize) -> Result<(), String> {
    let n = tree.value.len();
    if n == 0 {
        return Err("empty tree".to_string());
    }
    if tree.left.len() != n
        || tree.right.len() != n
        || tree.feature.len() != n
        || tree.threshold.len() != n
    {
        return Err("node arrays have mismatched lengths".to_string());
    }
    if !tree.missing_left.is_empty() && tree.missing_left.len() != n {
        return Err("missing_left length mismatch".to_string());
    }
    for i in 0..n {
        let (l, r) = (tree.left[i], tree.right[i]);
        let is_leaf = l < 0 && r < 0;
        if is_leaf {
            if !tree.value[i].is_finite() {
                return Err(format!("leaf {i} value is not finite"));
            }
            continue;
        }
        if l < 0 || r < 0 || l as usize >= n || r as usize >= n {
            return Err(format!("node {i} has out-of-range children ({l}, {r})"));
        }
        if l as usize <= i || r as usize <= i {
            // Children must come after their parent so a forward walk terminates.
            return Err(format!("node {i} children must have larger indices"));
        }
        let f = tree.feature[i];
        if f < 0 || f as usize >= n_features {
            return Err(format!("node {i} feature index {f} out of range"));
        }
        if !tree.threshold[i].is_finite() {
            return Err(format!("node {i} threshold is not finite"));
        }
    }
    Ok(())
}

pub(super) fn tree_leaf_value(tree: &LearnedTree, x: &[f64]) -> f64 {
    let mut node = 0usize;
    loop {
        let left = tree.left[node];
        let right = tree.right[node];
        if left < 0 && right < 0 {
            return tree.value[node];
        }
        let value = x[tree.feature[node] as usize];
        let go_left = if value.is_nan() {
            tree.missing_left.get(node).copied().unwrap_or(true)
        } else {
            value <= tree.threshold[node]
        };
        node = if go_left {
            left as usize
        } else {
            right as usize
        };
    }
}

/// Cross-rank aggregate features of one iteration, in
/// [`AGGREGATE_FEATURE_NAMES`] order. Callers validate the metrics first;
/// ranks with no scheduled work are skipped.
pub(crate) fn aggregate_features(
    metrics_by_rank: &[ForwardPassMetrics],
) -> [f64; AGGREGATE_FEATURE_NAMES.len()] {
    let mut num_active_ranks = 0.0_f64;
    let mut num_prefill = 0.0_f64;
    let mut sum_ptok = 0.0_f64;
    let mut sum_pkv = 0.0_f64;
    let mut var_plen = 0.0_f64;
    let mut num_decode = 0.0_f64;
    let mut sum_dkv = 0.0_f64;
    let mut var_dkv = 0.0_f64;
    let mut max_rank_ptok = 0.0_f64;
    let mut max_rank_dkv = 0.0_f64;
    let mut max_rank_nd = 0.0_f64;
    let mut attention_pairs = 0.0_f64;
    let mut sum_dkv_sq = 0.0_f64;

    for metrics in metrics_by_rank {
        let s = &metrics.scheduled_requests;
        let np = f64::from(s.num_prefill_requests);
        let ptok = f64::from(s.sum_prefill_tokens);
        let pkv = f64::from(s.sum_prefill_kv_tokens);
        let nd = f64::from(s.num_decode_requests);
        let dkv = f64::from(s.sum_decode_kv_tokens);
        let has_prefill = ptok > 0.0;
        let has_decode = nd > 0.0;
        if !has_prefill && !has_decode {
            continue;
        }
        num_active_ranks += 1.0;
        num_prefill += np;
        sum_ptok += ptok;
        sum_pkv += pkv;
        var_plen = var_plen.max(s.var_prefill_length.max(0.0));
        num_decode += nd;
        sum_dkv += dkv;
        var_dkv = var_dkv.max(s.var_decode_kv_tokens.max(0.0));
        max_rank_ptok = max_rank_ptok.max(ptok);
        max_rank_dkv = max_rank_dkv.max(dkv);
        max_rank_nd = max_rank_nd.max(nd);
        if has_prefill && np > 0.0 {
            // Balanced-partition attention proxy: sum over requests of
            // e * (p + (e + 1) / 2) with e = ptok / np and p = pkv / np.
            attention_pairs += pkv * ptok / np + ptok * ptok / (2.0 * np) + ptok / 2.0;
        }
        if has_decode {
            // Recover sum(kv_i^2) from the population variance:
            // n * var + n * mean^2.
            let mean = dkv / nd;
            sum_dkv_sq += nd * s.var_decode_kv_tokens.max(0.0) + nd * mean * mean;
        }
    }

    let mean_prefill_chunk = if num_prefill > 0.0 {
        sum_ptok / num_prefill
    } else {
        0.0
    };
    let mean_prefill_kv = if num_prefill > 0.0 {
        sum_pkv / num_prefill
    } else {
        0.0
    };
    let mean_decode_kv = if num_decode > 0.0 {
        sum_dkv / num_decode
    } else {
        0.0
    };

    [
        num_active_ranks,
        num_prefill,
        sum_ptok,
        sum_pkv,
        var_plen,
        num_decode,
        sum_dkv,
        var_dkv,
        max_rank_ptok,
        max_rank_dkv,
        max_rank_nd,
        mean_prefill_chunk,
        mean_prefill_kv,
        attention_pairs,
        mean_decode_kv,
        sum_dkv_sq,
        sum_ptok.ln_1p(),
        sum_pkv.ln_1p(),
        sum_dkv.ln_1p(),
        attention_pairs.ln_1p(),
        sum_dkv_sq.ln_1p(),
    ]
}

/// The `fpm5` subset of [`aggregate_features`], in preset order.
pub(crate) fn fpm5_features(metrics_by_rank: &[ForwardPassMetrics]) -> [f64; FPM5_FEATURE_COUNT] {
    let aggregate = aggregate_features(metrics_by_rank);
    FPM5_AGGREGATE_INDICES.map(|index| aggregate[index])
}

/// Named feature values for one iteration, indexed like [`feature_names`].
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct IterationFeatureVector {
    pub(crate) values: Vec<f64>,
    /// `true` when every active rank carried aligned, consistent per-request
    /// lists; `false` means the `req_*` features are NaN and the slots empty.
    pub(crate) request_lists: bool,
}

impl IterationFeatureVector {
    #[cfg(test)]
    pub(crate) fn get(&self, name: &str) -> Option<f64> {
        feature_index(name).map(|index| self.values[index])
    }

    /// Compute the named features from one iteration's per-rank FPMs. Callers
    /// validate the metrics first; ranks with no scheduled work are skipped.
    /// Fills the HiSim request slots too (sorted list); see `from_metrics_with`.
    pub(crate) fn from_metrics(metrics_by_rank: &[ForwardPassMetrics]) -> Self {
        Self::from_metrics_with(metrics_by_rank, true)
    }

    /// Same as `from_metrics`, but the per-request list is sorted and copied into
    /// the 32 HiSim slots only when `fill_slots` is set; artifacts that read no
    /// `slot*` feature skip that O(n log n) work. All `req_*` sums are exact
    /// integer arithmetic in f64 for real token counts, so their value does not
    /// depend on the summation order.
    pub(crate) fn from_metrics_with(
        metrics_by_rank: &[ForwardPassMetrics],
        fill_slots: bool,
    ) -> Self {
        let mut values = Vec::with_capacity(FEATURE_COUNT);
        values.extend_from_slice(&aggregate_features(metrics_by_rank));
        // Per-request pairs over all active ranks; `None` when any active rank
        // lacks the lists (mixed producers make per-request features unreliable).
        let mut pairs: Option<Vec<(f64, f64)>> = Some(Vec::new());

        for metrics in metrics_by_rank {
            let s = &metrics.scheduled_requests;
            let ptok = f64::from(s.sum_prefill_tokens);
            let pkv = f64::from(s.sum_prefill_kv_tokens);
            let nd = f64::from(s.num_decode_requests);
            let dkv = f64::from(s.sum_decode_kv_tokens);
            // Same active-rank rule as `aggregate_features`.
            if ptok <= 0.0 && nd <= 0.0 {
                continue;
            }
            // Sanity check on the past-KV total: prefix-cache hits and earlier
            // chunks can only be as large as the aggregates describe. Slack:
            // producers may read `sum_prefill_kv_tokens` after the step
            // (`+ ptok`) and per-request decode lengths one token late
            // (`+ nd`). Extends are not bounded here: speculative decode
            // legitimately extends a decode request by more than one token.
            let past_total: f64 = s.past_kv_lengths.iter().flatten().map(|&p| p as f64).sum();
            let past_consistent = past_total <= pkv + dkv + ptok + nd;
            match (pairs.as_mut(), &s.extend_lengths, &s.past_kv_lengths) {
                (Some(list), Some(extend), Some(past))
                    if !extend.is_empty() && extend.len() == past.len() && past_consistent =>
                {
                    list.extend(
                        extend
                            .iter()
                            .zip(past.iter())
                            .map(|(&e, &p)| (e as f64, p as f64)),
                    );
                }
                _ => pairs = None,
            }
        }

        let request_lists = matches!(&pairs, Some(list) if !list.is_empty());
        match pairs {
            Some(mut list) if !list.is_empty() => {
                if fill_slots {
                    // Sort by past descending, then extend descending (stable slot semantics).
                    list.sort_by(|a, b| {
                        b.1.partial_cmp(&a.1)
                            .unwrap_or(std::cmp::Ordering::Equal)
                            .then(b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal))
                    });
                }
                // One pass for every reduction. Per-request attention proxy is
                // e * (p + e / 2) (the SGLang simulator formula); the aggregate
                // `prefill_attention_pairs` above uses the balanced-partition estimate
                // e * (p + (e + 1) / 2). Both are mirrored byte-for-byte in the Python
                // trainer.
                let n = list.len() as f64;
                let (mut sum_e, mut sum_p, mut sum_ep, mut sum_e2, mut sum_p2, mut sum_attn) =
                    (0.0_f64, 0.0_f64, 0.0_f64, 0.0_f64, 0.0_f64, 0.0_f64);
                let (mut max_e, mut min_e, mut max_p, mut min_p) =
                    (f64::MIN, f64::MAX, f64::MIN, f64::MAX);
                let mut any_extend = false;
                for &(e, p) in &list {
                    sum_e += e;
                    sum_p += p;
                    sum_ep += e * p;
                    sum_e2 += e * e;
                    sum_p2 += p * p;
                    sum_attn += e * (p + e / 2.0);
                    max_e = max_e.max(e);
                    min_e = min_e.min(e);
                    max_p = max_p.max(p);
                    min_p = min_p.min(p);
                    any_extend |= e > 1.0;
                }
                let is_decode = if any_extend { 0.0 } else { 1.0 };
                let is_prefill = if any_extend { 1.0 } else { 0.0 };
                values.extend_from_slice(&[
                    n,
                    sum_e,
                    max_e,
                    min_e,
                    sum_p,
                    max_p,
                    min_p,
                    sum_ep,
                    sum_e2,
                    sum_p2,
                    sum_attn,
                    sum_e * max_p,
                    sum_p.ln_1p(),
                    sum_attn.ln_1p(),
                    n * sum_e,
                    max_p - min_p,
                    is_decode,
                    is_prefill,
                ]);
                if fill_slots {
                    for slot in 0..SLOT_COUNT {
                        match list.get(slot) {
                            Some((e, p)) => values.extend_from_slice(&[1.0, *p, *e]),
                            None => values.extend_from_slice(&[0.0, 0.0, 0.0]),
                        }
                    }
                } else {
                    values.extend(std::iter::repeat_n(0.0, 3 * SLOT_COUNT));
                }
            }
            _ => {
                // Producer emitted no per-request lists: NaN for req_* features
                // (missing-value routing) and empty slots.
                values.extend(std::iter::repeat_n(f64::NAN, REQUEST_FEATURE_NAMES.len()));
                values.extend(std::iter::repeat_n(0.0, 3 * SLOT_COUNT));
            }
        }
        debug_assert_eq!(values.len(), FEATURE_COUNT);
        Self {
            values,
            request_lists,
        }
    }
}

/// Options-independent artifact loader entry used by the model constructors.
pub(crate) fn load_learned(source: &str) -> Result<LearnedForwardPassModel, AicError> {
    let trimmed = source.trim_start();
    if trimmed.starts_with('{') {
        LearnedForwardPassModel::from_json(source)
    } else {
        LearnedForwardPassModel::from_path(Path::new(source))
    }
}
