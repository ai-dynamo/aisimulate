// SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Forward-pass-level performance model with optional online tuning (PR #1152).
//!
//! Built on the compiled [`crate::perfmodel::engine::Engine`]: the `Native` variant holds
//! an `Arc<Engine>` and the native estimate routes through
//! [`crate::perfmodel::engine::Engine::forward_pass_time_ms`]. The online correction /
//! regression / diagnostics / readiness logic is engine-agnostic.
//!
//! Native candidates currently use Python to compile the model into an
//! [`crate::perfmodel::engine::spec::EngineSpec`]. Selection may try several
//! candidates or data roots; after construction the hot path
//! (`estimate_forward_pass_time_ms` / `tune_with_fpms`) is pure Rust over the
//! `Engine` with no Python re-entry.
//!
//! Submodules:
//! - [`metrics`]: the `ForwardPassMetrics` telemetry types and validation.
//! - [`model`]: the public [`ForwardPassPerfModel`] and its diagnostics.
//! - [`correction`]: the native online-correction grid.
//! - [`regression`]: the regression fallback.
//! - [`learned`]: offline-trained tree-ensemble model over FPM features.
//! - [`samples`]: shared bucketed-sample infrastructure.
//! - [`options`]: tuning controls.
//! - [`snapshot`]: the on-disk state snapshot format.

mod config;
mod correction;
pub(crate) mod coverage;
mod dynamic_correction;
mod estimator;
mod evidence;
mod execution;
mod learned;
mod learned_online;
mod metrics;
mod model;
mod options;
mod quality_gate;
mod regression;
mod resources;
mod samples;
mod selector;
mod snapshot;
mod speculative;

#[cfg(test)]
mod tests;

pub use config::{
    DeploymentLimit, DeploymentLimits, EstimationMode, ForwardPassFallbackPolicy,
    ForwardPassPerfModelConfig, ForwardPassSpeculationConfig, UNKNOWN_IDENTITY, UNKNOWN_SIZE,
};
#[cfg(feature = "python")]
pub(crate) use config::{identity_optional_size, identity_size};
pub use coverage::{FpmQueryCoverage, FpmQueryCoverageCounts, FpmQueryGap, FpmQueryPurpose};
pub use estimator::*;
pub(crate) use evidence::accumulate_fpm_estimates;
pub use evidence::*;
pub use execution::{
    FPM_SPECULATIVE_ROUND_PREFIX, FpmExecutionBinding, FpmExecutionKind, FpmExecutionProfile,
    FpmSpeculativeMethod, FpmTimingScope,
};
pub use learned::LEARNED_SCHEMA_VERSION;
#[cfg(feature = "python")]
pub(crate) use learned_online::canonical_learned_identity;
pub(crate) use metrics::validate_forward_pass_metrics;
pub use metrics::{FPM_VERSION, ForwardPassMetrics, QueuedRequestMetrics, ScheduledRequestMetrics};
#[cfg(feature = "python")]
pub(crate) use model::NativeIterationEstimate;
pub use model::{
    ForwardPassCorrectionLimits, ForwardPassCorrectionQueryType, ForwardPassCorrectionReadiness,
    ForwardPassDeploymentTopology, ForwardPassPerfDiagnostics, ForwardPassPerfModel,
    ForwardPassPerfProvenance, ForwardPassPerfReadiness, ForwardPassPerfSource,
    ForwardPassReadinessReport, ForwardPassRegressionStoreDiagnostics,
    ForwardPassRegressionWorkloadKind, ForwardPassStateSnapshotSummary,
    ForwardPassStoreNotReadyReason, ForwardPassStoreReadiness, ForwardPassWorkerType,
    StateSnapshotOptions,
};
pub use options::{CorrectionMode, ForwardPassPerfOptions};
pub use regression::ForwardPassSplineDiagnostics;
pub use resources::{
    FpmCacheBudget, FpmCacheBudgetAdjusted, FpmCacheBudgetRequest, FpmCacheGroup, FpmCacheKind,
    FpmCacheLayout, FpmMambaCacheMode, FpmResourceConfig, FpmRuntimeMemoryConfig,
};
pub use snapshot::{STATE_SNAPSHOT_LAYOUT_VERSION, StateSnapshotKind};
pub use speculative::SpeculativeForwardPassEstimate;
