// SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Operator primitives: GEMM, attention, MLA, MoE, communication, elementwise,
//! embedding, overlap. Submodules each define a focused op type that holds
//! its config-time parameters and exposes a `query` method against
//! `PerfDatabase`.
//!
//! Each operator wraps the raw `perf_database/<family>.rs` table with
//! op-specific extras: SOL/EMPIRICAL/HYBRID database-mode dispatch, prefix
//! correction, fused-op accounting (rope/kv-write/qk-norm for attention),
//! and bandwidth scaling for collectives. The perf-DB layer stays
//! algorithm-free; this layer is where Python's `_query_*_table` static
//! methods live.

pub mod afd_comm;
pub mod attention;
pub mod base;
pub mod communication;
pub mod dsa;
pub mod dsv4;
pub mod dsv41;
pub mod elementwise;
pub mod embedding;
pub mod fpm_forward;
pub(crate) mod fpm_sol;
pub mod gemm;
pub mod mamba;
pub mod measured_composite;
pub mod mhc;
pub mod mla;
pub mod moe;
pub mod moe_a2a;
pub mod moe_dispatch;
pub mod moe_expert_compute;
mod moe_ll_monte_carlo;
pub mod msa;
pub mod op;
pub mod overlap;
pub mod util_empirical;
pub mod vision;
pub mod wideep_mla;

pub use afd_comm::{AfdCombineOp, AfdFCollectiveOp, AfdRankMapping, AfdTransferOp};
pub use attention::{ContextAttentionOp, EncoderAttentionOp, GenerationAttentionOp};
pub use base::{PerformanceResult, Source};
pub use communication::{CustomAllReduceOp, NcclOp, P2POp};
pub use dsa::DsaModuleOp;
pub use dsv4::{Dsv4MegaMoeOp, Dsv4ModuleOp};
pub use dsv41::{Dsv41AttentionOp, Dsv41EngramOp, Dsv41LinearOp, Dsv41MhcOp, Dsv41StageOp};
pub use elementwise::ElementwiseOp;
pub use embedding::EmbeddingOp;
pub use fpm_forward::{FpmForwardOp, FpmPhase};
pub use gemm::GemmOp;
pub use mamba::{GdnOp, KdaOp, Mamba2Op};
pub use mhc::MhcModuleOp;
pub use mla::{ContextMlaOp, GenerationMlaOp, MlaBmmOp, MlaModuleOp};
pub use moe::MoeOp;
pub use moe_a2a::MoeAllToAllOp;
#[allow(unused_imports)]
pub use moe_dispatch::{DispatchFlavor, MoEDispatchOp};
pub use moe_expert_compute::MoeExpertComputeOp;
pub use msa::MsaModuleOp;
#[allow(unused_imports)]
pub use op::{FallbackOp, Op, OverlapOp, RuntimeContext};
pub use vision::VisionEncoderOp;
pub use wideep_mla::{WideEpContextMlaOp, WideEpGenerationMlaOp};

pub mod glm53flash;
pub use glm53flash::{Glm53AttentionOp, Glm53FfnOp, Glm53MhcOp, Glm53PrimitiveOp, Glm53RouterOp};
