// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Self-authored request-boundary fixtures. These test logical snapshot state;
//! the sibling replay suite qualifies physical cache reuse in native engines.

use std::collections::BTreeMap;
use std::sync::Arc;

use super::*;

fn row(id: &str, conversation: &str, start: f64, duration: Option<f64>) -> AgenticMooncakeRow {
    AgenticMooncakeRow {
        request_id: id.into(),
        play_id: "play".into(),
        session_id: conversation.into(),
        model: "model".into(),
        input_length: Some(128),
        output_length: Some(3),
        hash_ids: Some(vec![10, 20]),
        not_before_ms: start,
        recorded_api_time_ms: duration,
        ..Default::default()
    }
}

fn edge(
    source: &str,
    relation: AgenticDependencyRelation,
    trigger: AgenticDependencyTrigger,
    delay: f64,
) -> AgenticDependency {
    AgenticDependency {
        request_id: source.into(),
        relation,
        trigger,
        delay_ms: delay,
    }
}

fn graph(rows: Vec<AgenticMooncakeRow>) -> ValidatedAgenticGraph {
    ValidatedAgenticGraph::from_agentic_mooncake_rows(
        AgenticMooncakeHeader {
            schema: AGENTIC_MOONCAKE_SCHEMA.into(),
            version: AGENTIC_MOONCAKE_VERSION,
            block_size: 64,
            hash_id_scope: AgenticHashIdScope::Local,
            source: AgenticSourceProvenance {
                format: "self-authored-test".into(),
                digest: "snapshot-fixture-v1".into(),
            },
        },
        rows,
    )
    .unwrap()
}

fn boundary_graph() -> ValidatedAgenticGraph {
    use AgenticDependencyRelation::{Sequence, Spawn};
    use AgenticDependencyTrigger::{Completion, Dispatch};
    let root = row("root", "main", 0.0, Some(120.0));
    let mut child = row("child", "worker", 20.0, Some(80.0));
    child.dependencies = vec![edge("root", Spawn, Dispatch, 20.0)];
    let mut background = row("background", "finished-conversation", 80.0, Some(500.0));
    background.dependencies = vec![edge("root", Spawn, Dispatch, 80.0)];
    let mut boundary = row("at-cut", "main", 100.0, Some(40.0));
    boundary.dependencies = vec![edge("root", Sequence, Completion, 10.0)];
    let mut child_next = row("child-next", "worker", 140.0, Some(20.0));
    child_next.dependencies = vec![edge("child", Sequence, Completion, 10.0)];
    let mut future = row("future", "main", 160.0, None);
    future.dependencies = vec![edge("at-cut", Sequence, Completion, 20.0)];
    graph(vec![root, child, background, boundary, child_next, future])
}

#[test]
fn conversation_lineage_survives_history_and_later_turns_with_fresh_play_namespaces() {
    use AgenticDependencyRelation::{Sequence, Spawn};
    use AgenticDependencyTrigger::{Completion, Dispatch};
    let root = row("root", "main", 0.0, Some(10.0));
    let mut child = row("child", "worker", 10.0, Some(10.0));
    child.dependencies = vec![edge("root", Spawn, Dispatch, 10.0)];
    let mut later = row("later", "worker", 30.0, Some(10.0));
    later.dependencies = vec![edge("child", Sequence, Completion, 10.0)];
    let mut nested = row("nested", "grandchild", 40.0, Some(10.0));
    nested.dependencies = vec![edge("later", Spawn, Dispatch, 10.0)];
    let graph = graph(vec![root, child, later, nested]);
    let snapshot = prepare(&graph, 25.0);
    assert!(request(&snapshot, "root").historical);
    assert!(request(&snapshot, "child").historical);
    let root = snapshot.identity("root").unwrap();
    let child = snapshot.identity("child").unwrap();
    let later = snapshot.identity("later").unwrap();
    let nested = snapshot.identity("nested").unwrap();
    assert_eq!(later.parent_id, None); // Legacy request-edge semantics stay intact.
    assert_eq!(later.lineage, child.lineage);
    assert_eq!(child.parent_id.as_deref(), Some(root.request_id.as_str()));
    let lineage = nested.lineage.as_ref().unwrap();
    assert_eq!(
        lineage.parent_conversation_id.as_deref(),
        Some(child.conversation_id.as_str())
    );
    assert_eq!(lineage.root_conversation_id, root.conversation_id);
    assert_ne!(lineage.root_conversation_id, root.request_id);
    let next = snapshot.context().prepare_play_from_start(0, 1).unwrap();
    assert_ne!(next.identity("nested").unwrap().lineage, nested.lineage);
    assert_eq!(
        next.identity("nested")
            .unwrap()
            .lineage
            .unwrap()
            .parent_conversation_id,
        Some(next.identity("child").unwrap().conversation_id)
    );
}

#[test]
fn ambiguous_conversation_parent_does_not_invent_a_routing_tree() {
    use AgenticDependencyRelation::Spawn;
    use AgenticDependencyTrigger::Dispatch;
    let a = row("a", "parent-a", 0.0, Some(10.0));
    let b = row("b", "parent-b", 0.0, Some(10.0));
    let mut child = row("child", "child", 20.0, Some(10.0));
    child.dependencies = vec![
        edge("a", Spawn, Dispatch, 20.0),
        edge("b", Spawn, Dispatch, 20.0),
    ];
    let mut nested = row("nested", "nested", 30.0, Some(10.0));
    nested.dependencies = vec![edge("child", Spawn, Dispatch, 10.0)];
    let graph = graph(vec![a, b, child, nested]);
    let snapshot = prepare(&graph, 0.0);
    assert!(snapshot.identity("child").unwrap().lineage.is_none());
    assert!(snapshot.identity("nested").unwrap().lineage.is_none());
}

fn request<'a>(play: &'a AgenticPlaySnapshot, source: &str) -> &'a AgenticSnapshotRequest {
    play.evidence()
        .requests
        .iter()
        .find(|request| request.source_request_id == source)
        .unwrap()
}

fn prepare(graph: &ValidatedAgenticGraph, cut: f64) -> AgenticPlaySnapshot {
    graph
        .prepare_snapshots(1, AgenticSnapshotOptions::seeded(42))
        .unwrap()
        .context()
        .prepare_play(0, 0, Some(cut))
        .unwrap()
}

fn drain(mut driver: WorkloadDriver) -> BTreeMap<String, ReadyTurn> {
    let mut requests = BTreeMap::new();
    while !driver.is_drained() {
        let now = driver
            .next_ready_time_ms()
            .expect("fixture must have a future wakeup");
        let ready = driver.pop_ready(now, usize::MAX);
        assert!(!ready.is_empty());
        for ready in ready {
            driver.on_complete(ready.request_uuid, now).unwrap();
            requests.insert(ready.authored_request_id.clone().unwrap(), ready);
        }
    }
    requests
}

#[test]
fn full_play_start_handles_nonzero_source_clocks_without_changing_absolute_cuts() {
    let root = row("root", "main", 10_000.0, Some(250.0));
    let mut next = row("next", "main", 11_000.0, Some(250.0));
    next.dependencies = vec![edge(
        "root",
        AgenticDependencyRelation::Sequence,
        AgenticDependencyTrigger::Completion,
        750.0,
    )];
    let mut earlier_play = row("other-play", "other", 1_000.0, None);
    earlier_play.play_id = "earlier-play".into();
    let mooncake = graph(vec![earlier_play, root, next]);

    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("nonzero-origin.json");
    std::fs::write(
        &path,
        serde_json::to_vec(&serde_json::json!({
            "id": "nonzero-origin", "models": ["model"],
            "block_size": 64, "hash_id_scope": "local",
            "requests": [
                {"t": 10, "type": "s", "model": "model", "in": 128,
                 "out": 3, "api_time": 0.25, "hash_ids": [10, 20]},
                {"t": 11, "type": "s", "model": "model", "in": 192,
                 "out": 3, "api_time": 0.25, "hash_ids": [10, 20, 30]}
            ]
        }))
        .unwrap(),
    )
    .unwrap();
    let weka = load_weka_agentic_graph(&path, Some(64)).unwrap();

    // Weka normalizes its nonzero source clock; Mooncake retains absolute starts.
    for (graph, first_ms) in [(mooncake, 10_000.0), (weka, 0.0)] {
        let prepared = graph
            .prepare_snapshots(1, AgenticSnapshotOptions::seeded(42))
            .unwrap();
        let context = prepared.context();
        let play = context.prepare_play_from_start(0, 1).unwrap();
        assert_eq!(play.evidence().t_star_ms, first_ms);
        assert_eq!(play.evidence().requests.len(), 2);
        assert!(play.evidence().requests.iter().all(|r| !r.historical));
        assert!(play.evidence().primers.is_empty());
        assert_eq!(
            play.evidence(),
            context
                .prepare_play(0, 1, Some(first_ms))
                .unwrap()
                .evidence()
        );
        assert_eq!(
            context
                .prepare_play(0, 1, Some(first_ms + 500.0))
                .unwrap()
                .evidence()
                .requests
                .iter()
                .filter(|r| r.historical)
                .count(),
            1
        );
        if first_ms > 0.0 {
            assert!(context.prepare_play(0, 1, Some(0.0)).is_err());
        }

        let mut driver = WorkloadDriver::new_agentic_snapshots(
            PreparedAgenticSnapshots::from_plays(vec![play]).unwrap(),
            64,
            true,
            2.0,
        )
        .unwrap();
        assert_eq!(driver.total_turns(), 2);
        assert_eq!(driver.next_ready_time_ms(), Some(0.0));
        let root = driver.pop_ready(0.0, usize::MAX);
        assert_eq!(root.len(), 1);
        assert!(driver.pop_ready(500.0, usize::MAX).is_empty());
        driver.on_complete(root[0].request_uuid, 600.0).unwrap();
        // Live completion plus the scaled edge delay controls the second turn.
        assert_eq!(driver.next_ready_time_ms(), Some(975.0));
        assert!(driver.pop_ready(974.0, usize::MAX).is_empty());
        let next = driver.pop_ready(975.0, usize::MAX);
        assert_eq!(next.len(), 1);
        driver.on_complete(next[0].request_uuid, 980.0).unwrap();
        assert!(driver.is_drained());
    }
}

#[test]
fn exact_cut_preserves_active_history_and_original_identity_with_residual_timers() {
    let graph = boundary_graph();
    let play = prepare(&graph, 100.0);
    assert_eq!(play.evidence().graph, graph.identity());
    assert_eq!(play.evidence().t_star_ms, 100.0);
    assert!(request(&play, "root").historical);
    assert_eq!(request(&play, "root").recorded_end_ms, Some(120.0));
    assert!(request(&play, "background").historical);
    assert_eq!(request(&play, "background").recorded_end_ms, Some(580.0));
    assert!(!request(&play, "at-cut").historical);
    assert_eq!(request(&play, "at-cut").remaining_delay_ms, 30.0);
    assert!(request(&play, "at-cut").pending_dependencies.is_empty());
    assert_eq!(request(&play, "child-next").remaining_delay_ms, 40.0);
    assert_eq!(request(&play, "future").remaining_delay_ms, 60.0);
    assert_eq!(
        request(&play, "future").pending_dependencies,
        vec![play.identity("at-cut").unwrap().request_id]
    );
    let mut primers = play
        .evidence()
        .primers
        .iter()
        .map(|primer| primer.source_request_id.as_str())
        .collect::<Vec<_>>();
    primers.sort_unstable();
    assert_eq!(primers, ["child", "root"]);
    assert!(
        play.evidence()
            .primers
            .iter()
            .all(|primer| primer.input_length == 128)
    );
    let root_id = play.identity("root").unwrap().request_id;
    assert_eq!(
        play.identity("child").unwrap().parent_id.as_deref(),
        Some(root_id.as_str())
    );
    assert_eq!(
        play.identity("future").unwrap().root_id.as_deref(),
        Some(root_id.as_str())
    );
    let turn_zero = play.context().prepare_play(0, 0, Some(0.0)).unwrap();
    assert!(Arc::ptr_eq(play.context(), turn_zero.context()));
    for node in graph.nodes() {
        assert_eq!(
            play.identity(node.request_id()).unwrap(),
            turn_zero.identity(node.request_id()).unwrap()
        );
    }
}

#[test]
fn snapshot_driver_scales_timers_and_waits_for_actual_live_completion() {
    let graph = boundary_graph();
    let play = prepare(&graph, 100.0);
    let expected_evidence = play.evidence().clone();
    let mut driver = WorkloadDriver::new_agentic_snapshots(
        PreparedAgenticSnapshots::from_plays(vec![play.clone()]).unwrap(),
        48,
        true,
        2.0,
    )
    .unwrap();
    assert_eq!(driver.total_turns(), 3);
    assert_eq!(
        driver.agentic_snapshot_evidence(),
        Some(std::slice::from_ref(&expected_evidence))
    );
    assert_eq!(driver.next_ready_time_ms(), Some(15.0));
    assert!(driver.pop_ready(14.0, usize::MAX).is_empty());
    let mut ready = driver.pop_ready_compact(15.0, usize::MAX);
    assert_eq!(ready.len(), 1);
    let first = ready.pop().unwrap();
    assert_eq!(first.authored_request_id.as_deref(), Some("at-cut"));
    assert!(first.request.materialized_tokens().is_none());
    assert_eq!(
        first
            .request
            .metadata()
            .replay_context
            .as_ref()
            .unwrap()
            .agentic,
        Some(play.identity("at-cut").unwrap())
    );
    assert_eq!(
        first.replay_hashes,
        Some(ReplayRequestHashes::from_tokens(
            &play.materialize_prefix("at-cut", 128).unwrap(),
            48,
        ))
    );
    assert_eq!(driver.next_ready_time_ms(), Some(20.0));
    let child = driver.pop_ready(20.0, usize::MAX).pop().unwrap();
    assert_eq!(child.authored_request_id.as_deref(), Some("child-next"));
    driver.on_complete(child.request_uuid, 25.0).unwrap();
    // The recorded completion was 140 ms, but the live executor completes at
    // 35 ms: its 20 / 2 ms edge delay releases the dependent at 45 ms.
    driver.on_complete(first.request_uuid, 35.0).unwrap();
    assert_eq!(driver.next_ready_time_ms(), Some(45.0));
    assert!(driver.pop_ready(44.0, usize::MAX).is_empty());
    let future = driver.pop_ready(45.0, usize::MAX).pop().unwrap();
    assert_eq!(future.authored_request_id.as_deref(), Some("future"));
    driver.on_complete(future.request_uuid, 50.0).unwrap();
    assert!(driver.is_drained());
    let transcript = driver.agentic_lifecycle_transcript().unwrap();
    let dispatched = transcript
        .events
        .iter()
        .filter(|event| event.event == AgenticLifecycleEventKind::Dispatch)
        .collect::<Vec<_>>();
    assert_eq!(dispatched.len(), 3);
    assert_eq!(
        dispatched
            .iter()
            .map(|event| event.at_ms)
            .collect::<Vec<_>>(),
        [15.0, 20.0, 45.0]
    );
}

#[test]
fn primer_uses_chronological_predecessor_not_lexicographic_request_order() {
    let mut rows = Vec::new();
    for (index, start, previous) in [
        (0, 0.0, None),
        (2, 20.0, Some(0)),
        (10, 100.0, Some(2)),
        (11, 110.0, Some(10)),
    ] {
        let mut next = row(&format!("outer:{index}"), "main", start, Some(1.0));
        if let Some(previous) = previous {
            next.dependencies.push(edge(
                &format!("outer:{previous}"),
                AgenticDependencyRelation::Sequence,
                AgenticDependencyTrigger::Completion,
                0.0,
            ));
        }
        rows.push(next);
    }
    let graph = graph(rows);
    assert_eq!(
        graph
            .nodes()
            .iter()
            .map(AgenticNode::request_id)
            .collect::<Vec<_>>(),
        ["outer:0", "outer:10", "outer:11", "outer:2"]
    );
    let play = prepare(&graph, 105.0);
    assert_eq!(play.evidence().primers.len(), 1);
    assert_eq!(play.evidence().primers[0].source_request_id, "outer:10");
    assert_eq!(
        play.evidence().primers[0].request_id,
        play.identity("outer:10").unwrap().request_id
    );
}

#[test]
fn equal_timestamp_primer_follows_sequence_dependency_order() {
    let root = row("outer:0", "main", 0.0, Some(0.0));
    let mut predecessor = row("outer:2", "main", 10.0, Some(0.0));
    predecessor.dependencies.push(edge(
        "outer:0",
        AgenticDependencyRelation::Sequence,
        AgenticDependencyTrigger::Completion,
        0.0,
    ));
    let mut latest = row("outer:10", "main", 10.0, Some(0.0));
    latest.dependencies.push(edge(
        "outer:2",
        AgenticDependencyRelation::Sequence,
        AgenticDependencyTrigger::Completion,
        0.0,
    ));
    let mut future = row("outer:11", "main", 20.0, Some(0.0));
    future.dependencies.push(edge(
        "outer:10",
        AgenticDependencyRelation::Sequence,
        AgenticDependencyTrigger::Completion,
        0.0,
    ));
    let graph = graph(vec![root, predecessor, latest, future]);
    let play = prepare(&graph, 15.0);
    assert_eq!(play.evidence().primers.len(), 1);
    assert_eq!(play.evidence().primers[0].source_request_id, "outer:10");
}

fn cycle_graph() -> ValidatedAgenticGraph {
    let mut rows = Vec::new();
    for play in ["a", "b"] {
        for (index, start) in [(0, 0.0), (1, 100.0)] {
            let mut request = row(&format!("{play}{index}"), play, start, Some(1.0));
            request.play_id = play.into();
            request.input_length = Some(64);
            request.hash_ids = Some(vec![10 + index]);
            rows.push(request);
        }
    }
    graph(rows)
}

#[test]
fn seeded_snapshots_are_repeatable_and_cycle_lanes_without_completion_order() {
    let graph = cycle_graph();
    let first = graph
        .prepare_snapshots(3, AgenticSnapshotOptions::seeded(42))
        .unwrap();
    let second = graph
        .prepare_snapshots(3, AgenticSnapshotOptions::seeded(42))
        .unwrap();
    assert_eq!(
        serde_json::to_vec(first.snapshots()).unwrap(),
        serde_json::to_vec(second.snapshots()).unwrap()
    );
    assert_eq!(
        first
            .snapshots()
            .iter()
            .map(|snapshot| snapshot.source_play_id.as_str())
            .collect::<Vec<_>>(),
        ["a", "b", "a"]
    );
    assert!(
        first
            .snapshots()
            .iter()
            .all(|snapshot| (25.0..75.0).contains(&snapshot.t_star_ms))
    );
    let changed = graph
        .prepare_snapshots(3, AgenticSnapshotOptions::seeded(43))
        .unwrap();
    assert_ne!(
        first.snapshots()[0].t_star_ms,
        changed.snapshots()[0].t_star_ms
    );
    let context = first.context();
    let late_first = context.prepare_play(2, 1, Some(0.0)).unwrap();
    let early_second = context.prepare_play(0, 1, Some(0.0)).unwrap();
    assert_eq!(
        late_first.evidence(),
        context.prepare_play(2, 1, Some(0.0)).unwrap().evidence()
    );
    assert_eq!(early_second.evidence().source_play_id, "b");
    assert_eq!(late_first.evidence().source_play_id, "b");
    assert_eq!(early_second.materialize_prefix("b0", 1).unwrap(), [6]);
    assert_eq!(late_first.materialize_prefix("b0", 1).unwrap(), [10]);
    assert_ne!(
        late_first.identity("b0").unwrap().cache_id,
        early_second.identity("b0").unwrap().cache_id
    );
    assert_eq!(
        first
            .snapshots()
            .iter()
            .map(|snapshot| snapshot.t_star_ms.to_bits())
            .collect::<Vec<_>>(),
        [
            4631854218153394059,
            4634544125269611050,
            4632905092361953415
        ],
        "versioned seed sampling must retain its exact binary64 cuts"
    );
}

#[test]
fn single_start_and_missing_or_zero_api_duration_preserve_provenance() {
    let single = graph(vec![row("only", "main", 0.0, None)]);
    let prepared = single
        .prepare_snapshots(2, AgenticSnapshotOptions::seeded(3))
        .unwrap();
    for snapshot in prepared.snapshots() {
        assert_eq!(snapshot.t_star_ms, 0.0);
        assert!(!snapshot.requests[0].historical);
        assert_eq!(snapshot.requests[0].recorded_end_ms, None);
        assert!(snapshot.primers.is_empty());
    }
    for duration in [None, Some(0.0)] {
        let predecessor = row("before", "main", 0.0, duration);
        let mut after = row("after", "main", 100.0, None);
        after.dependencies.push(edge(
            "before",
            AgenticDependencyRelation::Sequence,
            AgenticDependencyTrigger::Completion,
            150.0,
        ));
        let graph = graph(vec![predecessor, after]);
        let play = prepare(&graph, 50.0);
        assert_eq!(request(&play, "before").recorded_end_ms, duration);
        assert_eq!(request(&play, "after").remaining_delay_ms, 100.0);
    }
}

// Sampling oracle: the unmodified _seed_for_trace_lane and
// TrajectorySource._build_timestamped_trajectory methods in
// SemiAnalysisAI/aiperf@754356e9a39acc6cc6afb242d123bb57c3fb6f75,
// src/aiperf/timing/trajectory_source.py (Apache-2.0; NVIDIA copyright).
// These expected results were generated by executing those methods with
// NumPy, seed 42, request-start bounds [0, 100], and range [0.25, 0.75].
#[test]
fn imported_reference_cuts_preserve_lane_frontiers_and_corpus_cursor() {
    let graph = cycle_graph();
    let options: AgenticSnapshotOptions = serde_json::from_value(serde_json::json!({
        "seed": 42,
        "initial_selections": [
            {"source_play_id": "a", "t_star_ms": 40.56078627883167},
            {"source_play_id": "b", "t_star_ms": 61.46074327942309},
            {"source_play_id": "a", "t_star_ms": 32.230547630728225}
        ],
        "corpus_cursor": 3
    }))
    .unwrap();
    let prepared = graph.prepare_snapshots(3, options.clone()).unwrap();
    for (actual, selected) in prepared
        .snapshots()
        .iter()
        .zip(options.initial_selections.unwrap())
    {
        assert_eq!(actual.source_play_id, selected.source_play_id);
        assert_eq!(actual.t_star_ms.to_bits(), selected.t_star_ms.to_bits());
        assert!(
            actual
                .requests
                .iter()
                .all(|request| request.historical
                    == (request.recorded_start_ms < selected.t_star_ms))
        );
    }
    let context = prepared.context();
    assert_eq!(context.initial_corpus_cursor(), 3);
    // Reference recycling uses the SAME sequential sampler and starts at turn
    // zero: it does not draw a new randomized cut when a lane is reused.
    let recycled = context
        .prepare_source_play_from_start(
            (context.initial_corpus_cursor() % context.source_play_count() as u64) as usize,
            0,
            1,
        )
        .unwrap();
    assert_eq!(recycled.evidence().source_play_id, "b");
    assert_eq!(recycled.evidence().t_star_ms, 0.0);
    assert!(
        recycled
            .evidence()
            .requests
            .iter()
            .all(|request| !request.historical)
    );
    assert_ne!(
        recycled.evidence().cache_id,
        prepared.snapshots()[0].cache_id
    );
    // A recorded skipped draw must survive preparation rather than resetting
    // the shared cursor to lane count.
    let options = serde_json::from_value(serde_json::json!({
        "seed": 42,
        "initial_selections": [{"source_play_id": "b", "t_star_ms": 100.0}],
        "corpus_cursor": 4
    }))
    .unwrap();
    let prepared = graph.prepare_snapshots(1, options).unwrap();
    assert_eq!(prepared.context().initial_corpus_cursor(), 4);
    let mut driver = WorkloadDriver::new_agentic_snapshots(prepared, 64, true, 1.0).unwrap();
    driver
        .enable_agentic_profile(AgenticProfileOptions::default())
        .unwrap();
    let first = driver.pop_ready(0.0, 1).pop().unwrap();
    assert_eq!(first.authored_request_id.as_deref(), Some("b1"));
    driver
        .on_terminal(
            first.request_uuid,
            1.0,
            crate::replay::ReplayTerminalStatus::Completed,
        )
        .unwrap();
    assert!(driver.advance_agentic_profile(1.0).unwrap());
    let next = driver.pop_ready(1.0, 1).pop().unwrap();
    assert_eq!(next.authored_request_id.as_deref(), Some("a0"));
    assert_eq!(driver.agentic_profile_report().unwrap().corpus_cursor, 5);
    assert_ne!(first.request_uuid, next.request_uuid);
}

#[test]
fn imported_snapshot_selection_is_strict_and_never_falls_back_to_sampling() {
    let graph = cycle_graph();
    let valid = serde_json::json!({
        "seed": 42,
        "initial_selections": [{"source_play_id": "a", "t_star_ms": 50.0}],
        "corpus_cursor": 1
    });
    for field in ["initial_selections", "corpus_cursor"] {
        let mut value = valid.clone();
        value.as_object_mut().unwrap().remove(field);
        assert!(
            graph
                .prepare_snapshots(1, serde_json::from_value(value).unwrap())
                .is_err()
        );
    }
    for (path, value) in [
        ("source_play_id", serde_json::json!("missing")),
        ("t_star_ms", serde_json::json!(-1.0)),
        ("t_star_ms", serde_json::json!(101.0)),
    ] {
        let mut options = valid.clone();
        options["initial_selections"][0][path] = value;
        assert!(
            graph
                .prepare_snapshots(1, serde_json::from_value(options).unwrap())
                .is_err()
        );
    }
    assert!(
        graph
            .prepare_snapshots(2, serde_json::from_value(valid.clone()).unwrap())
            .is_err()
    );
    let mut options = valid;
    options["corpus_cursor"] = serde_json::json!(0);
    assert!(
        graph
            .prepare_snapshots(1, serde_json::from_value(options).unwrap())
            .is_err()
    );
    let legacy: AgenticSnapshotOptions =
        serde_json::from_value(serde_json::json!({"seed": 42})).unwrap();
    assert_eq!(
        serde_json::to_value(legacy).unwrap(),
        serde_json::json!({"seed": 42})
    );
}

#[test]
fn snapshots_retain_full_graph_outputs_and_logical_prompt_views() {
    let graph = boundary_graph();
    let prepared = graph
        .prepare_snapshots(1, AgenticSnapshotOptions::seeded(8))
        .unwrap();
    let zero = prepared.context().prepare_play(0, 0, Some(0.0)).unwrap();
    let cut = prepared.context().prepare_play(0, 0, Some(100.0)).unwrap();
    let full = drain(WorkloadDriver::new_agentic_trace(graph.clone(), 64).unwrap());
    let at_zero = drain(
        WorkloadDriver::new_agentic_snapshots(
            PreparedAgenticSnapshots::from_plays(vec![zero]).unwrap(),
            64,
            true,
            1.0,
        )
        .unwrap(),
    );
    let suffix = drain(
        WorkloadDriver::new_agentic_snapshots(
            PreparedAgenticSnapshots::from_plays(vec![cut.clone()]).unwrap(),
            64,
            true,
            1.0,
        )
        .unwrap(),
    );
    assert_eq!(at_zero.len(), full.len());
    for (id, ready) in &full {
        assert_eq!(ready.request.tokens, at_zero[id].request.tokens);
        assert_eq!(ready.replay_hashes, at_zero[id].replay_hashes);
        assert_eq!(
            ready.request.output_token_ids,
            at_zero[id].request.output_token_ids
        );
    }
    for (id, ready) in &suffix {
        assert_eq!(
            ready.request.output_token_ids,
            full[id].request.output_token_ids
        );
        assert_eq!(ready.request_uuid, at_zero[id].request_uuid);
        assert_eq!(
            ready.request.tokens,
            cut.materialize_prefix(id, 128).unwrap()
        );
    }
}

#[test]
fn original_weka_prefix_keeps_shared_units_and_private_partial_tail() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("trace.json");
    let requests = [(223, vec![10, 20, 30, 40]), (80, vec![10, 20]), (223, vec![10, 20, 30, 40])].into_iter().enumerate().map(|(index, (length, hashes))| {
        serde_json::json!({"t": index, "type":"s", "model":"model", "in":length, "out":1, "hash_ids":hashes})
    }).collect::<Vec<_>>();
    std::fs::write(&path, serde_json::to_vec(&serde_json::json!({"id":"play", "models":["model"], "block_size":64, "hash_id_scope":"local", "requests":requests})).unwrap()).unwrap();
    let graph = load_weka_agentic_graph(&path, Some(64)).unwrap();
    let id = |outer| {
        graph
            .nodes()
            .iter()
            .find(|node| node.request_id().ends_with(&format!(":outer:{outer}")))
            .unwrap()
            .request_id()
            .to_owned()
    };
    let original = id(0);
    let shortened = id(1);
    let follower = id(2);
    let play = prepare(&graph, 1000.0);
    let full = play.materialize_prefix(&original, 223).unwrap();
    let independently_short = play.materialize_prefix(&shortened, 80).unwrap();
    assert_eq!(&full[..64], &independently_short[..64]);
    assert_ne!(&full[64..80], &independently_short[64..]);
    let following = play.materialize_prefix(&follower, 223).unwrap();
    assert_eq!(&full[..192], &following[..192]);
    assert_ne!(&full[192..], &following[192..]);
    for length in [0, 1, 63, 64, 65, 80, 127, 128, 129, 192, 193, 207, 222, 223] {
        assert_eq!(
            play.materialize_prefix(&original, length).unwrap(),
            full[..length]
        );
    }
}

#[test]
fn encounter_allocated_prompt_preserves_full_width_source_ids_and_lane_offsets() {
    let mut authored = row("golden", "main", 0.0, None);
    authored.input_length = Some(257);
    authored.hash_ids = Some(vec![u64::MAX - 1, 0, 1_u64 << 32, u64::MAX, 7]);
    let graph = graph(vec![authored]);
    let prepared = graph
        .prepare_snapshots(2, AgenticSnapshotOptions::seeded(42))
        .unwrap();
    let play = prepared.context().prepare_play(0, 0, Some(0.0)).unwrap();
    let mut expected = [vec![0; 64], vec![1; 64], vec![2; 64], vec![3; 64]].concat();
    expected.push(4);
    assert_eq!(play.materialize_prefix("golden", 257).unwrap(), expected);
    let next = prepared.context().prepare_play(1, 0, Some(0.0)).unwrap();
    assert_eq!(
        next.materialize_prefix("golden", 257).unwrap(),
        expected.iter().map(|token| token + 5).collect::<Vec<_>>()
    );
}

#[test]
fn invalid_snapshot_inputs_and_exhausted_identity_ranges_fail_before_execution() {
    let graph = cycle_graph();
    assert!(
        graph
            .prepare_snapshots(0, AgenticSnapshotOptions::seeded(1))
            .is_err()
    );
    let prepared = graph
        .prepare_snapshots(2, AgenticSnapshotOptions::seeded(1))
        .unwrap();
    let context = prepared.context();
    for cut in [-1.0, 101.0, f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
        assert!(context.prepare_play(0, 0, Some(cut)).is_err());
    }
    assert!(context.prepare_play(2, 0, None).is_err());
    assert!(context.prepare_play(0, u64::MAX, None).is_err());
    let last = context
        .prepare_play(1, (1_u64 << 30) - 1, Some(0.0))
        .unwrap();
    assert_eq!(last.materialize_prefix("b1", 1).unwrap(), [u32::MAX]);
    assert!(context.prepare_play(0, 1_u64 << 30, Some(0.0)).is_err());
    let play = context.prepare_play(0, 0, Some(0.0)).unwrap();
    assert!(play.materialize_prefix("missing", 0).is_err());
    assert!(play.materialize_prefix("b0", 1).is_err());
    assert!(play.materialize_prefix("a0", 65).is_err());
    assert!(PreparedAgenticSnapshots::from_plays(Vec::new()).is_err());
    assert!(PreparedAgenticSnapshots::from_plays(vec![play.clone(), play.clone()]).is_err());
    let independent = graph
        .prepare_snapshots(2, AgenticSnapshotOptions::seeded(1))
        .unwrap();
    let other_context = independent.context().prepare_play(1, 0, Some(0.0)).unwrap();
    assert!(PreparedAgenticSnapshots::from_plays(vec![play.clone(), other_context]).is_err());
    for speedup in [0.0, -1.0, f64::NAN, f64::INFINITY, f64::MIN_POSITIVE] {
        let cohort = PreparedAgenticSnapshots::from_plays(vec![play.clone()]).unwrap();
        assert!(WorkloadDriver::new_agentic_snapshots(cohort, 64, true, speedup).is_err());
    }
    let mut misaligned = play.clone();
    misaligned.evidence.requests.reverse();
    let cohort = PreparedAgenticSnapshots::from_plays(vec![misaligned]).unwrap();
    let error = WorkloadDriver::new_agentic_snapshots(cohort, 64, true, 1.0).unwrap_err();
    assert!(error.to_string().contains("does not match its source play"));
}

#[test]
fn overflowing_recorded_intervals_and_dependency_deadlines_are_rejected() {
    let interval = graph(vec![
        row("first", "main", 1.0e308, Some(1.0e308)),
        row("last", "main", 1.5e308, None),
    ]);
    assert!(
        interval
            .prepare_snapshots(1, AgenticSnapshotOptions::seeded(1))
            .is_err()
    );
    let root = row("first", "main", 0.0, Some(1.0e308));
    let mut last = row("last", "main", 10.0, None);
    last.dependencies.push(edge(
        "first",
        AgenticDependencyRelation::Sequence,
        AgenticDependencyTrigger::Completion,
        1.0e308,
    ));
    let deadline = graph(vec![root, last]);
    assert!(
        deadline
            .prepare_snapshots(1, AgenticSnapshotOptions::seeded(1))
            .is_err()
    );
}

#[test]
fn historical_request_cannot_depend_on_a_request_not_started_at_the_cut() {
    let source = row("later-source", "source", 100.0, Some(1.0));
    let mut historical = row("earlier-target", "target", 0.0, None);
    historical.dependencies.push(edge(
        "later-source",
        AgenticDependencyRelation::Spawn,
        AgenticDependencyTrigger::Dispatch,
        0.0,
    ));
    let graph = graph(vec![source, historical]);
    let error = graph
        .prepare_snapshots(1, AgenticSnapshotOptions::seeded(1))
        .unwrap_err();
    assert!(
        error
            .to_string()
            .contains("historical request's unresolved dependency")
    );
}
