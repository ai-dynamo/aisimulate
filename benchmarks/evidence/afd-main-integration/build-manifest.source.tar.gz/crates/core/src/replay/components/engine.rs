// SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-FileCopyrightText: Copyright 2023-2026 SGLang Team
// SPDX-License-Identifier: Apache-2.0
// Modified behavioral adaptation of SGLang v0.5.22; see THIRD_PARTY_NOTICES.md.
// Source: https://github.com/sgl-project/sglang/tree/baa9befa381511cd4d56f83980951e5a45fffc6d

use std::collections::BTreeSet;
use std::marker::PhantomData;
use std::sync::{Arc, OnceLock};

use crate::engine::generalized::{PassId, SameTimestampRetry, SchedulerCommand};
use crate::engine::{
    Command, CommandResult, Engine, ForwardPassMetrics, HostOffloadObserver, KvHintSource, Metrics,
    PassCompletionEffects, Request,
};
use anyhow::{Context, Result, bail, ensure};
use uuid::Uuid;

use super::super::core::{
    EngineEventBatch, EngineProgress, NoEngineEvents, Placement, WorkerTopology,
};
use super::super::events::{EnginePassCompletion, SimulationWorkerStage, WorkerCompletionPayload};
use super::{
    EngineEffects, EnginePassMode, InternalEngineEffects, ObservedCommandEffects,
    ReplayEngineObservation,
};
use crate::replay::TraceCollector;
use crate::replay::engine::ReplayRoleFactory;
use crate::replay::protocol::{DirectRequest, ForwardPassSnapshot, OutputSignal};
use crate::replay::telemetry::{ReplaySchedulerIntervalMetrics, ReplaySchedulerMetricsSnapshot};

// SGLang admission may require hundreds of effect-free passes while its
// output-reservation ratio converges. Keep this above the native default of
// 600 decay steps while still bounding a broken scheduler's same-time retry.
const MAX_CONSECUTIVE_SAME_TIMESTAMP_RETRIES: usize = 1024;

#[derive(Clone)]
struct PendingPass {
    // Keep the engine's allocation. Only profile cancellation needs an index;
    // ordinary replay drops these IDs at pass completion without building one.
    committed_requests: Vec<Uuid>,
    committed_request_index: OnceLock<BTreeSet<Uuid>>,
    pass_id: PassId,
    started_at_ms: f64,
}

struct LogicalWorker {
    engine: Engine,
    scheduler_ids: Vec<usize>,
    /// Optional live rank telemetry, indexed by DP rank. This is owned by the
    /// worker so removing the worker also releases every rank row.
    telemetry: Option<Vec<RankMetricsState>>,
    /// Request IDs whose ownership is still counted by Replay for each rank.
    ///
    /// A handoff prefill can emit a terminal source signal before the later
    /// `ReleaseSource` command retires the engine-side hold. Tracking IDs, not
    /// only a counter, makes the second retirement idempotent while still
    /// accounting for cancellation before prefill completion.
    in_flight_by_rank: Vec<BTreeSet<Uuid>>,
    pending_pass: Option<PendingPass>,
    consecutive_same_timestamp_retries: usize,
    same_timestamp_countdown: Option<usize>,
    #[cfg(test)]
    same_timestamp_retries_total: usize,
}

impl LogicalWorker {
    fn total_in_flight(&self) -> usize {
        self.in_flight_by_rank.iter().map(BTreeSet::len).sum()
    }
}

#[derive(Clone, Copy)]
struct SchedulerOwner {
    worker_id: usize,
    dp_rank: u32,
}

#[derive(Debug, Clone)]
struct RankMetricsState {
    latest: Metrics,
    interval: ReplaySchedulerIntervalMetrics,
}

impl RankMetricsState {
    fn new(dp_rank: u32, total_blocks: u64, kv_cache_capacity_bytes: Option<u64>) -> Self {
        Self {
            latest: Metrics {
                dp_rank,
                total_blocks,
                kv_cache_capacity_bytes,
                kv_cache_used_bytes: kv_cache_capacity_bytes.map(|_| 0),
                ..Metrics::default()
            },
            interval: ReplaySchedulerIntervalMetrics::default(),
        }
    }

    fn update(&mut self, metrics: &Metrics, accumulate_cache: bool) -> Result<()> {
        let preemptions = metrics
            .preemptions_total
            .checked_sub(self.latest.preemptions_total)
            .context("scheduler preemption counter regressed")?;
        self.interval
            .checked_add_assign(ReplaySchedulerIntervalMetrics {
                preemptions,
                ..ReplaySchedulerIntervalMetrics::default()
            })?;
        if accumulate_cache {
            self.interval
                .checked_add_assign(ReplaySchedulerIntervalMetrics {
                    cache_hit_tokens: metrics.sglang_cache_hit_tokens,
                    cache_total_tokens: metrics.sglang_cache_total_tokens,
                    ..ReplaySchedulerIntervalMetrics::default()
                })?;
        }
        self.latest = metrics.clone();
        Ok(())
    }

    fn gauge_snapshot(&self, worker_id: usize) -> ReplaySchedulerMetricsSnapshot {
        ReplaySchedulerMetricsSnapshot {
            worker_id,
            dp_rank: self.latest.dp_rank,
            active_blocks: self.latest.active_blocks,
            inactive_blocks: self.latest.inactive_blocks,
            total_blocks: self.latest.total_blocks,
            kv_cache_used_bytes: self.latest.kv_cache_used_bytes,
            kv_cache_capacity_bytes: self.latest.kv_cache_capacity_bytes,
            active_cache_usage: self.latest.cache_usage,
            physical_cache_usage: self.latest.physical_cache_usage,
            running_requests: self.latest.running_requests,
            waiting_requests: self.latest.waiting_requests,
        }
    }

    fn take_interval(&mut self) -> ReplaySchedulerIntervalMetrics {
        std::mem::take(&mut self.interval)
    }
}

#[derive(Debug)]
struct EngineTelemetryState {
    retired_interval: ReplaySchedulerIntervalMetrics,
}

/// Fleet/lifecycle adapter around the authoritative generalized mock engine.
///
/// This type owns stable scheduler IDs, startup/draining state, and replay
/// accounting. Attention-DP readiness, pass barriers, and group completion
/// time are owned exclusively by [`Engine`].
pub(crate) struct EngineComponent<Observation = NoEngineEvents>
where
    Observation: ReplayEngineObservation,
{
    stage: SimulationWorkerStage,
    _pass_mode: EnginePassMode,
    workers: Vec<Option<LogicalWorker>>,
    scheduler_owners: Vec<Option<SchedulerOwner>>,
    /// Optional telemetry state keyed identically to `scheduler_owners`.
    /// Disabled replay paths allocate no rank telemetry rows.
    telemetry: Option<EngineTelemetryState>,
    live_worker_count: usize,
    total_in_flight: usize,
    ready_workers: BTreeSet<usize>,
    /// Ready workers whose prior pass changed no externally visible state.
    ///
    /// Keep them out of the current drive scan so a lower worker ID cannot
    /// starve later workers. They are reconsidered on the next coordinator
    /// drive at the same or a later virtual timestamp.
    deferred_ready_workers: BTreeSet<usize>,
    pending_removal: BTreeSet<usize>,
    pending_startup: BTreeSet<usize>,
    factory: ReplayRoleFactory,
    startup_time_ms: Option<f64>,
    capture_artifact_kv_events: bool,
    observation: PhantomData<Observation>,
}

impl<Observation> EngineComponent<Observation>
where
    Observation: ReplayEngineObservation,
{
    pub(crate) fn new_with_factory(
        stage: SimulationWorkerStage,
        pass_mode: EnginePassMode,
        factory: ReplayRoleFactory,
        num_workers: usize,
        startup_time_ms: Option<f64>,
    ) -> Result<Self> {
        let mut factory = factory;
        // A role outside a disaggregated deployment owns its shared G2 pool.
        factory.bind_g2_registry(&Arc::default());
        if let Some(config) = factory.g3_config.clone() {
            factory.g3_tier = Some(crate::engine::g3_offload::G3Tier::new(
                config,
                0,
                factory.g3_block_bytes,
            )?);
        }
        if let Some(config) = factory.kvcr_config.clone() {
            factory.kvcr = Some(crate::engine::kvcr::KvcrRegistry::new(config));
        }
        let mut component = Self {
            stage,
            _pass_mode: pass_mode,
            workers: Vec::with_capacity(num_workers),
            scheduler_owners: Vec::with_capacity(
                num_workers.saturating_mul(factory.dp_size() as usize),
            ),
            telemetry: None,
            live_worker_count: 0,
            total_in_flight: 0,
            ready_workers: BTreeSet::new(),
            deferred_ready_workers: BTreeSet::new(),
            pending_removal: BTreeSet::new(),
            pending_startup: BTreeSet::new(),
            factory,
            startup_time_ms,
            capture_artifact_kv_events: false,
            observation: PhantomData,
        };
        for _ in 0..num_workers {
            component.add_worker()?;
        }
        component.refresh_all_workers();
        Ok(component)
    }

    /// Retain raw pass-boundary KV events for a Replay-owned artifact sink.
    /// Normal engine and Router runs leave this disabled and avoid the clone.
    pub(crate) fn set_artifact_kv_capture(&mut self, capture: bool) {
        self.capture_artifact_kv_events = capture;
    }

    /// Enable rank-level replay telemetry before execution starts.
    ///
    /// The normal path leaves this disabled and does not allocate or update a
    /// parallel scheduler-state vector.
    pub(crate) fn enable_telemetry(&mut self) {
        if self.telemetry.is_some() {
            return;
        }
        let total_blocks = self.factory.total_blocks();
        let dp_size = self.factory.dp_size();
        for worker in self.workers.iter_mut().filter_map(Option::as_mut) {
            worker.telemetry = Some(
                (0..dp_size)
                    .map(|dp_rank| {
                        RankMetricsState::new(
                            dp_rank,
                            total_blocks,
                            self.factory.kv_cache_capacity_bytes(),
                        )
                    })
                    .collect(),
            );
        }
        self.telemetry = Some(EngineTelemetryState {
            retired_interval: ReplaySchedulerIntervalMetrics::default(),
        });
    }

    pub(crate) fn set_host_offload_observer(&mut self, observer: Arc<dyn HostOffloadObserver>) {
        for worker in self.workers.iter_mut().filter_map(Option::as_mut) {
            for rank in worker.engine.ranks_mut() {
                rank.set_host_offload_observer(Arc::clone(&observer));
            }
        }
    }

    pub(crate) fn g3_stats(&self) -> Option<crate::engine::G3Stats> {
        self.factory
            .g3_tier
            .as_ref()
            .map(|r| r.lock().unwrap().snapshot())
    }

    pub(crate) fn kvcr_stats(&self) -> Option<crate::engine::KvcrStats> {
        self.factory
            .kvcr
            .as_ref()
            .map(|r| r.lock().unwrap().stats())
    }

    pub(crate) fn g2_domains(&self) -> Vec<crate::replay::G2DomainStats> {
        self.factory
            .g2_registry()
            .and_then(|registry| registry.occupancy())
            .map(
                |(capacity_blocks, resident_blocks, used_blocks)| crate::replay::G2DomainStats {
                    capacity_blocks,
                    resident_blocks,
                    used_blocks,
                },
            )
            .into_iter()
            .collect()
    }

    /// Observe each host ownership domain once. A disaggregated deployment
    /// disables `include_shared` for its second role when the first role
    /// already sampled the deployment's shared pool.
    pub(crate) fn host_cache_snapshots(
        &self,
        include_shared: bool,
    ) -> Vec<crate::engine::HostCacheMetrics> {
        if self.telemetry.is_none() {
            return Vec::new();
        }
        let mut snapshots = Vec::new();
        if include_shared
            && let Some(metrics) = self
                .factory
                .g2_registry()
                .and_then(|registry| registry.metrics())
        {
            snapshots.push(metrics);
        }
        for (worker_id, worker) in self.workers.iter().enumerate() {
            let Some(worker) = worker else { continue };
            for rank in worker.engine.ranks() {
                if let Some(mut metrics) = rank.per_rank_host_cache_metrics() {
                    metrics.worker_id = Some(worker_id);
                    snapshots.push(metrics);
                }
            }
        }
        snapshots
    }

    pub(crate) fn reset_timing_evidence(&self) -> Result<()> {
        self.factory.reset_timing_evidence()
    }

    fn required_worker(&self, worker_id: usize) -> Result<&LogicalWorker> {
        self.workers
            .get(worker_id)
            .and_then(Option::as_ref)
            .with_context(|| format!("offline replay selected unknown worker {worker_id}"))
    }

    fn required_worker_mut(&mut self, worker_id: usize) -> Result<&mut LogicalWorker> {
        self.workers
            .get_mut(worker_id)
            .and_then(Option::as_mut)
            .with_context(|| format!("offline replay selected unknown worker {worker_id}"))
    }

    fn scheduler_owner(&self, scheduler_id: usize) -> Result<SchedulerOwner> {
        self.scheduler_owners
            .get(scheduler_id)
            .and_then(|owner| *owner)
            .with_context(|| format!("offline replay selected unknown rank {scheduler_id}"))
    }

    fn refresh_worker(&mut self, worker_id: usize) {
        let ready = self
            .workers
            .get(worker_id)
            .and_then(Option::as_ref)
            .is_some_and(|worker| {
                worker.pending_pass.is_none()
                    && worker.engine.is_ready()
                    && !worker.engine.waiting_for_external_command()
            });
        if ready {
            self.ready_workers.insert(worker_id);
        } else {
            self.ready_workers.remove(&worker_id);
        }
    }

    fn refresh_all_workers(&mut self) {
        for worker_id in 0..self.workers.len() {
            self.refresh_worker(worker_id);
        }
    }

    pub(crate) fn add_worker(&mut self) -> Result<usize> {
        let worker_id = self.workers.len();
        let next_live_worker_count = self
            .live_worker_count
            .checked_add(1)
            .context("live worker count overflow")?;
        let engine = self.factory.build(worker_id)?;
        let dp_size = usize::try_from(self.factory.dp_size())
            .context("native engine dp_size does not fit usize")?;
        let mut scheduler_ids = Vec::with_capacity(dp_size);
        for dp_rank in 0..self.factory.dp_size() {
            let scheduler_id = self.scheduler_owners.len();
            self.scheduler_owners
                .push(Some(SchedulerOwner { worker_id, dp_rank }));
            scheduler_ids.push(scheduler_id);
        }
        let telemetry = self.telemetry.as_ref().map(|_| {
            (0..self.factory.dp_size())
                .map(|dp_rank| {
                    RankMetricsState::new(
                        dp_rank,
                        self.factory.total_blocks(),
                        self.factory.kv_cache_capacity_bytes(),
                    )
                })
                .collect()
        });
        self.workers.push(Some(LogicalWorker {
            engine,
            scheduler_ids,
            telemetry,
            in_flight_by_rank: vec![BTreeSet::new(); dp_size],
            pending_pass: None,
            consecutive_same_timestamp_retries: 0,
            same_timestamp_countdown: None,
            #[cfg(test)]
            same_timestamp_retries_total: 0,
        }));
        self.live_worker_count = next_live_worker_count;
        self.refresh_worker(worker_id);
        Ok(worker_id)
    }

    fn tombstone_worker(&mut self, worker_id: usize) -> Result<bool> {
        let Some(worker) = self.workers.get(worker_id).and_then(Option::as_ref) else {
            return Ok(false);
        };
        if !worker.engine.is_drained() || worker.pending_pass.is_some() {
            bail!("cannot remove non-drained generalized engine {worker_id}");
        }
        let worker_in_flight = worker.total_in_flight();
        let scheduler_ids = worker.scheduler_ids.clone();
        let next_total_in_flight = self
            .total_in_flight
            .checked_sub(worker_in_flight)
            .context("worker in-flight accounting underflow during removal")?;
        let next_live_worker_count = self
            .live_worker_count
            .checked_sub(1)
            .context("live worker count underflow")?;
        let mut next_retired_interval = self
            .telemetry
            .as_ref()
            .map(|telemetry| telemetry.retired_interval);
        for scheduler_id in &scheduler_ids {
            self.scheduler_owners
                .get(*scheduler_id)
                .context("worker owned an out-of-range scheduler during removal")?;
        }
        if let Some(next_retired) = next_retired_interval.as_mut() {
            let ranks = worker
                .telemetry
                .as_ref()
                .context("telemetry-enabled worker did not retain live rank state")?;
            for rank in ranks {
                next_retired.checked_add_assign(rank.interval)?;
            }
        }

        // Validate every fallible invariant before mutating the fleet. If a
        // planner-triggered removal fails, Replay can now return the error
        // without leaving a half-tombstoned worker behind.
        if let Some(registry) = &self.factory.g3_tier {
            registry.lock().unwrap().unregister_worker(worker_id)?;
        }
        if let Some(registry) = &self.factory.kvcr {
            registry
                .lock()
                .unwrap()
                .unregister_worker(worker_id as u64)?;
        }
        self.ready_workers.remove(&worker_id);
        self.deferred_ready_workers.remove(&worker_id);
        self.workers
            .get_mut(worker_id)
            .context("worker disappeared during removal")?
            .take()
            .context("worker disappeared during removal")?;
        self.total_in_flight = next_total_in_flight;
        self.live_worker_count = next_live_worker_count;
        if let (Some(telemetry), Some(next_retired)) =
            (self.telemetry.as_mut(), next_retired_interval)
        {
            telemetry.retired_interval = next_retired;
        }
        for scheduler_id in scheduler_ids {
            *self
                .scheduler_owners
                .get_mut(scheduler_id)
                .context("worker owned an out-of-range scheduler during removal")? = None;
        }
        Ok(true)
    }

    pub(crate) fn mark_for_removal(&mut self, worker_id: usize) {
        self.pending_removal.insert(worker_id);
    }

    pub(crate) fn try_remove_drained(&mut self) -> Result<Vec<usize>> {
        let removable = self
            .pending_removal
            .iter()
            .copied()
            .filter(|worker_id| {
                self.workers
                    .get(*worker_id)
                    .and_then(Option::as_ref)
                    .is_none_or(|worker| {
                        worker.pending_pass.is_none()
                            && worker.total_in_flight() == 0
                            && worker.engine.is_drained()
                    })
            })
            .collect::<Vec<_>>();
        let mut removed = Vec::with_capacity(removable.len());
        for worker_id in removable {
            if self
                .tombstone_worker(worker_id)
                .with_context(|| format!("failed to remove drained worker {worker_id}"))?
            {
                removed.push(worker_id);
            }
            self.pending_removal.remove(&worker_id);
        }
        Ok(removed)
    }

    pub(crate) fn apply_target_count(
        &mut self,
        target: usize,
    ) -> Result<(Vec<usize>, Vec<usize>, Vec<usize>)> {
        let active_ids = self.active_group_ids();
        let effective = active_ids
            .len()
            .checked_add(self.pending_startup.len())
            .context("non-draining worker count overflow")?;
        let mut added = Vec::new();
        let mut newly_marked = Vec::new();
        let mut removed = Vec::new();

        if target > effective {
            for _ in 0..(target - effective) {
                let id = self.add_worker().with_context(|| {
                    format!("failed to add worker while scaling from {effective} to {target}")
                })?;
                if self.startup_time_ms.is_some() {
                    self.pending_startup.insert(id);
                    self.ready_workers.remove(&id);
                }
                added.push(id);
            }
        } else if target < effective {
            let excess = effective - target;
            let to_cancel = self
                .pending_startup
                .iter()
                .copied()
                .rev()
                .take(excess)
                .collect::<Vec<_>>();
            for id in &to_cancel {
                if self
                    .tombstone_worker(*id)
                    .with_context(|| format!("failed to cancel starting worker {id}"))?
                {
                    removed.push(*id);
                }
                self.pending_startup.remove(id);
            }
            for id in active_ids.iter().rev().take(excess - to_cancel.len()) {
                self.mark_for_removal(*id);
                newly_marked.push(*id);
            }
        }

        removed.extend(self.try_remove_drained()?);
        Ok((added, newly_marked, removed))
    }

    pub(crate) fn active_group_ids(&self) -> Vec<usize> {
        self.workers
            .iter()
            .enumerate()
            .filter(|(worker_id, worker)| {
                worker.is_some()
                    && !self.pending_removal.contains(worker_id)
                    && !self.pending_startup.contains(worker_id)
            })
            .map(|(worker_id, _)| worker_id)
            .collect()
    }

    pub(crate) fn starting_group_ids(&self) -> Vec<usize> {
        self.pending_startup.iter().copied().collect()
    }

    pub(crate) fn draining_group_ids(&self) -> Vec<usize> {
        self.pending_removal.iter().copied().collect()
    }

    pub(crate) fn non_draining_group_count(&self) -> usize {
        self.active_group_ids().len() + self.pending_startup.len()
    }

    pub(crate) fn worker_topology(&self, worker_id: usize) -> Option<WorkerTopology> {
        Some(WorkerTopology {
            worker_id,
            scheduler_ids: self.workers.get(worker_id)?.as_ref()?.scheduler_ids.clone(),
            router_hint: self.accepts_kv_hints(),
        })
    }

    pub(crate) fn active_topology(&self) -> Vec<WorkerTopology> {
        self.active_group_ids()
            .into_iter()
            .filter_map(|worker_id| self.worker_topology(worker_id))
            .collect()
    }

    pub(crate) fn dp_size(&self) -> u32 {
        self.factory.dp_size()
    }

    pub(crate) fn rank_identity(&self, scheduler_id: usize) -> Option<(usize, u32)> {
        let owner = self
            .scheduler_owners
            .get(scheduler_id)
            .and_then(|owner| *owner)?;
        Some((owner.worker_id, owner.dp_rank))
    }

    /// Whether this pool's engines act on router hints (it configures `kvcr`).
    pub(crate) fn accepts_kv_hints(&self) -> bool {
        self.factory.kvcr_config.is_some()
    }

    /// The source a placement's `kv.fetch` hint names, for the receiving engine.
    /// `None` without KVCR in this pool, without a hint, for a self-hint and
    /// for a source that is draining or has left the pool: new pulls from a
    /// draining source would hold off its removal.
    pub(crate) fn kv_hint_source(&self, placement: &Placement) -> Result<Option<KvHintSource>> {
        let Some(hints) = placement.kv_hints.filter(|_| self.accepts_kv_hints()) else {
            return Ok(None);
        };
        let source = hints.fetch.source_scheduler_id;
        ensure!(
            source < self.scheduler_owners.len(),
            "offline {:?} placement: kv_hints source scheduler {source} never existed",
            self.stage
        );
        if source == placement.scheduler_id {
            return Ok(None);
        }
        Ok(self
            .rank_identity(source)
            .filter(|(worker_id, _)| !self.pending_removal.contains(worker_id))
            .map(|(worker_id, dp_rank)| KvHintSource {
                worker_id: worker_id as u64,
                dp_rank,
            }))
    }

    /// Drop a hint resolved before a delay (such as tokenization) whose source
    /// has since started draining, so a late pull does not hold off its removal.
    pub(crate) fn live_kv_hint(&self, hint: Option<KvHintSource>) -> Option<KvHintSource> {
        hint.filter(|hint| {
            usize::try_from(hint.worker_id)
                .is_ok_and(|worker_id| !self.pending_removal.contains(&worker_id))
        })
    }

    fn update_scheduler_metrics(
        &mut self,
        scheduler_id: usize,
        metrics: &Metrics,
        accumulate_cache: bool,
    ) -> Result<()> {
        if self.telemetry.is_none() {
            return Ok(());
        }
        let owner = self.scheduler_owner(scheduler_id)?;
        if metrics.dp_rank != owner.dp_rank {
            bail!(
                "offline replay scheduler metrics rank mismatch: expected {}, got {}",
                owner.dp_rank,
                metrics.dp_rank
            );
        }
        self.required_worker_mut(owner.worker_id)?
            .telemetry
            .as_mut()
            .context("telemetry-enabled worker did not retain live rank state")?
            .get_mut(owner.dp_rank as usize)
            .context("offline replay scheduler telemetry referenced an out-of-range DP rank")?
            .update(metrics, accumulate_cache)
    }

    /// Return point-in-time gauge rows for every live worker/rank without
    /// consuming additive interval counters.
    pub(crate) fn telemetry_gauges_snapshot(&self) -> Vec<ReplaySchedulerMetricsSnapshot> {
        if self.telemetry.is_none() {
            return Vec::new();
        }
        let mut snapshots = Vec::with_capacity(
            self.live_worker_count
                .saturating_mul(self.factory.dp_size() as usize),
        );
        for (worker_id, worker) in self.workers.iter().enumerate() {
            let Some(worker) = worker else {
                continue;
            };
            let ranks = worker
                .telemetry
                .as_ref()
                .expect("live worker must retain scheduler telemetry");
            for state in ranks {
                snapshots.push(state.gauge_snapshot(worker_id));
            }
        }
        snapshots
    }

    /// Return live gauge rows and drain all role-level additive observations,
    /// including the folded contribution of ranks retired since the last call.
    pub(crate) fn take_telemetry_snapshot(
        &mut self,
    ) -> Result<(
        Vec<ReplaySchedulerMetricsSnapshot>,
        ReplaySchedulerIntervalMetrics,
    )> {
        let gauges = self.telemetry_gauges_snapshot();
        let Some(telemetry) = self.telemetry.as_mut() else {
            return Ok((gauges, ReplaySchedulerIntervalMetrics::default()));
        };
        let mut interval = telemetry.retired_interval;
        for worker in self.workers.iter().filter_map(Option::as_ref) {
            let ranks = worker
                .telemetry
                .as_ref()
                .expect("live worker must retain scheduler telemetry");
            for state in ranks {
                interval.checked_add_assign(state.interval)?;
            }
        }

        telemetry.retired_interval = ReplaySchedulerIntervalMetrics::default();
        for worker in self.workers.iter_mut().filter_map(Option::as_mut) {
            let ranks = worker
                .telemetry
                .as_mut()
                .expect("live worker must retain scheduler telemetry");
            for state in ranks {
                state.take_interval();
            }
        }
        Ok((gauges, interval))
    }

    pub(crate) fn telemetry_has_interval_observations(&self) -> bool {
        let Some(telemetry) = self.telemetry.as_ref() else {
            return false;
        };
        telemetry.retired_interval.has_observations()
            || self
                .workers
                .iter()
                .filter_map(Option::as_ref)
                .filter_map(|worker| worker.telemetry.as_ref())
                .flatten()
                .any(|rank| rank.interval.has_observations())
    }

    pub(crate) fn has_active_workers(&self) -> bool {
        !self.active_group_ids().is_empty()
    }

    pub(crate) fn startup_time_ms(&self) -> Option<f64> {
        self.startup_time_ms
    }

    pub(crate) fn mark_worker_ready(&mut self, worker_id: usize) -> bool {
        let ready = self.pending_startup.remove(&worker_id)
            && self.workers.get(worker_id).is_some_and(Option::is_some);
        if ready {
            self.refresh_worker(worker_id);
        }
        ready
    }

    pub(crate) fn dispatch(
        &mut self,
        scheduler_id: usize,
        request: DirectRequest,
        kv_hint: Option<KvHintSource>,
        now_ms: f64,
    ) -> Result<()> {
        let expected = request
            .uuid
            .context("offline replay request must have a UUID before dispatch")?;
        let effects = self.apply_command(
            scheduler_id,
            Command::Submit(native_request(request, kv_hint)?),
            now_ms,
        )?;
        if !matches!(effects.result, CommandResult::Submitted(id) if id == expected) {
            bail!("native engine returned an unexpected submit result");
        }
        Ok(())
    }

    pub(crate) fn apply_command(
        &mut self,
        scheduler_id: usize,
        command: Command,
        now_ms: f64,
    ) -> Result<ObservedCommandEffects<Observation::Batch>> {
        let owner = self.scheduler_owner(scheduler_id)?;
        let effects = self
            .required_worker_mut(owner.worker_id)?
            .engine
            .apply_command_effects(SchedulerCommand::new(owner.dp_rank, command), now_ms)
            .map_err(crate::replay::error::engine_boundary)?
            .into_by_rank()
            .into_iter()
            .next()
            .context("addressed native command produced no rank effects")?
            .effects;

        let acquired = match effects.result {
            CommandResult::Submitted(request_id)
            | CommandResult::DestinationAccepted { request_id } => Some(request_id),
            CommandResult::Applied | CommandResult::Noop => None,
        };
        self.apply_request_accounting(owner, acquired, &effects.retired_requests)?;
        self.update_scheduler_metrics(scheduler_id, &effects.metrics, false)?;
        let engine_events = Observation::observe_engine_events(
            self.stage.into(),
            owner.worker_id,
            owner.dp_rank,
            effects.kv_events,
        );
        self.refresh_worker(owner.worker_id);
        Ok(ObservedCommandEffects {
            result: effects.result,
            lifecycle_events: effects.lifecycle_events,
            engine_events,
        })
    }

    fn apply_request_accounting(
        &mut self,
        owner: SchedulerOwner,
        acquired: Option<Uuid>,
        retired: &[Uuid],
    ) -> Result<()> {
        let (before, after) = {
            let worker = self.required_worker_mut(owner.worker_id)?;
            let rank = worker
                .in_flight_by_rank
                .get_mut(owner.dp_rank as usize)
                .context("native command returned an out-of-range DP rank")?;
            let before = rank.len();
            if let Some(request_id) = acquired {
                rank.insert(request_id);
            }
            for request_id in retired {
                rank.remove(request_id);
            }
            (before, rank.len())
        };
        if after >= before {
            self.total_in_flight = self
                .total_in_flight
                .checked_add(after - before)
                .context("offline engine in-flight request count overflow")?;
        } else {
            self.total_in_flight = self
                .total_in_flight
                .checked_sub(before - after)
                .context("offline engine retired more requests than replay tracked")?;
        }
        Ok(())
    }

    pub(crate) fn worker_is_busy(&self, scheduler_id: usize) -> Result<bool> {
        let owner = self.scheduler_owner(scheduler_id)?;
        Ok(self
            .required_worker(owner.worker_id)?
            .pending_pass
            .is_some())
    }

    pub(crate) fn request_has_committed_pass(
        &self,
        scheduler_id: usize,
        request_id: Uuid,
    ) -> Result<bool> {
        let owner = self.scheduler_owner(scheduler_id)?;
        Ok(self
            .required_worker(owner.worker_id)?
            .pending_pass
            .as_ref()
            .is_some_and(|pass| {
                pass.committed_request_index
                    .get_or_init(|| pass.committed_requests.iter().copied().collect())
                    .contains(&request_id)
            }))
    }

    pub(crate) fn drive_ready(
        &mut self,
        now_ms: f64,
        _collector: Option<&mut TraceCollector>,
    ) -> Result<EngineEffects<Observation::Batch>> {
        // A serial coordinator may make a previously effect-free worker
        // observable without advancing virtual time. Retry those workers on
        // the next coordinator drive, while allowing every other ready worker
        // a turn in this scan.
        let deferred = std::mem::take(&mut self.deferred_ready_workers);
        for worker_id in deferred {
            self.refresh_worker(worker_id);
        }
        while let Some(worker_id) = self.ready_workers.pop_first() {
            let started = {
                let worker = self.required_worker_mut(worker_id)?;
                if worker.pending_pass.is_some()
                    || !worker.engine.is_ready()
                    || worker.engine.waiting_for_external_command()
                {
                    continue;
                }
                worker
                    .engine
                    .execute_pass(now_ms)
                    .map_err(crate::replay::error::engine_boundary)?
            };
            let Some(started) = started else {
                self.refresh_worker(worker_id);
                continue;
            };
            if let Some(registry) = &self.factory.kvcr {
                registry
                    .lock()
                    .unwrap()
                    .note_pass(worker_id as u64, started.end_ms);
            }

            let same_timestamp_retry = started.same_timestamp_retry;
            let mut pending = PendingPass {
                committed_requests: Vec::new(),
                committed_request_index: OnceLock::new(),
                pass_id: started.pass_id,
                started_at_ms: started.started_at_ms,
            };

            let mut effects: EngineEffects<Observation::Batch> = EngineEffects::default();
            for rank in started.by_rank {
                if let Some(telemetry) = self.required_worker_mut(worker_id)?.telemetry.as_mut() {
                    telemetry[rank.dp_rank as usize]
                        .interval
                        .checked_add_assign(ReplaySchedulerIntervalMetrics {
                            g1_prefix_cache_lookup: rank.effects.g1_prefix_cache_lookup,
                            ..ReplaySchedulerIntervalMetrics::default()
                        })?;
                }
                if pending.committed_requests.is_empty() {
                    pending.committed_requests = rank.effects.committed_requests;
                } else {
                    pending
                        .committed_requests
                        .extend(rank.effects.committed_requests);
                }
                effects
                    .admissions
                    .extend(rank.effects.admissions.into_iter().map(|admission| {
                        super::AdmissionEvent {
                            uuid: admission.request_id,
                            reused_input_tokens: admission.reused_input_tokens,
                            cache_tier_attribution: admission.cache_tier_attribution,
                        }
                    }));
                effects
                    .pressure_events
                    .extend(rank.effects.pressure_events.into_iter().map(|event| {
                        super::PressureEvent {
                            worker_id: worker_id as u64,
                            dp_rank: rank.dp_rank,
                            event,
                        }
                    }));
                if !rank.effects.kv_events.is_empty() {
                    bail!(
                        "generalized engine exposed KV observations before pass completion for worker {worker_id} rank {}",
                        rank.dp_rank
                    );
                }
            }
            self.required_worker_mut(worker_id)?.pending_pass = Some(pending);

            if started.end_ms > now_ms {
                effects.schedule_completion(
                    started.end_ms,
                    EnginePassCompletion::new(self.stage, worker_id, started.pass_id),
                );
            } else {
                // Completing the pass mutates the authoritative scheduler even
                // when it exposes no effects. Do not surface an empty
                // zero-duration completion as progress: doing so immediately
                // re-arms the still-ready worker and lets the virtual-time
                // driver spin forever at the same timestamp. A pass that already
                // exposed start effects is the exception: its matching completion
                // hook remains observable even when the completion payload is empty.
                let completions = self.complete_pass(
                    EnginePassCompletion::new(self.stage, worker_id, started.pass_id),
                    now_ms,
                )?;
                effects.immediate_completions = completions
                    .into_iter()
                    .filter(|payload| effects.should_retain_immediate_completion(payload.progress))
                    .collect();
            }
            effects.progress.made_progress = !effects.admissions.is_empty()
                || !effects.pressure_events.is_empty()
                || !effects.pass_start_events.is_empty()
                || effects.artifact_pass_start.is_some()
                || !effects.immediate_completions.is_empty()
                || effects.scheduled_completion.is_some();

            let same_timestamp_candidate = started.end_ms == now_ms
                && effects.is_empty()
                && self.ready_workers.contains(&worker_id);
            if same_timestamp_candidate {
                match same_timestamp_retry {
                    SameTimestampRetry::Countdown { remaining } => {
                        let worker = self.required_worker_mut(worker_id)?;
                        if worker
                            .same_timestamp_countdown
                            .is_some_and(|previous| remaining >= previous)
                        {
                            let in_flight = worker.total_in_flight();
                            bail!(
                                "offline replay detected an effect-free zero-duration pass with {in_flight} in-flight requests remaining"
                            );
                        }
                        // Configured round counts can exceed the admission
                        // convergence limit. Strict decrease proves this retry
                        // is bounded without inventing time or visible effects.
                        worker.same_timestamp_countdown = Some(remaining);
                        continue;
                    }
                    SameTimestampRetry::Retry => {
                        let worker = self.required_worker_mut(worker_id)?;
                        worker.consecutive_same_timestamp_retries += 1;
                        #[cfg(test)]
                        {
                            worker.same_timestamp_retries_total += 1;
                        }
                        if worker.consecutive_same_timestamp_retries
                            >= MAX_CONSECUTIVE_SAME_TIMESTAMP_RETRIES
                        {
                            let in_flight = worker.total_in_flight();
                            bail!(
                                "offline replay detected an effect-free zero-duration pass with {in_flight} in-flight requests remaining"
                            );
                        }
                        continue;
                    }
                    SameTimestampRetry::Exhausted => {
                        let in_flight = self.required_worker(worker_id)?.total_in_flight();
                        // Aggregated workers have no external handoff command
                        // that can release rank-local capacity. Disaggregated
                        // roles may still be woken by a future source release
                        // or destination activation, so their runtime owns the
                        // final deadlock decision.
                        if self.stage == SimulationWorkerStage::Aggregated && in_flight > 0 {
                            bail!(
                                "offline replay detected an effect-free zero-duration pass with {in_flight} in-flight requests remaining"
                            );
                        }
                    }
                    SameTimestampRetry::NotApplicable => {}
                }
            }
            self.required_worker_mut(worker_id)?
                .consecutive_same_timestamp_retries = 0;
            self.required_worker_mut(worker_id)?
                .same_timestamp_countdown = None;
            if effects.is_empty() {
                if self.ready_workers.remove(&worker_id) {
                    self.deferred_ready_workers.insert(worker_id);
                }
                continue;
            }
            return Ok(effects);
        }
        self.start_parked_kvcr_pulls();
        Ok(EngineEffects::default())
    }

    /// Start the KVCR pulls staged at `now_ms` once the scan has run every
    /// pass starting then, so a pull waits for a source pass at the same
    /// instant whatever the worker order. No worker needs a refresh: the
    /// ready set does not depend on when a pull starts (a staged pull already
    /// counts as registry work), and `next_internal_deadline_ms` reads each
    /// target's deadline from the registry when the driver asks.
    fn start_parked_kvcr_pulls(&self) {
        if let Some(registry) = &self.factory.kvcr {
            registry.lock().unwrap().start_parked();
        }
    }

    pub(crate) fn on_scheduled_completion(
        &mut self,
        completion: EnginePassCompletion<Observation::Batch>,
        now_ms: f64,
    ) -> Result<Vec<WorkerCompletionPayload<Observation::Batch>>> {
        self.complete_pass(completion, now_ms)
    }

    fn complete_pass(
        &mut self,
        completion: EnginePassCompletion<Observation::Batch>,
        now_ms: f64,
    ) -> Result<Vec<WorkerCompletionPayload<Observation::Batch>>> {
        if completion.stage != self.stage {
            bail!(
                "offline replay completion stage mismatch: expected {:?}, got {:?}",
                self.stage,
                completion.stage
            );
        }
        let pending = self
            .required_worker_mut(completion.worker_id)?
            .pending_pass
            .take()
            .context("offline replay completed a worker with no pass in flight")?;
        if pending.pass_id != completion.pass_id {
            bail!("offline replay generalized-engine pass ID mismatch");
        }
        let completed = self
            .required_worker_mut(completion.worker_id)?
            .engine
            .complete_pass(completion.pass_id, now_ms)
            .map_err(crate::replay::error::engine_boundary)?;
        let mut payloads = Vec::with_capacity(completed.effects.by_rank.len());
        for rank in completed.effects.into_by_rank() {
            let scheduler_id = self
                .required_worker(completion.worker_id)?
                .scheduler_ids
                .get(rank.dp_rank as usize)
                .copied()
                .context("native completion returned an out-of-range DP rank")?;
            let completed_request_ids = rank
                .effects
                .outputs
                .iter()
                .filter_map(|output| output.completed.then_some(output.request_id))
                .collect::<Vec<_>>();
            self.apply_request_accounting(
                SchedulerOwner {
                    worker_id: completion.worker_id,
                    dp_rank: rank.dp_rank,
                },
                None,
                &completed_request_ids,
            )?;
            self.update_scheduler_metrics(scheduler_id, &rank.effects.metrics, true)?;
            payloads.push(lower_completion::<Observation>(
                self.stage,
                completion.worker_id,
                scheduler_id,
                rank.dp_rank,
                &pending,
                self.capture_artifact_kv_events,
                rank.effects,
            ));
        }
        self.refresh_worker(completion.worker_id);
        Ok(payloads)
    }

    pub(crate) fn in_flight(&self) -> usize {
        self.total_in_flight
    }

    /// Earliest independently modeled deadline across every logical worker.
    pub(crate) fn next_internal_deadline_ms(&self) -> Option<f64> {
        if !self.factory.can_have_internal_deadlines() {
            return None;
        }
        self.workers
            .iter()
            .filter_map(Option::as_ref)
            // vLLM consumes connector completions with model-step output.
            // A transfer may physically finish mid-pass, but its residency and
            // LRU effects become scheduler-visible only at the group boundary.
            .filter(|worker| worker.pending_pass.is_none())
            .filter_map(|worker| worker.engine.next_internal_deadline_ms())
            .filter(|deadline| deadline.is_finite())
            .min_by(f64::total_cmp)
    }

    /// Process every idle worker whose internal deadline is due at `now_ms`.
    ///
    /// Physical deadlines inside an eagerly committed pass remain hidden;
    /// pass completion settles them before publishing boundary effects.
    pub(crate) fn process_internal_work(
        &mut self,
        now_ms: f64,
    ) -> Result<InternalEngineEffects<Observation::Batch>> {
        if !self.factory.can_have_internal_deadlines() {
            return Ok(InternalEngineEffects {
                engine_events: Observation::Batch::default(),
                made_progress: false,
                artifact_kv_events: self.capture_artifact_kv_events.then(Box::default),
            });
        }
        let mut observations = Observation::Batch::default();
        let mut artifact_events = Vec::new();
        let mut made_progress = false;

        for worker_id in 0..self.workers.len() {
            let due = self
                .workers
                .get(worker_id)
                .and_then(Option::as_ref)
                .filter(|worker| worker.pending_pass.is_none())
                .and_then(|worker| worker.engine.next_internal_deadline_ms())
                .is_some_and(|deadline| deadline.is_finite() && deadline <= now_ms);
            if !due {
                continue;
            }

            let effects = self
                .required_worker_mut(worker_id)?
                .engine
                .process_internal_work(now_ms)
                .map_err(crate::replay::error::engine_boundary)?;
            for rank in effects.into_by_rank() {
                if !rank.effects.admissions.is_empty() || !rank.effects.pressure_events.is_empty() {
                    bail!(
                        "engine internal work exposed pass-start scheduler effects for worker {worker_id} rank {}",
                        rank.dp_rank
                    );
                }
                let kv_events = rank.effects.kv_events;
                if self.capture_artifact_kv_events {
                    artifact_events.extend(kv_events.iter().cloned());
                }
                observations.append(Observation::observe_engine_events(
                    self.stage.into(),
                    worker_id,
                    rank.dp_rank,
                    kv_events,
                ));
                made_progress = true;
            }
            self.refresh_worker(worker_id);
        }

        Ok(InternalEngineEffects {
            engine_events: observations,
            made_progress,
            artifact_kv_events: self
                .capture_artifact_kv_events
                .then(|| artifact_events.into_boxed_slice()),
        })
    }

    pub(crate) fn is_drained(&self) -> bool {
        self.total_in_flight == 0
            && self
                .workers
                .iter()
                .filter_map(Option::as_ref)
                .all(|worker| worker.pending_pass.is_none() && worker.engine.is_drained())
    }

    /// Whether a worker can currently execute a pass that is not waiting on
    /// an external handoff command.
    ///
    /// The replay driver uses this only to distinguish a genuine scheduler
    /// livelock from a legitimate externally blocked handoff when no future
    /// virtual-time event exists.
    pub(crate) fn has_runnable_worker(&self) -> bool {
        !self.ready_workers.is_empty() || !self.deferred_ready_workers.is_empty()
    }

    /// Whether Replay still owns requests that the scheduler silently dropped
    /// without terminal effects.
    ///
    /// This is the terminal shape of an effect-free, zero-duration pass (for
    /// example an impossible SGLang admission): no pass or external command
    /// can wake the drained engine, but Replay must still diagnose the lost
    /// terminal signal instead of reporting generic quiescence.
    pub(crate) fn has_orphaned_in_flight(&self) -> bool {
        self.total_in_flight > 0
            && self
                .workers
                .iter()
                .filter_map(Option::as_ref)
                .all(|worker| worker.pending_pass.is_none() && worker.engine.is_drained())
    }

    pub(crate) fn worker_count(&self) -> usize {
        self.live_worker_count
    }
}

fn native_request(request: DirectRequest, kv_hint: Option<KvHintSource>) -> Result<Request> {
    Ok(Request {
        request_id: request
            .uuid
            .context("offline replay request must have a UUID before dispatch")?,
        tokens: request.tokens,
        cache_salt: request.cache_salt,
        max_output_tokens: request.max_output_tokens,
        output_token_ids: request.output_token_ids,
        session_id: request
            .replay_context
            .and_then(|context| context.session_id().map(str::to_owned)),
        images: request.images,
        kv_hint,
    })
}

fn lower_completion<Observation: ReplayEngineObservation>(
    stage: SimulationWorkerStage,
    worker_id: usize,
    scheduler_id: usize,
    dp_rank: u32,
    pass: &PendingPass,
    capture_artifact_kv_events: bool,
    effects: PassCompletionEffects,
) -> WorkerCompletionPayload<Observation::Batch> {
    let completed_requests = effects
        .outputs
        .iter()
        .filter(|output| output.completed)
        .count();
    // IMPORTANT: Preserve scheduler provenance. Outputs merge prefill with
    // decode and have already been truncated by stopping limits; counting them
    // here silently changes the acceptance metric (see DecodeAcceptance).
    let accept_length_output_tokens = effects.decode_acceptance.accepted_tokens;
    let accept_length_decode_forwards = effects.decode_acceptance.forwards;
    let made_progress = completed_requests > 0
        || !effects.outputs.is_empty()
        || !effects.lifecycle_events.is_empty()
        || !effects.kv_events.is_empty()
        || effects.forward_pass_metrics.num_prefill_requests > 0
        || effects.forward_pass_metrics.num_decode_requests > 0;
    let had_raw_observations = !effects.kv_events.is_empty();
    let artifact_pass_end_kv_events =
        capture_artifact_kv_events.then(|| effects.kv_events.clone().into_boxed_slice());
    let engine_events =
        Observation::observe_engine_events(stage.into(), worker_id, dp_rank, effects.kv_events);
    WorkerCompletionPayload {
        stage,
        worker_idx: scheduler_id,
        completed_requests,
        output_signals: effects
            .outputs
            .into_iter()
            .map(|output| OutputSignal {
                uuid: output.request_id,
                token_id: output.token_id,
                completed: output.completed,
                rejected: output.rejected,
                handoff_delay_ms: None,
                cached_tokens: output.cached_tokens,
            })
            .collect(),
        lifecycle_events: effects.lifecycle_events,
        engine_events,
        pass_started_at_ms: pass.started_at_ms,
        artifact_pass_end_kv_events,
        progress: EngineProgress {
            made_progress,
            had_raw_observations,
        },
        fpm: Some(native_fpm(dp_rank, effects.forward_pass_metrics)),
        accept_length_output_tokens,
        accept_length_decode_forwards,
    }
}

/// The forward-pass snapshot's wall time is the forward's own device time, which
/// the engine already separates from the pass under the SGLang host loop.
fn native_fpm(dp_rank: u32, fpm: ForwardPassMetrics) -> ForwardPassSnapshot {
    ForwardPassSnapshot {
        version: 0,
        worker_id: String::new(),
        dp_rank,
        counter_id: 0,
        num_prefill_requests: fpm.num_prefill_requests,
        sum_prefill_tokens: fpm.sum_prefill_tokens,
        var_prefill_length: fpm.var_prefill_length,
        sum_prefill_kv_tokens: fpm.sum_prefill_kv_tokens,
        num_decode_requests: fpm.num_decode_requests,
        sum_decode_kv_tokens: fpm.sum_decode_kv_tokens,
        var_decode_kv_tokens: fpm.var_decode_kv_tokens,
        num_queued_prefill: fpm.num_queued_prefill,
        sum_queued_prefill_tokens: fpm.sum_queued_prefill_tokens,
        var_queued_prefill_length: fpm.var_queued_prefill_length,
        num_queued_decode: fpm.num_queued_decode,
        sum_queued_decode_kv_tokens: fpm.sum_queued_decode_kv_tokens,
        var_queued_decode_kv_tokens: fpm.var_queued_decode_kv_tokens,
        wall_time_secs: fpm.duration_ms / 1_000.0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::engine::{
        Backend, EngineConfig, FrontendConfig, FrontendStage, KvEvent, KvcrConfig,
        NativeHostOffloadConfig, SglangConfig, TimingModelConfig,
    };
    use crate::replay::components::AdmissionEvent;
    use crate::replay::core::{KvFetchAction, KvHints};
    use crate::replay::{ReplayEngineConfig, ReplayEngineFactory, WorkerStage};

    #[test]
    fn fpm_snapshot_wall_time_is_the_forward_duration() {
        // Under the host loop a 7 ms prefill is launched by a pass that returns at
        // once; the snapshot must carry the forward's 7 ms, not the pass's 0.
        let snapshot = native_fpm(
            0,
            ForwardPassMetrics {
                duration_ms: 7.0,
                ..Default::default()
            },
        );
        assert_eq!(snapshot.wall_time_secs, 0.007);
    }

    #[derive(Debug, Default)]
    struct KvEventBatch(Vec<KvEvent>);

    impl EngineEventBatch for KvEventBatch {
        fn is_empty(&self) -> bool {
            self.0.is_empty()
        }

        fn append(&mut self, mut other: Self) {
            self.0.append(&mut other.0);
        }
    }

    #[derive(Debug, Default)]
    struct KvEventObservation;

    impl ReplayEngineObservation for KvEventObservation {
        type Batch = KvEventBatch;

        const CAPTURE_ENGINE_KV_EVENTS: bool = true;

        fn observe_engine_events(
            _stage: WorkerStage,
            _worker_id: usize,
            _dp_rank: u32,
            events: Vec<KvEvent>,
        ) -> Self::Batch {
            KvEventBatch(events)
        }
    }

    fn component(num_workers: usize, startup_time_ms: Option<f64>) -> EngineComponent {
        let factory = ReplayEngineFactory::new()
            .role_factory(
                &ReplayEngineConfig::default(),
                WorkerStage::Aggregated,
                false,
            )
            .unwrap();
        EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            num_workers,
            startup_time_ms,
        )
        .unwrap()
    }

    #[rstest::rstest]
    #[case(Backend::Vllm)]
    #[case(Backend::Sglang)]
    fn committed_request_membership_excludes_queued_work_during_chunked_prefill(
        #[case] backend: Backend,
        #[values(1, 2, 3)] dp_size: u32,
        #[values(false, true)] query_before_cancel: bool,
    ) {
        let config = ReplayEngineConfig {
            dp_size,
            rank: EngineConfig {
                backend,
                num_gpu_blocks: 32,
                block_size: 4,
                max_num_batched_tokens: 4,
                max_num_seqs: 1,
                enable_chunked_prefill: true,
                enable_prefix_caching: false,
                sglang: SglangConfig {
                    // SGLang divides this worker budget across attention-DP ranks.
                    chunked_prefill_size: 4 * dp_size as usize,
                    ..Default::default()
                },
                timing_model: TimingModelConfig::Fixed {
                    prefill_ms: 10.0,
                    decode_ms: 1.0,
                },
                ..EngineConfig::for_backend(backend)
            },
            ..ReplayEngineConfig::default()
        };
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        let mut component: EngineComponent = EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            1,
            None,
        )
        .unwrap();
        // With three ranks, leave rank 0 idle so collection starts at rank 1.
        let first_active_rank = if dp_size == 3 { 1 } else { 0 };
        let requests: Vec<_> = (first_active_rank..dp_size)
            .map(|rank| {
                (
                    rank as usize,
                    Uuid::from_u128(80_001 + u128::from(rank) * 2),
                    Uuid::from_u128(80_002 + u128::from(rank) * 2),
                )
            })
            .collect();
        for &(scheduler_id, committed, queued) in &requests {
            for (uuid, token) in [(committed, 1), (queued, 2)] {
                component
                    .dispatch(
                        scheduler_id,
                        DirectRequest {
                            tokens: vec![token; 12],
                            max_output_tokens: 2,
                            uuid: Some(uuid),
                            ..Default::default()
                        },
                        None,
                        0.0,
                    )
                    .unwrap();
            }
        }
        let mut started = component.drive_ready(0.0, None).unwrap();
        let scheduled = started.scheduled_completion.take().unwrap();
        assert_eq!(scheduled.at_ms, 10.0);
        // The selected request has not produced output: its first prompt chunk
        // still owns the committed pass, while the scheduler queue does not.
        for &(scheduler_id, committed, queued) in &requests {
            if query_before_cancel {
                assert!(
                    component
                        .request_has_committed_pass(scheduler_id, committed)
                        .unwrap()
                );
                assert!(
                    !component
                        .request_has_committed_pass(scheduler_id, queued)
                        .unwrap()
                );
            }
            for uuid in [queued, committed] {
                component
                    .apply_command(
                        scheduler_id,
                        Command::CancelRequest {
                            request_id: uuid,
                            discard_pending_output: true,
                        },
                        1.0,
                    )
                    .unwrap();
            }
        }
        assert_eq!(component.in_flight(), 0);
        // A first lookup after cancellation must still see the committed batch,
        // including every DP rank, even though the live requests are gone.
        for &(scheduler_id, committed, queued) in &requests {
            assert!(
                component
                    .request_has_committed_pass(scheduler_id, committed)
                    .unwrap()
            );
            assert!(
                !component
                    .request_has_committed_pass(scheduler_id, queued)
                    .unwrap()
            );
        }
        let completed = component
            .on_scheduled_completion(scheduled.completion, scheduled.at_ms)
            .unwrap();
        assert!(completed.iter().all(|pass| pass.output_signals.is_empty()));
        assert_eq!(
            completed
                .iter()
                .map(|pass| pass.fpm.as_ref().unwrap().sum_prefill_tokens)
                .sum::<u64>(),
            4 * requests.len() as u64
        );
        for &(scheduler_id, committed, _) in &requests {
            assert!(
                !component
                    .request_has_committed_pass(scheduler_id, committed)
                    .unwrap()
            );
        }
        assert!(component.is_drained());
    }

    #[test]
    fn initially_empty_fleet_drains_later_workers_host_store() {
        let config = ReplayEngineConfig {
            rank: EngineConfig {
                num_gpu_blocks: 1,
                block_size: 4,
                max_num_seqs: 1,
                max_num_batched_tokens: 4,
                kv_cache_bytes_per_token: Some(250_000),
                native_host_offload: Some(
                    crate::engine::NativeHostOffloadConfig::new(2).with_bandwidths(1.0, 1.0),
                ),
                timing_model: TimingModelConfig::Fixed {
                    prefill_ms: 0.0,
                    decode_ms: 0.0,
                },
                ..EngineConfig::default()
            },
            ..ReplayEngineConfig::default()
        };
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        let mut component: EngineComponent = EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            0,
            None,
        )
        .unwrap();
        assert_eq!(component.next_internal_deadline_ms(), None);
        assert!(!component.process_internal_work(0.0).unwrap().made_progress);

        let worker = component.add_worker().unwrap();
        component
            .dispatch(
                worker,
                DirectRequest {
                    tokens: vec![1, 2, 3, 4],
                    max_output_tokens: 0,
                    uuid: Some(Uuid::from_u128(32)),
                    ..Default::default()
                },
                None,
                0.0,
            )
            .unwrap();
        component.drive_ready(0.0, None).unwrap();

        assert_eq!(component.in_flight(), 0);
        assert_eq!(component.next_internal_deadline_ms(), Some(1.0));
        component.mark_for_removal(worker);
        assert!(component.try_remove_drained().unwrap().is_empty());
        assert!(!component.process_internal_work(0.5).unwrap().made_progress);
        assert!(component.process_internal_work(1.0).unwrap().made_progress);
        assert_eq!(component.try_remove_drained().unwrap(), vec![worker]);
    }

    #[test]
    fn frontend_stage_delivers_a_parked_request_at_its_deadline() {
        let config = ReplayEngineConfig {
            rank: EngineConfig {
                sglang: SglangConfig {
                    host_loop: true,
                    ..SglangConfig::default()
                },
                frontend: Some(FrontendConfig {
                    stages: vec![FrontendStage {
                        workers: 1,
                        service_ms: 4.0,
                        concurrency_scale: Vec::new(),
                    }],
                }),
                timing_model: TimingModelConfig::Fixed {
                    prefill_ms: 1.0,
                    decode_ms: 1.0,
                },
                ..EngineConfig::for_backend(Backend::Sglang)
            },
            ..ReplayEngineConfig::default()
        };
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        let mut component: EngineComponent = EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            1,
            None,
        )
        .unwrap();
        let uuid = Uuid::from_u128(7);
        component
            .dispatch(
                0,
                DirectRequest {
                    tokens: vec![1, 2, 3, 4],
                    max_output_tokens: 1,
                    uuid: Some(uuid),
                    ..Default::default()
                },
                None,
                0.0,
            )
            .unwrap();
        // The request sits in the frontend pool: the scheduler has nothing to run
        // and wakes through the pool's deadline rather than an effect-free pass.
        assert!(component.drive_ready(0.0, None).unwrap().is_empty());
        assert_eq!(component.next_internal_deadline_ms(), Some(4.0));
        assert!(component.process_internal_work(4.0).unwrap().made_progress);
        let admitted = component
            .drive_ready(4.0, None)
            .unwrap()
            .admissions
            .into_iter()
            .map(|admission| admission.uuid)
            .collect::<Vec<_>>();
        assert_eq!(admitted, vec![uuid]);
    }

    #[test]
    fn shared_g2_scale_in_drains_accepted_store_and_keeps_deployment_residency() {
        let config = serde_json::from_value(serde_json::json!({"rank": {
            "num_gpu_blocks": 1, "block_size": 4, "max_num_seqs": 1,
            "max_num_batched_tokens": 4, "enable_prefix_caching": true,
            "kv_cache_bytes_per_token": 250_000,
            "timing_model": {"type": "fixed", "prefill_ms": 0.0, "decode_ms": 0.0},
            "native_host_offload": {
                "scope": "cluster_shared", "num_host_blocks": 2, "kv_layout_id": "tp1",
                "d2h_bandwidth_gbps": 1.0, "h2d_bandwidth_gbps": 1.0,
            },
        }}))
        .unwrap();
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        let mut component: EngineComponent = EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            2,
            None,
        )
        .unwrap();
        let pool = |component: &EngineComponent| {
            let [domain] = component.g2_domains()[..] else {
                panic!("one deployment pool")
            };
            (domain.resident_blocks, domain.used_blocks)
        };
        let request = |id| DirectRequest {
            tokens: vec![1, 2, 3, 4],
            max_output_tokens: 0,
            uuid: Some(Uuid::from_u128(id)),
            ..Default::default()
        };
        // One 1 MB block per prompt: each D2H or H2D takes 1 ms at 1 GB/s.
        let run = |component: &mut EngineComponent, worker, id, now: f64| {
            component.dispatch(worker, request(id), None, now).unwrap();
            let mut admissions = component.drive_ready(now, None).unwrap().admissions;
            assert_eq!(component.next_internal_deadline_ms(), Some(now + 1.0));
            assert!(
                component
                    .process_internal_work(now + 1.0)
                    .unwrap()
                    .made_progress
            );
            admissions.extend(component.drive_ready(now + 1.0, None).unwrap().admissions);
            assert_eq!(component.in_flight(), 0);
            admissions
                .iter()
                .map(|admission| admission.cache_tier_attribution)
                .collect::<Vec<_>>()
        };
        let restored = Some(crate::engine::CacheTierAttribution {
            g1_reused_input_tokens: 0,
            host_reused_input_tokens: 4,
        });

        // Worker 1 computes the block; scale-in marks it while its D2H runs.
        component.dispatch(1, request(1), None, 0.0).unwrap();
        component.drive_ready(0.0, None).unwrap();
        assert_eq!(component.in_flight(), 0);
        assert_eq!(component.next_internal_deadline_ms(), Some(1.0));
        assert_eq!(
            component.apply_target_count(1).unwrap(),
            (vec![], vec![1], vec![])
        );
        assert_eq!(pool(&component), (0, 1));
        assert!(!component.process_internal_work(0.5).unwrap().made_progress);
        assert!(component.try_remove_drained().unwrap().is_empty());
        assert!(component.process_internal_work(1.0).unwrap().made_progress);
        assert_eq!(component.try_remove_drained().unwrap(), [1]);
        assert_eq!(pool(&component), (1, 1));

        // The survivor restores the retired worker's block from G2.
        assert_eq!(run(&mut component, 0, 2, 1.0), [restored]);
        // The deployment owns the pool: it outlives an empty fleet.
        assert_eq!(
            component.apply_target_count(0).unwrap(),
            (vec![], vec![0], vec![0])
        );
        assert_eq!(component.worker_count(), 0);
        assert_eq!(pool(&component), (1, 1));
        assert_eq!(component.apply_target_count(1).unwrap().0, [2]);
        assert_eq!(run(&mut component, 2, 3, 3.0), [restored]);
        assert_eq!(pool(&component), (1, 1));
    }

    #[test]
    fn g3_scale_in_does_not_wait_for_an_unrelated_workers_io() {
        use crate::engine::HostBlockKey;
        use crate::engine::g3_offload::Direction;
        let config: ReplayEngineConfig = serde_json::from_value(serde_json::json!({"rank": {
            "num_gpu_blocks": 8, "block_size": 4, "enable_prefix_caching": true,
            "kv_cache_bytes_per_token": 256,
            "native_host_offload": {"num_host_blocks": 8},
            "g3_offload": {"scope": "cluster_shared", "num_g3_blocks": 8, "latency_to_first_byte_ms": 100.0}
        }})).unwrap();
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        let mut component: EngineComponent = EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            2,
            None,
        )
        .unwrap();
        let registry = component.factory.g3_tier.clone().unwrap();
        let job = registry
            .lock()
            .unwrap()
            .submit(0, Direction::Write, &[HostBlockKey::new(1)], 0.0)
            .unwrap();
        let (_, _, removed) = component.apply_target_count(1).unwrap();
        assert_eq!(removed, vec![1]);
        assert!(registry.lock().unwrap().has_work(0));
        assert_eq!(component.add_worker().unwrap(), 2);
        // A retiring owner is retained until its own I/O has settled.
        component.mark_for_removal(0);
        assert!(component.try_remove_drained().unwrap().is_empty());
        assert!(component.workers[0].is_some());
        registry.lock().unwrap().cancel(job, 0.0);
        assert_eq!(component.try_remove_drained().unwrap(), vec![0]);
        assert_eq!(component.apply_target_count(0).unwrap().2, vec![2]);
        assert_eq!(component.add_worker().unwrap(), 3);
    }

    fn decode_component(num_workers: usize) -> EngineComponent {
        let config = ReplayEngineConfig {
            rank: EngineConfig {
                backend: Backend::Vllm,
                num_gpu_blocks: 16,
                block_size: 4,
                max_num_batched_tokens: 4,
                max_num_seqs: 1,
                enable_chunked_prefill: false,
                ..EngineConfig::for_backend(Backend::Vllm)
            },
            ..ReplayEngineConfig::default()
        };
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Decode, false)
            .unwrap();
        EngineComponent::new_with_factory(
            SimulationWorkerStage::Decode,
            EnginePassMode::Visible,
            factory,
            num_workers,
            None,
        )
        .unwrap()
    }

    #[test]
    fn scheduler_metrics_initialize_every_live_rank_with_capacity() {
        let mut component = decode_component(2);
        component.enable_telemetry();

        let rows = component.telemetry_gauges_snapshot();

        assert_eq!(rows.len(), 2);
        for (worker_id, row) in rows.iter().enumerate() {
            assert_eq!(row.worker_id, worker_id);
            assert_eq!(row.dp_rank, 0);
            assert_eq!(row.total_blocks, 16);
            assert_eq!(row.active_blocks, 0);
            assert_eq!(row.inactive_blocks, 0);
            assert_eq!(row.active_cache_usage, 0.0);
            assert_eq!(row.physical_cache_usage, 0.0);
            assert_eq!(row.running_requests, 0);
            assert_eq!(row.waiting_requests, 0);
        }
    }

    #[test]
    fn host_cache_snapshots_follow_pool_ownership_without_shared_duplicates() {
        for dp_size in [2, 4] {
            for scope in ["dp_rank_local", "cluster_shared"] {
                let config = serde_json::from_value(serde_json::json!({
                    "dp_size": dp_size,
                    "rank": {
                        "num_gpu_blocks": 8, "block_size": 4,
                        "max_num_seqs": 1, "max_num_batched_tokens": 8,
                        "enable_prefix_caching": true,
                        "kv_cache_bytes_per_token": 256,
                        "native_host_offload": {
                            "scope": scope, "num_host_blocks": 16, "kv_layout_id": "tp1"
                        },
                        "timing_model": {"type": "fixed", "prefill_ms": 0.0, "decode_ms": 0.0}
                    }
                }))
                .unwrap();
                let factory = ReplayEngineFactory::new()
                    .role_factory(&config, WorkerStage::Aggregated, false)
                    .unwrap();
                let mut component: EngineComponent = EngineComponent::new_with_factory(
                    SimulationWorkerStage::Aggregated,
                    EnginePassMode::Visible,
                    factory,
                    2,
                    None,
                )
                .unwrap();
                assert!(component.host_cache_snapshots(true).is_empty());
                component.enable_telemetry();
                let snapshots = component.host_cache_snapshots(true);
                let shared = scope == "cluster_shared";
                assert_eq!(snapshots.len(), if shared { 1 } else { 2 * dp_size });
                for (index, row) in snapshots.iter().enumerate() {
                    assert_eq!(row.capacity_blocks, 16);
                    assert_eq!(row.capacity_bytes, 16 * 4 * 256);
                    assert_eq!(row.used_blocks, 0);
                    assert_eq!(row.resident_bytes, 0);
                    assert_eq!(row.worker_id, (!shared).then_some(index / dp_size));
                    assert_eq!(row.dp_rank, (!shared).then_some((index % dp_size) as u32));
                }
                assert_eq!(
                    component.host_cache_snapshots(false).len(),
                    if shared { 0 } else { 2 * dp_size }
                );
                component
                    .dispatch(
                        0,
                        DirectRequest {
                            tokens: vec![1, 2, 3, 4],
                            max_output_tokens: 0,
                            uuid: Some(Uuid::from_u128(32)),
                            ..Default::default()
                        },
                        None,
                        0.0,
                    )
                    .unwrap();
                component.drive_ready(0.0, None).unwrap();
                let occupied = component.host_cache_snapshots(true);
                assert_eq!(occupied.iter().map(|row| row.used_blocks).sum::<u64>(), 1);
                assert_eq!(occupied.iter().map(|row| row.used_bytes).sum::<u64>(), 1024);
            }
        }
    }

    #[test]
    fn g1_lookup_observations_do_not_make_a_blocked_worker_progress() {
        for capture in [false, true] {
            let config = ReplayEngineConfig {
                rank: EngineConfig {
                    num_gpu_blocks: 16,
                    block_size: 4,
                    max_num_batched_tokens: 4,
                    max_num_seqs: 1,
                    enable_prefix_caching: true,
                    enable_chunked_prefill: false,
                    timing_model: TimingModelConfig::Fixed {
                        prefill_ms: 1.0,
                        decode_ms: 1.0,
                    },
                    ..EngineConfig::for_backend(Backend::Vllm)
                },
                ..ReplayEngineConfig::default()
            };
            let factory = ReplayEngineFactory::new()
                .role_factory(&config, WorkerStage::Aggregated, false)
                .unwrap();
            let mut component: EngineComponent = EngineComponent::new_with_factory(
                SimulationWorkerStage::Aggregated,
                EnginePassMode::Visible,
                factory,
                1,
                None,
            )
            .unwrap();
            if capture {
                component.enable_telemetry();
            }
            component
                .dispatch(
                    0,
                    DirectRequest {
                        tokens: (0..8).collect(),
                        max_output_tokens: 1,
                        uuid: Some(Uuid::from_u128(33)),
                        ..Default::default()
                    },
                    None,
                    0.0,
                )
                .unwrap();
            for _ in 0..2 {
                let effects = component.drive_ready(0.0, None).unwrap();
                assert!(effects.is_empty());
                assert!(!effects.progress.made_progress);
                assert_eq!(component.in_flight(), 1);
                let (_, interval) = component.take_telemetry_snapshot().unwrap();
                assert_eq!(
                    interval.g1_prefix_cache_lookup,
                    capture.then_some(crate::engine::PrefixCacheLookupCounts {
                        query_count: 1,
                        queried_tokens: 8,
                        matched_tokens: 0,
                    })
                );
                assert_eq!(interval.cache_hit_tokens, 0);
                assert_eq!(interval.cache_total_tokens, 0);
            }
        }
    }

    #[test]
    fn scheduler_metrics_follow_command_and_completion_boundaries() {
        let config = ReplayEngineConfig {
            rank: EngineConfig {
                backend: Backend::Vllm,
                num_gpu_blocks: 16,
                block_size: 4,
                max_num_batched_tokens: 16,
                max_num_seqs: 1,
                enable_chunked_prefill: false,
                timing_model: TimingModelConfig::Fixed {
                    prefill_ms: 1.0,
                    decode_ms: 1.0,
                },
                ..EngineConfig::for_backend(Backend::Vllm)
            },
            ..ReplayEngineConfig::default()
        };
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        let mut component: EngineComponent = EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            1,
            None,
        )
        .unwrap();
        component.enable_telemetry();
        component
            .dispatch(
                0,
                DirectRequest {
                    tokens: vec![1; 4],
                    max_output_tokens: 1,
                    uuid: Some(Uuid::from_u128(31)),
                    ..Default::default()
                },
                None,
                0.0,
            )
            .unwrap();

        let after_command = component.telemetry_gauges_snapshot();
        assert_eq!(after_command.len(), 1);
        assert_eq!(
            after_command[0].running_requests + after_command[0].waiting_requests,
            1
        );

        let mut started = component.drive_ready(0.0, None).unwrap();
        let scheduled = started
            .scheduled_completion
            .take()
            .expect("fixed timing must schedule a completion");
        component
            .on_scheduled_completion(scheduled.completion, scheduled.at_ms)
            .unwrap();

        let after_completion = component.telemetry_gauges_snapshot();
        assert_eq!(after_completion.len(), 1);
        let row = &after_completion[0];
        assert_eq!(row.running_requests, 0);
        assert_eq!(row.waiting_requests, 0);
        assert_eq!(row.active_blocks, 0);
        assert!(row.inactive_blocks > 0);
        assert_eq!(row.active_cache_usage, 0.0);
        assert!(row.physical_cache_usage > 0.0);
        assert_eq!(
            row.physical_cache_usage,
            row.inactive_blocks as f64 / row.total_blocks as f64
        );
    }

    #[test]
    fn scheduler_cache_metrics_accumulate_and_drain_per_tick() {
        let mut state = RankMetricsState::new(2, 100, None);
        state
            .update(
                &Metrics {
                    dp_rank: 2,
                    total_blocks: 100,
                    sglang_cache_hit_tokens: 3,
                    sglang_cache_total_tokens: 5,
                    preemptions_total: 2,
                    ..Metrics::default()
                },
                true,
            )
            .unwrap();
        state
            .update(
                &Metrics {
                    dp_rank: 2,
                    total_blocks: 100,
                    sglang_cache_hit_tokens: 7,
                    sglang_cache_total_tokens: 11,
                    preemptions_total: 5,
                    ..Metrics::default()
                },
                true,
            )
            .unwrap();
        // Command snapshots refresh instantaneous state but are not pass-local
        // cache observations and therefore must not alter the tick window.
        state
            .update(
                &Metrics {
                    dp_rank: 2,
                    total_blocks: 100,
                    preemptions_total: 5,
                    ..Metrics::default()
                },
                false,
            )
            .unwrap();

        let first = state.take_interval();
        assert_eq!(first.cache_hit_tokens, 10);
        assert_eq!(first.cache_total_tokens, 16);
        assert_eq!(first.preemptions, 5);
        let second = state.take_interval();
        assert_eq!(second.cache_hit_tokens, 0);
        assert_eq!(second.cache_total_tokens, 0);
        assert_eq!(second.preemptions, 0);
    }

    #[test]
    fn retired_rank_interval_counters_are_folded_without_retaining_gauges() {
        let mut component = decode_component(1);
        component.enable_telemetry();
        component
            .update_scheduler_metrics(
                0,
                &Metrics {
                    dp_rank: 0,
                    total_blocks: 16,
                    sglang_cache_hit_tokens: 3,
                    sglang_cache_total_tokens: 5,
                    preemptions_total: 4,
                    ..Metrics::default()
                },
                true,
            )
            .unwrap();

        let (_, _, removed) = component.apply_target_count(0).unwrap();
        assert_eq!(removed, vec![0]);

        let (gauges, interval) = component.take_telemetry_snapshot().unwrap();
        assert!(gauges.is_empty());
        assert_eq!(interval.cache_hit_tokens, 3);
        assert_eq!(interval.cache_total_tokens, 5);
        assert_eq!(interval.preemptions, 4);

        let (_, next_interval) = component.take_telemetry_snapshot().unwrap();
        assert_eq!(next_interval, ReplaySchedulerIntervalMetrics::default());
    }

    #[test]
    fn disabled_telemetry_returns_before_rank_lookup_or_state_cloning() {
        let mut component = decode_component(1);

        component
            .update_scheduler_metrics(usize::MAX, &Metrics::default(), true)
            .unwrap();

        assert!(component.telemetry.is_none());
    }

    #[test]
    fn canceling_busy_startup_worker_returns_error_without_losing_worker() {
        let mut component = component(1, Some(10.0));
        let (added, _, _) = component.apply_target_count(2).unwrap();
        let starting_worker = added[0];
        let scheduler_id = component
            .worker_topology(starting_worker)
            .unwrap()
            .scheduler_ids[0];
        component
            .dispatch(
                scheduler_id,
                DirectRequest {
                    tokens: vec![1],
                    max_output_tokens: 1,
                    uuid: Some(Uuid::from_u128(1)),
                    ..Default::default()
                },
                None,
                0.0,
            )
            .unwrap();

        let error = component.apply_target_count(1).unwrap_err();

        assert!(
            error
                .to_string()
                .contains("failed to cancel starting worker")
        );
        assert_eq!(component.starting_group_ids(), vec![starting_worker]);
        assert!(component.worker_topology(starting_worker).is_some());
        assert_eq!(component.worker_count(), 2);
    }

    #[test]
    fn drained_removal_error_preserves_pending_worker() {
        let mut component = component(1, None);
        component.mark_for_removal(0);
        component.live_worker_count = 0;

        let error = component.try_remove_drained().unwrap_err();

        assert!(
            error
                .to_string()
                .contains("failed to remove drained worker 0")
        );
        assert_eq!(component.draining_group_ids(), vec![0]);
        assert!(component.worker_topology(0).is_some());
    }

    #[test]
    fn effect_free_worker_does_not_starve_later_ready_worker() {
        let mut component = decode_component(2);
        component
            .dispatch(
                0,
                DirectRequest {
                    tokens: vec![1; 8],
                    max_output_tokens: 1,
                    uuid: Some(Uuid::from_u128(20)),
                    ..Default::default()
                },
                None,
                0.0,
            )
            .unwrap();
        component
            .dispatch(
                1,
                DirectRequest {
                    tokens: vec![2; 4],
                    max_output_tokens: 1,
                    uuid: Some(Uuid::from_u128(21)),
                    ..Default::default()
                },
                None,
                0.0,
            )
            .unwrap();

        let effects = component.drive_ready(0.0, None).unwrap();

        assert!(!effects.is_empty());
        assert_eq!(component.deferred_ready_workers, BTreeSet::from([0]));
        assert!(
            effects
                .admissions
                .iter()
                .any(|admission| admission.uuid == Uuid::from_u128(21)),
            "the later ready worker must run after the lower ID produces no effects"
        );
    }

    #[test]
    fn effect_free_worker_is_retried_on_the_next_coordinator_drive() {
        let mut component = decode_component(1);
        component
            .dispatch(
                0,
                DirectRequest {
                    tokens: vec![1; 8],
                    max_output_tokens: 1,
                    uuid: Some(Uuid::from_u128(22)),
                    ..Default::default()
                },
                None,
                0.0,
            )
            .unwrap();

        assert!(component.drive_ready(0.0, None).unwrap().is_empty());
        assert!(component.ready_workers.is_empty());
        assert_eq!(component.deferred_ready_workers, BTreeSet::from([0]));
        assert!(component.has_runnable_worker());

        assert!(component.drive_ready(0.0, None).unwrap().is_empty());
        assert_eq!(component.deferred_ready_workers, BTreeSet::from([0]));
    }

    #[test]
    fn kv_observations_are_visible_only_at_pass_completion_for_all_backends() {
        for (backend, uuid) in [
            (Backend::Vllm, Uuid::from_u128(10)),
            (Backend::Trtllm, Uuid::from_u128(11)),
            (Backend::Sglang, Uuid::from_u128(12)),
        ] {
            let config = ReplayEngineConfig {
                rank: EngineConfig {
                    backend,
                    num_gpu_blocks: 8,
                    block_size: 4,
                    timing_model: TimingModelConfig::Fixed {
                        prefill_ms: 1.0,
                        decode_ms: 1.0,
                    },
                    ..EngineConfig::for_backend(backend)
                },
                ..ReplayEngineConfig::default()
            };
            let factory = ReplayEngineFactory::new()
                .role_factory(&config, WorkerStage::Aggregated, true)
                .unwrap();
            let mut component: EngineComponent<KvEventObservation> =
                EngineComponent::new_with_factory(
                    SimulationWorkerStage::Aggregated,
                    EnginePassMode::Visible,
                    factory,
                    1,
                    None,
                )
                .unwrap();
            component
                .dispatch(
                    0,
                    DirectRequest {
                        tokens: vec![1; 4],
                        max_output_tokens: 1,
                        uuid: Some(uuid),
                        ..Default::default()
                    },
                    None,
                    0.0,
                )
                .unwrap();

            let mut pass_start = component.drive_ready(0.0, None).unwrap();
            assert!(
                pass_start.pass_start_events.0.is_empty(),
                "{backend:?} exposed KV observations at pass start"
            );
            let scheduled = pass_start
                .scheduled_completion
                .take()
                .expect("fixed timing must schedule a completion");
            let completed = component
                .on_scheduled_completion(scheduled.completion, scheduled.at_ms)
                .unwrap();
            assert!(
                completed
                    .iter()
                    .any(|payload| !payload.engine_events.0.is_empty()),
                "{backend:?} did not expose KV observations at pass completion"
            );
        }
    }

    #[test]
    fn sglang_component_rejects_an_impossible_prompt_without_retrying() {
        let config = ReplayEngineConfig {
            rank: EngineConfig {
                backend: Backend::Sglang,
                num_gpu_blocks: 1,
                block_size: 4,
                sglang: SglangConfig {
                    chunked_prefill_size: 8,
                    ..SglangConfig::default()
                },
                timing_model: TimingModelConfig::Fixed {
                    prefill_ms: 1.0,
                    decode_ms: 1.0,
                },
                ..EngineConfig::for_backend(Backend::Sglang)
            },
            ..ReplayEngineConfig::default()
        };
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        let mut component: EngineComponent = EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            1,
            None,
        )
        .unwrap();
        component
            .dispatch(
                0,
                DirectRequest {
                    tokens: vec![1; 8],
                    max_output_tokens: 2,
                    uuid: Some(Uuid::from_u128(2)),
                    ..Default::default()
                },
                None,
                37.0,
            )
            .unwrap();

        let effects = component.drive_ready(37.0, None).unwrap();
        let retries = component.workers[0]
            .as_ref()
            .unwrap()
            .same_timestamp_retries_total;

        assert_eq!(retries, 0);
        assert!(effects.admissions.is_empty());
        assert!(effects.scheduled_completion.is_none());
        assert_eq!(effects.immediate_completions.len(), 1);
        let outputs = &effects.immediate_completions[0].output_signals;
        assert_eq!(outputs.len(), 1);
        assert_eq!(outputs[0].uuid, Uuid::from_u128(2));
        assert!(outputs[0].completed && outputs[0].rejected);
    }

    #[test]
    fn pass_start_admission_retains_effect_free_immediate_completion() {
        let mut effects: EngineEffects = EngineEffects::default();
        effects.admissions.push(AdmissionEvent {
            uuid: Uuid::from_u128(3),
            reused_input_tokens: 0,
            cache_tier_attribution: None,
        });

        assert!(effects.should_retain_immediate_completion(EngineProgress::default()));
        assert!(
            !EngineEffects::<()>::default()
                .should_retain_immediate_completion(EngineProgress::default())
        );
    }

    fn placement_with_hint(scheduler_id: usize, source_scheduler_id: Option<usize>) -> Placement {
        Placement {
            request_id: Uuid::from_u128(1),
            scheduler_id,
            reported_overlap_tokens: 0,
            cache_sample: None,
            kv_hints: source_scheduler_id.map(|source_scheduler_id| KvHints {
                fetch: KvFetchAction {
                    source_scheduler_id,
                },
            }),
            placement_replica_id: None,
        }
    }

    fn attention_dp_component(
        num_workers: usize,
        dp_size: u32,
        kvcr: Option<KvcrConfig>,
    ) -> EngineComponent {
        let config = ReplayEngineConfig {
            dp_size,
            rank: EngineConfig {
                kv_cache_bytes_per_token: Some(250_000),
                native_host_offload: Some(NativeHostOffloadConfig::new(4)),
                kvcr,
                ..EngineConfig::default()
            },
            ..ReplayEngineConfig::default()
        };
        let factory = ReplayEngineFactory::new()
            .role_factory(&config, WorkerStage::Aggregated, false)
            .unwrap();
        EngineComponent::new_with_factory(
            SimulationWorkerStage::Aggregated,
            EnginePassMode::Visible,
            factory,
            num_workers,
            None,
        )
        .unwrap()
    }

    #[test]
    fn kv_hint_source_resolves_the_source_scheduler_to_worker_and_rank() {
        let mut component = attention_dp_component(2, 2, Some(KvcrConfig::default()));
        let source = |component: &EngineComponent, target, source| {
            component.kv_hint_source(&placement_with_hint(target, source))
        };
        let (worker0, worker1) = (
            component.worker_topology(0).unwrap(),
            component.worker_topology(1).unwrap(),
        );
        assert!(worker0.router_hint && worker1.router_hint);
        let (worker0, worker1) = (worker0.scheduler_ids, worker1.scheduler_ids);

        // No hint, no source.
        assert_eq!(source(&component, worker0[0], None).unwrap(), None);
        // A peer on another worker and a peer rank on the same worker.
        let worker1_rank0 = Some(KvHintSource {
            worker_id: 1,
            dp_rank: 0,
        });
        assert_eq!(
            source(&component, worker0[1], Some(worker1[0])).unwrap(),
            worker1_rank0
        );
        assert_eq!(
            source(&component, worker1[1], Some(worker1[0])).unwrap(),
            worker1_rank0
        );
        // A rank never fetches from itself.
        assert_eq!(
            source(&component, worker1[1], Some(worker1[1])).unwrap(),
            None
        );
        // A scheduler id that never existed is a placement-policy error that
        // names the pool.
        let never = component.scheduler_owners.len();
        let error = source(&component, worker0[0], Some(never)).unwrap_err();
        assert!(
            error.to_string().contains(&format!(
                "offline Aggregated placement: kv_hints source scheduler {never} never existed"
            )),
            "{error}"
        );
        // A draining source and one that has left the pool are ignored.
        assert_eq!(worker1[0], 2);
        let resolved = source(&component, worker0[0], Some(2)).unwrap();
        assert!(resolved.is_some());
        component.mark_for_removal(1);
        assert_eq!(source(&component, worker0[0], Some(2)).unwrap(), None);
        // A hint resolved before the drain is dropped when it is finally dispatched.
        assert_eq!(component.live_kv_hint(resolved), None);
        assert!(component.tombstone_worker(1).unwrap());
        assert_eq!(source(&component, worker0[0], Some(2)).unwrap(), None);

        // Without KVCR no worker advertises router hints and every hint is ignored.
        let plain = attention_dp_component(2, 2, None);
        assert!(!plain.worker_topology(0).unwrap().router_hint);
        for hinted in [worker1[0], worker0[0], never] {
            assert_eq!(source(&plain, worker0[1], Some(hinted)).unwrap(), None);
        }
    }

    #[test]
    fn kvcr_workers_join_the_registry_at_build_and_leave_at_removal() {
        // Build registers a worker's ranks; its removal unregisters them and no others.
        let mut component = attention_dp_component(2, 2, Some(KvcrConfig::default()));
        let registry = component.factory.kvcr.clone().unwrap();
        let rank1 = |worker_id| KvHintSource {
            worker_id,
            dp_rank: 1,
        };
        assert!(registry.lock().unwrap().source(rank1(1)).is_some());
        assert!(component.tombstone_worker(1).unwrap());
        let registry = registry.lock().unwrap();
        assert!(registry.source(rank1(1)).is_none());
        assert!(registry.source(rank1(0)).is_some());
    }
}
