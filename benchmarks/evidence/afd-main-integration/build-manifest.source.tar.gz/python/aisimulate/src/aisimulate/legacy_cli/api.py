# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
# Includes changes adapted from:
# https://github.com/ai-dynamo/aiconfigurator/blob/6290c161a354da5250c391bd43372b2e9c6f4a51/src/aiconfigurator/cli/api.py

"""
Python API for calling CLI workflows programmatically.

This module provides simple function interfaces to the CLI's "default", "exp",
"generate", "estimate", and "support" modes, making it easy to use from Python code without going through argparse.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import pandas as pd

from aisimulate.legacy_cli.main import (
    _default_support_version,
    build_default_tasks,
    build_experiment_tasks,
)
from aisimulate.legacy_cli.main import (
    _execute_tasks as _execute_tasks_internal,
)
from aisimulate.legacy_cli.report_and_save import save_results
from aisimulate.sdk.config import ModelConfig
from aisimulate.sdk.config_builders import apply_nextn as _apply_nextn
from aisimulate.sdk.config_builders import build_model_config as _build_model_config
from aisimulate.sdk.config_builders import resolve_dspark_nextn as _resolve_dspark_nextn
from aisimulate.sdk.config_builders import resolve_nextn_auto as _resolve_nextn_auto
from aisimulate.sdk.errors import ExperimentOutcome, NoFeasibleConfigError, is_gpu_retriable
from aisimulate.sdk.models import (
    check_is_moe,
    resolve_context_fmha_by_data,
    resolve_dsv4_moe_arch,
    resolve_nvfp4_for_system,
)
from aisimulate.sdk.moe_comm_resolver import resolve_model_config_moe_comm
from aisimulate.sdk.performance_result import MoECommFallback
from aisimulate.sdk.rust_engine_step import validate_engine_step_backend
from aisimulate.sdk.speculative import (
    SpeculativeDecodingProfile,
)
from aisimulate.sdk.speculative import (
    normalize_speculative_decoding as _normalize_nextn,
)
from aisimulate.sdk.task_v2 import Task

# Default per-phase latency-correction scales for single-point disagg estimates.
# (Migrated from the legacy V1 task module; same values as Task's field defaults.)
DEFAULT_PREFILL_LATENCY_CORRECTION_SCALE = 1.1
DEFAULT_DECODE_LATENCY_CORRECTION_SCALE = 1.08
POWER_DATA_COVERAGE_THRESHOLD = 0.9


def cli_support(
    model_path: str,
    system: str,
    *,
    backend: str = "trtllm",
    backend_version: str | None = None,
) -> tuple[bool, bool]:
    """
    Check if AIC supports the model/hardware combo for (agg, disagg).
    Support is determined by a majority vote of PASS status for the given
    architecture, system, backend, and version in the support matrix.
    It's a light-weight check, need to verify under the CLI default or exp mode.

    This is the programmatic equivalent of:
        aiconfigurator cli support --model-path ... --system ...

    Args:
        model_path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or local path.
        system: System name (GPU type), e.g., 'h200_sxm', 'b200_sxm'.
        backend: Optional backend name to filter by ('trtllm', 'sglang', 'vllm').
        backend_version: Optional backend database version; defaults to the current
            slot, or the latest model-relevant matrix version without slot policy.

    Returns:
        tuple[bool, bool]: (agg_supported, disagg_supported)
    """
    from aisimulate.sdk.common import SupportResult, check_support
    from aisimulate.sdk.utils import get_model_config_from_model_path

    try:
        model_info = get_model_config_from_model_path(model_path)
        architecture = model_info["architecture"]
    except Exception:
        architecture = None

    if not backend_version:
        backend_version = _default_support_version(model_path, system, backend, architecture)
        if backend_version is None:
            return SupportResult(
                agg_supported=False, disagg_supported=False, exact_match=False, architecture=architecture
            )

    return check_support(model_path, system, backend, backend_version, architecture=architecture)


logger = logging.getLogger(__name__)


@dataclass
class CLIResult:
    """Result from running CLI default or exp mode."""

    chosen_exp: str
    """Name of the experiment with the best throughput."""

    best_configs: dict[str, pd.DataFrame]
    """Best configurations per experiment, filtered by latency constraints."""

    pareto_fronts: dict[str, pd.DataFrame]
    """Pareto frontier data per experiment."""

    best_throughputs: dict[str, float]
    """Best throughput (tokens/s/gpu_cluster) per experiment."""

    tasks: dict[str, Task]
    """Task objects used for each experiment."""

    best_latencies: dict[str, dict[str, float]] = field(default_factory=dict)
    """Estimated latencies (ttft, tpot, request_latency) from the rank-1 config per experiment."""

    raw_results: dict[str, dict[str, pd.DataFrame | None]] = field(default_factory=dict)
    """Raw pareto_df results from TaskRunner, keyed by experiment name."""

    outcomes: dict[str, ExperimentOutcome] = field(default_factory=dict)
    """Per-experiment success/failure verdicts from _execute_tasks."""

    def __repr__(self) -> str:
        return (
            f"CLIResult(chosen_exp={self.chosen_exp!r}, "
            f"experiments={list(self.tasks.keys())}, "
            f"best_throughputs={self.best_throughputs})"
        )


def _execute_and_wrap_result(
    tasks: dict[str, Task],
    mode: str,
    top_n: int = 5,
    strict_sla: bool = False,
    target_request_rate: float | None = None,
    target_concurrency: float | None = None,
    parallel_experiments: bool = False,
) -> CLIResult:
    """Execute task configs using main.py's function and wrap result in CLIResult."""
    chosen_exp, best_configs, pareto_fronts, best_throughputs, best_latencies, outcomes = _execute_tasks_internal(
        tasks,
        mode,
        top_n=top_n,
        strict_sla=strict_sla,
        target_request_rate=target_request_rate,
        target_concurrency=target_concurrency,
        parallel_experiments=parallel_experiments,
    )

    return CLIResult(
        chosen_exp=chosen_exp,
        best_configs=best_configs,
        pareto_fronts=pareto_fronts,
        best_throughputs=best_throughputs,
        best_latencies=best_latencies,
        tasks=tasks,
        raw_results={},
        outcomes=outcomes,
    )


def cli_default(
    model_path: str,
    total_gpus: int,
    system: str,
    *,
    decode_system: str | None = None,
    backend: str = "trtllm",
    backend_version: str | None = None,
    database_mode: str = "SILICON",
    transfer_policy: str | list | None = None,
    isl: int = 4000,
    osl: int = 1000,
    image_height: int = 0,
    image_width: int = 0,
    num_images: int = 1,
    video_height: int = 0,
    video_width: int = 0,
    video_frames: int = 0,
    num_videos: int = 0,
    num_video_tokens: int = 0,
    enable_encoder_dp: bool = True,
    enable_epd: bool = False,
    encoder_tp: list[int] | None = None,
    encoder_system: str | None = None,
    encoder_latency_correction: float = 1.0,
    ttft: float = 2000.0,
    tpot: float = 30.0,
    request_latency: float | None = None,
    prefix: int = 0,
    nextn: int | str = 0,
    nextn_accepted: float | None = None,
    strict_sla: bool = False,
    free_gpu_memory_fraction: float | None = None,
    max_seq_len: int | None = None,
    top_n: int = 5,
    save_dir: str | None = None,
    generator_set: list[str] | None = None,
    generator_config: str | None = None,
    generator_dynamo_version: str | None = None,
    attention_backend: str | None = None,
    engine_step_backend: str | None = None,
    forward_model: str | None = None,
) -> CLIResult:
    """
    Run the default CLI mode: compare aggregated vs disaggregated serving.

    This is the programmatic equivalent of:
        aiconfigurator cli default --model-path ... --total-gpus ... --system ...

    Args:
        model_path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or local path.
        total_gpus: Total number of GPUs for deployment.
        system: System name (GPU type), e.g., 'h200_sxm', 'b200_sxm'.
        decode_system: System name for disagg decode workers. Defaults to `system`.
        backend: Backend name ('trtllm', 'sglang', 'vllm', 'auto'). Default is 'trtllm'.
            Use 'auto' to sweep across all three backends and compare results.
        backend_version: Backend database version. Default is latest.
        database_mode: Database mode for performance estimation
            ('SILICON', 'HYBRID', 'EMPIRICAL', 'SOL'). Default is 'SILICON'.
        isl: Input sequence length. Default is 4000.
        osl: Output sequence length. Default is 1000.
        enable_encoder_dp: Model the vision encoder data-parallel (default True;
            vLLM mm_encoder_tp_mode="data" / SGLang --mm-enable-dp-encoder semantics).
            False models the legacy TP-sharded encoder.
        video_height: Video frame height for vision-language models.
        video_width: Video frame width for vision-language models.
        video_frames: Number of frames per video.
        num_videos: Number of videos per request. Images and videos must be
            estimated separately until mixed visual packing is modeled.
        num_video_tokens: Explicit post-merge tokens per video. Requires
            ``video_frames`` so temporal attention sequences can be modeled.
        ttft: Time to first token target in ms. Default is 2000.
        tpot: Time per output token target in ms. Default is 30.
        request_latency: Optional end-to-end request latency target (ms).
            Enables request-latency optimization mode.
        prefix: Prefix cache length. Default is 0.
        nextn: MTP draft length, or ``"auto"`` to use the checkpoint's
            ``num_nextn_predict_layers`` (absent/0 keeps MTP disabled).
            Default 0 (disabled); never enabled implicitly.
        nextn_accepted: Average accepted draft tokens per decode step
            (0 <= nextn_accepted <= nextn). Required when the draft depth
            resolves to > 0; never inferred.
        strict_sla: When True, ``pareto_df`` is filtered to only
            SLA-compliant data points (TPOT or request-latency) *before*
            the Pareto frontier is computed.  TTFT is already enforced at
            sweep time.  Default is False (full Pareto frontier, TPOT-only
            constraint at picking time).
        free_gpu_memory_fraction: Fraction of free GPU memory allocated for KV cache
            (default ``None``, meaning the backend default is used). Must be > 0 and <= 1.
            Used to filter batch sizes that would exceed KV cache capacity.
        max_seq_len: TRT-LLM ``--max_seq_len`` setting. Controls how many KV blocks are
            pre-allocated per sequence. Defaults to ``isl + osl`` when ``None``.
        enable_epd: VL models -- serve the vision encoder from a dedicated
            encode-worker pool (agg becomes E+agg, disagg becomes E+P+D).
            Requires an image workload (image_height/image_width).
        encoder_tp: EPD encode-worker TP sizes to sweep (default [1, 2, 4, 8]).
        encoder_system: System (GPU type) for the encode workers; defaults to
            the prefill/agg side's system.
        encoder_latency_correction: Latency correction scale for the encode
            workers.  Default 1.0.
        top_n: Number of top configurations to return for each mode (agg/disagg). Default is 5.
        save_dir: Directory to save results. If None, results are not saved to disk.
        generator_set: List of inline generator overrides in KEY=VALUE format (e.g.,
            ``["rule=benchmark", "ServiceConfig.model_path=Qwen/Qwen3-32B-FP8"]``).
            Equivalent to repeating ``--generator-set`` on the CLI.
        generator_config: Path to a unified generator YAML config file.
        generator_dynamo_version: Override Dynamo version used by the generator.
        attention_backend: Attention kernel-lane override ('fa3', 'triton',
            'trtllm_mha', 'flashinfer', 'fla', or 'default'). None uses the
            framework default for the target system/backend version.
        engine_step_backend: Engine-step backend; "rust" (the compiled engine,
            default and only executor) is the only accepted value.
        forward_model: Forward-pass modeling mode ("op_level" or "fpm"). None keeps the default.

    Returns:
        CLIResult with chosen experiment, best configs, pareto fronts, and throughputs.

    Example:
        >>> result = cli_default(
        ...     model_path="Qwen/Qwen3-32B",
        ...     total_gpus=8,
        ...     system="h200_sxm",
        ...     ttft=2000,
        ...     tpot=30,
        ... )
        >>> print(result.chosen_exp)  # 'agg' or 'disagg'
        >>> print(result.best_throughputs)

        >>> # Use benchmark rule plugin for generator
        >>> result = cli_default(
        ...     model_path="Qwen/Qwen3-32B-FP8",
        ...     total_gpus=8,
        ...     system="h200_sxm",
        ...     save_dir="./results",
        ...     generator_set=["rule=benchmark"],
        ... )

        >>> # Compare all backends
        >>> result = cli_default(
        ...     model_path="Qwen/Qwen3-32B",
        ...     total_gpus=8,
        ...     system="h200_sxm",
        ...     backend="auto",
        ...     ttft=2000,
        ...     tpot=30,
        ... )
        >>> print(result.chosen_exp)  # e.g., 'agg_trtllm' or 'disagg_vllm'
        >>> print(result.best_throughputs)  # Shows all 6 backend/mode combinations
    """
    # Fail fast on inconsistent MTP inputs (same early check as the CLI path).
    # nextn="auto" resolves the draft depth from the checkpoint first.
    if nextn == "auto":
        nextn = _resolve_nextn_auto(model_path)
    nextn, nextn_accepted = _normalize_nextn(nextn, nextn_accepted)

    # Reuse build_default_tasks from main.py
    tasks = build_default_tasks(
        model_path=model_path,
        total_gpus=total_gpus,
        system=system,
        decode_system=decode_system,
        backend=backend,
        backend_version=backend_version,
        database_mode=database_mode,
        transfer_policy=transfer_policy,
        isl=isl,
        osl=osl,
        image_height=image_height,
        image_width=image_width,
        num_images=num_images,
        video_height=video_height,
        video_width=video_width,
        video_frames=video_frames,
        num_videos=num_videos,
        num_video_tokens=num_video_tokens,
        enable_encoder_dp=enable_encoder_dp,
        enable_epd=enable_epd,
        encoder_tp=encoder_tp,
        encoder_system=encoder_system,
        encoder_latency_correction=encoder_latency_correction,
        ttft=ttft,
        tpot=tpot,
        request_latency=request_latency,
        prefix=prefix,
        nextn=nextn,
        nextn_accepted=nextn_accepted,
        free_gpu_memory_fraction=free_gpu_memory_fraction,
        max_seq_len=max_seq_len,
        attention_backend=attention_backend,
        engine_step_backend=engine_step_backend,
        forward_model=forward_model,
    )

    result = _execute_and_wrap_result(tasks, mode="default", top_n=top_n, strict_sla=strict_sla)
    if not result.best_configs:
        raise NoFeasibleConfigError("No feasible configurations found for the given parameters.")

    if save_dir:
        # Create a mock args object for save_results compatibility
        class _MockArgs:
            pass

        mock_args = _MockArgs()
        mock_args.save_dir = save_dir
        mock_args.mode = "default"
        mock_args.model_path = model_path
        mock_args.total_gpus = total_gpus
        mock_args.system = system
        mock_args.backend = backend
        mock_args.isl = isl
        mock_args.osl = osl
        mock_args.image_height = image_height
        mock_args.image_width = image_width
        mock_args.num_images = num_images
        mock_args.video_height = video_height
        mock_args.video_width = video_width
        mock_args.video_frames = video_frames
        mock_args.num_videos = num_videos
        mock_args.num_video_tokens = num_video_tokens
        mock_args.ttft = ttft
        mock_args.tpot = tpot
        mock_args.request_latency = request_latency
        mock_args.top_n = top_n
        mock_args.generated_config_version = None
        mock_args.generator_set = generator_set
        mock_args.generator_config = generator_config
        mock_args.generator_dynamo_version = generator_dynamo_version

        save_results(
            args=mock_args,
            best_configs=result.best_configs,
            pareto_fronts=result.pareto_fronts,
            tasks=result.tasks,
            save_dir=save_dir,
            generated_backend_version=None,
        )

    return result


_MAX_GPUS_PER_WORKER = 64


def _build_recommend_tasks(base_tasks: dict, total_gpus: int) -> dict:
    """Scale GPU candidates for recommend mode."""
    import dataclasses

    num_gpu_candidates = [1 << i for i in range(total_gpus.bit_length()) if (1 << i) <= total_gpus]

    rebuilt = {}
    for name, task in base_tasks.items():
        overrides = {
            "total_gpus": total_gpus,
            "agg_num_gpu_candidates": num_gpu_candidates,
        }
        if task.serving_mode == "disagg":
            overrides.update(
                prefill_num_gpu_candidates=num_gpu_candidates,
                decode_num_gpu_candidates=num_gpu_candidates,
            )
        rebuilt[name] = dataclasses.replace(task, **overrides)
    return rebuilt


def cli_recommend(
    model_path: str,
    system: str,
    *,
    target_request_rate: float | None = None,
    target_concurrency: float | None = None,
    decode_system: str | None = None,
    backend: str = "trtllm",
    backend_version: str | None = None,
    database_mode: str = "HYBRID",
    transfer_policy: str | list | None = None,
    isl: int = 4000,
    osl: int = 1000,
    image_height: int = 0,
    image_width: int = 0,
    num_images: int = 1,
    video_height: int = 0,
    video_width: int = 0,
    video_frames: int = 0,
    num_videos: int = 0,
    num_video_tokens: int = 0,
    ttft: float = 2000.0,
    tpot: float = 30.0,
    request_latency: float | None = None,
    prefix: int = 0,
    nextn: int | str | None = None,
    nextn_accepted: float | None = None,
    strict_sla: bool = False,
    enable_chunked_prefill: bool = False,
    free_gpu_memory_fraction: float | None = None,
    max_seq_len: int | None = None,
    enable_wideep: bool = False,
    moe_backend: str | None = None,
    attention_backend: str | None = None,
    top_n: int = 5,
    save_dir: str | None = None,
    engine_step_backend: str | None = None,
    forward_model: str | None = None,
) -> CLIResult:
    """Find the minimum number of GPUs to meet a performance target.

    This is the programmatic equivalent of:
        aiconfigurator cli recommend --model-path ... --system ... --target-request-rate ...

    Inverts the default mode: instead of 'given GPUs, find best config',
    this answers 'given performance targets, find minimum GPUs'.  Designed
    as a procurement sizing tool — the output is unconstrained.

    The function sweeps all valid per-worker parallelism configurations and
    uses :func:`pick_load_match` to compute the replica count needed to
    serve the target load under the given SLA constraints.

    Exactly one of ``target_request_rate`` or ``target_concurrency`` must
    be provided.

    Args:
        model_path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or local path.
        system: System name (GPU type), e.g., 'h200_sxm', 'b200_sxm'.
        target_request_rate: Target system request rate in req/s.
        target_concurrency: Target number of concurrent requests.
        decode_system: System name for disagg decode workers. Defaults to ``system``.
        backend: Backend name ('trtllm', 'sglang', 'vllm', 'auto').
        backend_version: Backend database version. Default is latest.
        database_mode: Database mode ('SILICON', 'HYBRID', 'EMPIRICAL', 'SOL').
        transfer_policy: Fine-grained HYBRID/EMPIRICAL transfer control.
        isl: Input sequence length. Default is 4000.
        osl: Output sequence length. Default is 1000.
        image_height: Image height for vision-language models.
        image_width: Image width for vision-language models.
        num_images: Number of images per request.
        video_height: Video frame height for vision-language models.
        video_width: Video frame width for vision-language models.
        video_frames: Number of frames per video.
        num_videos: Number of videos per request. Images and videos must be
            estimated separately until mixed visual packing is modeled.
        num_video_tokens: Explicit post-merge tokens per video. Requires
            ``video_frames`` so temporal attention sequences can be modeled.
        ttft: Time to first token SLA target in ms. Default is 2000.
        tpot: Time per output token SLA target in ms. Default is 30.
        request_latency: Optional end-to-end request latency target (ms).
        prefix: Prefix cache length.
        nextn: MTP draft length, or 'auto' to resolve the depth from the
            checkpoint, falling back to DSPARK architecture metadata. Omitted
            or 0 keeps speculative decoding disabled unless a DSPARK model is
            paired with an explicit ``nextn_accepted`` workload measurement.
        nextn_accepted: Average accepted draft tokens per decode step
            (0 <= nextn_accepted <= nextn). Required when the draft depth
            resolves to > 0.
        strict_sla: When True, filter to SLA-compliant configs only.
        enable_chunked_prefill: Enable chunked prefill for finer context sweep.
        free_gpu_memory_fraction: Fraction of free GPU memory for KV cache.
        max_seq_len: TRT-LLM max_seq_len setting.
        enable_wideep: Enable Wide Expert Parallelism for MoE models.
        moe_backend: Explicit SGLang MoE backend override.
        attention_backend: Attention kernel-lane override ('fa3', 'triton',
            'trtllm_mha', 'flashinfer', 'fla', or 'default'). Supported values
            depend on the backend's collected tables (e.g. vllm supports
            'triton', 'flashinfer', and 'default'); an unsupported
            (backend, value) pair raises. None (default) uses the framework
            default for the target system/backend version.
        top_n: Number of top configurations to return per mode. Default is 5.
        save_dir: Directory to save results. If None, results are not saved.
        engine_step_backend: Engine-step backend; "rust" (the compiled engine,
            default and only executor) is the only accepted value.
        forward_model: Forward-pass modeling mode ("op_level" or "fpm").
            None keeps the default.

    Returns:
        CLIResult with best configs containing ``total_gpus_needed`` and
        ``replicas_needed`` columns, ranked by fewest GPUs first.

    Example:
        >>> result = cli_recommend(
        ...     model_path="Qwen/Qwen3-32B",
        ...     system="h200_sxm",
        ...     target_request_rate=50.0,
        ...     ttft=2000,
        ...     tpot=30,
        ... )
        >>> print(result.best_configs)
    """
    import math

    from aisimulate.sdk.perf_database import load_system_spec

    has_rate = target_request_rate is not None
    has_conc = target_concurrency is not None
    if has_rate == has_conc:
        raise ValueError("Exactly one of target_request_rate or target_concurrency must be provided.")
    load_target = target_request_rate if has_rate else target_concurrency
    if not (math.isfinite(load_target) and load_target > 0):
        raise ValueError(f"Load target must be a positive finite number, got {load_target}.")

    spec = load_system_spec(system)
    gpus_per_node = spec["node"]["num_gpus_per_node"]

    # Fail fast on inconsistent MTP inputs (same early check as cli_default).
    # Explicit "auto" resolves the checkpoint depth first and falls back to
    # DSPARK's architectural block size. An omitted nextn may use that DSPARK
    # depth only when the caller supplied an explicit workload acceptance
    # measurement. Explicit nextn=0 always remains the opt-out.
    if nextn == "auto":
        nextn = _resolve_nextn_auto(model_path)
        if nextn == 0:
            nextn = _resolve_dspark_nextn(model_path) or 0
    elif nextn is None:
        nextn = _resolve_dspark_nextn(model_path) if nextn_accepted is not None else 0

    nextn, nextn_accepted = _normalize_nextn(nextn, nextn_accepted)

    base_tasks = build_default_tasks(
        model_path=model_path,
        total_gpus=gpus_per_node,
        system=system,
        decode_system=decode_system,
        backend=backend,
        backend_version=backend_version,
        database_mode=database_mode,
        transfer_policy=transfer_policy,
        isl=isl,
        osl=osl,
        image_height=image_height,
        image_width=image_width,
        num_images=num_images,
        video_height=video_height,
        video_width=video_width,
        video_frames=video_frames,
        num_videos=num_videos,
        num_video_tokens=num_video_tokens,
        ttft=ttft,
        tpot=tpot,
        request_latency=request_latency,
        prefix=prefix,
        nextn=nextn,
        nextn_accepted=nextn_accepted,
        enable_chunked_prefill=enable_chunked_prefill,
        free_gpu_memory_fraction=free_gpu_memory_fraction,
        max_seq_len=max_seq_len,
        engine_step_backend=engine_step_backend,
        forward_model=forward_model,
        enable_wideep=enable_wideep,
        moe_backend=moe_backend,
        attention_backend=attention_backend,
    )

    # Build escalation sequence: gpus_per_node, *2, *4, *8, capped at _MAX_GPUS_PER_WORKER.
    budgets = [gpus_per_node]
    budget = gpus_per_node * 2
    while budget <= _MAX_GPUS_PER_WORKER:
        budgets.append(budget)
        budget *= 2

    result = None
    for attempt, gpu_budget in enumerate(budgets):
        tasks = _build_recommend_tasks(base_tasks, gpu_budget)
        result = _execute_and_wrap_result(
            tasks,
            mode="default",
            top_n=top_n,
            strict_sla=strict_sla,
            target_request_rate=target_request_rate,
            target_concurrency=target_concurrency,
            parallel_experiments=True,
        )
        retriable = [
            name
            for name, outcome in result.outcomes.items()
            if outcome.error is not None and is_gpu_retriable(outcome.error)
        ]
        if not retriable or attempt == len(budgets) - 1:
            break
        logger.info(
            "Recommend: %s may fit at larger budget; escalating to %d.",
            ", ".join(retriable),
            budgets[attempt + 1],
        )

    if not result.best_configs:
        raise NoFeasibleConfigError("No feasible GPU configuration found for the given load target.")

    if save_dir:

        class _MockArgs:
            pass

        mock_args = _MockArgs()
        mock_args.save_dir = save_dir
        mock_args.mode = "recommend"
        mock_args.model_path = model_path
        mock_args.total_gpus = 0
        mock_args.system = system
        mock_args.backend = backend
        mock_args.isl = isl
        mock_args.osl = osl
        mock_args.image_height = image_height
        mock_args.image_width = image_width
        mock_args.num_images = num_images
        mock_args.video_height = video_height
        mock_args.video_width = video_width
        mock_args.video_frames = video_frames
        mock_args.num_videos = num_videos
        mock_args.num_video_tokens = num_video_tokens
        mock_args.ttft = ttft
        mock_args.tpot = tpot
        mock_args.request_latency = request_latency
        mock_args.top_n = top_n
        mock_args.generated_config_version = None
        mock_args.generator_set = None
        mock_args.generator_config = None
        mock_args.generator_dynamo_version = None

        save_results(
            args=mock_args,
            best_configs=result.best_configs,
            pareto_fronts=result.pareto_fronts,
            tasks=result.tasks,
            save_dir=save_dir,
            generated_backend_version=None,
        )

    return result


def cli_exp(
    *,
    yaml_path: str | None = None,
    config: dict[str, dict] | None = None,
    attention_backend: str | None = None,
    top_n: int = 5,
    save_dir: str | None = None,
) -> CLIResult:
    """
    Run multiple experiments defined by YAML file or dict config.

    This is the programmatic equivalent of:
        aiconfigurator cli exp --yaml-path experiments.yaml

    You must provide either `yaml_path` or `config`, but not both.

    Args:
        yaml_path: Path to a YAML file containing experiment definitions.
        config: Dict containing experiment definitions (alternative to yaml_path).
            Keys are experiment names, values are experiment configs.
        attention_backend: Optional global attention kernel-lane override
            ('fa3', 'triton', 'trtllm_mha', 'flashinfer', 'fla', or 'default'),
            applied to every experiment. Per-experiment ``attention_backend``
            entries in the YAML/config take precedence.
        top_n: Number of top configurations to return for each experiment. Default is 5.
        save_dir: Directory to save results. If None, results are not saved to disk.

    Returns:
        CLIResult with chosen experiment, best configs, pareto fronts, and throughputs.

    Example (from YAML file):
        >>> result = cli_exp(yaml_path="experiments.yaml")

    Example (from dict config):
        >>> result = cli_exp(config={
        ...     "agg_qwen3": {
        ...         "serving_mode": "agg",
        ...         "model_path": "Qwen/Qwen3-32B",
        ...         "system_name": "h200_sxm",
        ...         "backend_name": "trtllm",
        ...         "total_gpus": 8,
        ...         "isl": 4000,
        ...         "osl": 1000,
        ...         "ttft": 2000,
        ...         "tpot": 30,
        ...     },
        ...     "disagg_qwen3": {
        ...         "serving_mode": "disagg",
        ...         "model_path": "Qwen/Qwen3-32B",
        ...         "system_name": "h200_sxm",
        ...         "backend_name": "trtllm",
        ...         "total_gpus": 16,
        ...         "isl": 4000,
        ...         "osl": 1000,
        ...         "ttft": 2000,
        ...         "tpot": 30,
        ...     },
        ... })
        >>> print(result.chosen_exp)
        >>> print(result.best_throughputs)

    YAML file format example:
        exps:  # Optional: defines execution order
          - agg_qwen3
          - disagg_qwen3

        agg_qwen3:
          serving_mode: agg
          model_path: Qwen/Qwen3-32B
          system_name: h200_sxm
          backend_name: trtllm
          total_gpus: 8
          isl: 4000
          osl: 1000

        disagg_qwen3:
          serving_mode: disagg
          model_path: Qwen/Qwen3-32B
          system_name: h200_sxm
          backend_name: trtllm
          total_gpus: 16
    """
    tasks = build_experiment_tasks(
        yaml_path=yaml_path,
        config=config,
        attention_backend=attention_backend,
    )

    if not tasks:
        raise ValueError("No valid experiments found in configuration.")

    result = _execute_and_wrap_result(tasks, mode="exp", top_n=top_n)
    if not result.best_configs:
        raise NoFeasibleConfigError("No feasible configurations found for the given experiments.")

    if save_dir:
        # Create a mock args object for save_results compatibility
        class _MockArgs:
            pass

        mock_args = _MockArgs()
        mock_args.save_dir = save_dir
        mock_args.mode = "exp"
        mock_args.yaml_path = yaml_path
        mock_args.top_n = top_n
        mock_args.generated_config_version = None

        save_results(
            args=mock_args,
            best_configs=result.best_configs,
            pareto_fronts=result.pareto_fronts,
            tasks=result.tasks,
            save_dir=save_dir,
            generated_backend_version=None,
        )

    return result


@dataclass
class EstimateResult:
    """Result from running a single-point performance estimate."""

    ttft: float
    """Time to first token (ms)."""

    tpot: float
    """Time per output token (ms)."""

    power_w: float | None
    """End-to-end weighted average power per GPU, or ``None`` when coverage is insufficient."""

    isl: int
    """Input sequence length used."""

    osl: int
    """Output sequence length used."""

    batch_size: int
    """Batch size used."""

    ctx_tokens: int
    """Context tokens budget for IFB scheduling."""

    tp_size: int
    """Tensor parallelism degree."""

    pp_size: int
    """Pipeline parallelism degree."""

    model_path: str
    """Model path used."""

    system_name: str
    """System name used."""

    backend_name: str
    """Backend name used."""

    backend_version: str
    """Backend version used."""

    raw: dict
    """Full result dict from the InferenceSummary."""

    mode: str = "agg"
    """Estimation mode: 'agg', 'disagg', 'static', 'static_ctx', or 'static_gen'."""

    summary: object | None = None
    """The underlying :class:`InferenceSummary`.

    Populated for static and agg modes. ``None`` for disagg (which uses its
    own DisaggInferenceSession.run_disagg pipeline and does not expose a
    single summary object with per-op breakdowns at the API boundary).
    """

    per_ops_data: dict | None = None
    """Per-operation latency breakdown (populated when available)."""

    per_ops_source: dict | None = None
    """Per-operation data source breakdown, parallel to ``per_ops_data``.

    Same nested shape as ``per_ops_data`` (one entry per op_name in each
    step), but values are source tags rather than latencies. Example::

        {
            "mix_step": {
                "context_attention (scaled)": "mixed",
                "context_full_moe":           "empirical",
                "context_qkv_gemm":           "silicon",
                ...
            },
            "genonly_step": {
                "generation_attention": "empirical",
                "generation_qkv_gemm":  "silicon",
                ...
            },
        }

    Values include ``"silicon"`` (table data), ``"empirical"`` (formula
    fallback), ``"sol"`` (explicit SOL estimate), ``"estimated"`` (modeled
    from measured components), and ``"mixed"`` (a sum of values from different
    sources). The ``scheduling`` section of ``per_ops_data`` is intentionally
    omitted here -- those entries are scheduling math / aggregate sums, not DB
    queries.
    """

    kv_cache_warning: str | None = None
    """Warning message for non-fatal memory capacity issues."""

    moe_comm_fallbacks: tuple[MoECommFallback, ...] = ()
    """Executed MoE communication topology substitutions.

    Populated only when the Rust operator successfully used a measured
    topology in place of the requested topology.
    """

    @property
    def request_latency(self) -> float:
        """End-to-end request latency (ms)."""
        return self.raw.get("request_latency", 0.0)

    @property
    def tokens_per_second(self) -> float:
        """Total output throughput (tokens/s)."""
        return self.raw.get("tokens/s", 0.0)

    @property
    def tokens_per_second_per_gpu(self) -> float:
        """Per-GPU output throughput (tokens/s/gpu)."""
        return self.raw.get("tokens/s/gpu", 0.0)

    @property
    def tokens_per_second_per_user(self) -> float:
        """Per-user output throughput (tokens/s/user)."""
        return self.raw.get("tokens/s/user", 0.0)

    @property
    def concurrency(self) -> float:
        """Effective concurrency (requests in flight)."""
        return self.raw.get("concurrency", 0.0)

    @property
    def seq_per_second(self) -> float:
        """Sequence throughput (seq/s)."""
        return self.raw.get("seq/s", 0.0)

    @property
    def num_total_gpus(self) -> int:
        """Total GPUs used by the parallelism config."""
        return int(self.raw.get("num_total_gpus", 0))

    @property
    def memory(self) -> float:
        """Estimated GPU memory usage (GB).

        For disagg mode there is no single memory value; use
        ``raw["(p)memory"]`` and ``raw["(d)memory"]`` instead.
        """
        if self.mode == "disagg":
            return 0.0
        return self.raw.get("memory", 0.0)

    @property
    def power_coverage(self) -> float | None:
        """Latency-weighted fraction of operations backed by power data."""
        coverage = self.raw.get("power_coverage")
        return float(coverage) if coverage is not None else None

    @property
    def power_is_available(self) -> bool:
        """Whether ``power_w`` passed the minimum data-coverage gate."""
        return self.power_w is not None

    def get(self) -> dict:
        """
        Return all metrics as a dict matching the CSV column schema.

        Includes ``tokens/s/gpu_cluster`` (equals ``tokens/s/gpu`` for
        single-point estimates where only one replica group is evaluated).

        Verified by ``tests/e2e/cli/test_cli_estimate_vs_default.py`` which
        asserts that the returned keys and values match the
        ``best_config_topn.csv`` output from ``cli_default``.
        """
        result = dict(self.raw)
        if "tokens/s/gpu_cluster" not in result:
            result["tokens/s/gpu_cluster"] = result.get("tokens/s/gpu", 0.0)
        return result

    def __repr__(self) -> str:
        power = f"{self.power_w:.1f}W" if self.power_w is not None else "unavailable"
        return (
            f"EstimateResult(mode={self.mode!r}, ttft={self.ttft:.3f}ms, tpot={self.tpot:.3f}ms, "
            f"power={power}, model={self.model_path}, "
            f"system={self.system_name}, backend={self.backend_name})"
        )


def _apply_power_coverage_gate(summary, result_dict: dict) -> dict:
    """Hide modeled power when measured-energy coverage is incomplete.

    Latency, throughput, and memory remain valid and are returned unchanged.
    The raw result records the exact coverage ratio so callers can explain why
    power is unavailable without treating the whole estimate as failed.
    """
    gated = dict(result_dict)
    gated["power_coverage"] = summary.get_power_data_coverage()
    return apply_row_power_coverage_gate(gated)


def apply_row_power_coverage_gate(row: dict) -> dict:
    """Hide ``power_w`` when ``power_coverage`` is missing, non-finite, or
    below the coverage threshold (fail-closed)."""
    import math

    gated = dict(row)
    coverage = gated.get("power_coverage")
    if (
        not isinstance(coverage, (int, float))
        or not math.isfinite(coverage)
        or coverage < POWER_DATA_COVERAGE_THRESHOLD
    ):
        gated["power_w"] = None
    return gated


def _resolve_moe_parallelism(
    tp_size: int,
    attention_dp_size: int,
    moe_tp_size: int | None,
    moe_ep_size: int | None,
    model_path: str | None = None,
) -> tuple[int, int]:
    """Resolve and validate MoE parallelism widths, returning (moe_tp_size, moe_ep_size).

    For dense (non-MoE) models, MoE parallelism has no effect on the
    computation, so leave the fields as provided.
    """
    if model_path is not None and not check_is_moe(model_path):
        return moe_tp_size, moe_ep_size

    cfg = ModelConfig(
        tp_size=tp_size,
        attention_dp_size=attention_dp_size,
        moe_tp_size=moe_tp_size,
        moe_ep_size=moe_ep_size,
    )
    return cfg.resolve_moe_parallelism()


def cli_estimate(
    model_path: str,
    system_name: str,
    *,
    mode: str = "agg",
    backend_name: str = "trtllm",
    backend_version: str | None = None,
    database_mode: str = "SILICON",
    transfer_policy: str | list | None = None,
    isl: int = 1024,
    osl: int = 1024,
    image_height: int = 0,
    image_width: int = 0,
    num_images: int = 1,
    video_height: int = 0,
    video_width: int = 0,
    video_frames: int = 0,
    num_videos: int = 0,
    num_video_tokens: int = 0,
    enable_encoder_dp: bool = True,
    batch_size: int = 128,
    ctx_tokens: int | None = None,
    tp_size: int = 1,
    pp_size: int = 1,
    attention_dp_size: int = 1,
    moe_tp_size: int | None = None,
    moe_ep_size: int | None = None,
    gemm_quant_mode: str | None = None,
    kvcache_quant_mode: str | None = None,
    fmha_quant_mode: str | None = None,
    moe_quant_mode: str | None = None,
    comm_quant_mode: str | None = None,
    # Disagg-specific parameters (ignored when mode='agg')
    decode_system_name: str | None = None,
    prefill_tp_size: int | None = None,
    prefill_pp_size: int | None = None,
    prefill_attention_dp_size: int | None = None,
    prefill_moe_tp_size: int | None = None,
    prefill_moe_ep_size: int | None = None,
    prefill_batch_size: int | None = None,
    prefill_num_workers: int | None = None,
    decode_tp_size: int | None = None,
    decode_pp_size: int | None = None,
    decode_attention_dp_size: int | None = None,
    decode_moe_tp_size: int | None = None,
    decode_moe_ep_size: int | None = None,
    decode_batch_size: int | None = None,
    decode_num_workers: int | None = None,
    systems_paths: str | None = None,
    free_gpu_memory_fraction: float | None = None,
    prefill_free_gpu_memory_fraction: float | None = None,
    decode_free_gpu_memory_fraction: float | None = None,
    max_seq_len: int | None = None,
    prefill_max_seq_len: int | None = None,
    decode_max_seq_len: int | None = None,
    engine_step_backend: str | None = None,
    forward_model: str | None = None,
    attention_backend: str | None = None,
    # Static-mode (and shared) extras
    prefix: int = 0,
    nextn: int | str = 0,
    nextn_accepted: float | None = None,
    speculative: dict | None = None,
    stride: int = 32,
) -> EstimateResult:
    """
    Estimate TTFT, TPOT, and power for a single model/system/config combination.

    Supports aggregated (IFB), disaggregated, and static-batching estimation.

    This is the programmatic equivalent of:
        aiconfigurator cli estimate --model-path ... --system ... --batch-size ...

    Args:
        model_path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or local path.
        system_name: System name (GPU type), e.g., 'h200_sxm', 'h100_sxm'.
        mode: Estimation mode — 'agg' (default), 'disagg', or one of the
            static modes ``'static'`` / ``'static_ctx'`` / ``'static_gen'``.
            Static modes run a single-pass ``InferenceSession.run_static`` (no
            IFB scheduling, no rate matching) and are useful for first-order
            latency/memory breakdowns.
        backend_name: Backend name ('trtllm', 'sglang', 'vllm'). Default is 'trtllm'.
        backend_version: Backend database version. Default is latest.
        database_mode: Database mode for performance estimation
            ('SILICON', 'HYBRID', 'EMPIRICAL', 'SOL'). Default is 'SILICON'.
        isl: Input sequence length. Default is 1024.
        osl: Output sequence length. Default is 1024.
        image_height: Image height in pixels for VL models. Default 0 disables encoder modeling.
        image_width: Image width in pixels for VL models. Default 0 disables encoder modeling.
        num_images: Number of images per request for VL models. Default 1.
        video_height: Video frame height for VL models. Default 0.
        video_width: Video frame width for VL models. Default 0.
        video_frames: Frames per video. Default 0 disables video modeling.
        num_videos: Number of videos per request. Default 0.
        num_video_tokens: Explicit post-merge tokens per video. Requires
            ``video_frames``. Default 0 derives tokens from video dimensions.
        enable_encoder_dp: Model the vision encoder data-parallel (default True;
            vLLM mm_encoder_tp_mode="data" / SGLang --mm-enable-dp-encoder semantics).
            False models the legacy TP-sharded encoder.
        batch_size: Batch size (max concurrent requests, used for agg mode). Default is 128.
        ctx_tokens: Context tokens budget for IFB scheduling (agg mode only).
            Default is None, which uses ``isl`` as the budget.
        tp_size: Tensor parallelism size. Default is 1. Also serves as fallback for
            prefill/decode TP when their specific args are omitted.
        pp_size: Pipeline parallelism size. Default is 1.
        attention_dp_size: Attention data parallelism size. Default is 1.
        moe_tp_size: MoE tensor parallelism size. At least one of ``moe_tp_size``
            or ``moe_ep_size`` is required for MoE models; the missing dimension
            is inferred when possible.
        moe_ep_size: MoE expert parallelism size. At least one of ``moe_tp_size``
            or ``moe_ep_size`` is required for MoE models; the missing dimension
            is inferred when possible.
        gemm_quant_mode: GEMM quantization mode. Default is None (auto-inferred).
        kvcache_quant_mode: KV cache quantization mode. Default is None (auto-inferred).
        fmha_quant_mode: FMHA quantization mode. Default is None (auto-inferred).
        moe_quant_mode: MoE quantization mode. Default is None (auto-inferred).
        comm_quant_mode: Communication quantization mode. Default is None (auto-inferred).
        decode_system_name: System for disagg decode workers. Defaults to ``system_name``.
        prefill_tp_size: Prefill TP size (disagg). Defaults to ``tp_size``.
        prefill_pp_size: Prefill PP size (disagg). Defaults to ``pp_size``.
        prefill_attention_dp_size: Prefill attention DP size (disagg). Defaults to ``attention_dp_size``.
        prefill_moe_tp_size: Prefill MoE TP size (disagg). Defaults to ``moe_tp_size``.
        prefill_moe_ep_size: Prefill MoE EP size (disagg). Defaults to ``moe_ep_size``.
        prefill_batch_size: Prefill batch size (disagg). Required when mode='disagg'.
        prefill_num_workers: Number of prefill workers (disagg). Required when mode='disagg'.
        decode_tp_size: Decode TP size (disagg). Defaults to ``tp_size``.
        decode_pp_size: Decode PP size (disagg). Defaults to ``pp_size``.
        decode_attention_dp_size: Decode attention DP size (disagg). Defaults to ``attention_dp_size``.
        decode_moe_tp_size: Decode MoE TP size (disagg). Defaults to ``moe_tp_size``.
        decode_moe_ep_size: Decode MoE EP size (disagg). Defaults to ``moe_ep_size``.
        decode_batch_size: Decode batch size (disagg). Required when mode='disagg'.
        decode_num_workers: Number of decode workers (disagg). Required when mode='disagg'.
        systems_paths: Comma-separated systems search paths. Use 'default' for built-in.
        free_gpu_memory_fraction: Fraction of free GPU memory TRT-LLM allocates for
            KV cache (default 0.9 for TRTLLM, 1.0 for other backends). Used to check whether the requested batch_size
            exceeds KV cache capacity.
        prefill_free_gpu_memory_fraction: Prefill-specific KV-cache memory
            fraction for disagg. Overrides ``free_gpu_memory_fraction`` for
            the prefill worker.
        decode_free_gpu_memory_fraction: Decode-specific KV-cache memory
            fraction for disagg. Overrides ``free_gpu_memory_fraction`` for
            the decode worker.
        max_seq_len: The TRT-LLM ``--max_seq_len`` setting used at serving time.
            Controls how many KV blocks TRT-LLM pre-allocates per sequence. Defaults
            to ``isl + osl`` when ``None``.
        prefill_max_seq_len: Prefill-specific maximum sequence length for
            disagg. Overrides ``max_seq_len`` for the prefill worker.
        decode_max_seq_len: Decode-specific maximum sequence length for
            disagg. Overrides ``max_seq_len`` for the decode worker.
        engine_step_backend: Engine-step backend; "rust" (the compiled engine,
            default and only executor) is the only accepted value.
        attention_backend: Attention kernel-lane override ('fa3', 'triton',
            'trtllm_mha', 'flashinfer', 'fla', or 'default'). Supported values
            depend on the backend's collected tables (e.g. vllm supports
            'triton', 'flashinfer', and 'default'); an unsupported
            (backend_name, value) pair raises. None (default) uses the
            framework default for the target system/backend version. Applied
            to agg, disagg, and all static modes.
        prefix: (common) Prefix cache length (subset of ``isl`` already cached).
            Applied to agg, disagg, and all static modes. Default 0.
        nextn: (common) MTP draft length, or ``"auto"`` to use the checkpoint's
            ``num_nextn_predict_layers``. Applied to agg, disagg, and all
            static modes. Default 0 (disabled); MTP is never enabled implicitly.
        nextn_accepted: (common) Average accepted draft tokens per decode step
            (0 <= nextn_accepted <= nextn). Required when the draft depth
            resolves to > 0; never inferred.
        speculative: Speculation mapping with method, params, optional draft_model_path
            or inline draft_config, and measured accepted_tokens. Non-MTP methods
            support agg/static modes; method="mtp" uses the legacy nextn path.
        stride: (static-only) Stride used by ``run_static`` to accelerate the
            OSL sweep. Ignored by agg / disagg. Default 32.

    Returns:
        EstimateResult with ttft, tpot, power_w, mode, and the full raw result dict.

    Example (agg):
        >>> result = cli_estimate("Qwen/Qwen3-32B", "h100_sxm", batch_size=64, isl=2048, osl=512, tp_size=2)

    Example (disagg):
        >>> result = cli_estimate(
        ...     "Qwen/Qwen3-32B", "h100_sxm", mode="disagg",
        ...     isl=2048, osl=512, tp_size=2,
        ...     prefill_batch_size=4, prefill_num_workers=2,
        ...     decode_batch_size=64, decode_num_workers=2,
        ... )
    """
    from aisimulate.sdk.backends.factory import get_backend
    from aisimulate.sdk.models import get_model
    from aisimulate.sdk.perf_database import (
        get_database_view,
        get_latest_database_version,
        get_systems_paths,
        set_systems_paths,
    )

    engine_step_backend = validate_engine_step_backend(engine_step_backend)

    # Resolve nextn="auto" against the checkpoint before mode dispatch so every
    # estimate path (agg/disagg/static) sees a plain int.
    if nextn == "auto":
        nextn = _resolve_nextn_auto(model_path)
    # A speculative: block desugars mtp onto the nextn pair; scheme-based
    # methods yield a SpeculationConfig consumed by agg/static estimation.
    speculation_config = None
    speculative_accepted = None
    if speculative is not None:
        from aisimulate.sdk.speculative import resolve_speculative_block

        resolution = resolve_speculative_block(speculative, nextn=nextn, nextn_accepted=nextn_accepted)
        nextn = resolution.nextn
        nextn_accepted = resolution.nextn_accepted
        speculation_config = resolution.speculation_config
        speculative_accepted = resolution.accepted_tokens
        if speculation_config is not None and mode not in ("agg", "static", "static_ctx", "static_gen"):
            raise NotImplementedError(
                f"scheme-based speculative methods are wired for agg/static estimation only "
                f"(got mode={mode!r}); mtp desugars to nextn and works everywhere."
            )
    nextn, nextn_accepted = _normalize_nextn(nextn, nextn_accepted)

    active_systems_paths = None
    if systems_paths is not None:
        previous_systems_paths = get_systems_paths()
        try:
            set_systems_paths(systems_paths)
            active_systems_paths = get_systems_paths()
        finally:
            set_systems_paths(previous_systems_paths)

    def _resolve_version_for(sys_name: str) -> str:
        resolved_version = backend_version
        if resolved_version is None:
            if active_systems_paths is None:
                resolved_version = get_latest_database_version(system=sys_name, backend=backend_name)
            else:
                resolved_version = get_latest_database_version(
                    system=sys_name,
                    backend=backend_name,
                    systems_paths=active_systems_paths,
                )
        if resolved_version is None:
            if database_mode == "SILICON":
                raise ValueError(
                    f"No database found for system={sys_name}, backend={backend_name}. "
                    "Check --systems-paths or available databases."
                )
            resolved_version = "estimate"
        return resolved_version

    def _load_database(sys_name: str):
        resolved_version = _resolve_version_for(sys_name)
        # database_mode is needed at construction, not just at query time: SILICON and
        # HYBRID load declared shared-layer silicon rows, while formula-only modes do not.
        database_kwargs = {
            "allow_missing_data": database_mode != "SILICON",
            "database_mode": database_mode,
            "transfer_policy": transfer_policy,
        }
        if active_systems_paths is not None:
            database_kwargs["systems_paths"] = active_systems_paths
        db = get_database_view(
            sys_name,
            backend_name,
            resolved_version,
            **database_kwargs,
        )
        if db is None:
            raise ValueError(
                f"Failed to load perf database for system={sys_name}, "
                f"backend={backend_name}, version={resolved_version}."
            )
        return db

    if mode in ("static", "static_ctx", "static_gen"):
        resolved_version = _resolve_version_for(system_name)
        return _run_static_estimate(
            static_mode=mode,
            model_path=model_path,
            system_name=system_name,
            backend_name=backend_name,
            resolved_version=resolved_version,
            isl=isl,
            osl=osl,
            image_height=image_height,
            image_width=image_width,
            num_images=num_images,
            video_height=video_height,
            video_width=video_width,
            video_frames=video_frames,
            num_videos=num_videos,
            num_video_tokens=num_video_tokens,
            enable_encoder_dp=enable_encoder_dp,
            batch_size=batch_size,
            prefix=prefix,
            tp_size=tp_size,
            pp_size=pp_size,
            attention_dp_size=attention_dp_size,
            moe_tp_size=moe_tp_size,
            moe_ep_size=moe_ep_size,
            gemm_quant_mode=gemm_quant_mode,
            kvcache_quant_mode=kvcache_quant_mode,
            fmha_quant_mode=fmha_quant_mode,
            moe_quant_mode=moe_quant_mode,
            comm_quant_mode=comm_quant_mode,
            nextn=nextn,
            nextn_accepted=nextn_accepted,
            speculation_config=speculation_config,
            speculative_accepted=speculative_accepted,
            stride=stride,
            engine_step_backend=engine_step_backend,
            forward_model=forward_model,
            load_database=_load_database,
            get_backend=get_backend,
            get_model=get_model,
            attention_backend=attention_backend,
        )

    if mode == "agg":
        resolved_version = _resolve_version_for(system_name)
        return _run_agg_estimate(
            model_path=model_path,
            system_name=system_name,
            backend_name=backend_name,
            resolved_version=resolved_version,
            isl=isl,
            osl=osl,
            image_height=image_height,
            image_width=image_width,
            num_images=num_images,
            video_height=video_height,
            video_width=video_width,
            video_frames=video_frames,
            num_videos=num_videos,
            num_video_tokens=num_video_tokens,
            enable_encoder_dp=enable_encoder_dp,
            batch_size=batch_size,
            ctx_tokens=ctx_tokens,
            tp_size=tp_size,
            pp_size=pp_size,
            attention_dp_size=attention_dp_size,
            moe_tp_size=moe_tp_size,
            moe_ep_size=moe_ep_size,
            gemm_quant_mode=gemm_quant_mode,
            kvcache_quant_mode=kvcache_quant_mode,
            fmha_quant_mode=fmha_quant_mode,
            moe_quant_mode=moe_quant_mode,
            comm_quant_mode=comm_quant_mode,
            load_database=_load_database,
            get_backend=get_backend,
            get_model=get_model,
            free_gpu_memory_fraction=free_gpu_memory_fraction,
            max_seq_len=max_seq_len,
            engine_step_backend=engine_step_backend,
            forward_model=forward_model,
            attention_backend=attention_backend,
            prefix=prefix,
            nextn=nextn,
            nextn_accepted=nextn_accepted,
            speculation_config=speculation_config,
            speculative_accepted=speculative_accepted,
        )
    elif mode == "disagg":
        prefill_resolved_version = _resolve_version_for(system_name)
        decode_system = decode_system_name or system_name
        decode_resolved_version = _resolve_version_for(decode_system)
        resolved_version = (
            prefill_resolved_version
            if prefill_resolved_version == decode_resolved_version
            else f"{prefill_resolved_version}-{decode_resolved_version}"
        )
        # Validate required disagg params
        for name, val in [
            ("prefill_batch_size", prefill_batch_size),
            ("prefill_num_workers", prefill_num_workers),
            ("decode_batch_size", decode_batch_size),
            ("decode_num_workers", decode_num_workers),
        ]:
            if val is None:
                raise ValueError(f"{name} is required for disagg mode.")

        return _run_disagg_estimate(
            model_path=model_path,
            system_name=system_name,
            decode_system_name=decode_system,
            free_gpu_memory_fraction=free_gpu_memory_fraction,
            prefill_free_gpu_memory_fraction=prefill_free_gpu_memory_fraction,
            decode_free_gpu_memory_fraction=decode_free_gpu_memory_fraction,
            max_seq_len=max_seq_len,
            prefill_max_seq_len=prefill_max_seq_len,
            decode_max_seq_len=decode_max_seq_len,
            backend_name=backend_name,
            resolved_version=resolved_version,
            isl=isl,
            osl=osl,
            image_height=image_height,
            image_width=image_width,
            num_images=num_images,
            video_height=video_height,
            video_width=video_width,
            video_frames=video_frames,
            num_videos=num_videos,
            num_video_tokens=num_video_tokens,
            enable_encoder_dp=enable_encoder_dp,
            # Prefill config (fall back to shared args)
            prefill_tp_size=prefill_tp_size if prefill_tp_size is not None else tp_size,
            prefill_pp_size=prefill_pp_size if prefill_pp_size is not None else pp_size,
            prefill_attention_dp_size=prefill_attention_dp_size
            if prefill_attention_dp_size is not None
            else attention_dp_size,
            prefill_moe_tp_size=prefill_moe_tp_size if prefill_moe_tp_size is not None else moe_tp_size,
            prefill_moe_ep_size=prefill_moe_ep_size if prefill_moe_ep_size is not None else moe_ep_size,
            prefill_batch_size=prefill_batch_size,
            prefill_num_workers=prefill_num_workers,
            # Decode config (fall back to shared args)
            decode_tp_size=decode_tp_size if decode_tp_size is not None else tp_size,
            decode_pp_size=decode_pp_size if decode_pp_size is not None else pp_size,
            decode_attention_dp_size=decode_attention_dp_size
            if decode_attention_dp_size is not None
            else attention_dp_size,
            decode_moe_tp_size=decode_moe_tp_size if decode_moe_tp_size is not None else moe_tp_size,
            decode_moe_ep_size=decode_moe_ep_size if decode_moe_ep_size is not None else moe_ep_size,
            decode_batch_size=decode_batch_size,
            decode_num_workers=decode_num_workers,
            # Shared quant
            gemm_quant_mode=gemm_quant_mode,
            kvcache_quant_mode=kvcache_quant_mode,
            fmha_quant_mode=fmha_quant_mode,
            moe_quant_mode=moe_quant_mode,
            comm_quant_mode=comm_quant_mode,
            load_database=_load_database,
            get_backend=get_backend,
            get_model=get_model,
            engine_step_backend=engine_step_backend,
            forward_model=forward_model,
            attention_backend=attention_backend,
            prefix=prefix,
            nextn=nextn,
            nextn_accepted=nextn_accepted,
        )
    elif mode == "afd":
        raise ValueError(
            "mode='afd' is no longer served by the legacy compatibility CLI. AFD runs "
            "through the unified CLI: `aisimulate recommend` with an `workers.<role>.afd` block, "
            "then `aisimulate predict` on the selected recommendation."
        )
    else:
        raise ValueError(
            f"Unsupported estimate mode: {mode!r}. Use 'agg', 'disagg', 'static', 'static_ctx', or 'static_gen'."
        )


def _run_agg_estimate(
    *,
    model_path,
    system_name,
    backend_name,
    resolved_version,
    isl,
    osl,
    image_height,
    image_width,
    num_images,
    video_height,
    video_width,
    video_frames,
    num_videos,
    num_video_tokens,
    enable_encoder_dp,
    batch_size,
    ctx_tokens,
    tp_size,
    pp_size,
    attention_dp_size,
    moe_tp_size,
    moe_ep_size,
    gemm_quant_mode,
    kvcache_quant_mode,
    fmha_quant_mode,
    moe_quant_mode,
    comm_quant_mode,
    load_database,
    get_backend,
    get_model,
    free_gpu_memory_fraction=None,
    max_seq_len=None,
    engine_step_backend=None,
    forward_model=None,
    attention_backend: str | None = None,
    speculation_config=None,
    speculative_accepted: float | None = None,
    # Common (also accepted by disagg / static)
    prefix: int = 0,
    nextn: int = 0,
    nextn_accepted: float | None = None,
) -> EstimateResult:
    """Run aggregated (IFB) estimation."""
    from aisimulate.sdk.backends.base_backend import BaseBackend
    from aisimulate.sdk.config import RuntimeConfig
    from aisimulate.sdk.inference_session import InferenceSession

    moe_tp_size, moe_ep_size = _resolve_moe_parallelism(
        tp_size, attention_dp_size, moe_tp_size, moe_ep_size, model_path=model_path
    )

    model_config = _build_model_config(
        tp_size,
        pp_size,
        attention_dp_size,
        moe_tp_size,
        moe_ep_size,
        gemm_quant_mode,
        kvcache_quant_mode,
        fmha_quant_mode,
        moe_quant_mode,
        comm_quant_mode,
        forward_model=forward_model,
        enable_encoder_dp=enable_encoder_dp,
        attention_backend=attention_backend,
        speculation=speculation_config,
    )
    _apply_nextn(model_config, nextn)
    # Agg workers run context attention → resolve fmha against the perf data
    # before building the model (mirrors the sweep/task_v2 path).
    resolve_context_fmha_by_data(
        model_config, model_path, load_database(system_name), backend_name, is_context_role=True
    )
    resolve_dsv4_moe_arch(model_config, model_path, system_name=system_name, backend_name=backend_name)
    resolve_nvfp4_for_system(model_config, system_name, model_path, backend_name=backend_name)
    runtime_config = RuntimeConfig(
        isl=isl,
        osl=osl,
        batch_size=batch_size,
        image_height=image_height,
        image_width=image_width,
        num_images_per_request=num_images,
        video_height=video_height,
        video_width=video_width,
        video_frames=video_frames,
        num_videos_per_request=num_videos,
        num_video_tokens=num_video_tokens,
        prefix=prefix,
        engine_step_backend=engine_step_backend,
    )

    model = get_model(model_path, model_config, backend_name)
    if ctx_tokens is None:
        ctx_tokens = isl + BaseBackend._visual_context_tokens(model, runtime_config)
    database = load_database(system_name)
    backend = get_backend(backend_name, system_name, system_spec=getattr(database, "system_spec", None))
    session = InferenceSession(model, database, backend)
    if speculation_config is not None:
        speculative_profile = SpeculativeDecodingProfile.from_scheme(model.spec_scheme, speculative_accepted)
    else:
        speculative_profile = SpeculativeDecodingProfile.from_inputs(nextn, nextn_accepted)
    summary = session.run_agg(
        runtime_config,
        ctx_tokens=ctx_tokens,
        max_seq_len=max_seq_len,
        free_gpu_memory_fraction=free_gpu_memory_fraction,
        decode_tokens_per_iteration=speculative_profile.tokens_per_iteration,
    )
    summary = speculative_profile.project_summary(summary, role="agg")

    if summary.check_oom():
        raise RuntimeError(
            f"OOM: the model '{model_path}' does not fit in GPU memory on system '{system_name}' "
            f"with the given parallelism (tp={tp_size}, pp={pp_size}, dp={attention_dp_size}). "
            "Try increasing tp_size/pp_size, using a quantized model, or "
            "using a system with more VRAM per GPU."
        )

    result_dict = summary.get_result_dict()
    if result_dict is None:
        raise RuntimeError("Estimation produced no results. The configuration may be invalid.")
    result_dict = _apply_power_coverage_gate(summary, result_dict)

    kv_warning = None
    if summary.check_kv_cache_oom():
        frac_str = str(free_gpu_memory_fraction) if free_gpu_memory_fraction is not None else "backend default"
        kv_warning = (
            f"Requested batch_size ({batch_size}) exceeds estimated KV cache capacity "
            f"(free_gpu_memory_fraction={frac_str}). "
            "The serving runtime will queue excess requests, causing significantly higher TTFT and inaccurate TPOT."
        )

    return EstimateResult(
        ttft=result_dict["ttft"],
        tpot=result_dict["tpot"],
        power_w=result_dict.get("power_w", 0.0),
        isl=isl,
        osl=osl,
        batch_size=batch_size,
        ctx_tokens=ctx_tokens,
        tp_size=tp_size,
        pp_size=pp_size,
        model_path=model_path,
        system_name=system_name,
        backend_name=backend_name,
        backend_version=resolved_version,
        raw=result_dict,
        mode="agg",
        summary=summary,
        per_ops_data=summary.get_per_ops_data(),
        per_ops_source=summary.get_per_ops_source(),
        moe_comm_fallbacks=summary.get_moe_comm_fallbacks(),
        kv_cache_warning=kv_warning,
    )


def _run_static_estimate(
    *,
    static_mode: str,
    model_path,
    system_name,
    backend_name,
    resolved_version,
    isl,
    osl,
    image_height,
    image_width,
    num_images,
    video_height,
    video_width,
    video_frames,
    num_videos,
    num_video_tokens,
    enable_encoder_dp,
    batch_size,
    prefix,
    tp_size,
    pp_size,
    attention_dp_size,
    moe_tp_size,
    moe_ep_size,
    gemm_quant_mode,
    kvcache_quant_mode,
    fmha_quant_mode,
    moe_quant_mode,
    comm_quant_mode,
    nextn,
    nextn_accepted,
    stride,
    engine_step_backend,
    load_database,
    get_backend,
    get_model,
    forward_model=None,
    attention_backend: str | None = None,
    speculation_config=None,
    speculative_accepted: float | None = None,
) -> EstimateResult:
    """Run a single-pass static-batching estimation.

    Wraps :meth:`InferenceSession.run_static` and produces an ``EstimateResult``
    whose ``raw`` dict follows :data:`aisimulate.sdk.common.ColumnsStatic`.
    """
    from aisimulate.sdk.config import RuntimeConfig
    from aisimulate.sdk.inference_session import InferenceSession

    if static_mode not in ("static", "static_ctx", "static_gen"):
        raise ValueError(
            f"Unsupported static mode: {static_mode!r}. Expected one of 'static', 'static_ctx', 'static_gen'."
        )

    moe_tp_size, moe_ep_size = _resolve_moe_parallelism(
        tp_size, attention_dp_size, moe_tp_size, moe_ep_size, model_path=model_path
    )

    model_config = _build_model_config(
        tp_size,
        pp_size,
        attention_dp_size,
        moe_tp_size,
        moe_ep_size,
        gemm_quant_mode,
        kvcache_quant_mode,
        fmha_quant_mode,
        moe_quant_mode,
        comm_quant_mode,
        forward_model=forward_model,
        enable_encoder_dp=enable_encoder_dp,
        attention_backend=attention_backend,
        speculation=speculation_config,
    )
    _apply_nextn(model_config, nextn)
    database = load_database(system_name)

    if check_is_moe(model_path):
        required_phases = ("context",) if static_mode == "static_ctx" else ("context", "generation")
        resolve_model_config_moe_comm(
            model_config,
            model_path=model_path,
            backend_name=backend_name,
            database=database,
            required_phases=required_phases,
            fmha_quant_mode_explicit=fmha_quant_mode is not None,
            kvcache_quant_mode_explicit=kvcache_quant_mode is not None,
        )

    # static / static_ctx run context attention; static_gen is generation-only
    # and legitimately keeps fp8 FMHA. A resolved large-EP tuple already owns
    # its WideEP MLA quant labels; the generic narrow-attention guard must not
    # reinterpret those labels as an explicit user request.
    if model_config.moe_comm_backend is None:
        resolve_context_fmha_by_data(
            model_config,
            model_path,
            database,
            backend_name,
            is_context_role=static_mode != "static_gen",
        )

    resolve_dsv4_moe_arch(model_config, model_path, system_name=system_name, backend_name=backend_name)
    resolve_nvfp4_for_system(model_config, system_name, model_path, backend_name=backend_name)

    runtime_config = RuntimeConfig(
        batch_size=batch_size,
        isl=isl,
        osl=osl,
        image_height=image_height,
        image_width=image_width,
        num_images_per_request=num_images,
        video_height=video_height,
        video_width=video_width,
        video_frames=video_frames,
        num_videos_per_request=num_videos,
        num_video_tokens=num_video_tokens,
        prefix=prefix,
        engine_step_backend=engine_step_backend,
    )

    model = get_model(model_path, model_config, backend_name)
    backend = get_backend(backend_name, system_name, system_spec=getattr(database, "system_spec", None))
    session = InferenceSession(model, database, backend)
    summary = session.run_static(
        runtime_config=runtime_config,
        mode=static_mode,
        stride=stride,
    )
    projection_role = (
        "prefill" if static_mode == "static_ctx" else ("decode" if static_mode == "static_gen" else "static")
    )
    if speculation_config is not None:
        profile = SpeculativeDecodingProfile.from_scheme(model.spec_scheme, speculative_accepted)
    else:
        profile = SpeculativeDecodingProfile.from_inputs(nextn, nextn_accepted)
    summary = profile.project_summary(summary, role=projection_role)

    static_warning = None
    if summary.check_oom():
        static_warning = (
            f"OOM: the model '{model_path}' does not fit in GPU memory on system "
            f"'{system_name}' with the given parallelism (tp={tp_size}, pp={pp_size}, "
            f"dp={attention_dp_size}) and batch_size={batch_size}. Reduce batch_size, "
            "increase tp/pp, use quantization, or pick a system with more VRAM per GPU."
        )

    result_dict = summary.get_result_dict()
    if result_dict is None:
        raise RuntimeError("Static estimation produced no results. The configuration may be invalid.")
    result_dict = _apply_power_coverage_gate(summary, result_dict)

    return EstimateResult(
        ttft=float(result_dict.get("ttft", 0.0) or 0.0),
        tpot=float(result_dict.get("tpot", 0.0) or 0.0),
        power_w=result_dict.get("power_w"),
        isl=isl,
        osl=osl,
        batch_size=batch_size,
        ctx_tokens=isl,  # static has no IFB budget; expose isl for convenience.
        tp_size=tp_size,
        pp_size=pp_size,
        model_path=model_path,
        system_name=system_name,
        backend_name=backend_name,
        backend_version=resolved_version,
        raw=result_dict,
        mode=static_mode,
        summary=summary,
        per_ops_data=None,
        per_ops_source=None,
        moe_comm_fallbacks=summary.get_moe_comm_fallbacks(),
        kv_cache_warning=static_warning,
    )


def _run_disagg_estimate(
    *,
    model_path,
    system_name,
    decode_system_name,
    backend_name,
    resolved_version,
    isl,
    osl,
    image_height,
    image_width,
    num_images,
    video_height,
    video_width,
    video_frames,
    num_videos,
    num_video_tokens,
    enable_encoder_dp,
    prefill_tp_size,
    prefill_pp_size,
    prefill_attention_dp_size,
    prefill_moe_tp_size,
    prefill_moe_ep_size,
    prefill_batch_size,
    prefill_num_workers,
    decode_tp_size,
    decode_pp_size,
    decode_attention_dp_size,
    decode_moe_tp_size,
    decode_moe_ep_size,
    decode_batch_size,
    decode_num_workers,
    gemm_quant_mode,
    kvcache_quant_mode,
    fmha_quant_mode,
    moe_quant_mode,
    comm_quant_mode,
    load_database,
    get_backend,
    get_model,
    engine_step_backend=None,
    forward_model=None,
    attention_backend: str | None = None,
    # Common (also accepted by agg / static)
    prefix: int = 0,
    nextn: int = 0,
    nextn_accepted: float | None = None,
    free_gpu_memory_fraction: float | None = None,
    prefill_free_gpu_memory_fraction: float | None = None,
    decode_free_gpu_memory_fraction: float | None = None,
    max_seq_len: int | None = None,
    prefill_max_seq_len: int | None = None,
    decode_max_seq_len: int | None = None,
) -> EstimateResult:
    """Run disaggregated estimation."""
    from aisimulate.sdk.config import RuntimeConfig
    from aisimulate.sdk.inference_session import DisaggInferenceSession

    # Resolve MoE parallelism for prefill and decode separately
    p_moe_tp, p_moe_ep = _resolve_moe_parallelism(
        prefill_tp_size,
        prefill_attention_dp_size,
        prefill_moe_tp_size,
        prefill_moe_ep_size,
        model_path=model_path,
    )
    d_moe_tp, d_moe_ep = _resolve_moe_parallelism(
        decode_tp_size,
        decode_attention_dp_size,
        decode_moe_tp_size,
        decode_moe_ep_size,
        model_path=model_path,
    )

    prefill_model_config = _build_model_config(
        prefill_tp_size,
        prefill_pp_size,
        prefill_attention_dp_size,
        p_moe_tp,
        p_moe_ep,
        gemm_quant_mode,
        kvcache_quant_mode,
        fmha_quant_mode,
        moe_quant_mode,
        comm_quant_mode,
        forward_model=forward_model,
        enable_encoder_dp=enable_encoder_dp,
        attention_backend=attention_backend,
    )
    decode_model_config = _build_model_config(
        decode_tp_size,
        decode_pp_size,
        decode_attention_dp_size,
        d_moe_tp,
        d_moe_ep,
        gemm_quant_mode,
        kvcache_quant_mode,
        fmha_quant_mode,
        moe_quant_mode,
        comm_quant_mode,
        forward_model=forward_model,
        enable_encoder_dp=enable_encoder_dp,
        attention_backend=attention_backend,
    )
    # Apply common nextn/MTP overrides to *both* prefill and decode worker
    # configs so a single ``--nextn N`` reaches each side of the disagg pair.
    _apply_nextn(prefill_model_config, nextn)
    _apply_nextn(decode_model_config, nextn)

    prefill_database = load_database(system_name)
    decode_database = load_database(decode_system_name)
    if check_is_moe(model_path):
        resolve_model_config_moe_comm(
            prefill_model_config,
            model_path=model_path,
            backend_name=backend_name,
            database=prefill_database,
            required_phases=("context",),
            fmha_quant_mode_explicit=fmha_quant_mode is not None,
            kvcache_quant_mode_explicit=kvcache_quant_mode is not None,
        )
        resolve_model_config_moe_comm(
            decode_model_config,
            model_path=model_path,
            backend_name=backend_name,
            database=decode_database,
            required_phases=("generation",),
            fmha_quant_mode_explicit=fmha_quant_mode is not None,
            kvcache_quant_mode_explicit=kvcache_quant_mode is not None,
        )

    # Prefill runs context attention → resolve fmha against the perf data. Decode
    # is generation-only and keeps fp8, so it needs no adjustment. A resolved
    # large-EP tuple owns its WideEP attention labels and must not be rewritten
    # by the generic narrow-attention fallback.
    if prefill_model_config.moe_comm_backend is None:
        resolve_context_fmha_by_data(
            prefill_model_config, model_path, prefill_database, backend_name, is_context_role=True
        )
    resolve_dsv4_moe_arch(prefill_model_config, model_path, system_name=system_name, backend_name=backend_name)
    resolve_nvfp4_for_system(prefill_model_config, system_name, model_path, backend_name=backend_name)
    resolve_dsv4_moe_arch(
        decode_model_config,
        model_path,
        system_name=decode_system_name or system_name,
        backend_name=backend_name,
    )
    resolve_nvfp4_for_system(
        decode_model_config,
        decode_system_name or system_name,
        model_path,
        backend_name=backend_name,
    )

    runtime_config = RuntimeConfig(
        isl=isl,
        osl=osl,
        image_height=image_height,
        image_width=image_width,
        num_images_per_request=num_images,
        video_height=video_height,
        video_width=video_width,
        video_frames=video_frames,
        num_videos_per_request=num_videos,
        num_video_tokens=num_video_tokens,
        prefix=prefix,
        engine_step_backend=engine_step_backend,
    )

    prefill_backend = get_backend(backend_name)
    decode_backend = get_backend(backend_name)

    session = DisaggInferenceSession(
        prefill_database=prefill_database,
        prefill_backend=prefill_backend,
        decode_database=decode_database,
        decode_backend=decode_backend,
    )
    session.set_latency_correction_scales(
        DEFAULT_PREFILL_LATENCY_CORRECTION_SCALE,
        DEFAULT_DECODE_LATENCY_CORRECTION_SCALE,
    )

    summary = session.run_disagg(
        model_path=model_path,
        runtime_config=runtime_config,
        prefill_model_config=prefill_model_config,
        prefill_batch_size=prefill_batch_size,
        prefill_num_worker=prefill_num_workers,
        decode_model_config=decode_model_config,
        decode_batch_size=decode_batch_size,
        decode_num_worker=decode_num_workers,
        speculative_profile=SpeculativeDecodingProfile.from_inputs(nextn, nextn_accepted),
        free_gpu_memory_fraction=free_gpu_memory_fraction,
        prefill_free_gpu_memory_fraction=prefill_free_gpu_memory_fraction,
        decode_free_gpu_memory_fraction=decode_free_gpu_memory_fraction,
        max_seq_len=max_seq_len,
        prefill_max_seq_len=prefill_max_seq_len,
        decode_max_seq_len=decode_max_seq_len,
    )

    if summary.check_oom():
        oom_details = []
        if decode_system_name != system_name:
            oom_details.append(f"prefill system '{system_name}' or decode system '{decode_system_name}'")
        else:
            oom_details.append(f"system '{system_name}'")
        raise RuntimeError(
            f"OOM: the model '{model_path}' does not fit in GPU memory on {oom_details[0]} "
            f"with the given parallelism. "
            "Try increasing tp_size/pp_size, using a quantized model, or "
            "using a system with more VRAM per GPU."
        )

    result_dict = summary.get_result_dict()
    if result_dict is None:
        raise RuntimeError("Disagg estimation produced no results. The configuration may be invalid.")
    result_dict = _apply_power_coverage_gate(summary, result_dict)

    return EstimateResult(
        ttft=result_dict["ttft"],
        tpot=result_dict["tpot"],
        power_w=result_dict.get("power_w", 0.0),
        isl=isl,
        osl=osl,
        batch_size=prefill_batch_size,
        ctx_tokens=0,
        tp_size=prefill_tp_size,
        pp_size=prefill_pp_size,
        model_path=model_path,
        system_name=system_name,
        backend_name=backend_name,
        backend_version=resolved_version,
        raw=result_dict,
        mode="disagg",
        per_ops_data=summary.get_per_ops_data(),
        per_ops_source=summary.get_per_ops_source(),
        moe_comm_fallbacks=summary.get_moe_comm_fallbacks(),
    )


# Re-export generate_naive_config as cli_generate for consistency
# This is already a clean Python function in generator.api
from aisimulate.generator.api import generate_naive_config as cli_generate

__all__ = [
    "CLIResult",
    "EstimateResult",
    "cli_default",
    "cli_estimate",
    "cli_exp",
    "cli_generate",
    "cli_recommend",
    "cli_support",
]
