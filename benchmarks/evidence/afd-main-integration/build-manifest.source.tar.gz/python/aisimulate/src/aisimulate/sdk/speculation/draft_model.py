# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
# Includes changes adapted from:
# https://github.com/ai-dynamo/aiconfigurator/blob/6290c161a354da5250c391bd43372b2e9c6f4a51/src/aiconfigurator/sdk/speculation/draft_model.py

"""Compatibility alias for aisimulate_core.sdk.speculation.draft_model."""

from aisimulate.sdk._compat import alias_module as _alias_module

_alias_module(__name__, "aisimulate_core.sdk.speculation.draft_model")
