# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Lower a ranked AISimulate Sweeper candidate into ``GeneratorRequest``.

The Sweeper owns search and ranking. The generator owns deterministic lowering
and artifact rendering. This module is the deliberately small boundary between
those components: it consumes the public, JSON-shaped candidate contract and
does not import Sweeper or Dynamo implementation types.
"""

from __future__ import annotations

import copy
import math
from collections.abc import Mapping
from dataclasses import asdict, is_dataclass, replace
from typing import Any

from ..context_parallel import ContextParallelUnsupportedError, context_parallel_params
from .schema import (
    BackendSpec,
    EmitTargets,
    GeneratorRequest,
    ModelFacts,
    ModelSpec,
    Overrides,
    Platform,
    RoleSizing,
    SlaSpec,
    Topology,
)


class SweeperCandidateError(ValueError):
    """A candidate cannot be represented faithfully by the generator."""


_DEFAULT_GPU_MEMORY_UTILIZATION = {
    "sglang": 0.88,
    "trtllm": 0.9,
    "vllm": 0.9,
}


def _as_mapping(value: Any, *, label: str) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return copy.deepcopy(dict(value))
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(mode="json")
        if isinstance(dumped, Mapping):
            return copy.deepcopy(dict(dumped))
    if is_dataclass(value) and not isinstance(value, type):
        dumped = asdict(value)
        if isinstance(dumped, Mapping):
            return copy.deepcopy(dict(dumped))
    raise SweeperCandidateError(f"{label} must be a mapping or a serializable model")


def _required_text(config: Mapping[str, Any], key: str) -> str:
    value = config.get(key)
    if not isinstance(value, str) or not value.strip():
        raise SweeperCandidateError(f"candidate.config.{key} is required")
    return value.strip()


def _role_hardware_sku(config: Mapping[str, Any], role: str, *, fallback: str) -> str:
    key = f"{role}_hardware_sku"
    value = config.get(key)
    if value is None:
        return fallback
    if not isinstance(value, str) or not value.strip():
        raise SweeperCandidateError(f"candidate.config.{key} must be nonempty when provided")
    return value.strip()


def _positive_int(value: Any, *, path: str) -> int:
    if isinstance(value, bool):
        raise SweeperCandidateError(f"{path} must be a positive integer")
    try:
        normalized = int(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise SweeperCandidateError(f"{path} must be a positive integer") from exc
    if normalized <= 0 or normalized != value:
        raise SweeperCandidateError(f"{path} must be a positive integer")
    return normalized


def _positive_float(value: Any, *, path: str) -> float:
    if isinstance(value, bool):
        raise SweeperCandidateError(f"{path} must be a positive number")
    try:
        normalized = float(value)
    except (TypeError, ValueError) as exc:
        raise SweeperCandidateError(f"{path} must be a positive number") from exc
    if not math.isfinite(normalized) or normalized <= 0:
        raise SweeperCandidateError(f"{path} must be a positive number")
    return normalized


def _flatten_overrides(overrides: Mapping[str, Any] | None) -> dict[str, Any]:
    """Accept CLI-shaped nested sections or the request's flat raw form."""

    raw: dict[str, Any] = {}
    for key, value in (overrides or {}).items():
        if isinstance(value, Mapping) and "." not in key:
            for child_key, child_value in value.items():
                raw[f"{key}.{child_key}"] = copy.deepcopy(child_value)
        else:
            raw[key] = copy.deepcopy(value)
    return raw


def _role_sizing(
    config: Mapping[str, Any],
    role: str,
    *,
    backend: str,
    backend_version: str,
    architecture: str | None = None,
) -> tuple[RoleSizing, int]:
    prefix = "" if role == "agg" else f"{role}_"

    tp = _positive_int(config.get(f"{prefix}tp"), path=f"candidate.config.{prefix}tp")
    pp = _positive_int(config.get(f"{prefix}pp"), path=f"candidate.config.{prefix}pp")
    dp = _positive_int(
        config.get(f"{prefix}attention_dp"),
        path=f"candidate.config.{prefix}attention_dp",
    )
    moe_tp = _positive_int(
        config.get(f"{prefix}moe_tp"),
        path=f"candidate.config.{prefix}moe_tp",
    )
    moe_ep = _positive_int(
        config.get(f"{prefix}moe_ep"),
        path=f"candidate.config.{prefix}moe_ep",
    )
    # Context-parallel knobs are optional columns: prefill CP (``cp``) adds
    # attention ranks, decode CP (``dcp``) stripes KV inside the TP group.
    cp = _positive_int(config.get(f"{prefix}cp", 1), path=f"candidate.config.{prefix}cp")
    dcp = _positive_int(config.get(f"{prefix}dcp", 1), path=f"candidate.config.{prefix}dcp")
    workers_key = "replicas" if role == "agg" else f"{role}_replicas"
    workers = _positive_int(config.get(workers_key), path=f"candidate.config.{workers_key}")

    max_batch_size = _positive_int(
        config.get(f"{role}_max_num_seqs"),
        path=f"candidate.config.{role}_max_num_seqs",
    )
    max_num_tokens = _positive_int(
        config.get(f"{role}_max_num_batched_tokens"),
        path=f"candidate.config.{role}_max_num_batched_tokens",
    )
    tokens_per_block = config.get(f"{role}_block_size")
    if tokens_per_block is not None:
        tokens_per_block = _positive_int(tokens_per_block, path=f"candidate.config.{role}_block_size")
    memory_path = f"candidate.config.{role}_gpu_memory_utilization"
    blocks_path = f"candidate.config.{role}_num_gpu_blocks"
    memory_value = config.get(f"{role}_gpu_memory_utilization")
    blocks_value = config.get(f"{role}_num_gpu_blocks")
    if memory_value is not None and blocks_value is not None:
        raise SweeperCandidateError(f"{memory_path} and {blocks_path} are mutually exclusive")

    try:
        cp_params = context_parallel_params(
            backend=backend,
            backend_version=backend_version,
            context_parallel_size=cp,
            decode_context_parallel_size=dcp,
            architecture=architecture,
        )
    except ContextParallelUnsupportedError as exc:
        raise SweeperCandidateError(f"candidate.config.{prefix}cp/dcp: {exc}") from exc

    extra: dict[str, Any] = {
        # Prefill CP ranks are extra GPUs; decode CP reuses the TP ranks.
        "gpus_per_worker": tp * pp * dp * cp,
        "max_num_tokens": max_num_tokens,
        "disable_prefix_cache": not bool(config.get(f"{role}_enable_prefix_caching")),
        **cp_params,
    }
    # An unset block size delegates selection to the backend at startup.
    if tokens_per_block is not None:
        extra["tokens_per_block"] = tokens_per_block
    if blocks_value is not None:
        num_gpu_blocks = _positive_int(blocks_value, path=blocks_path)
        extra["num_gpu_blocks"] = num_gpu_blocks
        if backend in {"sglang", "trtllm"}:
            # These backends accept a token capacity, so converting a block
            # count requires known geometry rather than a simulation default.
            if tokens_per_block is None:
                raise SweeperCandidateError(
                    f"candidate.config.{role}_block_size is required to convert {blocks_path} "
                    f"to a token capacity for {backend}; the runtime block size is unknown"
                )
            extra["kv_cache_max_tokens"] = num_gpu_blocks * tokens_per_block
    else:
        if memory_value is None:
            memory_value = _DEFAULT_GPU_MEMORY_UTILIZATION.get(backend)
            if memory_value is None:
                raise SweeperCandidateError(
                    f"{memory_path} is required because backend {backend!r} has no default GPU memory utilization"
                )
        memory_fraction = _positive_float(memory_value, path=memory_path)
        if memory_fraction > 1:
            raise SweeperCandidateError(f"{memory_path} must be at most 1")
        extra["kv_cache_free_gpu_memory_fraction"] = memory_fraction
    context_key = "context_length" if role == "agg" else f"{role}_context_length"
    role_context_length = config.get(context_key)
    selected_context_key = context_key if role_context_length is not None else "context_length"
    context_length = role_context_length if role_context_length is not None else config.get("context_length")
    if context_length is not None:
        extra["max_seq_len"] = _positive_int(context_length, path=f"candidate.config.{selected_context_key}")

    return (
        RoleSizing(
            tensor_parallel_size=tp,
            pipeline_parallel_size=pp,
            data_parallel_size=dp,
            moe_tensor_parallel_size=moe_tp,
            moe_expert_parallel_size=moe_ep,
            max_batch_size=max_batch_size,
            extra=extra,
        ),
        workers,
    )


def _map_adapters(config: Mapping[str, Any], raw: dict[str, Any]) -> None:
    adapters = config.get("adapters") or {}
    if not isinstance(adapters, Mapping):
        raise SweeperCandidateError("candidate.config.adapters must be a mapping")

    seen: set[str] = set()
    for provider_name, provider_config in adapters.items():
        if not isinstance(provider_name, str) or not provider_name:
            raise SweeperCandidateError("candidate adapter names must be non-empty strings")
        if not isinstance(provider_config, Mapping):
            raise SweeperCandidateError(f"candidate adapter {provider_name!r} must contain a configuration mapping")
        payload = copy.deepcopy(dict(provider_config))
        feature = provider_name.rsplit(".", 1)[-1].replace("-", "_")
        target = {
            "router": "router_config",
            "planner": "planner_config",
            "kvbm": "kvbm_config",
        }.get(feature)
        if target is None:
            if payload:
                raise SweeperCandidateError(f"candidate adapter {provider_name!r} has no generator mapping")
            continue
        if target in seen:
            raise SweeperCandidateError(f"multiple candidate adapters map to DynConfig.{target}")
        seen.add(target)
        if feature == "planner":
            planner_enabled = bool(payload.get("enable_throughput_scaling") or payload.get("enable_load_scaling"))
            if not planner_enabled:
                continue
            # Dynamo's provider adds the selected preset name for result
            # reporting. The runtime hook intentionally excludes that field.
            payload.pop("scaling_policy", None)
        raw[f"DynConfig.{target}"] = payload
        if feature == "router":
            raw["DynConfig.enable_router"] = True
            if payload.get("mode") is not None:
                raw["DynConfig.router_mode"] = payload["mode"]


def _resolve_model_facts(model_path: str, config: Mapping[str, Any]) -> ModelFacts:
    try:
        from aisimulate.sdk.models import check_is_moe
        from aisimulate.sdk.utils import get_model_config_from_model_path

        model_info = get_model_config_from_model_path(model_path)
        is_moe = check_is_moe(model_path, model_info=model_info)
    except Exception as exc:
        raise SweeperCandidateError(
            f"could not resolve generator model facts for {model_path!r}; pass model_facts explicitly"
        ) from exc
    return ModelFacts(
        is_moe=bool(is_moe),
        nextn=config.get("aic_nextn"),
        architecture=model_info.get("architecture"),
    )


def _is_trace_workload(workload: Mapping[str, Any]) -> bool:
    return bool(workload.get("trace_path") or workload.get("trace_paths")) or workload.get("source_type") == "trace"


def _request_lengths(workload: Mapping[str, Any], raw: Mapping[str, Any]) -> tuple[int | None, int | None]:
    """Return the workload's fixed ISL/OSL, or ``(None, None)`` for a trace.

    A trace has no single request length. Any length supplied for one would be
    a placeholder that rules could size generated fields from, so it is
    rejected and the request's SLA stays absent.
    """
    if _is_trace_workload(workload):
        supplied = [
            name
            for name, value in (
                ("workload.isl", workload.get("isl")),
                ("workload.osl", workload.get("osl")),
                ("SlaConfig.isl", raw.get("SlaConfig.isl")),
                ("SlaConfig.osl", raw.get("SlaConfig.osl")),
            )
            if value is not None
        ]
        if supplied:
            raise SweeperCandidateError(f"a trace workload has no fixed request length; remove {', '.join(supplied)}")
        return None, None

    # A present None is a missing length, so it must not hide an override.
    isl = workload.get("isl")
    osl = workload.get("osl")
    if isl is None:
        isl = raw.get("SlaConfig.isl")
    if osl is None:
        osl = raw.get("SlaConfig.osl")
    if isl is None or osl is None:
        raise SweeperCandidateError(
            "a synthetic workload must provide isl and osl (or set SlaConfig.isl/osl overrides)"
        )
    return _positive_int(isl, path="workload.isl"), _positive_int(osl, path="workload.osl")


def from_sweeper_candidate(
    candidate: Any,
    *,
    workload: Any | None = None,
    deployment_target: str = "dynamo-j2",
    output_dir: str | None = None,
    environment_profile: str | None = None,
    generator_overrides: Mapping[str, Any] | None = None,
    model_facts: ModelFacts | None = None,
) -> GeneratorRequest:
    """Build a generator request from one ranked Sweeper candidate.

    ``candidate`` may be the public Pydantic ``Candidate`` or its JSON mapping.
    ``workload`` should be the matching Sweeper workload (or a mapping containing
    ``isl``/``osl``). A trace workload is lowered without request lengths.
    Cluster-specific values remain generator overrides or an environment
    profile; evaluated engine and adapter choices always win.
    """

    candidate_payload = _as_mapping(candidate, label="candidate")
    config_value = candidate_payload.get("config", candidate_payload)
    config = _as_mapping(config_value, label="candidate.config")

    if config.get("speculation") is not None:
        raise SweeperCandidateError("ngram deployment generation is unsupported; use the saved prediction YAML")

    if not config.get("afd_roles") and (
        config.get("encoder") is not None or config.get("deployment_artifact_generation_supported") is False
    ):
        raise SweeperCandidateError("EPD deployment generation is unsupported; cannot drop the encoder pool")
    mode = _required_text(config, "deployment_mode")
    if config.get("afd_roles"):
        raise SweeperCandidateError(
            "native deployment generation is not supported for analytical AFD candidates; "
            "pass the concrete recommendation to 'aisimulate predict' to produce "
            "afd-replay-spec.json and afd-qualification.json"
        )
    if mode not in {"agg", "disagg"}:
        raise SweeperCandidateError(f"candidate.config.deployment_mode must be 'agg' or 'disagg', got {mode!r}")
    workload_payload = _as_mapping(workload, label="workload")
    model_path = _required_text(config, "model_name")
    backend = _required_text(config, "backend")
    backend_version = _required_text(config, "backend_version")
    hardware_sku = _required_text(config, "hardware_sku")

    if mode == "disagg":
        role_hardware = {
            role: _role_hardware_sku(config, role, fallback=hardware_sku) for role in ("prefill", "decode")
        }
        if len(set(role_hardware.values())) != 1:
            raise SweeperCandidateError(
                "heterogeneous P/D deployment artifact generation is unsupported because the generator "
                f"has one global hardware profile; got {role_hardware}"
            )
        hardware_sku = role_hardware["prefill"]

    # Resolved before role sizing: SGLang's prefill-CP layout (--cp-strategy)
    # depends on the model architecture.
    resolved_model_facts = model_facts or _resolve_model_facts(model_path, config)

    active_roles = ("agg",) if mode == "agg" else ("prefill", "decode")
    roles: dict[str, RoleSizing] = {}
    workers: dict[str, int] = {}
    expected_gpus = 0
    for role in active_roles:
        sizing, count = _role_sizing(
            config,
            role,
            backend=backend,
            backend_version=backend_version,
            architecture=resolved_model_facts.architecture,
        )
        roles[role] = sizing
        workers[role] = count
        expected_gpus += count * int(sizing.extra["gpus_per_worker"])

    if backend == "sglang":
        # Sweeper's backend-neutral scheduler limit is the SGLang prefill
        # ceiling. Keep max_num_tokens for the evaluated candidate contract,
        # and also lower it to the generator field that renders the SGLang
        # --max-prefill-tokens flag without mutating frozen RoleSizing values.
        roles = {
            role: replace(
                sizing,
                extra={**sizing.extra, "max_prefill_tokens": sizing.extra["max_num_tokens"]},
            )
            for role, sizing in roles.items()
        }

    used_gpus = candidate_payload.get("used_gpus", config.get("used_gpus"))
    if used_gpus is not None:
        normalized_used_gpus = _positive_int(used_gpus, path="candidate.used_gpus")
        if normalized_used_gpus != expected_gpus:
            raise SweeperCandidateError(
                "candidate GPU count cannot be lowered losslessly: "
                f"used_gpus={normalized_used_gpus}, topology={expected_gpus}"
            )

    raw = _flatten_overrides(generator_overrides)
    isl, osl = _request_lengths(workload_payload, raw)
    if isl is None and deployment_target == "slurm":
        # The Slurm bundle's default operation replays one fixed ISL/OSL.
        raise SweeperCandidateError("a Slurm bundle needs a fixed request length; use a Dynamo target for a trace")

    # Evaluated facts take precedence over deployment-environment overrides.
    raw["backend"] = backend
    raw["rule"] = "benchmark"
    raw["preserve_engine_limits"] = True
    raw["NodeConfig.system_name"] = hardware_sku
    if isl is not None:
        raw["SlaConfig.isl"] = isl
        raw["SlaConfig.osl"] = osl
    concurrency = config.get("concurrency")
    if concurrency is not None:
        raw["BenchConfig.estimated_concurrency"] = _positive_int(concurrency, path="candidate.config.concurrency")
    _map_adapters(config, raw)

    candidate_nextn = config.get("aic_nextn")
    if candidate_nextn is not None and resolved_model_facts.nextn != candidate_nextn:
        resolved_model_facts = ModelFacts(
            is_moe=resolved_model_facts.is_moe,
            nextn=_positive_int(candidate_nextn, path="candidate.config.aic_nextn"),
            prefix=resolved_model_facts.prefix,
            architecture=resolved_model_facts.architecture,
            extra=copy.deepcopy(resolved_model_facts.extra),
        )
    for key, value in resolved_model_facts.extra.items():
        raw[f"ModelConfig.{key}"] = copy.deepcopy(value)
    for key in ("is_moe", "nextn", "prefix", "architecture"):
        value = getattr(resolved_model_facts, key)
        if value is not None:
            raw[f"ModelConfig.{key}"] = value
    if backend == "trtllm":
        # The benchmark rule renders the MiniMax-M3 sparse-attention keys from ModelConfig as the
        # default path does (module_bridge): TRT-LLM >= 1.3.0rc29 needs `algorithm` to build the M3
        # KV-cache manager on every SM; `implementation` is the SM100-family prescription.
        from aisimulate.generator.utils import msa_sparse_algorithm, msa_sparse_implementation

        for key, value in (
            ("msa_sparse_algorithm", msa_sparse_algorithm(backend, model_path)),
            ("msa_sparse_implementation", msa_sparse_implementation(backend, model_path, hardware_sku)),
        ):
            if value and f"ModelConfig.{key}" not in raw:
                raw[f"ModelConfig.{key}"] = value

    request = GeneratorRequest(
        model=ModelSpec(model_path=model_path),
        backend=BackendSpec(name=backend, generated_config_version=backend_version),
        topology=Topology(mode=mode, roles=roles, workers=workers),
        sla=SlaSpec(isl=isl, osl=osl),
        platform=Platform(
            hardware_profile=hardware_sku,
            environment_profile=environment_profile,
        ),
        emit=EmitTargets(
            output_dir=output_dir,
            deployment_target=deployment_target,
        ),
        model_facts=resolved_model_facts,
        overrides=Overrides(raw=raw),
    )
    errors = request.validate()
    if errors:
        raise SweeperCandidateError("invalid generator request: " + "; ".join(errors))
    return request


__all__ = ["SweeperCandidateError", "from_sweeper_candidate"]
