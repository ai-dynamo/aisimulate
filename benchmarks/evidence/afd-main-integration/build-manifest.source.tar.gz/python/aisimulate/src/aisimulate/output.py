# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Minimal durable-output contract for the unified CLI."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any, TextIO

import yaml

from .detail import format_prediction_details
from .power import format_power_summary

if TYPE_CHECKING:
    from .sweeper.result import SweepResult

_RECOMMENDATION_NAME = re.compile(r"^[0-9]{4}\.yaml$")
_COMPACT_JSON = json.JSONEncoder(sort_keys=True, separators=(",", ":"))


def prepare_output_directory(path: str | Path, *, overwrite: bool) -> Path:
    """Create an output directory without deleting unrelated user files."""

    root = Path(path)
    if root.exists() and not root.is_dir():
        raise ValueError(f"output path {root} exists and is not a directory")
    if root.exists() and any(root.iterdir()) and not overwrite:
        raise ValueError(f"output directory {root} is not empty; pass --overwrite to replace known AISimulate outputs")
    root.mkdir(parents=True, exist_ok=True)
    if overwrite:
        for name in (
            "prediction.json",
            "report.html",
            "fpm-coverage.json",
            "recommendation.json",
            "recommendation.csv",
            "requests.jsonl",
            "telemetry-requests.jsonl",
            "telemetry-samples.jsonl",
            "telemetry-lifecycle.jsonl",
            "resource-plan.json",
            "resource-runtime.json",
            "execution-events.jsonl",
            "afd-replay-spec.json",
            "afd-qualification.json",
        ):
            target = root / name
            if target.is_file() or target.is_symlink():
                target.unlink()
        recommendations = root / "recommendations"
        if recommendations.is_dir():
            for target in recommendations.iterdir():
                if _RECOMMENDATION_NAME.fullmatch(target.name) and (target.is_file() or target.is_symlink()):
                    target.unlink()
    return root


def write_prediction_report(root: Path, report: dict[str, Any]) -> Path:
    path = root / "prediction.json"
    # json.dump writes the chunks json.dumps would join, so a large per-request
    # report is never held as one string. A failed encoding leaves no report, as before.
    try:
        with path.open("w", encoding="utf-8") as output:
            json.dump(report, output, indent=2, sort_keys=True)
            output.write("\n")
    except BaseException:
        path.unlink(missing_ok=True)
        raise
    return path


def write_fpm_coverage(root: Path, coverage: dict[str, Any]) -> Path:
    """Persist native lookup evidence even when the replay fails."""

    path = root / "fpm-coverage.json"
    path.write_text(json.dumps(coverage, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def write_requests(root: Path, records: list[dict[str, Any]]) -> Path:
    path = root / "requests.jsonl"
    with path.open("w", encoding="utf-8") as output:
        for record in records:
            output.write(json.dumps(record, sort_keys=True, separators=(",", ":")))
            output.write("\n")
    return path


def write_telemetry(root: Path, telemetry: dict[str, Any]) -> dict[str, Any]:
    """Write all-phase telemetry streams and return their compact report manifest."""

    streams = ("requests", "samples", "lifecycle")
    for stream in streams:
        records = telemetry.get(stream)
        if not isinstance(records, list) or any(not isinstance(record, dict) for record in records):
            raise ValueError(f"telemetry.{stream} must be a list of JSON mappings")
    paths = {stream: root / f"telemetry-{stream}.jsonl" for stream in streams}
    try:
        for stream, path in paths.items():
            with path.open("w", encoding="utf-8") as output:
                for record in telemetry[stream]:
                    json.dump(record, output, sort_keys=True, separators=(",", ":"), allow_nan=False)
                    output.write("\n")
    except BaseException:
        for path in paths.values():
            path.unlink(missing_ok=True)
        raise
    return {
        **{key: value for key, value in telemetry.items() if key not in streams},
        "artifacts": {stream: path.name for stream, path in paths.items()},
        "record_counts": {stream: len(telemetry[stream]) for stream in streams},
    }


def write_recommendation_result(root: Path, result: SweepResult) -> Path:
    """Write the lossless recommendation ledger and derived candidate views."""

    path = root / "recommendation.json"
    path.write_text(result.to_json() + "\n", encoding="utf-8")
    return path


def write_recommendation_csv(root: Path, result: SweepResult) -> Path:
    """Write the complete candidate ledger as an analysis-friendly CSV."""

    path = root / "recommendation.csv"
    path.write_text(result.to_csv(), encoding="utf-8")
    return path


def write_recommendations(root: Path, configs: list[Mapping[str, Any]]) -> list[Path]:
    directory = root / "recommendations"
    directory.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for index, config in enumerate(configs, start=1):
        path = directory / f"{index:04d}.yaml"
        path.write_text(
            yaml.safe_dump(
                dict(config),
                sort_keys=False,
                allow_unicode=True,
            ),
            encoding="utf-8",
        )
        paths.append(path)
    return paths


def format_prediction_stdout(
    summary: dict[str, Any],
    output_format: str,
    *,
    details: dict[str, Any] | None = None,
    power_diagnostics: dict[str, Any] | None = None,
    diagnostics_top_n: int = 12,
) -> str:
    from .replay.reporting import format_power_diagnostics, format_report_table

    if output_format == "json":
        return _COMPACT_JSON.encode(_prediction_json_payload(summary, details, power_diagnostics))
    if details is not None:
        rendered = (
            format_prediction_stdout(summary, output_format)
            + "\n\n"
            + format_prediction_details(details, energy_top_n=diagnostics_top_n)
        )
        if power_diagnostics is not None and "energy" not in details["sections"]:
            rendered += "\n\n" + format_power_diagnostics(power_diagnostics, top_n=diagnostics_top_n)
        return rendered
    if power_diagnostics is not None:
        return (
            format_prediction_stdout(summary, output_format)
            + "\n\n"
            + format_power_diagnostics(power_diagnostics, top_n=diagnostics_top_n)
        )
    provenance_lines = [
        f"KV cache ({role}): {precision['dtype']} (source: {precision['source']})"
        for role, precision in summary.get("kv_cache_precision", {}).items()
    ]
    for role, provenance in summary.get("prediction_provenance", {}).items():
        if reason := provenance.get("unavailable_reason"):
            provenance_lines.append(f"Timing ({role}): unavailable ({reason})")
            continue
        version = provenance.get("data_version")
        if version is None:
            version = f"unavailable ({provenance['data_version_unavailable_reason']})"
        provenance_lines.append(
            f"Timing ({role}): estimator={provenance['estimator']}; "
            f"source={provenance['timing_source']}; data_version={version}"
        )
    invalid_banner = ""
    if summary.get("prediction_status") == "invalid":
        invalid_banner = f"INVALID prediction ({summary['stop_reason']}): {summary['diagnostic']}\n"
    if summary.get("metric_semantics") == "analytical_epd_overlay":
        lines = ["AISimulate analytical EPD (aggregate estimates; no encoder queue simulation)"]
        for name in (
            "mean_ttft_ms",
            "mean_tpot_ms",
            "mean_e2e_latency_ms",
            "output_throughput_tok_s",
            "completed_requests",
            "duration_ms",
            "gpu_hours",
            "encoder_gpus",
            "total_gpus",
        ):
            lines.append(f"{name}: {summary.get(name, 'N/A')}")
        lines.append(format_power_summary(summary))
        lines.extend(provenance_lines)
        lines.append("duration_ms is a rate-derived accounting interval, not an EPD event timeline.")
        return invalid_banner + "\n".join(lines)

    table = invalid_banner + format_report_table(summary)
    if provenance_lines:
        table += "\n" + "\n".join(provenance_lines)
    if summary.get("agentic_qualification") == "functional_only":
        return "AgentX functional replay only; not an AgentX benchmark result.\n" + table
    return table


def write_prediction_stdout(
    output: TextIO,
    summary: dict[str, Any],
    output_format: str,
    *,
    details: dict[str, Any] | None = None,
    power_diagnostics: dict[str, Any] | None = None,
    diagnostics_top_n: int = 12,
) -> None:
    """Write format_prediction_stdout's text without building JSON output as one string."""

    if output_format == "json":
        _write_compact_json(output, _prediction_json_payload(summary, details, power_diagnostics))
        return
    output.write(
        format_prediction_stdout(
            summary,
            output_format,
            details=details,
            power_diagnostics=power_diagnostics,
            diagnostics_top_n=diagnostics_top_n,
        )
    )


def _prediction_json_payload(
    summary: dict[str, Any],
    details: dict[str, Any] | None,
    power_diagnostics: dict[str, Any] | None,
) -> dict[str, Any]:
    if power_diagnostics is not None:
        return {
            "summary": summary,
            "power_diagnostics": power_diagnostics,
            **({"details": details} if details is not None else {}),
        }
    return summary if details is None else {"summary": summary, "details": details}


def _write_compact_json(output: TextIO, value: Any, _enclosing: frozenset[int] = frozenset()) -> None:
    """Write _COMPACT_JSON.encode(value) piecewise.

    Objects are walked key by key and lists element by element, so a large
    per-request list is never one string. Every leaf and list element goes
    through the same encoder, keeping the bytes identical.
    """

    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        if id(value) in _enclosing:
            raise ValueError("Circular reference detected")
        enclosing = _enclosing | {id(value)}
        output.write("{")
        for index, key in enumerate(sorted(value)):
            if index:
                output.write(",")
            output.write(_COMPACT_JSON.encode(key))
            output.write(":")
            _write_compact_json(output, value[key], enclosing)
        output.write("}")
    elif isinstance(value, list):
        output.write("[")
        for index, item in enumerate(value):
            if index:
                output.write(",")
            output.write(_COMPACT_JSON.encode(item))
        output.write("]")
    else:
        output.write(_COMPACT_JSON.encode(value))


def format_recommendation_stdout(rows: list[dict[str, Any]], output_format: str) -> str:
    if output_format == "json":
        return json.dumps(rows, sort_keys=True, separators=(",", ":"))
    if not rows:
        return "No feasible candidate found."
    lines = ["AISimulate recommendations"]
    for row in rows:
        objective = row.get("objectives") or {"score": row.get("score")}
        metrics = ", ".join(f"{key}={value:.4g}" for key, value in objective.items())
        power = " " + format_power_summary(row)
        lines.append(f"{row['rank']}: {metrics} used_gpus={row['used_gpus']}{power} config={row['config_path']}")
    return "\n".join(lines)
