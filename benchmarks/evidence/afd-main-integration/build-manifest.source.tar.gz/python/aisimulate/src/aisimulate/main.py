# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""The single public AISimulate command-line application."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from copy import deepcopy
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from .afd_artifacts import write_afd_qualification_artifacts
from .cli_args import _apply_overrides, _CliConfigError, _extract_output_configs, _load_mapping, build_parser
from .config.cli import (
    CorePredictionConfig,
    CoreRecommendationConfig,
    prediction_mapping,
)
from .config.common import split_config_sections
from .config_adapter import (
    ConfigAdapterResolutionError,
    PredictionAdapterContext,
    SimulationConfigAdapter,
    resolve_config_adapters,
)
from .detail import build_prediction_details, energy_diagnostics
from .estimator_readiness import perf_data_missing_message
from .output import (
    format_recommendation_stdout,
    prepare_output_directory,
    write_fpm_coverage,
    write_prediction_report,
    write_prediction_stdout,
    write_recommendation_csv,
    write_recommendation_result,
    write_recommendations,
    write_requests,
    write_telemetry,
)
from .output_adapter import (
    OutputAdapterExecutionError,
    OutputAdapterResolutionError,
    resolve_output_adapters,
    write_output_adapters,
)
from .power import normalize_power_summary
from .predict import PredictionExecutionError, run_prediction
from .replay.dashboard import write_replay_dashboard
from .resources import (
    GuardedRunnerFactory,
    ResourceLimitError,
    build_plan,
    require_plan,
    workload_bounds,
)
from .stack import StackResolutionError, resolve_runner_factory
from .support.cli import run_support_command
from .sweeper.provider import AdapterReplaySpec
from .sweeper.replay import ReplayOutputRequirements


class _CliExecutionError(RuntimeError):
    pass


def _write_incomplete_fpm_coverage(root: Path, error: BaseException) -> None:
    coverage = getattr(error, "fpm_query_coverage", None)
    try:
        if isinstance(coverage, str):
            coverage = json.loads(coverage)
        if isinstance(coverage, dict):
            write_fpm_coverage(root, {**coverage, "status": "incomplete", "error": str(error)})
    except (ValueError, OSError) as write_error:
        sys.stderr.write(f"could not save FPM coverage: {write_error}\n")


class _PredictionCliRunner:
    def __init__(self, runner, output_root: Path, mark_execution_ready, mark_shutdown) -> None:
        self._runner = runner
        self._output_root = output_root
        self._mark_execution_ready = mark_execution_ready
        self._mark_shutdown = mark_shutdown

    def run(self, spec, *, output_requirements=None):
        try:
            return self._runner.run(spec, output_requirements=output_requirements)
        except BaseException as exc:
            # Persist native query evidence before close() can replace the
            # execution error.
            _write_incomplete_fpm_coverage(self._output_root, exc)
            raise

    def close(self) -> None:
        self._mark_shutdown()
        try:
            self._runner.close()
        finally:
            self._mark_execution_ready()


class _PredictionCliRunnerFactory:
    def __init__(self, factory, output_dir, overwrite, mark_execution_ready, mark_shutdown) -> None:
        self._factory = factory
        self._output_dir = output_dir
        self._overwrite = overwrite
        self._mark_execution_ready = mark_execution_ready
        self._mark_shutdown = mark_shutdown
        self.output_root: Path | None = None

    def capabilities(self):
        return self._factory.capabilities()

    def create(self, worker_id):
        self.output_root = prepare_output_directory(self._output_dir, overwrite=self._overwrite)
        runner = self._factory.create(worker_id)
        self._mark_execution_ready()
        return _PredictionCliRunner(runner, self.output_root, self._mark_execution_ready, self._mark_shutdown)


def _resolve_section_adapters(sections: dict[str, dict[str, Any]], stack: str) -> dict[str, SimulationConfigAdapter]:
    adapters = resolve_config_adapters(f"{stack}.{section}" for section in sections)
    for name, adapter in adapters.items():
        if adapter.section not in sections:
            raise ConfigAdapterResolutionError(f"config adapter {name!r} does not match a configured section")
    return adapters


def _prediction_adapter_context(
    config: CorePredictionConfig,
) -> PredictionAdapterContext:
    return PredictionAdapterContext(
        engine=config.engine.model_dump(mode="json", exclude_none=True),
        traffic=config.traffic.model_dump(mode="json", exclude_none=True),
        evaluation=config.evaluation.model_dump(mode="json", exclude_none=True),
    )


def _compile_prediction_adapters(
    configs: dict[str, dict[str, Any]],
    adapters: dict[str, SimulationConfigAdapter],
    *,
    stack: str,
    context: PredictionAdapterContext,
) -> dict[str, AdapterReplaySpec]:
    compiled: dict[str, AdapterReplaySpec] = {}
    for section, raw in configs.items():
        name = f"{stack}.{section}"
        adapter = adapters[name]
        compiled[name] = adapter.compile_prediction(raw, context)
    return compiled


def _predict(args: argparse.Namespace, raw: dict[str, Any], factory) -> int:
    core_raw, adapter_raw = split_config_sections(raw, command="predict")
    config = CorePredictionConfig.model_validate(core_raw)
    capture_telemetry = args.capture_telemetry or args.export_html
    if capture_telemetry and (args.stack != "engine" or args.online):
        raise ValueError("telemetry capture requires offline --stack engine")
    if config.traffic.load.agentic_warmup_policy != "repeated_prefixes" and (args.stack != "engine" or args.online):
        raise ValueError(f"{config.traffic.load.agentic_warmup_policy} CLI requires offline --stack engine")
    if (
        config.engine.speculation is not None
        and config.engine.speculation.kind == "ngram"
        and (args.stack != "engine" or args.online or adapter_raw)
    ):
        raise ValueError("ngram speculation requires offline --stack engine without adapters")
    if config.engine.speculation is not None and args.online:
        raise ValueError("speculation requires offline execution")
    plan = _resource_plan(args, config, factory)
    require_plan(plan)
    from .supervision import checkpoint, mark_execution_ready, mark_shutdown

    checkpoint("resource_plan", plan)
    factory = GuardedRunnerFactory(factory, args.stack, config.execution.resources)
    encoder = config.engine.workers.encoder
    if encoder is not None and (args.stack != "engine" or args.online or adapter_raw):
        raise ValueError("encoder pools require offline --stack engine without adapters")
    analytical_epd = encoder is not None and encoder.mode == "analytical"
    if analytical_epd and args.capture_per_request:
        raise ValueError("analytical EPD cannot capture per-request records")
    adapters = _resolve_section_adapters(adapter_raw, args.stack)
    factory = _PredictionCliRunnerFactory(
        factory,
        args.output_dir,
        args.overwrite,
        mark_execution_ready,
        mark_shutdown,
    )
    result = run_prediction(
        config,
        adapter_configs=adapter_raw,
        stack=args.stack,
        runner_factory=factory,
        providers=adapters,
        execution_mode="online" if args.online else "offline",
        output_requirements=ReplayOutputRequirements(
            include_raw_report=not analytical_epd,
            capture_per_request=args.capture_per_request,
            capture_telemetry=capture_telemetry,
            telemetry_sample_interval_ms=args.telemetry_sample_interval_ms,
            capture_memory_diagnostics="memory" in args.detail,
            capture_performance_diagnostics=bool({"time", "source"}.intersection(args.detail)),
        ),
    )
    root = factory.output_root
    if root is None:
        raise RuntimeError("prediction runner was not created")
    spec = result.replay_spec
    summary = result.summary
    native = result.native
    if isinstance(native.get("fpm_query_coverage"), dict):
        write_fpm_coverage(root, native["fpm_query_coverage"])
    power_diagnostics = None
    if args.diagnostics == "power":
        power_diagnostics = energy_diagnostics(native)
        native = {**native, "power_diagnostics": power_diagnostics}
    resolved_basis = native.get("weka_nested_timestamp_basis")
    if isinstance(resolved_basis, str):
        source = config.traffic.source
        requested_basis = getattr(source, "nested_timestamp_basis", None) or "auto"
        if requested_basis == "auto":
            sys.stderr.write(
                "INFO: heuristically resolved one nested timestamp basis after validating the complete "
                f"Weka corpus: requested='auto', resolved={resolved_basis!r}\n"
            )
        else:
            sys.stderr.write(
                "INFO: validated the complete Weka corpus with configured "
                f"nested_timestamp_basis requested={requested_basis!r}, resolved={resolved_basis!r}\n"
            )
    details = build_prediction_details(native, args.detail) if args.detail else None
    if details is not None:
        native = {**native, "details": details}
    if capture_telemetry:
        telemetry = native.get("telemetry")
        if not isinstance(telemetry, dict):
            raise RuntimeError("selected stack did not provide replay telemetry")
        native = {**native, "telemetry": write_telemetry(root, telemetry)}
    report_path = write_prediction_report(root, native)
    write_afd_qualification_artifacts(root, spec, memory=native.get("afd_memory"))
    if args.capture_per_request:
        records = native.get("per_request")
        if not isinstance(records, list):
            raise RuntimeError("selected stack did not provide per-request prediction records")
        if any(not isinstance(record, dict) for record in records):
            raise RuntimeError("per-request records must be JSON mappings")
        write_requests(root, records)
    phases = result.report.metadata.get("agentic_phases")
    preparation_aborted = isinstance(phases, dict) and phases.get("phase") == "aborted"
    if preparation_aborted:
        sys.stderr.write(
            f"ERROR: agentic preparation aborted: {phases.get('failure_reason') or 'preparation did not complete'}; "
            f"saved full report to: {report_path}\n"
        )
    dashboard_path = None
    if args.export_html:
        try:
            dashboard_path = write_replay_dashboard(
                root, native, telemetry, config=config.model_dump(mode="json", exclude_none=True)
            )
        except (ValueError, OSError) as exc:
            raise RuntimeError(f"HTML dashboard rendering failed; native outputs saved to {root}: {exc}") from exc
    if preparation_aborted:
        return 1
    write_prediction_stdout(
        sys.stdout,
        summary,
        args.format,
        details=details,
        power_diagnostics=power_diagnostics,
        diagnostics_top_n=args.diagnostics_top_n,
    )
    sys.stdout.write("\n")
    if args.format == "table":
        sys.stdout.write(f"Saved full report to: {report_path}\n")
        if dashboard_path is not None:
            sys.stdout.write(f"Saved dashboard to: {dashboard_path}\n")
    if summary.get("prediction_status") == "invalid":
        sys.stderr.write(f"ERROR: {summary['diagnostic']} Saved full report to: {report_path}\n")
        return 1
    return 0


def _scheduler_variant_key(candidate, concrete: dict[str, Any]) -> str | None:
    """Fold only scheduler-limit variants with identical complete predictions.

    All other inputs and reported metrics must match, not merely the score.
    The full result ledger retains every evaluated configuration.
    """
    if not candidate.metrics:
        return None
    normalized = deepcopy(concrete)
    for worker in normalized.get("engine", {}).get("workers", {}).values():
        scheduler = worker.get("scheduler", {})
        scheduler.pop("max_batched_tokens", None)
        scheduler.pop("max_sequences", None)
    return json.dumps(
        [normalized, candidate.score, candidate.objectives, candidate.metrics],
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )


def _recommend(args: argparse.Namespace, raw: dict[str, Any], factory) -> int:
    from .recommend import run_recommendation

    raw, output_configs = _extract_output_configs(raw, getattr(args, "outputs", []), stack=args.stack)
    output_adapters = resolve_output_adapters(output_configs)
    core_raw, adapter_raw = split_config_sections(raw, command="recommend")
    config = CoreRecommendationConfig.model_validate(core_raw)
    if (
        config.traffic is not None
        and config.traffic.load.agentic_warmup_policy != "repeated_prefixes"
        and args.stack != "engine"
    ):
        raise ValueError(f"{config.traffic.load.agentic_warmup_policy} CLI requires offline --stack engine")
    adapters = _resolve_section_adapters(adapter_raw, args.stack)
    result = run_recommendation(
        config,
        adapter_configs=adapter_raw,
        stack=args.stack,
        runner_factory=factory,
        providers=adapters,
        output_configs=output_configs,
        show_progress=args.format == "table",
    )
    selected: list[tuple[str, Any, dict[str, Any]]] = []
    seen_configs: set[str] = set()
    seen_variants: set[str] = set()
    folded = 0
    for candidate_id, candidate in zip(
        result.selected_candidate_ids,
        result.selected_candidates,
        strict=True,
    ):
        if candidate.prediction_config is None:
            raise RuntimeError("recommendation candidate has no concrete public config")
        candidate_core, candidate_adapters = split_config_sections(candidate.prediction_config, command="predict")
        prediction = CorePredictionConfig.model_validate(candidate_core)
        unknown_sections = set(candidate_adapters) - set(adapter_raw)
        if unknown_sections:
            raise RuntimeError(f"recommendation produced unconfigured adapter sections {sorted(unknown_sections)}")
        compiled_adapters = _compile_prediction_adapters(
            candidate_adapters,
            adapters,
            stack=args.stack,
            context=_prediction_adapter_context(prediction),
        )
        concrete = prediction_mapping(
            prediction,
            {adapters[name].section: spec.config for name, spec in compiled_adapters.items()},
        )
        config_key = json.dumps(concrete, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        if config_key in seen_configs:
            continue
        seen_configs.add(config_key)
        variant_key = _scheduler_variant_key(candidate, concrete)
        if variant_key is not None:
            if variant_key in seen_variants:
                folded += 1
                continue
            seen_variants.add(variant_key)
        selected.append((candidate_id, candidate, concrete))
    result = result.with_selected_prediction_configs(
        [(candidate_id, concrete) for candidate_id, _, concrete in selected]
    )
    root = prepare_output_directory(args.output_dir, overwrite=args.overwrite)
    result_path = write_recommendation_result(root, result)
    write_recommendation_csv(root, result)
    if folded:
        sys.stderr.write(
            f"Folded {folded} scheduler-limit variant(s) with identical predicted metrics; "
            "all evaluated candidates remain in recommendation.json and recommendation.csv\n"
        )
    if not selected:
        sys.stderr.write(f"no feasible candidate found; saved full result to: {result_path}\n")
        return 3 if getattr(result.counts, "resource_limited", 0) else 1
    paths = write_recommendations(root, [config for _, _, config in selected])
    try:
        write_output_adapters(
            output_adapters,
            output_configs,
            result=result,
            output_dir=root,
        )
    except OutputAdapterExecutionError as exc:
        raise _CliExecutionError(str(exc)) from exc
    rows = []
    for index, ((_, candidate, _), path) in enumerate(zip(selected, paths, strict=True), start=1):
        row = {
            "rank": index,
            "score": candidate.score,
            "objectives": candidate.objectives,
            "used_gpus": candidate.used_gpus,
            "config_path": str(path),
        }
        row.update(normalize_power_summary(candidate.metrics))
        rows.append(row)
    sys.stdout.write(format_recommendation_stdout(rows, args.format))
    sys.stdout.write("\n")
    if args.format == "table":
        sys.stdout.write(f"Saved full result to: {result_path}\n")
    if getattr(result.counts, "resource_limited", 0):
        sys.stderr.write("some candidates were resource-limited; saved results cover only evaluated candidates\n")
        return 3
    return 0


def _resource_plan(args, config, factory) -> dict[str, Any]:
    return build_plan(
        workload_bounds(config),
        stack=args.stack,
        policy=config.execution.resources,
        requested_parallelism=config.optimizer.parallelism if isinstance(config, CoreRecommendationConfig) else 1,
        factory=factory,
    )


def _write_resource_plan(args, plan: dict[str, Any]) -> None:
    root = prepare_output_directory(args.output_dir, overwrite=args.overwrite)
    (root / "resource-plan.json").write_text(json.dumps(plan, indent=2, allow_nan=False) + "\n")
    sys.stdout.write(json.dumps(plan, indent=2, allow_nan=False) + "\n")


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))
    if args.command == "onboard":
        try:
            return run_support_command(args)
        except (ValidationError, ValueError, OSError) as exc:
            parser.error(str(exc))
        except KeyboardInterrupt:
            return 130
    # Stack resolution deliberately precedes opening the configuration file.
    try:
        factory = resolve_runner_factory(args.stack)
    except StackResolutionError as exc:
        parser.error(str(exc))
    try:
        raw = _load_mapping(args.config)
        _apply_overrides(raw, args.overrides, command=args.command)
        if args.command == "predict":
            return _predict(args, raw, factory)
        return _recommend(args, raw, factory)
    except (
        _CliConfigError,
        ConfigAdapterResolutionError,
        OutputAdapterResolutionError,
        ValidationError,
        ValueError,
    ) as exc:
        parser.error(f"{args.config}: {exc}")
    except KeyboardInterrupt:
        return 130
    except ResourceLimitError as exc:
        sys.stderr.write(f"aisimulate {args.command}: {exc}\n")
        try:
            _write_resource_plan(args, exc.plan)
        except (OSError, ValueError) as output_error:
            sys.stderr.write(f"could not save resource plan: {output_error}\n")
        return 3
    except PredictionExecutionError as exc:
        message = perf_data_missing_message(exc) or str(exc)
        sys.stderr.write(f"aisimulate {args.command} failed: {message}\n")
        return 1
    except Exception as exc:
        sys.stderr.write(f"aisimulate {args.command} failed: {type(exc).__name__}: {exc}\n")
        return 1


if __name__ == "__main__":
    from .supervision import main as supervised_main

    raise SystemExit(supervised_main())
