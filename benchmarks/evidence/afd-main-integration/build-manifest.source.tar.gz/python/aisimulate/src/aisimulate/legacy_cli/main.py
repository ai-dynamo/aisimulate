# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
# Includes changes adapted from:
# https://github.com/ai-dynamo/aiconfigurator/blob/6290c161a354da5250c391bd43372b2e9c6f4a51/src/aiconfigurator/cli/main.py

import argparse
import logging
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import pandas as pd
import yaml

from aisimulate import __version__
from aisimulate.generator.api import (
    add_generator_override_arguments,
    generate_naive_config,
    generator_cli_helper,
    load_generator_overrides_from_args,
)
from aisimulate.legacy_cli.estimate_detail_report import (
    detail_requests_time,
    format_estimate_detail_report,
    format_moe_comm_fallback,
)
from aisimulate.legacy_cli.report_and_save import log_final_summary, save_results
from aisimulate.legacy_cli.utils import merge_experiment_results_by_mode, process_experiment_result
from aisimulate.logging_utils import setup_logging
from aisimulate.sdk import common, perf_database
from aisimulate.sdk.attention_lanes import ATTENTION_BACKEND_CHOICES
from aisimulate.sdk.config_builders import resolve_nextn_auto
from aisimulate.sdk.errors import (
    EmpiricalNotImplementedError,
    ExperimentOutcome,
    MissingSystemFlopsError,
    NoFeasibleConfigError,
    PerfDataNotAvailableError,
    SolNotImplementedError,
    is_expected_cli_error,
)
from aisimulate.sdk.performance_result import MOE_COMM_FALLBACKS_COLUMN
from aisimulate.sdk.rust_engine_step import validate_engine_step_backend
from aisimulate.sdk.speculative import normalize_speculative_decoding
from aisimulate.sdk.task_v2 import Task, _warn_large_ep_flag
from aisimulate.sdk.utils import ListFlowDumper, get_model_config_from_model_path

logger = logging.getLogger(__name__)

_SOL_DETAIL_UNAVAILABLE_ERRORS = (
    PerfDataNotAvailableError,
    EmpiricalNotImplementedError,
    MissingSystemFlopsError,
    SolNotImplementedError,
)


def _latest_support_matrix_version(
    matrix: list[dict[str, str]],
    system: str,
    backend: str,
    model: str | None = None,
    architecture: str | None = None,
    queryable_versions: set[str] | None = None,
) -> str | None:
    """Pick the highest PEP 440 version for the relevant support-matrix rows.

    Matches system and backend case-insensitively. When a model is provided,
    exact-model rows win, then architecture rows. If neither model nor
    architecture matches, return None instead of selecting an unrelated row.
    When ``queryable_versions`` is given, rows for other versions are ignored
    before model precedence applies, so an exact-model row at a stale version
    cannot hide a queryable architecture row.
    """
    rows = [
        row
        for row in matrix
        if row["System"].lower() == system.lower()
        and row["Backend"].lower() == backend.lower()
        and (queryable_versions is None or row["Version"] in queryable_versions)
    ]

    if model:
        exact_rows = [row for row in rows if row["HuggingFaceID"].lower() == model.lower()]
        if exact_rows:
            rows = exact_rows
        elif architecture:
            architecture_rows = [row for row in rows if row["Architecture"] == architecture]
            if architecture_rows:
                rows = architecture_rows
            else:
                logger.debug(
                    "No support-matrix rows match model=%s or architecture=%s for system=%s backend=%s",
                    model,
                    architecture,
                    system,
                    backend,
                )
                return None
        else:
            logger.debug(
                "No exact support-matrix rows match model=%s for system=%s backend=%s and no architecture was provided",
                model,
                system,
                backend,
            )
            return None

    versions = [
        (version, parsed)
        for version in {row["Version"] for row in rows}
        if (parsed := common.parse_support_matrix_version(version))
    ]
    if not versions:
        return None
    return max(versions, key=lambda version: version[1])[0]


def _queryable_versions(system: str, backend: str) -> set[str] | None:
    """Versions prediction accepts for (system, backend), or None when ungated.

    Support-matrix rows can outlive a version slot (a regenerated ``next``
    replaces the old one), and reporting such a version would advertise data
    that prediction rejects.
    """
    slots = perf_database.get_version_slots(system.lower(), backend.lower())
    return set(slots.values()) if slots else None


def _build_common_cli_parser() -> argparse.ArgumentParser:
    common_parser = argparse.ArgumentParser(add_help=False)
    common_parser.add_argument(
        "--log-level",
        type=str.upper,
        default=None,
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        help=("Set the minimum log level. Priority: --log-level > AICONFIGURATOR_LOG_LEVEL > --debug > INFO."),
    )
    common_parser.add_argument(
        "--debug",
        action="store_true",
        help="Deprecated alias for --log-level DEBUG, kept for backward compatibility.",
    )
    common_parser.add_argument(
        "--no-color",
        dest="no_color",
        action="store_true",
        help="Disable ANSI colors in output.",
    )
    # TODO: maybe move --systems-path here?
    return common_parser


def _build_common_cli_experiments_parser() -> argparse.ArgumentParser:
    # TODO: some arguments might be unused in some modes.
    # Example: --top-n not used for generate mode.
    common_parser = argparse.ArgumentParser(add_help=False)
    common_parser.add_argument("--save-dir", type=str, default=None, help="Directory to save the results.")
    common_parser.add_argument(
        "--top-n",
        type=int,
        default=5,
        help="Number of top configurations to output for each experiment (in exp mode) "
        "or for each mode (agg/disagg) in default mode. Default: 5.",
    )
    common_parser.add_argument(
        "--systems-paths",
        type=str,
        default=None,
        help=(
            "Systems search paths (comma-separated). Use 'default' for the built-in systems path. "
            "Example: default,/opt/aic/systems,/data/aic/systems."
        ),
    )
    common_parser.add_argument(
        "--deployment-target",
        type=str,
        choices=["dynamo-j2", "dynamo-python", "llm-d-helm", "llm-d-kustomize", "fpm", "slurm"],
        default="dynamo-j2",
        help="Deployment target platform. Options: dynamo-j2 (default, typed Dynamo manifests), "
        "dynamo-python (Dynamo Python config modifiers), llm-d-helm (llm-d Helm values), "
        "llm-d-kustomize (llm-d Kustomize overlays), fpm (reusable resource Pod + run.sh), "
        "slurm (Dynamo service and benchmark jobs).",
    )
    common_parser.add_argument(
        "--engine-step-backend",
        choices=["rust"],
        default=None,
        help="Engine-step latency backend. The compiled Rust engine is the only step "
        "executor ('rust'); the deprecated 'python' no-op was removed after its "
        "one-release window.",
    )
    common_parser.add_argument(
        "--forward-model",
        choices=["op_level", "fpm"],
        default=None,
        help="Forward-pass modeling mode. Default 'op_level' keeps granular op-level modeling; "
        "'fpm' predicts from collected whole-model forward-pass data (requires fpm_forward "
        "perf data for the exact model/system/backend/version).",
    )
    add_generator_override_arguments(common_parser)
    return common_parser


def _parse_nextn(value: str) -> int | str:
    """argparse type for --nextn: a non-negative integer draft length, or 'auto'
    to use the checkpoint's num_nextn_predict_layers."""
    if value.strip().lower() == "auto":
        return "auto"
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"--nextn must be a non-negative integer or 'auto', got {value!r}") from None
    if parsed < 0:
        raise argparse.ArgumentTypeError(f"--nextn must be >= 0 or 'auto', got {parsed}")
    return parsed


def _speculative_block_from_args(args) -> dict | None:
    """Assemble the Task ``speculative:`` block from --spec-* flags.

    Returns None when --spec-method is absent; Task-level validation owns the
    consistency rules (acceptance bound, nextn mutual exclusion, key checks).
    """
    method = getattr(args, "spec_method", None)
    if not method:
        for flag in ("spec_draft_model_path", "spec_num_draft_tokens", "spec_accepted_tokens"):
            if getattr(args, flag, None) is not None:
                raise SystemExit(f"--{flag.replace('_', '-')} requires --spec-method.")
        return None
    params: dict = {}
    if getattr(args, "spec_num_draft_tokens", None) is not None:
        if method == "mtp":
            token_key = "depth"
        elif method in ("ngram", "draft_model", "eagle3"):
            token_key = "num_speculative_tokens"
        else:
            token_key = "num_draft_tokens"
        params[token_key] = args.spec_num_draft_tokens
    block: dict = {"method": method, "params": params}
    if getattr(args, "spec_draft_model_path", None):
        block["draft_model_path"] = args.spec_draft_model_path
    if getattr(args, "spec_accepted_tokens", None) is not None:
        block["accepted_tokens"] = args.spec_accepted_tokens
    return block


def _resolve_and_validate_nextn(args) -> None:
    """Fail fast on inconsistent MTP input; resolve --nextn auto to the checkpoint depth.

    Mutates ``args.nextn`` in place so everything downstream sees a plain int.
    """
    speculative = _speculative_block_from_args(args)
    if speculative is not None:
        from aisimulate.sdk.speculative import resolve_speculative_block

        try:
            resolution = resolve_speculative_block(speculative, nextn=args.nextn, nextn_accepted=args.nextn_accepted)
        except (TypeError, ValueError) as exc:
            raise SystemExit(str(exc)) from exc
        args.nextn, args.nextn_accepted = resolution.nextn, resolution.nextn_accepted
    if args.nextn == "auto":
        try:
            resolved = resolve_nextn_auto(args.model_path)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        if resolved > 0:
            logger.info(
                "--nextn auto: modeling MTP with nextn=%d from the checkpoint's num_nextn_predict_layers.",
                resolved,
            )
        else:
            logger.info(
                "--nextn auto: checkpoint ships no MTP layers (num_nextn_predict_layers absent or 0); "
                "MTP stays disabled."
            )
        try:
            resolved, args.nextn_accepted = normalize_speculative_decoding(resolved, args.nextn_accepted)
        except ValueError as exc:
            raise SystemExit(
                f"--nextn auto resolved to nextn={resolved} from the checkpoint's num_nextn_predict_layers: {exc}"
            ) from exc
        args.nextn = resolved
        return
    try:
        args.nextn, args.nextn_accepted = normalize_speculative_decoding(args.nextn, args.nextn_accepted)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc


def _positive_float(value: str) -> float:
    """Argparse type for positive finite floats (load targets, SLA thresholds)."""
    import math

    f = float(value)
    if not (math.isfinite(f) and f > 0):
        raise argparse.ArgumentTypeError(f"must be a positive finite number, got {value!r}")
    return f


def _memory_fraction(value: str) -> float:
    """Argparse type for finite GPU memory fractions in ``(0, 1]``."""
    import math

    fraction = float(value)
    if not (math.isfinite(fraction) and 0 < fraction <= 1):
        raise argparse.ArgumentTypeError(f"must be a finite number in (0, 1], got {value!r}")
    return fraction


def _validate_model_path(model_path: str) -> str:
    """
    Validate model_path which can be:
    1. A HuggingFace model path (e.g., "Qwen/Qwen3-32B")
    2. A local path containing a config.json file
    """
    import os

    # Check if it's a local path with config.json
    if os.path.isdir(model_path):
        config_path = os.path.join(model_path, "config.json")
        if os.path.isfile(config_path):
            return model_path
        raise argparse.ArgumentTypeError(f"Directory '{model_path}' does not contain a config.json file.")

    # Check if it's a file path to config.json directly
    if os.path.isfile(model_path) and model_path.endswith("config.json"):
        return os.path.dirname(model_path) or model_path

    # Otherwise treat as HuggingFace model path
    if model_path in common.DefaultHFModels:
        return model_path

    # Try to fetch from HuggingFace
    try:
        get_model_config_from_model_path(model_path)
        return model_path
    except Exception as e:
        raise argparse.ArgumentTypeError(
            f"'{model_path}' is not a valid HuggingFace model path or local path with config.json. Error: {e}"
        ) from e


def _add_attention_backend_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--attention-backend",
        type=str,
        choices=ATTENTION_BACKEND_CHOICES,
        default=None,
        help="Attention kernel backend used by the deployment. Applies to every model graph with standard "
        "dense ContextAttention/GenerationAttention ops and to supported DeepSeek MLA/WideEP paths. "
        "Support depends on the serving backend, performance tables, and backend version; unsupported named "
        "values fail closed. For modeling, unset/default uses the mapped framework default when available and "
        "otherwise the safe default fallback. SGLang WideEP maps unset/default to flashinfer and also supports "
        "fa3. The deployment generator emits supported named SGLang values, omits unset/default, and rejects "
        "fla for SGLang 0.5.14.",
    )


def _add_default_mode_arguments(parser):
    parser.add_argument(
        "--model-path",
        "--model",
        dest="model_path",
        type=_validate_model_path,
        required=True,
        help="Model path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or "
        "local path to directory containing config.json.",
    )
    parser.add_argument(
        "--total-gpus",
        type=int,
        default=None,
        help="Total GPUs for deployment. "
        "Omit and provide --target-request-rate or --target-concurrency to find minimum GPUs.",
    )
    load_group = parser.add_mutually_exclusive_group()
    load_group.add_argument(
        "--target-request-rate",
        type=_positive_float,
        default=None,
        help="Target system request rate in req/s. When provided without --total-gpus, "
        "finds the minimum GPU count (recommend mode).",
    )
    load_group.add_argument(
        "--target-concurrency",
        type=_positive_float,
        default=None,
        help="Target number of concurrent users. When provided without --total-gpus, "
        "finds the minimum GPU count (recommend mode).",
    )
    parser.add_argument(
        "--system",
        type=str,
        required=True,
        help=(
            "System name (GPU type). Example: "
            "h200_sxm,h100_sxm,h100_pcie,b200_sxm,b300_sxm,gb200,a100_sxm,a100_pcie,l40s,l4,a30,gb300."
        ),
    )
    parser.add_argument(
        "--decode-system",
        type=str,
        default=None,
        help="System name for disagg decode workers. Defaults to --system if omitted.",
    )
    parser.add_argument(
        "--backend",
        choices=[backend.value for backend in common.BackendName] + ["auto"],
        type=str,
        default=common.BackendName.trtllm.value,
        help="Backend name. Use a specific backend (trtllm, vllm, sglang) or 'auto' to sweep "
        "across all supported backends for the given system and compare results side by side. "
        "When 'auto' is used, selected serving-mode results are merged across backends and the "
        "globally optimal configuration is selected. Default: trtllm.",
    )
    parser.add_argument(
        "--serving-mode",
        choices=["auto", "all", "agg", "disagg"],
        type=str,
        default="auto",
        help="Serving modes to sweep and compare. 'auto' (default) and 'all' both compare agg and "
        "disagg; pick a single mode to restrict the search.",
    )
    parser.add_argument(
        "--perf-db-version",
        "--backend-version",
        dest="backend_version",
        type=str,
        default=None,
        help="[expert] Performance-database version used for the simulation/search "
        "(search fidelity). Accepts a queryable slot version or the aliases "
        "current / previous / next (see systems/query_versions.yaml). "
        "Default: current. Alias: --backend-version.",
    )
    parser.add_argument(
        "--database-mode",
        choices=[mode.name for mode in common.DatabaseMode if mode != common.DatabaseMode.SOL_FULL],
        type=str,
        default=common.DatabaseMode.SILICON.name,
        help="Database mode for performance estimation. "
        "SILICON (default): uses silicon-collected data; results are fully reproducible. "
        "HYBRID (recommended for frontier/new models): extends SILICON coverage with "
        "SOL+empirical estimates for configurations not yet in the database — use this "
        "for models released after the last silicon data collection. "
        "EMPIRICAL: SOL+empirical factor only. SOL: theoretical Speed-of-Light only.",
    )
    parser.add_argument(
        "--transfer-policy",
        type=str,
        default=None,
        help="Fine-grained HYBRID/EMPIRICAL transfer control: which empirical transfer kinds "
        "may fill missing data. A preset (off|conservative|balanced|aggressive) or a "
        "comma-separated list of kinds (xshape,xquant,xprofile,xop). "
        "Default: all kinds enabled. Ignored in SILICON mode.",
    )
    parser.add_argument("--isl", type=int, default=4000, help="Input sequence length. Default: 4000.")
    parser.add_argument("--osl", type=int, default=1000, help="Output sequence length. Default: 1000.")
    parser.add_argument(
        "--image-height",
        type=int,
        default=0,
        help="Image height in pixels for vision-language models. Default: 0 (disabled).",
    )
    parser.add_argument(
        "--image-width",
        type=int,
        default=0,
        help="Image width in pixels for vision-language models. Default: 0 (disabled).",
    )
    parser.add_argument(
        "--num-images", type=int, default=1, help="Number of images per request for vision-language models. Default: 1."
    )
    parser.add_argument("--video-height", type=int, default=0, help="Video frame height in pixels. Default: 0.")
    parser.add_argument("--video-width", type=int, default=0, help="Video frame width in pixels. Default: 0.")
    parser.add_argument("--video-frames", type=int, default=0, help="Frames per video. Default: 0 (disabled).")
    parser.add_argument("--num-videos", type=int, default=0, help="Number of videos per request. Default: 0.")
    parser.add_argument(
        "--num-video-tokens",
        type=int,
        default=0,
        help="Explicit post-merge tokens per video; requires --video-frames. Default: 0 (derive from dimensions).",
    )
    parser.add_argument(
        "--disable-encoder-dp",
        action="store_true",
        help="Model the vision encoder as TP-sharded instead of the default data-parallel "
        "(vLLM mm_encoder_tp_mode='data' / SGLang --mm-enable-dp-encoder semantics).",
    )
    parser.add_argument(
        "--enable-epd",
        action="store_true",
        help="EPD (vision-language models): run the vision encoder on dedicated encode workers "
        "instead of colocated. Turns the disagg experiment into E+P+D and the agg experiment "
        "into E+agg; requires an image workload (--image-height/--image-width).",
    )
    parser.add_argument(
        "--encoder-tp",
        type=int,
        nargs="+",
        default=None,
        help="EPD encode-worker TP sizes to sweep (requires --enable-epd). Default: 1 2 4 8.",
    )
    parser.add_argument(
        "--encoder-system",
        type=str,
        default=None,
        help="System (GPU type) for EPD encode workers (requires --enable-epd). "
        "Defaults to the prefill/agg side's system.",
    )
    parser.add_argument(
        "--encoder-latency-correction",
        type=float,
        default=1.0,
        help="Latency correction scale for EPD encode workers (requires --enable-epd). Default: 1.0.",
    )
    parser.add_argument(
        "--ttft",
        type=float,
        default=2000.0,
        help="Time to first token SLA target in ms. Configurations exceeding this value are "
        "filtered from the pareto and topN configs. (Default: 2000)",
    )
    parser.add_argument(
        "--tpot",
        type=float,
        default=30.0,
        help="Time per output token SLA target in ms. Configurations exceeding this value are "
        "filtered from the topN configs. (Default: 30) \n"
        "**Note: the pareto may still include configs exceeding the given tpot. "
        "Pass --strict-sla to only keep configs that meet the given tpot constraint.**",
    )
    parser.add_argument(
        "--strict-sla",
        action="store_true",
        default=False,
        help="Filter the Pareto frontier and best configs to only SLA-compliant data points "
        "(--ttft + --tpot, or --request-latency). Without this flag, the Pareto frontier "
        "may include configs that exceed --tpot.",
    )
    parser.add_argument(
        "--request-latency",
        type=float,
        default=None,
        help="Optional end-to-end request latency target (ms). Enables request-latency optimization mode.",
    )
    parser.add_argument(
        "--inclusive-tpot",
        action="store_true",
        default=False,
        help=(
            "Report TPOT as (ttft + tpot * (osl - 1)) / osl, spreading TTFT cost across all output tokens. "
            "Affects terminal output and saved CSV only; SLA filtering always uses inter-token latency."
        ),
    )
    parser.add_argument("--prefix", type=int, default=0, help="Prefix cache length. Default to 0.")
    parser.add_argument(
        "--nextn",
        type=_parse_nextn,
        default=0,
        help="MTP (Multi-Token Prediction) draft length, or 'auto' to use the checkpoint's "
        "num_nextn_predict_layers (absent/0 keeps MTP disabled). When the depth is > 0, enables "
        "speculative decoding in the configuration search and requires --nextn-accepted. "
        "Default: 0 (disabled); MTP is never enabled implicitly when the flag is omitted.",
    )
    parser.add_argument(
        "--nextn-accepted",
        type=float,
        default=None,
        help="Average accepted draft tokens per decode step (0 <= nextn_accepted <= nextn). "
        "Required when --nextn resolves to > 0; there is no built-in acceptance "
        "assumption — use a measured value from your deployment (e.g. the engine's "
        "reported average acceptance length minus 1).",
    )
    parser.add_argument(
        "--enable-chunked-prefill",
        action="store_true",
        default=False,
        help="Enable chunked prefill for finer-grained context token sweep during optimization. "
        "When off (default), context token stride is aligned to ISL for faster sweeping.",
    )
    parser.add_argument(
        "--free-gpu-memory-fraction",
        type=float,
        default=None,
        help="Fraction of GPU memory the framework allocates for KV cache "
        "(default: the framework's own default for the selected backend -- vLLM's "
        "gpu_memory_utilization, resolved by backend version; TRT-LLM's "
        "free_gpu_memory_fraction; SGLang's mem_fraction_static, derived from device "
        "capacity where known and 0.88 otherwise). "
        "Used to filter batch sizes that would exceed KV cache capacity.",
    )
    parser.add_argument(
        "--max-seq-len",
        type=int,
        default=None,
        help="TRT-LLM --max_seq_len setting (default: isl + osl). "
        "Controls how many KV blocks TRT-LLM pre-allocates per sequence. "
        "Set this to match your actual deployment for accurate KV cache capacity filtering.",
    )
    parser.add_argument(
        "--enable-wideep",
        action="store_true",
        default=False,
        help="Deprecated and ignored: large-EP is explored automatically from data coverage. "
        "Restrict with *_moe_ep_candidates in an exp YAML.",
    )
    parser.add_argument(
        "--moe-backend",
        type=str,
        choices=["deepep_moe", "megamoe"],
        default=None,
        help="Explicit SGLang MoE backend. Use 'megamoe' to model DeepSeek-V4 MegaMoE on Blackwell. "
        "'deepep_moe' is deprecated and ignored (large-EP is explored automatically from data coverage).",
    )
    _add_attention_backend_argument(parser)


def _add_recommend_mode_arguments(parser):
    parser.add_argument(
        "--model-path",
        "--model",
        dest="model_path",
        type=_validate_model_path,
        default=None,
        help="Model path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or "
        "local path to directory containing config.json.",
    )
    load_group = parser.add_mutually_exclusive_group(required=True)
    load_group.add_argument(
        "--target-request-rate",
        type=_positive_float,
        default=None,
        help="Target system request rate in req/s. Find minimum GPUs to serve this rate.",
    )
    load_group.add_argument(
        "--target-concurrency",
        type=_positive_float,
        default=None,
        help="Target number of concurrent users. Find minimum GPUs to serve this concurrency.",
    )
    parser.add_argument(
        "--system",
        type=str,
        default=None,
        help=(
            "System name (GPU type). Example: "
            "h200_sxm,h100_sxm,h100_pcie,b200_sxm,b300_sxm,gb200,a100_sxm,a100_pcie,l40s,l4,a30,gb300."
        ),
    )
    parser.add_argument(
        "--decode-system",
        type=str,
        default=None,
        help="System name for disagg decode workers. Defaults to --system if omitted.",
    )
    parser.add_argument(
        "--backend",
        choices=[backend.value for backend in common.BackendName] + ["auto"],
        type=str,
        default=common.BackendName.trtllm.value,
        help="Backend name. Use a specific backend (trtllm, vllm, sglang) or 'auto' to sweep "
        "across all supported backends for the given system and compare results side by side. "
        "Default: trtllm.",
    )
    parser.add_argument(
        "--perf-db-version",
        "--backend-version",
        dest="backend_version",
        type=str,
        default=None,
        help="[expert] Performance-database version used for the simulation/search "
        "(search fidelity). Default: latest measured version. Alias: --backend-version.",
    )
    parser.add_argument(
        "--database-mode",
        choices=[mode.name for mode in common.DatabaseMode if mode != common.DatabaseMode.SOL_FULL],
        type=str,
        default=common.DatabaseMode.HYBRID.name,
        help="Database mode for performance estimation. "
        "HYBRID (default for recommend): extends SILICON with SOL+empirical estimates — "
        "produces results even for frontier/new models without full silicon data. "
        "SILICON: silicon-collected data only; results are fully reproducible. "
        "EMPIRICAL: SOL+empirical factor only. SOL: theoretical Speed-of-Light only.",
    )
    parser.add_argument(
        "--transfer-policy",
        type=str,
        default=None,
        help="Fine-grained HYBRID/EMPIRICAL transfer control. "
        "A preset (off|conservative|balanced|aggressive) or comma-separated kinds. "
        "Default: all kinds enabled. Ignored in SILICON mode.",
    )
    parser.add_argument("--isl", type=int, default=4000, help="Input sequence length. Default: 4000.")
    parser.add_argument("--osl", type=int, default=1000, help="Output sequence length. Default: 1000.")
    parser.add_argument(
        "--image-height",
        type=int,
        default=0,
        help="Image height in pixels for vision-language models. Default: 0 (disabled).",
    )
    parser.add_argument(
        "--image-width",
        type=int,
        default=0,
        help="Image width in pixels for vision-language models. Default: 0 (disabled).",
    )
    parser.add_argument(
        "--num-images", type=int, default=1, help="Number of images per request for vision-language models. Default: 1."
    )
    parser.add_argument("--video-height", type=int, default=0, help="Video frame height in pixels. Default: 0.")
    parser.add_argument("--video-width", type=int, default=0, help="Video frame width in pixels. Default: 0.")
    parser.add_argument("--video-frames", type=int, default=0, help="Frames per video. Default: 0 (disabled).")
    parser.add_argument("--num-videos", type=int, default=0, help="Number of videos per request. Default: 0.")
    parser.add_argument(
        "--num-video-tokens",
        type=int,
        default=0,
        help="Explicit post-merge tokens per video; requires --video-frames. Default: 0 (derive from dimensions).",
    )
    parser.add_argument(
        "--ttft",
        type=float,
        default=2000.0,
        help="Time to first token SLA target in ms. (Default: 2000)",
    )
    parser.add_argument(
        "--tpot",
        type=float,
        default=30.0,
        help="Time per output token SLA target in ms. (Default: 30)",
    )
    parser.add_argument(
        "--strict-sla",
        action="store_true",
        default=False,
        help="Filter the Pareto frontier and best configs to only SLA-compliant data points.",
    )
    parser.add_argument(
        "--request-latency",
        type=float,
        default=None,
        help="Optional end-to-end request latency target (ms). Enables request-latency optimization mode.",
    )
    parser.add_argument("--prefix", type=int, default=0, help="Prefix cache length. Default to 0.")
    parser.add_argument(
        "--nextn",
        type=_parse_nextn,
        default=None,
        help="MTP (Multi-Token Prediction) draft length, or 'auto' to use the checkpoint's "
        "num_nextn_predict_layers and then DSPARK architecture metadata. When the depth is > 0, "
        "enables speculative decoding and requires a measured --nextn-accepted value. Omitted or "
        "0 keeps speculation disabled unless a DSPARK model is paired with --nextn-accepted.",
    )
    parser.add_argument(
        "--nextn-accepted",
        type=float,
        default=None,
        help="Average accepted draft tokens per decode step (0 <= nextn_accepted <= nextn). "
        "Required when --nextn resolves to > 0; there is no built-in acceptance "
        "assumption — use a measured value from your deployment (e.g. the engine's "
        "reported average acceptance length minus 1).",
    )
    parser.add_argument(
        "--enable-chunked-prefill",
        action="store_true",
        default=False,
        help="Enable chunked prefill for finer-grained context token sweep during optimization.",
    )
    parser.add_argument(
        "--free-gpu-memory-fraction",
        type=float,
        default=None,
        help="Fraction of GPU memory the framework allocates for KV cache "
        "(default: the framework's own default for the selected backend -- vLLM's "
        "gpu_memory_utilization, resolved by backend version; TRT-LLM's "
        "free_gpu_memory_fraction; SGLang's mem_fraction_static, derived from device "
        "capacity where known and 0.88 otherwise).",
    )
    parser.add_argument(
        "--max-seq-len",
        type=int,
        default=None,
        help="TRT-LLM --max_seq_len setting (default: isl + osl).",
    )
    parser.add_argument(
        "--enable-wideep",
        action="store_true",
        default=False,
        help="Deprecated and ignored: large-EP is explored automatically from data coverage. "
        "Restrict with *_moe_ep_candidates in an exp YAML.",
    )
    parser.add_argument(
        "--moe-backend",
        type=str,
        choices=["deepep_moe", "megamoe"],
        default=None,
        help="Explicit SGLang MoE backend. Use 'megamoe' to model DeepSeek-V4 MegaMoE on Blackwell. "
        "'deepep_moe' is deprecated and ignored (large-EP is explored automatically from data coverage).",
    )
    _add_attention_backend_argument(parser)


def _add_experiments_mode_arguments(parser):
    parser.add_argument(
        "--yaml-path",
        type=str,
        required=True,
        help="Path to a YAML file containing experiment definitions.",
    )
    parser.add_argument(
        "--inclusive-tpot",
        action="store_true",
        default=False,
        help=(
            "Report TPOT as (ttft + tpot * (osl - 1)) / osl, spreading TTFT cost across all output tokens. "
            "Affects terminal output and saved CSV only; SLA filtering always uses inter-token latency."
        ),
    )
    _add_attention_backend_argument(parser)


def _add_generate_mode_arguments(parser):
    """Add arguments for the generate mode (naive config generation)."""
    parser.add_argument(
        "--model-path",
        "--model",
        dest="model_path",
        type=_validate_model_path,
        required=True,
        help="Model path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or "
        "local path to directory containing config.json.",
    )
    parser.add_argument(
        "--total-gpus",
        type=int,
        required=True,
        help="Total GPUs for deployment.",
    )
    parser.add_argument(
        "--system",
        type=str,
        required=True,
        help=(
            "System name (GPU type). Example: "
            "h200_sxm,h100_sxm,h100_pcie,b200_sxm,b300_sxm,gb200,a100_sxm,a100_pcie,l40s,l4,a30,gb300."
        ),
    )
    parser.add_argument(
        "--backend",
        choices=[backend.value for backend in common.BackendName],
        type=str,
        default=common.BackendName.trtllm.value,
        help="Backend name (default: trtllm).",
    )


def _add_speculative_scheme_arguments(parser):
    """Speculation scheme flags for the single-point estimate command."""
    parser.add_argument(
        "--spec-method",
        default=None,
        help="Speculative decoding method (ngram, draft_model, eagle3, dflash, dspark, or mtp). "
        "Non-MTP methods support agg/static estimates and require --spec-accepted-tokens.",
    )
    parser.add_argument(
        "--spec-draft-model-path",
        default=None,
        help="Draft checkpoint (Hugging Face repo or local path) providing the draft config.json.",
    )
    parser.add_argument(
        "--spec-num-draft-tokens",
        type=int,
        default=None,
        help="Drafted tokens per round (MTP depth for --spec-method mtp).",
    )
    parser.add_argument(
        "--spec-accepted-tokens",
        type=float,
        default=None,
        help="Measured average accepted draft tokens per round; no built-in acceptance assumption.",
    )


def _add_estimate_mode_arguments(parser):
    """Add arguments for the estimate mode (single-point TTFT/TPOT/power estimation)."""
    parser.add_argument(
        "--model-path",
        "--model",
        dest="model_path",
        type=_validate_model_path,
        required=True,
        help="Model path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or "
        "local path to directory containing config.json.",
    )
    parser.add_argument(
        "--estimate-mode",
        choices=["agg", "disagg", "static", "static_ctx", "static_gen"],
        type=str,
        default="agg",
        help="Estimation mode: 'agg' (default, IFB), 'disagg' (separate prefill/decode workers), "
        "or one of the static modes 'static' / 'static_ctx' / 'static_gen' for a single-pass, "
        "no-IFB latency/memory breakdown.",
    )
    parser.add_argument(
        "--system",
        type=str,
        required=True,
        help=(
            "System name (GPU type). Example: "
            "h200_sxm,h100_sxm,h100_pcie,b200_sxm,b300_sxm,gb200,a100_sxm,a100_pcie,l40s,l4,a30,gb300."
        ),
    )
    parser.add_argument(
        "--decode-system",
        type=str,
        default=None,
        help="System name for disagg decode workers. Defaults to --system if omitted.",
    )
    parser.add_argument(
        "--prefill-free-gpu-memory-fraction",
        type=_memory_fraction,
        default=None,
        help="Prefill worker KV-cache memory fraction (disagg). Overrides --free-gpu-memory-fraction for prefill.",
    )
    parser.add_argument(
        "--decode-free-gpu-memory-fraction",
        type=_memory_fraction,
        default=None,
        help="Decode worker KV-cache memory fraction (disagg). Overrides --free-gpu-memory-fraction for decode.",
    )
    parser.add_argument(
        "--prefill-max-seq-len",
        type=int,
        default=None,
        help="Prefill worker maximum sequence length (disagg). Overrides --max-seq-len for prefill.",
    )
    parser.add_argument(
        "--decode-max-seq-len",
        type=int,
        default=None,
        help="Decode worker maximum sequence length (disagg). Overrides --max-seq-len for decode.",
    )
    parser.add_argument(
        "--backend",
        choices=[backend.value for backend in common.BackendName],
        type=str,
        default=common.BackendName.trtllm.value,
        help="Backend name (default: trtllm).",
    )
    parser.add_argument(
        "--perf-db-version",
        "--backend-version",
        dest="backend_version",
        type=str,
        default=None,
        help="[expert] Performance-database version used for the simulation/search "
        "(search fidelity). Accepts a queryable slot version or the aliases "
        "current / previous / next (see systems/query_versions.yaml). "
        "Default: current. Alias: --backend-version.",
    )
    parser.add_argument("--isl", type=int, default=1024, help="Input sequence length. Default: 1024.")
    parser.add_argument("--osl", type=int, default=1024, help="Output sequence length. Default: 1024.")
    parser.add_argument(
        "--image-height",
        type=int,
        default=0,
        help="Image height in pixels for vision-language models. Default: 0 (disabled).",
    )
    parser.add_argument(
        "--image-width",
        type=int,
        default=0,
        help="Image width in pixels for vision-language models. Default: 0 (disabled).",
    )
    parser.add_argument(
        "--num-images", type=int, default=1, help="Number of images per request for vision-language models. Default: 1."
    )
    parser.add_argument("--video-height", type=int, default=0, help="Video frame height in pixels. Default: 0.")
    parser.add_argument("--video-width", type=int, default=0, help="Video frame width in pixels. Default: 0.")
    parser.add_argument("--video-frames", type=int, default=0, help="Frames per video. Default: 0 (disabled).")
    parser.add_argument("--num-videos", type=int, default=0, help="Number of videos per request. Default: 0.")
    parser.add_argument(
        "--num-video-tokens",
        type=int,
        default=0,
        help="Explicit post-merge tokens per video; requires --video-frames. Default: 0 (derive from dimensions).",
    )
    parser.add_argument(
        "--disable-encoder-dp",
        action="store_true",
        help="Model the vision encoder as TP-sharded instead of the default data-parallel "
        "(vLLM mm_encoder_tp_mode='data' / SGLang --mm-enable-dp-encoder semantics).",
    )
    parser.add_argument(
        "--enable-epd",
        action="store_true",
        help="EPD single point: overlay a fixed encode-worker pool on the agg/disagg point; "
        "the LM side becomes language-only. Supports --estimate-mode agg/disagg.",
    )
    parser.add_argument(
        "--encoder-tp",
        type=int,
        default=None,
        help="EPD encode-worker TP (required with --enable-epd).",
    )
    parser.add_argument(
        "--encoder-batch-size",
        type=int,
        default=None,
        help="EPD encode-worker batch size. Default: 1.",
    )
    parser.add_argument(
        "--encoder-num-workers",
        type=int,
        default=None,
        help="EPD encode workers in the pool. Default: 1.",
    )
    parser.add_argument(
        "--batch-size",
        "--bs",
        dest="batch_size",
        type=int,
        default=128,
        help="Batch size (max concurrent requests, used for agg/static). Default: 128. Alias: --bs.",
    )
    parser.add_argument(
        "--ctx-tokens",
        type=int,
        default=None,
        help="Context tokens budget for IFB scheduling (agg only). Default: same as ISL.",
    )

    # Shared parallelism defaults (also used as fallback for prefill/decode-specific args)
    parser.add_argument(
        "--tp-size",
        "--tp",
        dest="tp_size",
        type=int,
        default=1,
        help="Tensor parallelism size. Default: 1. Alias: --tp.",
    )
    parser.add_argument(
        "--pp-size",
        "--pp",
        dest="pp_size",
        type=int,
        default=1,
        help="Pipeline parallelism size. Default: 1. Alias: --pp.",
    )
    parser.add_argument(
        "--attention-dp-size",
        "--dp",
        dest="attention_dp_size",
        type=int,
        default=1,
        help="Attention data parallelism size. Default: 1. Alias: --dp.",
    )
    parser.add_argument(
        "--moe-tp-size",
        "--etp",
        dest="moe_tp_size",
        type=int,
        default=None,
        help="MoE tensor parallelism size. Alias: --etp.",
    )
    parser.add_argument(
        "--moe-ep-size",
        "--ep",
        dest="moe_ep_size",
        type=int,
        default=None,
        help="MoE expert parallelism size. Alias: --ep.",
    )

    # Disagg: prefill-specific overrides (fall back to shared args when None)
    parser.add_argument(
        "--prefill-tp-size",
        "--p-tp",
        dest="prefill_tp_size",
        type=int,
        default=None,
        help="Prefill TP size (disagg). Defaults to --tp-size. Alias: --p-tp.",
    )
    parser.add_argument(
        "--prefill-pp-size",
        "--p-pp",
        dest="prefill_pp_size",
        type=int,
        default=None,
        help="Prefill PP size (disagg). Defaults to --pp-size. Alias: --p-pp.",
    )
    parser.add_argument(
        "--prefill-attention-dp-size",
        "--p-dp",
        dest="prefill_attention_dp_size",
        type=int,
        default=None,
        help="Prefill attention DP size (disagg). Defaults to --attention-dp-size. Alias: --p-dp.",
    )
    parser.add_argument(
        "--prefill-moe-tp-size",
        "--p-etp",
        dest="prefill_moe_tp_size",
        type=int,
        default=None,
        help="Prefill MoE TP size (disagg). Defaults to --moe-tp-size. Alias: --p-etp.",
    )
    parser.add_argument(
        "--prefill-moe-ep-size",
        "--p-ep",
        dest="prefill_moe_ep_size",
        type=int,
        default=None,
        help="Prefill MoE EP size (disagg). Defaults to --moe-ep-size. Alias: --p-ep.",
    )
    parser.add_argument(
        "--prefill-batch-size",
        "--p-bs",
        dest="prefill_batch_size",
        type=int,
        default=None,
        help="Prefill batch size (disagg). Required for disagg mode. Alias: --p-bs.",
    )
    parser.add_argument(
        "--prefill-num-workers",
        "--p-workers",
        dest="prefill_num_workers",
        type=int,
        default=None,
        help="Number of prefill workers (disagg). Required for disagg mode. Alias: --p-workers.",
    )

    # Disagg: decode-specific overrides (fall back to shared args when None)
    parser.add_argument(
        "--decode-tp-size",
        "--d-tp",
        dest="decode_tp_size",
        type=int,
        default=None,
        help="Decode TP size (disagg). Defaults to --tp-size. Alias: --d-tp.",
    )
    parser.add_argument(
        "--decode-pp-size",
        "--d-pp",
        dest="decode_pp_size",
        type=int,
        default=None,
        help="Decode PP size (disagg). Defaults to --pp-size. Alias: --d-pp.",
    )
    parser.add_argument(
        "--decode-attention-dp-size",
        "--d-dp",
        dest="decode_attention_dp_size",
        type=int,
        default=None,
        help="Decode attention DP size (disagg). Defaults to --attention-dp-size. Alias: --d-dp.",
    )
    parser.add_argument(
        "--decode-moe-tp-size",
        "--d-etp",
        dest="decode_moe_tp_size",
        type=int,
        default=None,
        help="Decode MoE TP size (disagg). Defaults to --moe-tp-size. Alias: --d-etp.",
    )
    parser.add_argument(
        "--decode-moe-ep-size",
        "--d-ep",
        dest="decode_moe_ep_size",
        type=int,
        default=None,
        help="Decode MoE EP size (disagg). Defaults to --moe-ep-size. Alias: --d-ep.",
    )
    parser.add_argument(
        "--decode-batch-size",
        "--d-bs",
        dest="decode_batch_size",
        type=int,
        default=None,
        help="Decode batch size (disagg). Required for disagg mode. Alias: --d-bs.",
    )
    parser.add_argument(
        "--decode-num-workers",
        "--d-workers",
        dest="decode_num_workers",
        type=int,
        default=None,
        help="Number of decode workers (disagg). Required for disagg mode. Alias: --d-workers.",
    )

    # Quantization
    parser.add_argument(
        "--gemm-quant-mode",
        choices=[m.name for m in common.GEMMQuantMode],
        type=str,
        default=None,
        help="GEMM quantization mode. Auto-inferred from model config if omitted.",
    )
    parser.add_argument(
        "--kvcache-quant-mode",
        choices=[m.name for m in common.KVCacheQuantMode],
        type=str,
        default=None,
        help="KV cache quantization mode. Auto-inferred from model config if omitted.",
    )
    parser.add_argument(
        "--fmha-quant-mode",
        choices=[m.name for m in common.FMHAQuantMode],
        type=str,
        default=None,
        help="FMHA quantization mode. Auto-inferred from model config if omitted.",
    )
    parser.add_argument(
        "--moe-quant-mode",
        choices=[m.name for m in common.MoEQuantMode],
        type=str,
        default=None,
        help="MoE quantization mode. Auto-inferred from model config if omitted.",
    )
    parser.add_argument(
        "--comm-quant-mode",
        choices=[m.name for m in common.CommQuantMode],
        type=str,
        default=None,
        help="Communication quantization mode. Auto-inferred (default: half) if omitted.",
    )
    parser.add_argument(
        "--database-mode",
        choices=[mode.name for mode in common.DatabaseMode if mode != common.DatabaseMode.SOL_FULL],
        type=str,
        default=common.DatabaseMode.SILICON.name,
        help="Database mode for performance estimation. "
        "SILICON (default): uses silicon-collected data; results are fully reproducible. "
        "HYBRID (recommended for frontier/new models): extends SILICON coverage with "
        "SOL+empirical estimates for configurations not yet in the database — use this "
        "for models released after the last silicon data collection. "
        "EMPIRICAL: SOL+empirical factor only. SOL: theoretical Speed-of-Light only.",
    )
    parser.add_argument(
        "--transfer-policy",
        type=str,
        default=None,
        help="Fine-grained HYBRID/EMPIRICAL transfer control: which empirical transfer kinds "
        "may fill missing data. A preset (off|conservative|balanced|aggressive) or a "
        "comma-separated list of kinds (xshape,xquant,xprofile,xop). "
        "Default: all kinds enabled. Ignored in SILICON mode.",
    )
    parser.add_argument(
        "--detail",
        type=str,
        default=None,
        help="Comma-separated breakdown sections to print after the summary box. "
        "Choices: summary, memory, time, energy, source, all. "
        "Example: --detail memory,time. Default: no extra detail. "
        "Use 'all' to print every section.",
    )
    # Common workload extras — apply to agg / disagg / static / static_ctx / static_gen.
    parser.add_argument(
        "--prefix",
        type=int,
        default=0,
        help="(common) Prefix cache length (subset of ISL already cached per request). Default: 0. "
        "Applied to agg, disagg, and all static modes.",
    )
    parser.add_argument(
        "--nextn",
        type=_parse_nextn,
        default=0,
        help="(common) MTP draft length (compute cost side), or 'auto' to use the checkpoint's "
        "num_nextn_predict_layers. Default: 0 (disabled); MTP is never enabled implicitly. "
        "Applied to agg, disagg, and all static modes. Requires --nextn-accepted when the "
        "resolved depth is > 0.",
    )
    parser.add_argument(
        "--nextn-accepted",
        type=float,
        default=None,
        help="(common) Average accepted draft tokens per decode step "
        "(0 <= nextn_accepted <= nextn). Required when --nextn resolves to > 0; "
        "there is no built-in acceptance assumption — use a measured value from "
        "your deployment.",
    )
    _add_speculative_scheme_arguments(parser)
    parser.add_argument(
        "--stride",
        type=int,
        default=32,
        help="(static-only) Stride used by run_static to accelerate the OSL sweep. "
        "Ignored for agg / disagg modes. Default: 32.",
    )
    parser.add_argument(
        "--free-gpu-memory-fraction",
        type=float,
        default=None,
        help="Fraction of GPU memory the framework allocates for KV cache "
        "(default: the framework's own default for the selected backend -- vLLM's "
        "gpu_memory_utilization, resolved by backend version; TRT-LLM's "
        "free_gpu_memory_fraction; SGLang's mem_fraction_static, derived from device "
        "capacity where known and 0.88 otherwise). "
        "Used to estimate max concurrent sequences and warn when batch_size "
        "exceeds KV cache capacity.",
    )
    parser.add_argument(
        "--max-seq-len",
        type=int,
        default=None,
        help="TRT-LLM --max_seq_len setting (default: isl + osl). "
        "Controls how many KV blocks TRT-LLM pre-allocates per sequence. "
        "Set this to match your actual deployment to get an accurate KV cache capacity warning.",
    )
    _add_attention_backend_argument(parser)


def _add_support_mode_arguments(parser):
    """Add arguments for the support mode (support matrix check)."""
    parser.add_argument(
        "--model-path",
        "--model",
        dest="model_path",
        type=_validate_model_path,
        required=True,
        help="Model path: HuggingFace model path (e.g., 'Qwen/Qwen3-32B') or "
        "local path to directory containing config.json.",
    )
    parser.add_argument(
        "--system",
        type=str,
        required=True,
        help="System name (GPU type) or 'all' for a matrix view across every system. "
        "Example: h200_sxm, h100_sxm, h100_pcie, b200_sxm, b300_sxm, gb200, a100_sxm, a100_pcie, l40s, l4, a30, gb300.",
    )
    parser.add_argument(
        "--backend",
        choices=[backend.value for backend in common.BackendName] + ["all"],
        type=str,
        default=None,
        help="Backend name to filter by, or 'all' for all backends. "
        "Defaults to 'all' when --system is 'all', otherwise 'trtllm'.",
    )
    parser.add_argument(
        "--perf-db-version",
        "--backend-version",
        dest="backend_version",
        type=str,
        default=None,
        help="Optional backend / perf-db version to filter by. Alias: --backend-version.",
    )


_USAGE_EXAMPLES = """
Examples:
# Sweep across all backends for Dynamo 1.0.0
aiconfigurator cli default --model Qwen/Qwen3-32B-FP8 \\
    --backend auto \\
    --top-n 3 \\
    --total-gpus 8 --system h200_sxm \\
    --ttft 600 --tpot 50 --isl 4000 --osl 500 \\
    --dynamo-version 0.7.1 \\
    --generator-set K8sConfig.k8s_pvc_name=$YOUR_PVC_NAME \\
    --generator-set K8sConfig.k8s_namespace=$YOUR_NAMESPACE \\
    --save-dir results

# Sweep against trtllm 1.2.0rc5 perf data but generate config matching trtllm 1.2.0rc6
aiconfigurator cli default --model Qwen/Qwen3-32B-FP8 \\
    --backend trtllm \\
    --total-gpus 8 --system h200_sxm \\
    --perf-db-version 1.2.0rc5 \\
    --config-template-version 1.2.0rc6 \\
    --save-dir results
"""


def configure_parser(parser):
    common_cli_parser = _build_common_cli_parser()
    common_cli_experiments_parser = _build_common_cli_experiments_parser()
    subparsers = parser.add_subparsers(dest="mode", required=True)

    default_parser = subparsers.add_parser(
        "default",
        parents=[common_cli_parser, common_cli_experiments_parser],
        help="Run the default agg vs disagg comparison.",
        description="Run the default agg vs disagg comparison.",
        epilog=_USAGE_EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_default_mode_arguments(default_parser)

    help_text = "Run one or more experiments defined in a YAML file. Example: example.yaml"
    # an example yaml for demonstration
    example_yaml_path = os.path.join(os.path.dirname(__file__), "example.yaml")
    with open(example_yaml_path) as f:
        example_yaml = yaml.safe_load(f)
    description = help_text + "\n\nExample:\n\n" + yaml.dump(example_yaml, indent=2, Dumper=ListFlowDumper)

    experiments_parser = subparsers.add_parser(
        "exp",
        parents=[common_cli_parser, common_cli_experiments_parser],
        help=help_text,
        description=description,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_experiments_mode_arguments(experiments_parser)

    # Generate mode - naive config without sweeping
    generate_parser = subparsers.add_parser(
        "generate",
        parents=[common_cli_parser, common_cli_experiments_parser],
        help="Generate naive agg config without SLA optimization (no sweeping).",
        description=(
            "Generate a working agg configuration without running the parameter sweep. "
            "Calculates the smallest TP that fits the model in memory "
            "(TP * VRAM/GPU > 1.5 * model_weight). No SLA optimization is performed."
        ),
    )
    _add_generate_mode_arguments(generate_parser)

    # Estimate mode - single-point performance estimation
    estimate_parser = subparsers.add_parser(
        "estimate",
        parents=[common_cli_parser, common_cli_experiments_parser],
        help="Estimate TTFT, TPOT, and power for a single model/system/config.",
        description=(
            "Run a single-point performance estimation to predict TTFT (time to first token), "
            "TPOT (time per output token), and power consumption for a given model, system, "
            "and configuration. No parameter sweep or SLA optimization is performed."
        ),
    )
    _add_estimate_mode_arguments(estimate_parser)

    # Support mode - support matrix check
    support_parser = subparsers.add_parser(
        "support",
        parents=[common_cli_parser],
        help="(Optional) Check if AIC supports the model/hardware combo for (agg, disagg).",
        description="Optional pre-flight check to verify support for a specific model and system "
        "combination using the support matrix. You can skip this and run 'cli default' directly. "
        "Use --system all for a consolidated matrix view across all systems and backends.",
    )
    _add_support_mode_arguments(support_parser)

    recommend_parser = subparsers.add_parser(
        "recommend",
        parents=[common_cli_parser, common_cli_experiments_parser],
        help="Find minimum GPUs to meet a performance target.",
        description=(
            "Given a model, system, workload (ISL/OSL), SLA targets (TTFT/TPOT), "
            "and a load target (request rate or concurrency), find the minimum "
            "number of GPUs needed. Designed as a procurement sizing tool — "
            "the output is unconstrained."
        ),
    )
    _add_recommend_mode_arguments(recommend_parser)


def _get_system_data_root(system_name: str) -> str | None:
    """Resolve a system's perf-data root (the dir holding either
    <family>/<backend>/<version> or legacy <backend>/<version> subtrees)."""
    for systems_root in perf_database.get_systems_paths():
        system_yaml = os.path.join(systems_root, f"{system_name}.yaml")
        if not os.path.isfile(system_yaml):
            continue
        with open(system_yaml, encoding="utf-8") as fh:
            system_spec = yaml.safe_load(fh) or {}
        data_dir = system_spec.get("data_dir")
        if not data_dir:
            return None
        return os.path.join(systems_root, data_dir)
    return None


def _database_mode_requires_declared_perf_database(database_mode: str | None) -> bool:
    return (database_mode or "").upper() in {
        common.DatabaseMode.SILICON.name,
        common.DatabaseMode.HYBRID.name,
    }


def _resolve_version_for_matching(system_name: str, backend_name: str, backend_version: str | None) -> str | None:
    """Alias-aware form of a requested version for membership checks.

    `get_supported_databases` enumerates resolved LITERALS, so every
    comparison against it must resolve the requested alias per
    (system, backend) first — otherwise `--backend-version current` is
    rejected while its literal passes. Raw versions pass through untouched
    (allow_unlisted: matching decides membership, not the slot gate);
    unresolvable aliases (gate off / slot unpopulated) fall back to the raw
    string so the membership check fails with the normal guidance.
    """
    if backend_version is None:
        return None
    try:
        return perf_database.resolve_query_version(system_name, backend_name, backend_version, allow_unlisted=True)
    except (ValueError, KeyError):
        return backend_version


def _ensure_backend_version_available(
    system_name: str,
    backend_name: str,
    backend_version: str | None = None,
) -> None:
    """
    Validate that the backend is supported for the given system and version.

    Args:
        system_name: System name (e.g., 'gb200_sxm')
        backend_name: Backend name (e.g., 'vllm')
        backend_version: Backend database version. Default is None, which means latest version.
    Raises:
        SystemExit: If the backend is not supported for the given system and version.
    """
    supported = perf_database.get_supported_databases()
    backends = supported.get(system_name, {}).keys()
    if backend_name not in backends:
        logger.error(
            "Backend %s is not supported for system %s. Supported backends: %s",
            backend_name,
            system_name,
            ", ".join(sorted(backends)),
        )
        raise SystemExit(1)

    versions = supported.get(system_name, {}).get(backend_name, [])
    if backend_version in ("current", "previous", "next"):
        # An alias that fails to resolve deserves the alias-specific error
        # ("has no 'previous' version; available slots: ..."), not the
        # generic missing-directory guidance that circularly suggests aliases.
        try:
            backend_version = perf_database.resolve_query_version(system_name, backend_name, backend_version)
        except ValueError as e:
            # User-facing gate message: no traceback wanted, so not
            # logger.exception.
            logger.error("%s", e)  # noqa: TRY400
            raise SystemExit(1) from e
    else:
        backend_version = _resolve_version_for_matching(system_name, backend_name, backend_version)
    if backend_version is None or backend_version in versions:
        return

    # Old-style raw-version escape: the loader-level unlisted-version gate
    # (perf_database resolve) honors this variable; the precheck must not be
    # stricter than the loader, or the documented escape is unreachable.
    if os.environ.get("AIC_ALLOW_UNLISTED_VERSIONS", "").lower() in ("1", "true", "yes"):
        logger.warning(
            "AIC_ALLOW_UNLISTED_VERSIONS is set: querying raw version %s/%s on %s "
            "outside the queryable slots %s. This data is not maintained to the "
            "queryable bar; results may have partial op coverage.",
            backend_name,
            backend_version,
            system_name,
            versions,
        )
        return

    systems_paths = perf_database.get_systems_paths()
    systems_paths_display = ", ".join(systems_paths) if systems_paths else "<none>"

    logger.error(
        "No perf database for system=%s backend=%s version=%s.",
        system_name,
        backend_name,
        backend_version,
    )
    system_data_root = _get_system_data_root(system_name)
    if system_data_root:
        logger.error(
            "Searched: %s (backend=%s, version=%s; both family-first <family>/<backend>/<version> "
            "and legacy <backend>/<version> layouts)",
            system_data_root,
            backend_name,
            backend_version,
        )
    logger.error("Configured systems paths: %s", systems_paths_display)
    if versions:
        logger.error("Available versions: %s", ", ".join(versions))
        logger.error(
            "Fix: switch --backend-version to one of the available slot versions "
            "or the aliases current / previous / next, or remove "
            "--backend-version to use current. Versions outside the slots "
            "are data coordinates, not queryable versions "
            "(see systems/query_versions.yaml).",
        )
        logger.error(
            "Old-style raw-version query (data outside the slots is not "
            "maintained to the queryable bar): re-run the same command with "
            "AIC_ALLOW_UNLISTED_VERSIONS=1.",
        )
    else:
        logger.error("Available versions: none")
        logger.error(
            "Fix: no database was found for system=%s backend=%s in current --systems-paths.",
            system_name,
            backend_name,
        )
        logger.error(
            "Try adding a path that contains this database via --systems-paths. "
            'Example: --systems-paths "default,/path/to/extra/systems".'
        )
    raise SystemExit(1)


def build_default_tasks(
    model_path: str,
    total_gpus: int,
    system: str,
    decode_system: str | None = None,
    backend: str = "trtllm",
    backend_version: str | None = None,
    database_mode: str = "SILICON",
    transfer_policy: str | list | None = None,
    isl: int = 4000,
    osl: int = 1000,
    image_height: int = 0,
    image_width: int = 0,
    num_images: int = 1,
    enable_encoder_dp: bool = True,
    enable_epd: bool = False,
    encoder_tp: list[int] | None = None,
    encoder_system: str | None = None,
    encoder_latency_correction: float = 1.0,
    ttft: float = 2000.0,
    tpot: float = 30.0,
    request_latency: float | None = None,
    prefix: int = 0,
    nextn: int | str = 0,
    nextn_accepted: float | None = None,
    enable_chunked_prefill: bool = False,
    free_gpu_memory_fraction: float | None = None,
    max_seq_len: int | None = None,
    enable_wideep: bool = False,
    moe_backend: str | None = None,
    attention_backend: str | None = None,
    engine_step_backend: str | None = None,
    forward_model: str | None = None,
    serving_mode: str = "auto",
    video_height: int = 0,
    video_width: int = 0,
    video_frames: int = 0,
    num_videos: int = 0,
    num_video_tokens: int = 0,
) -> dict[str, Task]:
    """Build task configs for the selected default-mode serving modes.

    Args:
        model_path: HuggingFace model path or local path.
        total_gpus: Total number of GPUs for deployment.
        system: System name (GPU type).
        decode_system: System for disagg decode workers. Defaults to `system`.
        backend: Backend name ('trtllm', 'sglang', 'vllm', 'auto').
            Use 'auto' to sweep across all backends.
        backend_version: Backend database version. Default is latest.
        database_mode: Database mode for performance estimation.
        isl: Input sequence length.
        osl: Output sequence length.
        video_height: Video frame height in pixels.
        video_width: Video frame width in pixels.
        video_frames: Frames per video.
        num_videos: Number of videos per request.
        num_video_tokens: Explicit post-merge tokens per video. Requires
            ``video_frames``; zero derives the token count from dimensions.
        ttft: Time to first token target in ms.
        tpot: Time per output token target in ms.
        request_latency: Optional end-to-end request latency target (ms).
        prefix: Prefix cache length.
        nextn: MTP draft length, or ``"auto"`` to use the checkpoint's
            ``num_nextn_predict_layers`` (absent/0 keeps MTP disabled).
            Default 0 (disabled); never enabled implicitly.
        nextn_accepted: Average accepted draft tokens per decode step
            (0 <= nextn_accepted <= nextn). Required when the draft depth
            resolves to > 0; never inferred.
        enable_chunked_prefill: Whether to enable chunked prefill for finer context token sweep.
        enable_wideep: DEPRECATED and ignored (warns once): large-EP is explored
            automatically from data coverage inside the single MoE task per
            serving mode. Restrict with *_moe_ep_candidates in an exp YAML.
        moe_backend: Explicit SGLang MoE backend override ('deepep_moe' is
            deprecated and ignored; 'megamoe' is a real kernel selection).
        engine_step_backend: Engine-step latency backend. The compiled Rust
            engine is the only step executor; "rust" is the only accepted
            value (the deprecated "python" no-op was removed).
        forward_model: Forward-pass modeling mode ("op_level" or "fpm"). None
            keeps the default. Both evaluate on the compiled engine ("fpm"
            through its native FpmForward operation).
        serving_mode: Serving modes to build. ``"auto"`` and ``"all"`` both build
            agg and disagg, and an explicit mode builds only that mode.

    Returns:
        Task objects keyed by serving mode and, when requested, backend.
    """
    engine_step_backend = validate_engine_step_backend(engine_step_backend)

    # Deprecated large-EP knobs: warn once, then ignore (the flag is NOT
    # forwarded to the tasks; an explicit moe_backend value still passes
    # through unchanged — 'deepep_moe' is inert in modeling, 'megamoe' real).
    if enable_wideep:
        _warn_large_ep_flag("enable_wideep")
    if moe_backend == "deepep_moe":
        _warn_large_ep_flag("moe_backend=deepep_moe")

    decode_system = decode_system or system
    if serving_mode not in ("auto", "all", "agg", "disagg"):
        raise ValueError(f"Invalid serving_mode: {serving_mode!r}. Use 'auto', 'all', 'agg', or 'disagg'.")
    if serving_mode in ("auto", "all"):
        modes_to_sweep = {"agg", "disagg"}
    else:
        modes_to_sweep = {serving_mode}
    if enable_epd and not (modes_to_sweep & {"agg", "disagg"}):
        raise ValueError("enable_epd requires an agg or disagg experiment.")
    needs_disagg = "disagg" in modes_to_sweep

    backends_to_sweep = [b.value for b in common.BackendName] if backend == "auto" else [backend]
    if backend == "auto" and moe_backend == "megamoe":
        backends_to_sweep = [common.BackendName.sglang.value]

    if backend == "auto":
        supported = perf_database.get_supported_databases()
        available = []
        requires_declared_perf_database = _database_mode_requires_declared_perf_database(database_mode)
        for backend_name in backends_to_sweep:
            sys_backends = supported.get(system, {})
            if not requires_declared_perf_database:
                sys_versions = sys_backends.get(backend_name, [])
                resolved_bv = _resolve_version_for_matching(system, backend_name, backend_version)
                if not sys_versions:
                    logger.warning(
                        "No measured database for backend %s on system=%s; including it for %s estimates.",
                        backend_name,
                        system,
                        database_mode,
                    )
                elif resolved_bv is not None and resolved_bv not in sys_versions:
                    logger.warning(
                        "No measured database version %s for backend %s on system=%s; including it for %s estimates.",
                        backend_version,
                        backend_name,
                        system,
                        database_mode,
                    )
                available.append(backend_name)
                continue
            if backend_name not in sys_backends:
                logger.warning("Skipping backend %s: not supported for system %s.", backend_name, system)
                continue
            if backend_version is not None and _resolve_version_for_matching(
                system, backend_name, backend_version
            ) not in sys_backends.get(backend_name, []):
                logger.warning(
                    "Skipping backend %s: version %s not available for system %s.",
                    backend_name,
                    backend_version,
                    system,
                )
                continue
            available.append(backend_name)
        if not available:
            logger.error(
                "No backends available for system %s. Supported backends: %s",
                system,
                ", ".join(sorted(supported.get(system, {}).keys())),
            )
            raise SystemExit(1)
        backends_to_sweep = available
    elif _database_mode_requires_declared_perf_database(database_mode):
        _ensure_backend_version_available(system, backend, backend_version)
        if needs_disagg and decode_system != system:
            _ensure_backend_version_available(decode_system, backend, backend_version)
    else:
        supported = perf_database.get_supported_databases()
        systems_to_check = [("system", system)]
        if needs_disagg:
            systems_to_check = [("prefill", system), ("decode", decode_system)]
        for role, sys_name in systems_to_check:
            versions = supported.get(sys_name, {}).get(backend, [])
            resolved_bv = _resolve_version_for_matching(sys_name, backend, backend_version)
            if resolved_bv is not None and versions and resolved_bv not in versions:
                logger.warning(
                    "No measured database version %s for %s system=%s backend=%s; using %s estimates.",
                    backend_version,
                    role,
                    sys_name,
                    backend,
                    database_mode,
                )
            elif not versions:
                logger.warning(
                    "No measured database for %s system=%s backend=%s; using estimate-only version with %s mode.",
                    role,
                    sys_name,
                    backend,
                    database_mode,
                )

    def _disagg_backend_available(backend_name: str) -> bool:
        if decode_system == system or not _database_mode_requires_declared_perf_database(database_mode):
            return True
        supported = perf_database.get_supported_databases()
        decode_versions = supported.get(decode_system, {}).get(backend_name, [])
        if not decode_versions:
            logger.warning(
                "Skipping disagg for backend %s: not supported for decode system %s.",
                backend_name,
                decode_system,
            )
            return False
        if (
            backend_version is not None
            and _resolve_version_for_matching(decode_system, backend_name, backend_version) not in decode_versions
        ):
            logger.warning(
                "Skipping disagg for backend %s: version %s not available for decode system %s.",
                backend_name,
                backend_version,
                decode_system,
            )
            return False
        return True

    global_kwargs: dict[str, Any] = {
        "isl": isl,
        "osl": osl,
        "prefix": prefix,
        "ttft": ttft,
        "tpot": tpot,
        "request_latency": request_latency,
        "total_gpus": total_gpus,
        "database_mode": database_mode,
        "transfer_policy": transfer_policy,
        "free_gpu_memory_fraction": free_gpu_memory_fraction,
        "max_seq_len": max_seq_len,
        "attention_backend": attention_backend,
        "engine_step_backend": engine_step_backend,
    }
    if forward_model is not None:
        global_kwargs["forward_model"] = forward_model
    if nextn == "auto" or (isinstance(nextn, int) and nextn > 0):
        global_kwargs["nextn"] = nextn
        global_kwargs["nextn_accepted"] = nextn_accepted

    if image_height or image_width or (num_images and num_images != 1):
        global_kwargs["image_height"] = image_height
        global_kwargs["image_width"] = image_width
        global_kwargs["num_images_per_request"] = num_images
    if video_height or video_width or video_frames or num_videos or num_video_tokens:
        global_kwargs["video_height"] = video_height
        global_kwargs["video_width"] = video_width
        global_kwargs["video_frames"] = video_frames
        global_kwargs["num_videos_per_request"] = num_videos
        global_kwargs["num_video_tokens"] = num_video_tokens
    if not enable_encoder_dp:
        global_kwargs["enable_encoder_dp"] = False

    def _sglang_moe_backend_override(backend_name: str) -> str | None:
        # An explicit --moe-backend applies to SGLang tasks only (matches the
        # legacy behavior); the deprecated enable_wideep flag no longer spells
        # deepep_moe here — large EP is coverage-driven inside the one task.
        if backend_name != common.BackendName.sglang.value:
            return None
        return moe_backend

    def _make_agg(backend_name: str, moe_backend_value: str | None) -> Task:
        return Task(
            serving_mode="agg",
            model_path=model_path,
            system_name=system,
            backend_name=backend_name,
            backend_version=backend_version,
            enable_chunked_prefill=enable_chunked_prefill,
            moe_backend=moe_backend_value,
            enable_epd=enable_epd,
            encoder_tp_candidates=encoder_tp,
            encoder_system_name=encoder_system,
            encoder_latency_correction=encoder_latency_correction,
            **global_kwargs,
        )

    def _make_disagg(backend_name: str, moe_backend_value: str | None) -> Task:
        return Task(
            serving_mode="disagg",
            prefill_model_path=model_path,
            decode_model_path=model_path,
            prefill_system_name=system,
            decode_system_name=decode_system,
            prefill_backend_name=backend_name,
            decode_backend_name=backend_name,
            prefill_backend_version=backend_version,
            decode_backend_version=backend_version,
            prefill_enable_chunked_prefill=enable_chunked_prefill,
            moe_backend=moe_backend_value,
            enable_epd=enable_epd,
            encoder_tp_candidates=encoder_tp,
            encoder_system_name=encoder_system,
            encoder_latency_correction=encoder_latency_correction,
            **global_kwargs,
        )

    # ONE task per (model, serving mode): the flag-driven wideep/non-wideep
    # variants and the flag-conditioned extra SGLang DeepEP sweeps are gone.
    # Each MoE task auto-explores the fused AND (when perf data covers the
    # model shape) the multi-node large-EP regimes per parallel tuple, so the
    # frontier is the union of what the removed variants produced.
    tasks: dict[str, Task] = {}

    for backend_name in backends_to_sweep:
        backend_moe = _sglang_moe_backend_override(backend_name)

        if "agg" in modes_to_sweep:
            exp_name = f"agg_{backend_name}" if backend == "auto" else "agg"
            tasks[exp_name] = _make_agg(backend_name, backend_moe)

        if "disagg" not in modes_to_sweep:
            continue
        if not _disagg_backend_available(backend_name):
            continue
        if total_gpus < 2:
            logger.warning("Skipping disagg since it requires at least 2 GPUs.")
            continue

        exp_name = f"disagg_{backend_name}" if backend == "auto" else "disagg"
        tasks[exp_name] = _make_disagg(backend_name, backend_moe)

    if not tasks:
        logger.error("No task configs could be built for serving_mode=%s.", serving_mode)
        raise SystemExit(1)
    return tasks


def build_experiment_tasks(
    yaml_path: str | None = None,
    config: dict[str, Any] | None = None,
    engine_step_backend: str | None = None,
    forward_model: str | None = None,
    attention_backend: str | None = None,
) -> dict[str, Task]:
    """Build task configs from YAML file or config dict.

    Args:
        yaml_path: Path to a YAML file containing experiment definitions.
        config: Dict containing experiment definitions (alternative to yaml_path).
            Keys are experiment names, values are experiment configs.
        engine_step_backend: Optional global engine-step latency backend override.
            Per-experiment ``engine_step_backend`` entries take precedence;
            unset defaults to the compiled Rust engine.
        forward_model: Optional global forward-pass modeling mode ("op_level"/"fpm").
            Per-experiment ``forward_model`` entries take precedence.

    Returns:
        Dict mapping experiment names to Task objects.

    Raises:
        ValueError: If both or neither of yaml_path/config provided, or YAML load fails.
        TypeError: If experiment data is not a dict.
    """
    if yaml_path is not None and config is not None:
        raise ValueError("Provide either yaml_path or config, not both.")
    if yaml_path is None and config is None:
        raise ValueError("Must provide either yaml_path or config.")

    # Load experiment data
    if yaml_path is not None:
        try:
            with open(yaml_path, encoding="utf-8") as fh:
                experiment_data = yaml.safe_load(fh) or {}
        except Exception as exc:
            raise ValueError(f"Error loading experiment YAML file '{yaml_path}'") from exc
    else:
        experiment_data = config

    if not isinstance(experiment_data, dict):
        raise TypeError("Experiment data must be a mapping (dict).")

    order = experiment_data.get("exps")
    if isinstance(order, list):
        experiment_names = [name for name in order if name in experiment_data]
    else:
        experiment_names = [name for name in experiment_data if name != "exps"]

    tasks: dict[str, Any] = {}

    for exp_name in experiment_names:
        exp_config = experiment_data[exp_name]
        if not isinstance(exp_config, dict):
            logger.warning("Skipping experiment '%s': configuration is not a mapping.", exp_name)
            continue

        serving_mode = exp_config.get("serving_mode")
        # model_path / system_name are top-level for agg and legacy-V1 disagg, but
        # flat-V2 disagg carries them only under prefill_* / decode_*.  Accept either.
        model_path = (
            exp_config.get("model_path") or exp_config.get("prefill_model_path") or exp_config.get("decode_model_path")
        )
        if serving_mode == "afd":
            logger.warning(
                "Skipping experiment '%s': serving_mode 'afd' no longer runs through the "
                "legacy CLI. AFD runs through the unified CLI: `aisimulate recommend` "
                "with an `workers.<role>.afd` block, then `aisimulate predict`.",
                exp_name,
            )
            continue
        if serving_mode not in {"agg", "disagg"} or not model_path:
            logger.warning("Skipping experiment '%s': missing serving_mode or model_path.", exp_name)
            continue

        system_name = (
            exp_config.get("system_name")
            or exp_config.get("prefill_system_name")
            or exp_config.get("decode_system_name")
        )
        if not system_name:
            logger.warning("Skipping experiment '%s': no system_name provided.", exp_name)
            continue

        database_mode = exp_config.get("database_mode", common.DatabaseMode.SILICON.name)

        if exp_config.get("total_gpus") is None:
            logger.warning("Skipping experiment '%s': total_gpus not provided.", exp_name)
            continue

        if _database_mode_requires_declared_perf_database(database_mode):
            # Early-fail on an unavailable backend version (clearer than failing deep in the sweep).
            # Role-aware: agg and legacy-v1 disagg carry backend/version/system at the top level;
            # flat-v2 disagg carries them per role (prefill_*/decode_*), falling back to top-level so
            # v1 configs still validate.
            if serving_mode == "disagg":
                role_checks = [
                    (
                        exp_config.get("prefill_system_name") or system_name,
                        exp_config.get("prefill_backend_name") or exp_config.get("backend_name"),
                        exp_config.get("prefill_backend_version") or exp_config.get("backend_version"),
                    ),
                    (
                        exp_config.get("decode_system_name") or system_name,
                        exp_config.get("decode_backend_name") or exp_config.get("backend_name"),
                        exp_config.get("decode_backend_version") or exp_config.get("backend_version"),
                    ),
                ]
            else:
                role_checks = [(system_name, exp_config.get("backend_name"), exp_config.get("backend_version"))]
            seen_combos: set[tuple[str, str, str]] = set()
            for sys_name, bname, bver in role_checks:
                bname = bname or common.BackendName.trtllm.value
                if bver is not None and sys_name and (sys_name, bname, bver) not in seen_combos:
                    seen_combos.add((sys_name, bname, bver))
                    _ensure_backend_version_available(sys_name, bname, bver)

        # Per-experiment engine_step_backend / forward_model win over the global defaults.
        overrides: dict[str, Any] = {}
        if engine_step_backend is not None and "engine_step_backend" not in exp_config:
            overrides["engine_step_backend"] = engine_step_backend
        if forward_model is not None and "forward_model" not in exp_config:
            overrides["forward_model"] = forward_model
        if attention_backend is not None and "attention_backend" not in exp_config:
            overrides["attention_backend"] = attention_backend

        try:
            task_config = {**exp_config, "database_mode": database_mode}
            tasks[exp_name] = Task.from_yaml(task_config, **overrides)
        except Exception as exc:
            if is_expected_cli_error(exc):
                logger.log(logging.ERROR, "Failed to build Task for experiment '%s': %s", exp_name, exc)
                logger.debug("Traceback for experiment %s", exp_name, exc_info=True)
            else:
                logger.exception("Failed to build Task for experiment '%s'", exp_name)

    return tasks


def _execute_tasks(
    tasks: dict[str, Task],
    mode: str,
    top_n: int = 5,
    target_request_rate: float | None = None,
    target_concurrency: float | None = None,
    max_total_gpus: int | None = None,
    strict_sla: bool = False,
    inclusive_tpot: bool = False,
    parallel_experiments: bool = False,
) -> tuple[
    str,
    dict[str, pd.DataFrame],
    dict[str, pd.DataFrame],
    dict[str, float],
    dict[str, dict[str, float]],
    dict[str, ExperimentOutcome],
]:
    """
    Execute task configs and return the chosen experiment, best configs, results, best
    throughputs, and estimated latencies.

    Args:
        tasks: Dictionary mapping experiment names to Task objects to execute.
        mode: Execution mode ('default' or 'exp').
        top_n: Number of top configurations to return for each experiment.
        target_request_rate: If set, activates load-match picking (minimize
            GPUs for the given request rate in req/s).
        target_concurrency: If set, activates load-match picking (minimize
            GPUs for the given number of concurrent requests).
        max_total_gpus: Optional upper bound on total GPUs for load-match.
        strict_sla: When True, enforce both TTFT and TPOT SLA constraints
            during picking.
        inclusive_tpot: When True, replace TPOT in terminal and CSV output
            with (ttft + tpot * (osl - 1)) / osl.

    Returns:
        tuple:
            - The experiment name with the overall best throughput ("chosen experiment").
            - Dictionary of best config DataFrames per experiment (or per serving mode if merged).
            - Dictionary of Pareto frontier DataFrames per experiment (or mode).
            - Dictionary of best throughput values per experiment (or mode).
            - Dictionary of estimated latencies per experiment. Each value is a
              dict with keys ``"ttft"``, ``"tpot"``, ``"request_latency"``
              extracted from the rank-1 config.
    """
    results: dict[str, dict[str, pd.DataFrame]] = {}
    outcomes: dict[str, ExperimentOutcome] = {}
    start_time = time.time()

    def _run_one(exp_name: str, task) -> tuple[str, dict | None, ExperimentOutcome]:
        """Run a single experiment and return (name, result_or_None, outcome)."""
        try:
            logger.info("Starting experiment: %s", exp_name)
            logger.debug("Task config: \n%s", task.to_yaml())
            pareto_df = task.run()
            if pareto_df is not None and not pareto_df.empty:
                logger.info("Experiment %s completed with %d results.", exp_name, len(pareto_df))
                return exp_name, {"pareto_df": pareto_df}, ExperimentOutcome(exp_name)
            db_mode = getattr(task, "database_mode", None)
            hybrid_hint = (
                " For frontier/new models without silicon data, try --database-mode HYBRID."
                if db_mode == common.DatabaseMode.SILICON.name
                else ""
            )
            # Load-target runs (recommend / auto-recommend) manage the GPU budget
            # internally, so --total-gpus advice would point at an ignored flag.
            gpu_hint = (
                "(2) the model does not fit — try a quantized model; "
                if target_request_rate is not None or target_concurrency is not None
                else "(2) the model does not fit — try a larger --total-gpus value or a quantized model; "
            )
            msg = (
                f"Experiment {exp_name} returned no results. Possible causes: "
                "(1) TTFT/TPOT constraints are too tight — try relaxing --ttft or --tpot; "
                f"{gpu_hint}"
                f"(3) no perf data in the database for this configuration.{hybrid_hint}"
            )
            logger.warning(msg)
            return exp_name, None, ExperimentOutcome(exp_name)
        except NoFeasibleConfigError as exc:
            msg = f"Experiment {exp_name} found no SLA-feasible configuration: {exc}"
            logger.warning(msg)
            return exp_name, None, ExperimentOutcome(exp_name, error=exc)
        except Exception as exc:
            if is_expected_cli_error(exc):
                logger.log(logging.ERROR, "Error running experiment %s: %s", exp_name, exc)
                logger.debug("Traceback for experiment %s", exp_name, exc_info=True)
            else:
                logger.exception("Error running experiment %s", exp_name)
            return exp_name, None, ExperimentOutcome(exp_name, error=exc)

    if parallel_experiments and len(tasks) >= 2:
        with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
            futures = {pool.submit(_run_one, n, t): n for n, t in tasks.items()}
            for future in as_completed(futures):
                exp_name, task_result, outcome = future.result()
                outcomes[exp_name] = outcome
                if task_result is not None:
                    results[exp_name] = task_result
    else:
        for exp_name, task in tasks.items():
            exp_name, task_result, outcome = _run_one(exp_name, task)
            outcomes[exp_name] = outcome
            if task_result is not None:
                results[exp_name] = task_result

    if len(results) < 1:
        first_config = next(iter(tasks.values()), None)
        db_mode = getattr(first_config, "database_mode", None) if first_config else None
        if db_mode == common.DatabaseMode.SILICON.name:
            logger.error(
                "No successful experiment runs to compare. "
                "If this is a frontier or newly-released model, retry with --database-mode HYBRID "
                "to extend coverage beyond the silicon database."
            )
        else:
            logger.error("No successful experiment runs to compare.")
        for outcome in outcomes.values():
            if outcome.error is not None:
                logger.error("  -> Experiment %s failed: %s", outcome.experiment, outcome.error)
        return "none", {}, {}, {}, {}, outcomes

    best_configs: dict[str, pd.DataFrame] = {}
    best_throughputs: dict[str, float] = {}
    best_latencies: dict[str, dict[str, float]] = {}
    pareto_fronts: dict[str, pd.DataFrame | None] = {}
    pareto_x_axis: dict[str, str] = {}
    for name, task_result in results.items():
        task = tasks[name]
        best_config_df, best_throughput, pareto_frontier_df, x_axis_col, latencies = process_experiment_result(
            task,
            task_result,
            top_n,
            target_request_rate=target_request_rate,
            target_concurrency=target_concurrency,
            max_total_gpus=max_total_gpus,
            strict_sla=strict_sla,
        )
        best_configs[name] = best_config_df
        best_throughputs[name] = best_throughput
        best_latencies[name] = latencies
        pareto_fronts[name] = pareto_frontier_df
        pareto_x_axis[name] = x_axis_col

    if mode == "default" and len(tasks) > 2:
        best_configs, best_throughputs, pareto_fronts, pareto_x_axis = merge_experiment_results_by_mode(
            tasks, best_configs, pareto_fronts, pareto_x_axis, top_n
        )

    chosen_exp = max(best_throughputs, key=best_throughputs.get) if best_throughputs else "none"

    log_final_summary(
        chosen_exp=chosen_exp,  # for summary
        best_throughputs=best_throughputs,  # for summary
        best_configs=best_configs,  # for table
        pareto_fronts=pareto_fronts,  # for plotting
        tasks=tasks,  # for info in summary
        mode=mode,
        pareto_x_axis=pareto_x_axis,
        top_n=top_n,
        target_request_rate=target_request_rate,
        target_concurrency=target_concurrency,
        inclusive_tpot=inclusive_tpot,
    )

    end_time = time.time()
    logger.info("All experiments completed in %.2f seconds", end_time - start_time)

    return chosen_exp, best_configs, pareto_fronts, best_throughputs, best_latencies, outcomes


def _run_generate_mode(args):
    """Run the generate mode to create a naive agg config without sweeping."""
    model_path = args.model_path
    logger.info("Generating naive agg configuration for %s on %d GPUs", model_path, args.total_gpus)

    generator_overrides = load_generator_overrides_from_args(args)

    # Use the public API function
    result = generate_naive_config(
        model_path=model_path,
        total_gpus=args.total_gpus,
        system=args.system,
        backend=args.backend,
        output_dir=args.save_dir or "./output",
        generated_config_version=getattr(args, "generated_config_version", None),
        generator_dynamo_version=getattr(args, "generator_dynamo_version", None),
        generator_overrides=generator_overrides,
        deployment_target=getattr(args, "deployment_target", "dynamo-j2"),
    )

    # Extract result data for CLI output
    generator_params = result["generator_params"]
    backend_version = result["backend_version"]
    output_dir = result["output_dir"]
    parallelism = result["parallelism"]
    tp = parallelism["tp"]
    pp = parallelism["pp"]
    gpus_per_worker = parallelism.get("gpus_per_worker", tp * pp)
    replicas = parallelism["replicas"]
    gpus_used = parallelism["gpus_used"]

    # Print summary
    print("\n" + "=" * 60)
    print("  Naive Configuration Generated Successfully")
    print("=" * 60)
    print(f"  Model:           {model_path}")
    print(f"  System:          {args.system}")
    print(f"  Backend:         {args.backend} ({backend_version})")
    print(f"  Total GPUs:      {args.total_gpus} (using {gpus_used})")
    print(f"  Parallelism:     TP={tp}, PP={pp}")
    print(f"  Replicas:        {replicas} (each using {gpus_per_worker} GPUs)")
    print(f"  Max Batch Size:  {_get_naive_summary_max_batch_size(generator_params)}")
    print(f"  Output:          {output_dir}")
    print("=" * 60)
    print("\nGenerated files:")
    for filename in sorted(os.listdir(output_dir)):
        filepath = os.path.join(output_dir, filename)
        if os.path.isfile(filepath):
            print(f"  - {filename}")
        elif os.path.isdir(filepath):
            print(f"  - {filename}/")
            for subfile in sorted(os.listdir(filepath)):
                print(f"      - {subfile}")
    print("\n" + "-" * 60)
    print("  WARNING: This is a NAIVE configuration generated without")
    print("  memory validation or performance optimization. It may NOT")
    print("  work if the model is too large for the available GPU memory.")
    print("")
    print("  For production deployments, use 'aiconfigurator cli default'")
    print("  to run the full parameter sweep with SLA optimization.")
    print("-" * 60)
    if getattr(args, "deployment_target", None) == "slurm":
        print("\nOn the Slurm cluster, run: bash submit.sh benchmark (or: bash submit.sh serve).")
    else:
        print("\nTo deploy, run the generated shell script or apply the k8s manifest.")
    print("=" * 60 + "\n")


def _get_naive_summary_max_batch_size(generator_params: dict[str, Any]) -> Any:
    params = generator_params.get("params", {})
    if not isinstance(params, dict):
        return "n/a"
    for role in ("agg", "prefill", "decode"):
        role_params = params.get(role)
        if isinstance(role_params, dict) and role_params.get("max_batch_size") is not None:
            return role_params["max_batch_size"]
    for role_params in params.values():
        if isinstance(role_params, dict) and role_params.get("max_batch_size") is not None:
            return role_params["max_batch_size"]
    return "n/a"


def _run_support_matrix_mode(args):
    """Run support check across system/backend combinations and display a matrix."""
    model = args.model_path
    version_filter = args.backend_version

    try:
        architecture = get_model_config_from_model_path(model)["architecture"]
    except Exception:
        architecture = None

    matrix = common.get_support_matrix()
    systems = common.sort_support_matrix_systems(common.SupportedSystems) if args.system == "all" else [args.system]
    backends = [b.value for b in common.BackendName] if args.backend == "all" else [args.backend]
    existing_combos = {(row["System"].lower(), row["Backend"].lower()) for row in matrix}

    results: dict[tuple[str, str], common.SupportResult | None] = {}
    has_inferred = False

    for system in systems:
        for be in backends:
            if (system.lower(), be.lower()) not in existing_combos:
                results[(system, be)] = None
                continue

            if version_filter:
                version = version_filter
            else:
                version = _latest_support_matrix_version(
                    matrix,
                    system,
                    be,
                    model=model,
                    architecture=architecture,
                    queryable_versions=_queryable_versions(system, be),
                )
                if version is None:
                    results[(system, be)] = None
                    continue

            result = common.check_support(
                model=model, system=system, backend=be, version=version, architecture=architecture
            )
            if not result.exact_match and result.agg_total_count == 0 and result.disagg_total_count == 0:
                result = None
            elif not result.exact_match and result.architecture:
                has_inferred = True
            results[(system, be)] = result

    # ── render matrix ────────────────────────────────────────────
    col_w = 6  # sub-column width (fits "disagg", "YES*", etc.)
    gap = "   "
    sys_w = max(len("System"), *(len(s) for s in systems)) + 2
    block_w = col_w * 2 + 1  # "agg" + space + "disagg"

    def _cell(supported: bool, inferred: bool) -> str:
        return f"{('YES' if supported else 'NO') + ('*' if inferred else ''):>{col_w}}"

    sub_col = f"{'agg':>{col_w}} {'disagg':>{col_w}}"
    header1 = " " * sys_w + gap.join(be.center(block_w) for be in backends)
    header2 = f"{'System':<{sys_w}}" + gap.join(sub_col for _ in backends)
    sep = "-" * sys_w + gap.join("-" * block_w for _ in backends)
    total_w = max(60, len(sep) + 4)

    lines = ["", "=" * total_w, "  AIC Support Matrix", "=" * total_w, f"  Model:  {model}"]
    if architecture:
        lines.append(f"  Arch:   {architecture}")
    if version_filter:
        lines.append(f"  Version filter: {version_filter}")
    lines += ["-" * total_w, f"  {header1}", f"  {header2}", f"  {sep}"]

    for system in systems:
        cells = []
        for be in backends:
            r = results.get((system, be))
            if r is None:
                cells.append(f"{'-':>{col_w}} {'-':>{col_w}}")
            else:
                inf = not r.exact_match and r.architecture is not None
                cells.append(f"{_cell(r.agg_supported, inf)} {_cell(r.disagg_supported, inf)}")
        lines.append(f"  {system:<{sys_w}}" + gap.join(cells))

    lines.append("=" * total_w)
    lines.append("  YES = supported  NO = not supported  - = no data")
    if has_inferred:
        lines.append("  * = inferred from architecture majority vote")
    if not version_filter:
        lines.append("  Using latest available version per system/backend combination.")
    lines += ["=" * total_w, ""]
    print("\n".join(lines))


def _default_support_version(model: str, system: str, backend: str, architecture: str | None) -> str | None:
    """Use the current slot, or the latest relevant certification version without slot policy."""
    slots = perf_database.get_version_slots(system.lower(), backend.lower())
    if slots:
        return slots["current"]
    return _latest_support_matrix_version(
        common.get_support_matrix(), system, backend, model=model, architecture=architecture
    )


def _run_support_mode(args):
    """Run the support mode to see if a model/hardware combo is supported."""
    if args.backend is None:
        args.backend = "all" if args.system == "all" else "trtllm"

    if args.system == "all" or args.backend == "all":
        _run_support_matrix_mode(args)
        return

    model = args.model_path
    system = args.system
    backend = args.backend
    version = args.backend_version

    # Resolve architecture for better check
    try:
        model_info = get_model_config_from_model_path(model)
        architecture = model_info["architecture"]
    except Exception:
        architecture = None

    # Match prediction's current slot even when it has no certification rows.
    # Trees without slot policy retain their matrix-based compatibility default.
    if not version:
        version = _default_support_version(model, system, backend, architecture)
        if version is None:
            logger.info(
                "No valid support-matrix backend version found for model=%s system=%s backend=%s",
                model,
                system,
                backend,
            )
            print("\nNo valid support-matrix backend version found for this model/system/backend combination.\n")
            return

    logger.info("Checking support for model=%s, system=%s, backend=%s, version=%s", model, system, backend, version)

    result = common.check_support(
        model=model, system=system, backend=backend, version=version, architecture=architecture
    )

    print("\n" + "=" * 60)
    print("  AIC Support Check Results")
    print("=" * 60)
    print(f"  Model:           {model}")
    print(f"  System:          {system}")
    print(f"  Backend:         {backend}")
    print(f"  Version:         {version}")
    print("-" * 60)
    print(f"  Aggregated Support:    {'YES' if result.agg_supported else 'NO'}")
    print(f"  Disaggregated Support: {'YES' if result.disagg_supported else 'NO'}")
    if not result.exact_match and result.agg_total_count == 0 and result.disagg_total_count == 0:
        print("  Note: No matching model or eligible architecture certification rows were found.")

    # Show explanation if support was inferred from architecture majority vote
    if not result.exact_match and result.architecture and (result.agg_total_count > 0 or result.disagg_total_count > 0):
        print("-" * 60)
        print(
            f"  Note: Model '{model}' not found in support matrix cache,\n\
    but the model matches architecture '{result.architecture}'."
        )
        print(f"  Support inferred from architecture '{result.architecture}' majority vote:")
        if result.agg_total_count:
            p, t = result.agg_pass_count, result.agg_total_count
            print(f"    Aggregated:    {p}/{t} passed (>{t // 2} required)")
        if result.disagg_total_count:
            p, t = result.disagg_pass_count, result.disagg_total_count
            print(f"    Disaggregated: {p}/{t} passed (>{t // 2} required)")

    print("=" * 60 + "\n")


def _print_per_ops_section(title: str, ops: dict) -> None:
    """Print a single section of per-op latency breakdown."""
    total = sum(ops.values())
    print(f"  {title} (total: {total:.3f} ms)")
    for op_name, latency in sorted(ops.items(), key=lambda x: -x[1]):
        pct = latency / total * 100 if total > 0 else 0
        print(f"    {op_name:<40s} {latency:>10.3f} ms  ({pct:>5.1f}%)")


def _print_per_ops_latency(per_ops_data: dict) -> None:
    """Print per-operation latency breakdown from run_agg / run_disagg.

    NOTE: ``cli estimate`` now surfaces per-op breakdowns through
    ``format_estimate_detail_report`` (driven by ``--detail``). These helpers
    are kept available for future callers that still want the standalone
    summary print.
    """
    print("\n" + "-" * 60)
    print("  Per-Operation Latency Breakdown")
    print("-" * 60)

    # Agg mode: mix_step + genonly_step + scheduling
    scheduling = per_ops_data.get("scheduling")
    if scheduling:
        num_mix = scheduling.get("num_mix_steps", 0)
        num_genonly = scheduling.get("num_genonly_steps", 0)
        print(f"  Scheduling: {num_mix:.0f} mix steps + {num_genonly:.0f} gen-only steps")
        print()

    mix_ops = per_ops_data.get("mix_step", {})
    if mix_ops:
        _print_per_ops_section("Mix Step", mix_ops)

    genonly_ops = per_ops_data.get("genonly_step", {})
    if genonly_ops:
        print()
        _print_per_ops_section("Gen-Only Step", genonly_ops)

    # Disagg mode: prefill + decode
    prefill_ops = per_ops_data.get("prefill", {})
    if prefill_ops:
        _print_per_ops_section("Prefill (static_ctx)", prefill_ops)

    decode_ops = per_ops_data.get("decode", {})
    if decode_ops:
        print()
        _print_per_ops_section("Decode (static_gen)", decode_ops)


def _run_estimate_epd(args, estimate_mode: str) -> None:
    """EPD single-point estimate via Task.run_single_* (dedicated encode pool)."""
    from aisimulate.legacy_cli.api import apply_row_power_coverage_gate
    from aisimulate.sdk.task_v2 import _QUANT_ENUM_TABLES, Task

    if estimate_mode not in ("agg", "disagg"):
        raise SystemExit("--enable-epd supports --estimate-mode agg or disagg only.")
    if any(
        fraction is not None
        for fraction in (
            args.prefill_free_gpu_memory_fraction,
            args.decode_free_gpu_memory_fraction,
        )
    ):
        raise SystemExit(
            "--prefill-free-gpu-memory-fraction and --decode-free-gpu-memory-fraction "
            "are not supported with --enable-epd; use --free-gpu-memory-fraction."
        )
    if any(
        max_seq_len is not None
        for max_seq_len in (
            args.prefill_max_seq_len,
            args.decode_max_seq_len,
        )
    ):
        raise SystemExit(
            "--prefill-max-seq-len and --decode-max-seq-len are not supported with --enable-epd; use --max-seq-len."
        )
    workload = dict(
        enable_epd=True,
        backend_version=args.backend_version,
        database_mode=args.database_mode,
        transfer_policy=args.transfer_policy,
        isl=args.isl,
        osl=args.osl,
        prefix=args.prefix,
        image_height=args.image_height,
        image_width=args.image_width,
        num_images_per_request=args.num_images,
        free_gpu_memory_fraction=args.free_gpu_memory_fraction,
        max_seq_len=args.max_seq_len,
        engine_step_backend=args.engine_step_backend,
        forward_model=args.forward_model,
        nextn=args.nextn,
        nextn_accepted=args.nextn_accepted,
        speculative=_speculative_block_from_args(args),
    )
    workload.update({name: getattr(args, name) for name in _QUANT_ENUM_TABLES if getattr(args, name, None)})
    encoder_kwargs = dict(
        encoder_tp=args.encoder_tp,
        encoder_batch_size=1 if args.encoder_batch_size is None else args.encoder_batch_size,
        encoder_num_workers=1 if args.encoder_num_workers is None else args.encoder_num_workers,
    )
    if estimate_mode == "agg":
        task = Task.from_cli(
            serving_mode="agg",
            model_path=args.model_path,
            system_name=args.system,
            backend_name=args.backend,
            **workload,
        )
        row = task.run_single_agg(
            tp=args.tp_size,
            pp=args.pp_size,
            dp=args.attention_dp_size,
            moe_tp=args.moe_tp_size,
            moe_ep=args.moe_ep_size,
            batch_size=args.batch_size,
            ctx_tokens=args.ctx_tokens,
            **encoder_kwargs,
        )
    else:
        # Required disagg params and shared-arg fallbacks mirror cli_estimate.
        for name in ("prefill_batch_size", "prefill_num_workers", "decode_batch_size", "decode_num_workers"):
            if getattr(args, name) is None:
                raise SystemExit(f"{name} is required for disagg mode.")

        def _role(value, shared):
            return value if value is not None else shared

        # Shared quant/version args map to the per-role fields: disagg Tasks
        # reject top-level worker fields and silently ignore backend_version.
        role_shared = {"backend_version": workload.pop("backend_version", None)}
        for name in [k for k in workload if k.endswith("quant_mode")]:
            role_shared[name] = workload.pop(name)
        task = Task.from_cli(
            serving_mode="disagg",
            prefill_model_path=args.model_path,
            decode_model_path=args.model_path,
            prefill_system_name=args.system,
            decode_system_name=args.decode_system or args.system,
            prefill_backend_name=args.backend,
            decode_backend_name=args.backend,
            **{f"prefill_{k}": v for k, v in role_shared.items()},
            **{f"decode_{k}": v for k, v in role_shared.items()},
            **workload,
        )
        row = task.run_single_disagg(
            prefill_tp=_role(args.prefill_tp_size, args.tp_size),
            prefill_pp=_role(args.prefill_pp_size, args.pp_size),
            prefill_dp=_role(args.prefill_attention_dp_size, args.attention_dp_size),
            prefill_moe_tp=_role(args.prefill_moe_tp_size, args.moe_tp_size),
            prefill_moe_ep=_role(args.prefill_moe_ep_size, args.moe_ep_size),
            prefill_batch_size=args.prefill_batch_size,
            prefill_num_workers=args.prefill_num_workers,
            decode_tp=_role(args.decode_tp_size, args.tp_size),
            decode_pp=_role(args.decode_pp_size, args.pp_size),
            decode_dp=_role(args.decode_attention_dp_size, args.attention_dp_size),
            decode_moe_tp=_role(args.decode_moe_tp_size, args.moe_tp_size),
            decode_moe_ep=_role(args.decode_moe_ep_size, args.moe_ep_size),
            decode_batch_size=args.decode_batch_size,
            decode_num_workers=args.decode_num_workers,
            **encoder_kwargs,
        )
    row = apply_row_power_coverage_gate(row)
    _warn_moe_comm_fallbacks(row)
    logger.info("EPD %s single-point estimate:", estimate_mode)
    keys = (
        "ttft",
        "tpot",
        "encoder_latency",
        "request_latency",
        "seq/s",
        "tokens/s/gpu",
        "num_total_gpus",
        "(a)workers",
        "(p)workers",
        "(d)workers",
        "(e)workers",
        "(e)tp",
        "(e)bs",
        "(e)memory",
        "power_w",
    )
    for key in keys:
        if key not in row:
            continue
        value = row[key]
        if key == "power_w" and value is None:
            logger.info("  %-16s unavailable (%.0f%% power-data coverage)", key, row.get("power_coverage", 0.0) * 100)
            continue
        logger.info("  %-16s %s", key, f"{value:.3f}" if isinstance(value, float) else value)


def _warn_moe_comm_fallbacks(result) -> None:
    """Warn when an estimate executed against substitute MoE topology data."""
    fallbacks = result.get(MOE_COMM_FALLBACKS_COLUMN, ()) if isinstance(result, dict) else result.moe_comm_fallbacks
    for fallback in fallbacks:
        logger.warning(
            "Estimated MoE communication latency used fallback silicon data: %s.",
            format_moe_comm_fallback(fallback),
        )


def _run_estimate_mode(args):
    """Run the estimate mode to predict TTFT, TPOT, and power for a single config."""
    from aisimulate.legacy_cli.api import cli_estimate

    if not args.enable_epd and any(
        v is not None for v in (args.encoder_tp, args.encoder_batch_size, args.encoder_num_workers)
    ):
        raise SystemExit("--encoder-tp/--encoder-batch-size/--encoder-num-workers require --enable-epd.")

    estimate_mode = args.estimate_mode

    logger.info(
        "Estimating performance (%s) for %s on %s (backend=%s, tp=%d, bs=%d)",
        estimate_mode,
        args.model_path,
        args.system,
        args.backend,
        args.tp_size,
        args.batch_size,
    )

    _resolve_and_validate_nextn(args)

    if args.enable_epd:
        _run_estimate_epd(args, estimate_mode)
        return

    # Resolve --detail before running the estimate so time detail can compare
    # against a second SOL-mode result.
    detail_arg = (args.detail or "").strip()
    try:
        needs_sol_detail = bool(detail_arg) and detail_requests_time(detail_arg)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc

    # Build kwargs shared between agg, disagg, and static
    estimate_kwargs = dict(
        model_path=args.model_path,
        system_name=args.system,
        mode=estimate_mode,
        backend_name=args.backend,
        backend_version=args.backend_version,
        database_mode=args.database_mode,
        transfer_policy=args.transfer_policy,
        isl=args.isl,
        osl=args.osl,
        image_height=args.image_height,
        image_width=args.image_width,
        num_images=args.num_images,
        video_height=args.video_height,
        video_width=args.video_width,
        video_frames=args.video_frames,
        num_videos=args.num_videos,
        num_video_tokens=args.num_video_tokens,
        enable_encoder_dp=not args.disable_encoder_dp,
        batch_size=args.batch_size,
        ctx_tokens=args.ctx_tokens,
        tp_size=args.tp_size,
        pp_size=args.pp_size,
        attention_dp_size=args.attention_dp_size,
        moe_tp_size=args.moe_tp_size,
        moe_ep_size=args.moe_ep_size,
        gemm_quant_mode=args.gemm_quant_mode,
        kvcache_quant_mode=args.kvcache_quant_mode,
        fmha_quant_mode=args.fmha_quant_mode,
        moe_quant_mode=args.moe_quant_mode,
        comm_quant_mode=args.comm_quant_mode,
        free_gpu_memory_fraction=args.free_gpu_memory_fraction,
        max_seq_len=args.max_seq_len,
        engine_step_backend=args.engine_step_backend,
        forward_model=args.forward_model,
        attention_backend=getattr(args, "attention_backend", None),
        prefix=args.prefix,
        nextn=args.nextn,
        nextn_accepted=args.nextn_accepted,
        speculative=_speculative_block_from_args(args),
        stride=args.stride,
    )

    if estimate_mode == "disagg":
        estimate_kwargs.update(
            decode_system_name=args.decode_system,
            prefill_tp_size=args.prefill_tp_size,
            prefill_pp_size=args.prefill_pp_size,
            prefill_attention_dp_size=args.prefill_attention_dp_size,
            prefill_moe_tp_size=args.prefill_moe_tp_size,
            prefill_moe_ep_size=args.prefill_moe_ep_size,
            prefill_batch_size=args.prefill_batch_size,
            prefill_num_workers=args.prefill_num_workers,
            decode_tp_size=args.decode_tp_size,
            decode_pp_size=args.decode_pp_size,
            decode_attention_dp_size=args.decode_attention_dp_size,
            decode_moe_tp_size=args.decode_moe_tp_size,
            decode_moe_ep_size=args.decode_moe_ep_size,
            decode_batch_size=args.decode_batch_size,
            decode_num_workers=args.decode_num_workers,
            prefill_free_gpu_memory_fraction=args.prefill_free_gpu_memory_fraction,
            decode_free_gpu_memory_fraction=args.decode_free_gpu_memory_fraction,
            prefill_max_seq_len=args.prefill_max_seq_len,
            decode_max_seq_len=args.decode_max_seq_len,
        )

    result = cli_estimate(**estimate_kwargs)
    _warn_moe_comm_fallbacks(result)
    sol_result = None
    sol_detail_error = None
    if needs_sol_detail:
        if args.database_mode == common.DatabaseMode.SOL.name:
            sol_result = result
        else:
            sol_estimate_kwargs = dict(estimate_kwargs)
            sol_estimate_kwargs["database_mode"] = common.DatabaseMode.SOL.name
            try:
                sol_result = cli_estimate(**sol_estimate_kwargs)
            except _SOL_DETAIL_UNAVAILABLE_ERRORS as exc:
                sol_detail_error = str(exc)

    print("\n" + "=" * 60)
    print(f"  Performance Estimate ({result.mode})")
    print("=" * 60)
    print(f"  Model:            {result.model_path}")
    print(f"  System:           {result.system_name}")
    print(f"  Backend:          {result.backend_name} ({result.backend_version})")
    print("-" * 60)
    print(f"  ISL:              {result.isl}")
    print(f"  OSL:              {result.osl}")
    if args.image_height > 0 and args.image_width > 0 and args.num_images > 0:
        print(f"  Images:           {args.num_images} x {args.image_height}x{args.image_width}")
        print(f"  Encoder parallel: {'TP (weight-sharded)' if args.disable_encoder_dp else 'DP (data-parallel)'}")
    has_video_dimensions = args.video_height > 0 and args.video_width > 0
    if args.video_frames > 0 and args.num_videos > 0 and (has_video_dimensions or args.num_video_tokens > 0):
        if has_video_dimensions:
            print(
                f"  Videos:           {args.num_videos} x {args.video_frames} frames x "
                f"{args.video_height}x{args.video_width}"
            )
        else:
            print(
                f"  Videos:           {args.num_videos} x {args.video_frames} frames x "
                f"{args.num_video_tokens} tokens/video"
            )
        print(f"  Encoder parallel: {'TP (weight-sharded)' if args.disable_encoder_dp else 'DP (data-parallel)'}")

    # ``--prefix`` and ``--nextn`` are common parameters applied to every
    # mode (agg / disagg / static*), so surface them in the summary box
    # for all modes rather than gating on mode.
    if args.prefix:
        print(f"  Prefix:           {args.prefix}")
    if args.nextn:
        print(f"  MTP nextn:        {args.nextn} (nextn_accepted={args.nextn_accepted})")

    if result.mode == "disagg":
        raw = result.raw
        print(f"  (p) TP:           {raw.get('(p)tp', 'N/A')}")
        print(f"  (p) PP:           {raw.get('(p)pp', 'N/A')}")
        print(f"  (p) BS:           {raw.get('(p)bs', 'N/A')}")
        print(f"  (p) Workers:      {raw.get('(p)workers', 'N/A')}")
        print(f"  (d) TP:           {raw.get('(d)tp', 'N/A')}")
        print(f"  (d) PP:           {raw.get('(d)pp', 'N/A')}")
        print(f"  (d) BS:           {raw.get('(d)bs', 'N/A')}")
        print(f"  (d) Workers:      {raw.get('(d)workers', 'N/A')}")
        print(f"  Total GPUs:       {raw.get('num_total_gpus', 'N/A')}")
    else:
        # agg / static / static_ctx / static_gen share the same single-replica shape.
        print(f"  Batch Size:       {result.batch_size}")
        if result.mode == "agg":
            print(f"  Context Tokens:   {result.ctx_tokens}")
        print(f"  TP Size:          {result.tp_size}")
        print(f"  PP Size:          {result.pp_size}")
        if args.attention_dp_size and args.attention_dp_size != 1:
            print(f"  Attention DP:     {args.attention_dp_size}")

    print("-" * 60)
    if result.mode == "static_gen":
        # ttft is zero by construction; surface generation_latency instead.
        gen_lat = float(result.raw.get("generation_latency", 0.0) or 0.0)
        print(f"  Generation lat.:  {gen_lat:.3f} ms")
        print(f"  TPOT:             {result.tpot:.3f} ms")
    elif result.mode == "static_ctx":
        print(f"  TTFT:             {result.ttft:.3f} ms")
    else:
        print(f"  TTFT:             {result.ttft:.3f} ms")
        print(f"  TPOT:             {result.tpot:.3f} ms")
        print(f"  Request Latency:  {result.request_latency:.3f} ms")
    encoder_latency = float(result.raw.get("encoder_latency", 0.0) or 0.0)
    if encoder_latency > 0.0:
        print(f"  Encoder lat.:     {encoder_latency:.3f} ms")
    if result.power_w is None:
        coverage = result.power_coverage
        coverage_note = f" ({coverage:.1%} coverage)" if coverage is not None else ""
        print(f"  Power (per GPU):  unavailable{coverage_note}")
    else:
        print(f"  Power (per GPU):  {result.power_w:.1f} W")
    print("-" * 60)
    print(f"  tokens/s:         {result.tokens_per_second:,.2f}")
    print(f"  tokens/s/gpu:     {result.tokens_per_second_per_gpu:,.2f}")
    print(f"  tokens/s/user:    {result.tokens_per_second_per_user:,.2f}")
    print(f"  seq/s:            {result.seq_per_second:,.3f}")
    print(f"  Concurrency:      {result.concurrency:.0f}")
    if result.mode == "disagg":
        raw = result.raw
        print(f"  (p) Memory:       {raw.get('(p)memory', 'N/A')} GB")
        print(f"  (d) Memory:       {raw.get('(d)memory', 'N/A')} GB")
        encoder_memory = float(raw.get("(e)memory", 0.0) or 0.0)
        if encoder_memory > 0.0:
            print(f"  Encoder memory:   {encoder_memory:.3f} GB (included in prefill)")
    else:
        print(f"  Memory (GPU):     {result.memory:.2f} GB")
        encoder_memory = float(result.raw.get("encoder_memory", 0.0) or 0.0)
        if encoder_memory > 0.0:
            print(f"  Encoder memory:   {encoder_memory:.3f} GB (included)")
    print("=" * 60)

    if result.kv_cache_warning:
        logger.warning(result.kv_cache_warning)

    if detail_arg:
        try:
            report = format_estimate_detail_report(result, sol_result, detail=detail_arg)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        if sol_detail_error is not None:
            report = f"SOL comparison unavailable: {sol_detail_error}\n\n{report}"
        if report:
            print("\n" + "-" * 60)
            print(f"  Detailed Breakdown ({detail_arg})")
            print("-" * 60)
            print(report)
        else:
            logger.warning("--detail requested but no breakdown data is available for this mode.")

    print()


def _resolve_cli_log_level(args) -> int:
    """Pick the log level with priority: --log-level > AICONFIGURATOR_LOG_LEVEL > --debug > INFO."""
    cli_level = getattr(args, "log_level", None)
    if cli_level:
        return getattr(logging, cli_level)
    env_level = os.environ.get("AICONFIGURATOR_LOG_LEVEL")
    if env_level:
        resolved = env_level.strip().upper()
        if resolved in {"CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"}:
            return getattr(logging, resolved)
    if getattr(args, "debug", False):
        return logging.DEBUG
    return logging.INFO


def _validate_fpm_sweep_tasks(args, tasks: dict[str, Task]) -> None:
    """Reject task shapes that can only fail after an expensive FPM sweep."""
    if getattr(args, "deployment_target", "dynamo-j2") != "fpm":
        return

    unsupported: list[str] = []
    for name, task in tasks.items():
        serving_mode = getattr(task, "serving_mode", None)
        backend = getattr(task, "primary_backend_name", None)
        if serving_mode != "agg" or backend != common.BackendName.vllm.value:
            unsupported.append(f"{name} ({serving_mode or 'unknown'}/{backend or 'unknown'})")

    if unsupported:
        raise SystemExit(
            "--deployment-target fpm supports only vLLM aggregated tasks; "
            "unsupported task(s): " + ", ".join(unsupported)
        )


def _run_recommend(args) -> None:
    """Run recommend mode: find minimum GPUs for a load target."""
    from aisimulate.legacy_cli.api import cli_recommend
    from aisimulate.sdk.errors import NoResultsError

    logger.info(
        "Finding minimum GPUs for %s on %s (backend=%s)",
        args.model_path,
        args.system,
        args.backend,
    )
    try:
        cli_recommend(
            model_path=args.model_path,
            system=args.system,
            target_request_rate=getattr(args, "target_request_rate", None),
            target_concurrency=getattr(args, "target_concurrency", None),
            decode_system=args.decode_system,
            backend=args.backend,
            backend_version=args.backend_version,
            database_mode=args.database_mode,
            transfer_policy=args.transfer_policy,
            isl=args.isl,
            osl=args.osl,
            image_height=args.image_height,
            image_width=args.image_width,
            num_images=args.num_images,
            video_height=args.video_height,
            video_width=args.video_width,
            video_frames=args.video_frames,
            num_videos=args.num_videos,
            num_video_tokens=args.num_video_tokens,
            ttft=args.ttft,
            tpot=args.tpot,
            request_latency=args.request_latency,
            prefix=args.prefix,
            nextn=args.nextn,
            nextn_accepted=args.nextn_accepted,
            strict_sla=getattr(args, "strict_sla", False),
            enable_chunked_prefill=args.enable_chunked_prefill,
            free_gpu_memory_fraction=args.free_gpu_memory_fraction,
            max_seq_len=args.max_seq_len,
            enable_wideep=getattr(args, "enable_wideep", False),
            moe_backend=getattr(args, "moe_backend", None),
            attention_backend=getattr(args, "attention_backend", None),
            top_n=args.top_n,
            save_dir=args.save_dir,
            engine_step_backend=args.engine_step_backend,
            forward_model=args.forward_model,
        )
    except NoResultsError as exc:
        logger.debug("Recommend mode traceback", exc_info=True)
        raise SystemExit(1) from exc


def _validate_default_mode_inputs(args) -> None:
    """Validate default-mode args that are conditional on the selected sweeper."""
    if args.mode != "default":
        return
    if getattr(args, "thorough_config", None):
        return

    required = {
        "model_path": "--model-path/--model",
        "system": "--system",
    }
    missing = [flag for attr, flag in required.items() if getattr(args, attr, None) is None]
    if missing:
        raise SystemExit(
            "default mode requires "
            + ", ".join(missing)
            + " unless --thorough-config provides a native Spica SmartSearchConfig."
        )
    has_gpus = getattr(args, "total_gpus", None) is not None
    has_load_target = (
        getattr(args, "target_request_rate", None) is not None or getattr(args, "target_concurrency", None) is not None
    )
    if not has_gpus and not has_load_target:
        raise SystemExit(
            "default mode requires either --total-gpus or a load target (--target-request-rate / --target-concurrency)."
        )


def main(args):
    setup_logging(
        level=_resolve_cli_log_level(args),
        no_color=getattr(args, "no_color", False),
    )

    # Handle support mode early — it doesn't need systems_paths or top_n
    if args.mode == "support":
        _run_support_mode(args)
        return

    try:
        perf_database.set_systems_paths(args.systems_paths)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc

    logger.info(f"Loading AIConfigurator version: {__version__}")
    logger.info(f"Number of top configurations to output: {args.top_n} (change with --top-n)")

    # Handle generate mode separately (no sweeping)
    if args.mode == "generate":
        _run_generate_mode(args)
        return

    # Handle estimate mode separately (single-point estimation)
    if args.mode == "estimate":
        # Expected user errors surface from the SDK as ValueError (invalid
        # sizing/parameters, unsupported quant/compatibility) or as a perf-data
        # coverage miss (PerfDataNotAvailableError / EmpiricalNotImplementedError).
        # Convert them to a concise CLI error instead of a full traceback; keep
        # the traceback at DEBUG (--log-level DEBUG) and let genuine bugs
        # (KeyError, OOM RuntimeError, …) propagate unchanged.
        try:
            _run_estimate_mode(args)
        except Exception as exc:
            if is_expected_cli_error(exc):
                logger.debug("Traceback for estimate mode", exc_info=True)
                raise SystemExit("Error: " + str(exc)) from exc
            raise
        return

    if args.mode == "recommend":
        if not getattr(args, "model_path", None):
            raise SystemExit("recommend mode requires --model-path")
        if not getattr(args, "system", None):
            raise SystemExit("recommend mode requires --system")
        # Preserve omitted, explicit zero, and "auto" as distinct recommend API
        # inputs. cli_recommend owns DSPARK fallback and acceptance validation.
        try:
            _run_recommend(args)
        except Exception as exc:
            if is_expected_cli_error(exc):
                logger.debug("Traceback for recommend mode", exc_info=True)
                raise SystemExit("Error: " + str(exc)) from exc
            raise
        return

    if args.mode == "default":
        _resolve_and_validate_nextn(args)
        _validate_default_mode_inputs(args)

        # No --total-gpus but a load target means recommend mode
        has_load_target = (
            getattr(args, "target_request_rate", None) is not None
            or getattr(args, "target_concurrency", None) is not None
        )
        if getattr(args, "total_gpus", None) is None and has_load_target:
            if args.enable_epd or args.encoder_tp or args.encoder_system or args.encoder_latency_correction != 1.0:
                raise SystemExit(
                    "--enable-epd/encoder_* flags are not supported by the auto-recommend routing "
                    "(load target without --total-gpus); pass --total-gpus to run the EPD sweep."
                )
            _run_recommend(args)
            return
        if has_load_target:
            logger.warning(
                "--target-request-rate/--target-concurrency are ignored in default mode when "
                "--total-gpus is set. Omit --total-gpus to find the minimum GPUs for the load target."
            )

        # Warn when SLA/workload parameters are implicitly defaulted
        _default_params = {"isl": 4000, "osl": 1000, "ttft": 2000.0, "tpot": 30.0}
        _implicit = [
            f"{k.upper()}={getattr(args, k)}"
            for k, v in _default_params.items()
            if f"--{k}" not in sys.argv and getattr(args, k) == v
        ]
        if _implicit:
            logger.warning(
                "Using default SLA/workload parameters: %s. "
                "These act as filters — configurations exceeding these thresholds are excluded. "
                "Set them explicitly (e.g. --ttft, --tpot, --isl, --osl) to avoid unexpected filtering.",
                ", ".join(_implicit),
            )
        logger.info(
            "Effective parameters: ISL=%d, OSL=%d, TTFT=%.1fms, TPOT=%.1fms, backend=%s",
            args.isl,
            args.osl,
            args.ttft,
            args.tpot,
            args.backend,
        )
        tasks = build_default_tasks(
            model_path=args.model_path,
            total_gpus=args.total_gpus,
            system=args.system,
            decode_system=args.decode_system,
            backend=args.backend,
            backend_version=args.backend_version,
            database_mode=args.database_mode,
            transfer_policy=args.transfer_policy,
            isl=args.isl,
            osl=args.osl,
            image_height=args.image_height,
            image_width=args.image_width,
            num_images=args.num_images,
            video_height=args.video_height,
            video_width=args.video_width,
            video_frames=args.video_frames,
            num_videos=args.num_videos,
            num_video_tokens=args.num_video_tokens,
            enable_encoder_dp=not args.disable_encoder_dp,
            enable_epd=args.enable_epd,
            encoder_tp=args.encoder_tp,
            encoder_system=args.encoder_system,
            encoder_latency_correction=args.encoder_latency_correction,
            ttft=args.ttft,
            tpot=args.tpot,
            request_latency=args.request_latency,
            prefix=args.prefix,
            nextn=args.nextn,
            nextn_accepted=args.nextn_accepted,
            enable_chunked_prefill=args.enable_chunked_prefill,
            free_gpu_memory_fraction=args.free_gpu_memory_fraction,
            max_seq_len=args.max_seq_len,
            engine_step_backend=args.engine_step_backend,
            forward_model=args.forward_model,
            serving_mode=args.serving_mode,
            enable_wideep=getattr(args, "enable_wideep", False),
            moe_backend=getattr(args, "moe_backend", None),
            attention_backend=getattr(args, "attention_backend", None),
        )
    elif args.mode == "exp":
        try:
            build_kwargs: dict[str, Any] = {"yaml_path": args.yaml_path}
            if args.engine_step_backend is not None:
                build_kwargs["engine_step_backend"] = args.engine_step_backend
            if args.forward_model is not None:
                build_kwargs["forward_model"] = args.forward_model
            if getattr(args, "attention_backend", None) is not None:
                build_kwargs["attention_backend"] = args.attention_backend
            tasks = build_experiment_tasks(**build_kwargs)
        except (ValueError, TypeError) as exc:
            logger.exception("Failed to build experiment task configs")
            raise SystemExit(1) from exc
        if not tasks:
            logger.error("No valid experiments found in '%s'.", args.yaml_path)
            raise SystemExit(1)
    else:
        raise SystemExit(f"Unsupported mode: {args.mode}")

    _validate_fpm_sweep_tasks(args, tasks)

    execute_kwargs: dict = {}
    if getattr(args, "strict_sla", False):
        execute_kwargs["strict_sla"] = True
    if getattr(args, "inclusive_tpot", False):
        execute_kwargs["inclusive_tpot"] = True
    _, best_configs, pareto_fronts, _, _, _ = _execute_tasks(
        tasks,
        args.mode,
        top_n=args.top_n,
        **execute_kwargs,
    )
    if not best_configs:
        raise SystemExit(1)

    if args.save_dir:
        save_results(
            args=args,
            best_configs=best_configs,
            pareto_fronts=pareto_fronts,
            tasks=tasks,
            save_dir=args.save_dir,
            generated_backend_version=args.generated_config_version,
            backend=args.backend if args.mode == "default" else None,
        )


if __name__ == "__main__":
    if generator_cli_helper(sys.argv[1:]):
        sys.exit(0)
    parser = argparse.ArgumentParser(
        description="AIConfigurator for Disaggregated Serving Deployment",
        epilog=_USAGE_EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    configure_parser(parser)
    args = parser.parse_args()
    main(args)
