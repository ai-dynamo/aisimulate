# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import dataclasses
import json
import logging
import os
import random
import traceback

import matplotlib.pyplot as plt
import pandas as pd
import yaml
from prettytable import PrettyTable

from aisimulate.generator.api import (
    generate_from_request,
    get_default_dynamo_version_mapping,
    load_generator_overrides_from_args,
    resolve_backend_version_for_dynamo,
)
from aisimulate.generator.module_bridge import task_config_to_generator_config
from aisimulate.generator.request import from_legacy_params
from aisimulate.legacy_cli.estimate_detail_report import format_moe_comm_fallback
from aisimulate.logging_utils import _cli_bold, _cli_underline
from aisimulate.sdk import pareto_analysis
from aisimulate.sdk.config import has_video_input
from aisimulate.sdk.pareto_analysis import draw_pareto_to_string
from aisimulate.sdk.performance_result import (
    MOE_COMM_FALLBACKS_COLUMN,
    merge_moe_comm_fallbacks,
    moe_comm_fallbacks_to_dicts,
)
from aisimulate.sdk.picking import WORKER_GPU_DIMS, parallel_dim
from aisimulate.sdk.task_v2 import Task
from aisimulate.sdk.utils import safe_mkdir

logger = logging.getLogger(__name__)


def _apply_inclusive_tpot(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of df with tpot replaced by inclusive semantics.

    inclusive tpot = (ttft + tpot * (osl - 1)) / osl
    Applied to output copies only — never to internal computation DataFrames.
    """
    if "ttft" in df.columns:
        df = df.copy()
        df["tpot"] = (df["ttft"] + df["tpot"] * (df["osl"] - 1)) / df["osl"]
    return df


def _check_power_data_available(best_configs: dict[str, pd.DataFrame], threshold: float = 0.9) -> bool:
    """
    Check if power data is available and meaningful across configurations.

    Args:
        best_configs: Dictionary of experiment name to best configurations DataFrame
        threshold: Minimum ratio of configs with meaningful power data (default 0.9)

    Returns:
        True if power data should be displayed (>= threshold of configs have power >= 1W)
    """
    total_count = 0
    power_count = 0

    for config_df in best_configs.values():
        if config_df is not None and not config_df.empty and "power_w" in config_df.columns:
            for power_value in config_df["power_w"].values:
                if pd.isna(power_value):
                    continue
                total_count += 1
                if power_value >= 1.0:
                    power_count += 1

    if total_count == 0:
        return False

    # Show power column if >= threshold of configs have meaningful power data
    power_ratio = power_count / total_count
    return power_ratio >= threshold


def _format_power(power_w: object) -> str:
    return "" if pd.isna(power_w) else f"{float(power_w):.1f}W"


def _composed_worker_gpus(row: dict, role: str = "") -> int:
    """Per-worker GPU count from ``(p)``/``(d)``-prefixed or plain columns.

    Iterates :data:`aisimulate.sdk.picking.WORKER_GPU_DIMS` so every
    parallelism dimension lands here automatically; columns a row predates
    (e.g. ``(d)cp``) default to 1.
    """
    gpus = 1
    for dim in WORKER_GPU_DIMS:
        gpus *= parallel_dim(row.get(f"({role}){dim}" if role else dim))
    return gpus


def _plot_worker_setup_table(
    exp_name: str,
    config_df: pd.DataFrame,
    total_gpus: int,
    tpot_target: float,
    top: int,
    is_moe: bool,
    request_latency_target: float | None,
    show_power: bool = True,
) -> str:
    """Plot worker setup table for a single experiment."""
    buf = []

    if config_df is None or config_df.empty:
        return ""

    config_df = config_df.copy()
    if "replicas_needed" in config_df.columns:
        config_df["tokens/s/gpu_cluster"] = config_df["tokens/s/gpu"]
    else:
        config_df["tokens/s/gpu_cluster"] = (
            config_df["tokens/s/gpu"]
            * (total_gpus // config_df["num_total_gpus"])
            * config_df["num_total_gpus"]
            / total_gpus
            if total_gpus > 0
            else 0
        )
    constraint_col = "tpot"
    constraint_target = tpot_target
    constraint_label = "TPOT"
    if request_latency_target is not None and request_latency_target > 0:
        constraint_col = "request_latency"
        constraint_target = request_latency_target
        constraint_label = "request latency"
    if constraint_target is not None and constraint_target > 0:
        top_configs = config_df[config_df[constraint_col] <= constraint_target].copy()
    else:
        top_configs = config_df.copy()
    if "replicas_needed" in top_configs.columns:
        top_configs = top_configs.sort_values(by="total_gpus_needed", ascending=True)
    else:
        top_configs = top_configs.sort_values(by="tokens/s/gpu_cluster", ascending=False)
    top_configs = top_configs.head(top).copy()

    if top_configs.empty:
        return f"\nNo configurations for {exp_name} met the {constraint_label} constraint."

    if "replicas_needed" in top_configs.columns:
        top_configs["replicas"] = top_configs["replicas_needed"].astype(int)
        top_configs["total_gpus_used"] = top_configs["total_gpus_needed"].astype(int)
    else:
        top_configs["replicas"] = total_gpus // top_configs["num_total_gpus"]
        top_configs["total_gpus_used"] = top_configs["num_total_gpus"] * top_configs["replicas"]

    def _power_cell(row) -> str:
        # power_w == 0.0 on an EPD row is the no-data sentinel (incomplete
        # encoder energy data), not a real 0 W estimate.
        if (row.get("(e)workers") or 0) > 0 and row["power_w"] < 1.0:
            return "n/a"
        return _format_power(row["power_w"])

    ranking_label = "total_gpus_needed" if "replicas_needed" in top_configs.columns else "tokens/s/gpu"
    buf.append(f"\n{exp_name} Top Configurations: (Ranked by {ranking_label})")
    table = PrettyTable()

    # Check if it is disagg config by checking for prefill/decode specific columns
    is_disagg = "(p)tp" in top_configs.columns

    top_configs["cluster_request_rate"] = top_configs["request_rate"] * top_configs["replicas"]

    # EPD rows (disagg E+P+D or agg E+agg) carry a dedicated encode-worker
    # pool; show it only when present.
    has_encoder_pool = "(e)workers" in top_configs.columns and (top_configs["(e)workers"].fillna(0) > 0).any()

    if is_disagg:
        field_names = [
            "Rank",
            "backend",
            _cli_bold("tokens/s/gpu"),
            "tokens/s/user",
            "req/s",
            "TTFT",
            "request_latency",
            "concurrency",
            "total_gpus (used)",
            "replicas",
            "gpus/replica",
            "(p)workers",
            "(p)gpus/worker",
            "(p)parallel",
            "(p)bs",
            "(d)workers",
            "(d)gpus/worker",
            "(d)parallel",
            "(d)bs",
        ]
        if has_encoder_pool:
            field_names.extend(["(e)workers", "(e)tp", "(e)bs"])
        if show_power:
            field_names.append("power_w")
        table.field_names = field_names
        for i, row in enumerate(top_configs.to_dict("records")):
            display_total_gpus = row["total_gpus_used"] if "replicas_needed" in row else total_gpus
            display_concurrency = row["concurrency"] * row["replicas"]
            # Worker GPU totals come from the shared dims list so a new
            # parallelism dimension cannot be silently dropped again (#1476);
            # the cp display factor stays hidden when cp=1 for readability.
            p_gpus = _composed_worker_gpus(row, "p")
            d_gpus = _composed_worker_gpus(row, "d")
            p_cp = parallel_dim(row.get("(p)cp"))
            p_cp_label = f"cp{_cli_underline(str(p_cp))}" if p_cp > 1 else ""
            p_cp_factor = f"x{_cli_underline(str(p_cp))}" if p_cp > 1 else ""
            if is_moe:
                p_parallel = (
                    f"tp{_cli_underline(str(row['(p)tp']))}"
                    f"pp{_cli_underline(str(row['(p)pp']))}"
                    f"dp{_cli_underline(str(row['(p)dp']))}"
                    f"{p_cp_label}"
                    f"etp{row['(p)moe_tp']}ep{row['(p)moe_ep']}"
                )
                d_parallel = (
                    f"tp{_cli_underline(str(row['(d)tp']))}"
                    f"pp{_cli_underline(str(row['(d)pp']))}"
                    f"dp{_cli_underline(str(row['(d)dp']))}"
                    f"etp{row['(d)moe_tp']}ep{row['(d)moe_ep']}"
                )
                p_gpus_worker = (
                    f"{p_gpus} "
                    f"(={_cli_underline(str(row['(p)tp']))}x"
                    f"{_cli_underline(str(row['(p)pp']))}x"
                    f"{_cli_underline(str(row['(p)dp']))}{p_cp_factor})"
                )
                d_gpus_worker = (
                    f"{d_gpus} "
                    f"(={_cli_underline(str(row['(d)tp']))}x"
                    f"{_cli_underline(str(row['(d)pp']))}x"
                    f"{_cli_underline(str(row['(d)dp']))})"
                )
            else:
                p_parallel = f"tp{_cli_underline(str(row['(p)tp']))}pp{_cli_underline(str(row['(p)pp']))}{p_cp_label}"
                d_parallel = f"tp{_cli_underline(str(row['(d)tp']))}pp{_cli_underline(str(row['(d)pp']))}"
                p_gpus_worker = (
                    f"{p_gpus} (={_cli_underline(str(row['(p)tp']))}x{_cli_underline(str(row['(p)pp']))}{p_cp_factor})"
                )
                d_gpus_worker = f"{d_gpus} (={_cli_underline(str(row['(d)tp']))}x{_cli_underline(str(row['(d)pp']))})"
            e_workers = int(row.get("(e)workers", 0) or 0)
            encoder_term = f"+{e_workers}x{int(row.get('(e)tp', 0) or 0)}(e)" if e_workers else ""
            gpus_replica_str = (
                f"{row['num_total_gpus']} (={row['(p)workers']}x{p_gpus}+{row['(d)workers']}x{d_gpus}{encoder_term})"
            )
            row_data = [
                i + 1,
                row["backend"],
            ]
            row_data.extend(
                [
                    _cli_bold(f"{row['tokens/s/gpu_cluster']:.2f}"),
                    f"{row['tokens/s/user']:.2f}",
                    f"{row['cluster_request_rate']:.2f}",
                    f"{row['ttft']:.2f}",
                    f"{row['request_latency']:.2f}",
                    f"{display_concurrency} (={row['concurrency']}x{row['replicas']})",
                    f"{display_total_gpus} ({row['total_gpus_used']}={row['replicas']}x{row['num_total_gpus']})",
                    row["replicas"],
                    gpus_replica_str,
                    row["(p)workers"],
                    p_gpus_worker,
                    p_parallel,
                    row["(p)bs"],
                    row["(d)workers"],
                    d_gpus_worker,
                    d_parallel,
                    row["(d)bs"],
                ]
            )
            if has_encoder_pool:
                row_data.extend(
                    [
                        e_workers,
                        int(row.get("(e)tp", 0) or 0),
                        int(row.get("(e)bs", 0) or 0),
                    ]
                )
            if show_power:
                row_data.append(_power_cell(row))
            table.add_row(row_data)
    else:  # agg
        field_names = [
            "Rank",
            "backend",
            _cli_bold("tokens/s/gpu"),
            "tokens/s/user",
            "req/s",
            "TTFT",
            "request_latency",
            "concurrency",
            "total_gpus (used)",
            "replicas",
            "gpus/replica",
            "gpus/worker",
            "parallel",
            "bs",
        ]
        if has_encoder_pool:
            field_names.extend(["(a)workers", "(e)workers", "(e)tp", "(e)bs"])
        if show_power:
            field_names.append("power_w")
        table.field_names = field_names
        for i, row in enumerate(top_configs.to_dict("records")):
            display_total_gpus = row["total_gpus_used"] if "replicas_needed" in row else total_gpus
            display_concurrency = row["concurrency"] * row["replicas"]
            if is_moe:
                parallel = (
                    f"tp{_cli_underline(str(row['tp']))}"
                    f"pp{_cli_underline(str(row['pp']))}"
                    f"dp{_cli_underline(str(row['dp']))}"
                    f"etp{row['moe_tp']}ep{row['moe_ep']}"
                )
                gpus_worker = (
                    f"{row['pp'] * row['tp'] * row['dp']} "
                    f"(={_cli_underline(str(row['tp']))}x"
                    f"{_cli_underline(str(row['pp']))}x"
                    f"{_cli_underline(str(row['dp']))})"
                )
            else:
                parallel = f"tp{_cli_underline(str(row['tp']))}pp{_cli_underline(str(row['pp']))}"
                gpus_worker = (
                    f"{row['pp'] * row['tp']} (={_cli_underline(str(row['tp']))}x{_cli_underline(str(row['pp']))})"
                )
            row_data = [
                i + 1,
                row["backend"],
            ]
            a_workers = int(row.get("(a)workers", 0) or 0)
            e_workers = int(row.get("(e)workers", 0) or 0)
            if e_workers:
                # E+agg cell: (a)workers language-only agg workers + encode pool.
                worker_gpus = _composed_worker_gpus(row)
                gpus_replica = (
                    f"{row['num_total_gpus']} "
                    f"(={a_workers}x{worker_gpus}+{e_workers}x{int(row.get('(e)tp', 0) or 0)}(e))"
                )
            else:
                gpus_replica = row["num_total_gpus"]
            row_data.extend(
                [
                    _cli_bold(f"{row['tokens/s/gpu_cluster']:.2f}"),
                    f"{row['tokens/s/user']:.2f}",
                    f"{row['cluster_request_rate']:.2f}",
                    f"{row['ttft']:.2f}",
                    f"{row['request_latency']:.2f}",
                    f"{display_concurrency} (={row['concurrency']}x{row['replicas']})",
                    f"{display_total_gpus} ({row['total_gpus_used']}={row['replicas']}x{row['num_total_gpus']})",
                    row["replicas"],
                    gpus_replica,
                    gpus_worker,
                    parallel,
                    row["bs"],
                ]
            )
            if has_encoder_pool:
                row_data.extend(
                    [
                        a_workers,
                        e_workers,
                        int(row.get("(e)tp", 0) or 0),
                        int(row.get("(e)bs", 0) or 0),
                    ]
                )
            if show_power:
                row_data.append(_power_cell(row))
            table.add_row(row_data)

    buf.append(table.get_string())
    return "\n".join(buf)


def _auto_result_tasks(
    exp_name: str,
    tasks: dict[str, Task],
    *result_dfs: pd.DataFrame | None,
) -> dict[str, Task]:
    task_keys: list[str] = []
    backends: set[str] = set()
    for result_df in result_dfs:
        if result_df is None or result_df.empty:
            continue
        if "_task_key" in result_df.columns:
            task_keys.extend(str(value) for value in result_df["_task_key"].dropna().unique())
        if "backend" in result_df.columns:
            backends.update(str(value) for value in result_df["backend"].dropna().unique())

    if task_keys:
        resolved: dict[str, Task] = {}
        for task_key in dict.fromkeys(task_keys):
            if task_key not in tasks:
                raise ValueError(
                    f"Cannot save result bucket {exp_name!r}: result references unknown task key "
                    f"{task_key!r}; available task keys: {sorted(tasks)}."
                )
            task = tasks[task_key]
            if task.serving_mode != exp_name:
                raise ValueError(
                    f"Cannot save result bucket {exp_name!r}: task {task_key!r} has serving_mode={task.serving_mode!r}."
                )
            resolved[task_key] = task
        return resolved

    mode_tasks = {key: task for key, task in tasks.items() if task.serving_mode == exp_name}
    if not backends:
        return mode_tasks

    resolved = {}
    for backend_name in sorted(backends):
        matches = {key: task for key, task in mode_tasks.items() if task.primary_backend_name == backend_name}
        if len(matches) != 1:
            raise ValueError(
                f"Cannot save result bucket {exp_name!r} for backend {backend_name!r}: "
                f"expected exactly one matching task, found {sorted(matches)}; "
                f"available task keys: {sorted(tasks)}."
            )
        resolved.update(matches)
    return resolved


def _task_for_result_row(exp_name: str, row: pd.Series, exp_tasks: dict[str, Task]) -> Task:
    task_key = row.get("_task_key")
    if task_key is not None and not pd.isna(task_key):
        task_key = str(task_key)
        if task_key not in exp_tasks:
            raise ValueError(
                f"Cannot save result row for {exp_name!r}: task key {task_key!r} is not in "
                f"the bucket tasks {sorted(exp_tasks)}."
            )
        return exp_tasks[task_key]

    backend_name = row.get("backend")
    matches = [task for task in exp_tasks.values() if task.primary_backend_name == backend_name]
    if len(matches) != 1:
        raise ValueError(
            f"Cannot save result row for {exp_name!r}, backend {backend_name!r}: expected "
            f"exactly one task, found {len(matches)} among {sorted(exp_tasks)}."
        )
    return matches[0]


def log_final_summary(
    chosen_exp: str,
    best_throughputs: dict[str, float],
    best_configs: dict[str, pd.DataFrame],
    pareto_fronts: dict[str, pd.DataFrame | None],
    tasks: dict[str, Task],
    mode: str,
    pareto_x_axis: dict[str, str] | None = None,
    top_n: int = 5,
    target_request_rate: float | None = None,
    target_concurrency: float | None = None,
    inclusive_tpot: bool = False,
):
    """Log final summary of configuration results"""
    # display_* copies carry inclusive TPOT for printed values only.
    # The originals are kept for _plot_worker_setup_table which does TPOT filtering.
    if inclusive_tpot:
        display_best_configs = {k: _apply_inclusive_tpot(v) for k, v in best_configs.items()}
        display_pareto_fronts = {
            k: _apply_inclusive_tpot(v) if v is not None else None for k, v in pareto_fronts.items()
        }
    else:
        display_best_configs = best_configs
        display_pareto_fronts = pareto_fronts

    load_match = target_request_rate is not None or target_concurrency is not None

    # Consolidate and format results into a summary box for clear presentation
    summary_box = []
    summary_box.append("*" * 80)
    summary_box.append("*{:^78}*".format(" AIConfigurator Final Results "))
    summary_box.append("*" * 80)

    summary_box.append("  " + "-" * 76)
    summary_box.append("  Input Configuration & SLA Target:")

    # For multi-backend mode, get task using the backend from best_configs
    chosen_best_config = best_configs.get(chosen_exp)
    if chosen_best_config is not None and "backend" in chosen_best_config.columns and not chosen_best_config.empty:
        chosen_backend = chosen_best_config["backend"].iloc[0]
        task_key = f"{chosen_exp}_{chosen_backend}"
        # Verify the key exists (for multi-backend mode)
        if task_key in tasks:
            chosen_task = tasks[task_key]
        else:
            chosen_task = tasks[chosen_exp]
    else:
        chosen_task = tasks[chosen_exp]
    chosen_total_gpus = chosen_task.total_gpus

    summary_box.append(f"    Model: {chosen_task.primary_model_path} (is_moe: {chosen_task.is_moe})")
    if not load_match:
        summary_box.append(f"    Total GPUs: {chosen_total_gpus}")

    if load_match:
        # Load-match mode summary
        if target_request_rate is not None:
            summary_box.append(f"    Target Load: {target_request_rate} req/s")
        else:
            summary_box.append(f"    Target Concurrency: {target_concurrency}")
        # Show GPUs needed for each mode (and load_served_pct if capacity exceeded)
        for exp_name, df in best_configs.items():
            if df is not None and not df.empty and "total_gpus_needed" in df.columns:
                row = df.iloc[0]
                gpus = int(row["total_gpus_needed"])
                replicas = int(row["replicas_needed"])
                line = f"    {exp_name} GPUs needed: {gpus} (replicas: {replicas})"
                if "load_served_pct" in df.columns:
                    pct = float(row["load_served_pct"])
                    if pct < 100.0:
                        line += f" -- WARNING: only {pct:.1f}% of target load can be served"
                summary_box.append(line)
        summary_box.append(f"    Best Experiment Chosen: {_cli_bold(chosen_exp)}")
    elif mode == "default":
        agg_value = best_throughputs.get("agg", 0.0)
        disagg_value = best_throughputs.get("disagg", 0.0)
        if "agg" in best_throughputs and "disagg" in best_throughputs:
            if agg_value == disagg_value:
                comparison = "agg and disagg tied"
            else:
                winner, loser = ("agg", "disagg") if agg_value >= disagg_value else ("disagg", "agg")
                loser_value = best_throughputs[loser]
                benefit_ratio = float("inf") if loser_value == 0 else best_throughputs[winner] / loser_value
                comparison = f"{winner} {benefit_ratio:.2f}x better than {loser}"
            bold_msg = _cli_bold(f"{chosen_exp} at {best_throughputs[chosen_exp]:.2f} tokens/s/gpu ({comparison})")
        else:
            bold_msg = _cli_bold(f"{chosen_exp} at {best_throughputs[chosen_exp]:.2f} tokens/s/gpu")
        summary_box.append(f"    Best Experiment Chosen: {bold_msg}")
    else:
        bold_msg = _cli_bold(f"{chosen_exp} at {best_throughputs[chosen_exp]:.2f} tokens/s/gpu")
        summary_box.append(f"    Best Experiment Chosen: {bold_msg}")

    summary_box.append("  " + "-" * 76)

    # ============================= overall summary
    summary_box.append("  Overall Best Configuration:")
    best_config_df = display_best_configs[chosen_exp]
    best_throughput = best_throughputs[chosen_exp]

    if not best_config_df.empty:
        best_conf_details = best_config_df.iloc[0]
        if load_match and "replicas_needed" in best_conf_details.index:
            per_gpu = float(best_conf_details["tokens/s/gpu"])
            display_total_gpus = int(best_conf_details["total_gpus_needed"])
            total_throughput = per_gpu * display_total_gpus
        else:
            per_gpu = best_throughput
            display_total_gpus = chosen_total_gpus
            total_throughput = best_throughput * display_total_gpus
        summary_box.append(f"    - Best Throughput: {total_throughput:,.2f} tokens/s")
        summary_box.append(f"    - Per-GPU Throughput: {per_gpu:.2f} tokens/s/gpu")
        summary_box.append(f"    - Per-User Throughput: {best_conf_details['tokens/s/user']:.2f} tokens/s/user")
        if load_match and "replicas_needed" in best_conf_details.index:
            cluster_rr = float(best_conf_details["request_rate"]) * int(best_conf_details["replicas_needed"])
        else:
            replicas = chosen_total_gpus // int(best_conf_details["num_total_gpus"])
            cluster_rr = float(best_conf_details["request_rate"]) * replicas
        summary_box.append(f"    - Request Rate: {cluster_rr:.2f} req/s")
        summary_box.append(f"    - TTFT: {best_conf_details['ttft']:.2f}ms")
        summary_box.append(f"    - TPOT: {best_conf_details['tpot']:.2f}ms")
        summary_box.append(f"    - Request Latency: {best_conf_details['request_latency']:.2f}ms")
    else:
        summary_box.append(f"    - Best Throughput: {best_throughput * chosen_total_gpus:,.2f} tokens/s")
        summary_box.append(f"    - Per-GPU Throughput: {best_throughput:.2f} tokens/s/gpu")
    summary_box.append("  " + "-" * 76)

    # ============================= pareto frontier
    pareto_plot_buf = ""
    if len(display_pareto_fronts) <= 10:  # avoid overly crowded plots
        target_x_axis = "tokens/s/user"
        target_y_axis = "tokens/s/gpu_cluster"
        if pareto_x_axis:
            target_x_axis = pareto_x_axis.get(chosen_exp, target_x_axis)
        series_payload = []
        if target_x_axis != target_y_axis:
            for name, df in display_pareto_fronts.items():
                if df is None or df.empty:
                    continue
                series_x_axis = pareto_x_axis.get(name, target_x_axis) if pareto_x_axis else target_x_axis
                if series_x_axis != target_x_axis:
                    continue
                if target_x_axis not in df.columns or target_y_axis not in df.columns:
                    continue
                series_payload.append({"df": df, "label": name})
        if series_payload:
            summary_box.append("  Pareto Frontier:")
            highlight_series = None
            if (
                not best_config_df.empty
                and target_x_axis in best_config_df.columns
                and target_y_axis in best_config_df.columns
            ):
                highlight_series = {
                    "df": best_config_df.head(1),
                    "label": f"{chosen_exp} selected",
                }
            pareto_plot_buf = draw_pareto_to_string(
                f"{chosen_task.primary_model_path} Pareto Frontier",
                series_payload,
                highlight=highlight_series,
                x_label=target_x_axis,
                y_label=target_y_axis,
            )
            summary_box.append(pareto_plot_buf)
    summary_box.append("  " + "-" * 76)

    # ============================= deployment details
    summary_box.append("  Deployment Details:")
    summary_box.append(
        "    (p) stands for prefill, (d) stands for decode, bs stands for batch size, "
        "a replica stands for the smallest scalable unit xPyD of the disagg system"
    )
    summary_box.append("    Some math: total gpus used = replicas * gpus/replica")
    summary_box.append(
        "               gpus/replica = (p)gpus/worker * (p)workers + (d)gpus/worker * (d)workers; "
        "for Agg, gpus/replica = gpus/worker"
    )
    summary_box.append(
        "               gpus/worker = tp * pp * dp = etp * ep * pp for MoE models; "
        f"tp * pp for dense models (underlined {_cli_underline('numbers')} are the actual values in math)"
    )

    # Check if power data is available before plotting tables
    show_power = _check_power_data_available(best_configs)

    # Plot worker setup tables for all experiments
    for exp_name, config_df in best_configs.items():
        # For multi-backend mode, use the first backend's config for table display
        # (total_gpus, is_moe, etc. should be the same across backends)
        if "backend" in config_df.columns and not config_df.empty:
            first_backend = config_df["backend"].iloc[0]
            task_key = f"{exp_name}_{first_backend}"
            # Verify the key exists (for multi-backend mode)
            if task_key not in tasks:
                task_key = exp_name
        else:
            task_key = exp_name

        if task_key not in tasks:
            logger.info("No task config for %s, skipping deployment table.", exp_name)
            continue

        if not config_df.empty and "backend" not in config_df.columns:
            config_df = config_df.copy()
            config_df["backend"] = tasks[task_key].primary_backend_name

        exp_task = tasks[task_key]
        total_gpus = exp_task.total_gpus or 0
        table_buf = _plot_worker_setup_table(
            exp_name,
            config_df,
            total_gpus,
            exp_task.tpot,
            top_n,
            exp_task.is_moe,
            exp_task.request_latency,
            show_power,
        )
        summary_box.append(table_buf)

    summary_box.append("*" * 80)
    logger.info("\n" + "\n".join(summary_box))


def save_results(
    args,
    best_configs: dict[str, pd.DataFrame],
    pareto_fronts: dict[str, pd.DataFrame | None],
    tasks: dict[str, Task],
    save_dir: str,
    generated_backend_version: str | None = None,
    backend: str | None = None,
):
    """Save the results to a directory."""
    # The deployment generator has no video benchmark schema. Validate before
    # creating the result directory so this unsupported request cannot be
    # swallowed by the best-effort artifact rendering block below.
    for task in tasks.values():
        if has_video_input(
            num_videos=getattr(task, "num_videos_per_request", 0),
            video_height=getattr(task, "video_height", 0),
            video_width=getattr(task, "video_width", 0),
            video_frames=getattr(task, "video_frames", 0),
            num_video_tokens=getattr(task, "num_video_tokens", 0),
        ):
            raise NotImplementedError(
                "Saved deployment artifacts do not support video workloads yet; "
                "run without --save-dir or use an image workload."
            )

    # display_* copies carry inclusive TPOT for CSV/plot output only.
    # Originals are kept for artifact generation (task_config_to_generator_config).
    if getattr(args, "inclusive_tpot", False):
        display_best_configs = {k: _apply_inclusive_tpot(v) for k, v in best_configs.items()}
        display_pareto_fronts = {
            k: _apply_inclusive_tpot(v) if v is not None else None for k, v in pareto_fronts.items()
        }
    else:
        display_best_configs = best_configs
        display_pareto_fronts = pareto_fronts

    first_exp_name = list(tasks.keys())[0]
    first_task = tasks[first_exp_name]

    backend_str = backend or first_task.primary_backend_name

    # Get a safe model name for directory naming:
    # - For local paths: use basename (e.g., "/data/models/my_model" -> "my_model")
    # - For root path: return "root" (e.g., "/" -> "root")
    # - For HuggingFace IDs: return as-is (e.g., "Qwen/Qwen3-32B" -> "Qwen/Qwen3-32B")
    def get_safe_model_name(path: str) -> str:
        # Check if it's a local path (existing directory)
        if os.path.isdir(path):
            # Use abspath to resolve .. and . to actual path
            normalized = os.path.abspath(path)
            basename = os.path.basename(normalized)
            return basename if basename else "root"
        # Otherwise treat as HuggingFace model ID
        return path

    safe_model_name = get_safe_model_name(first_task.primary_model_path)

    result_prefix = (
        f"{safe_model_name}_{first_task.primary_system_name}_{backend_str}_"
        f"isl{first_task.isl}_osl{first_task.osl}_"
        f"ttft{int(first_task.ttft)}_tpot{int(first_task.tpot)}"
    )
    result_dir_path = os.path.join(save_dir, f"{result_prefix}_{random.randint(0, 1000000)}")

    logger.info(f"Saving results to {result_dir_path}")
    try:
        safe_result_dir = safe_mkdir(result_dir_path, exist_ok=True)
        generator_overrides = load_generator_overrides_from_args(args)

        # Save overall pareto plots in the root directory
        fig, ax = plt.subplots(1, 1, figsize=(8, 5))
        pareto_axis = {}
        for exp_name, cfg in tasks.items():
            if cfg.request_latency is not None and cfg.request_latency > 0:
                pareto_axis[exp_name] = "request_latency"
            else:
                pareto_axis[exp_name] = "tokens/s/user"
        all_request_latency = bool(pareto_axis) and all(axis == "request_latency" for axis in pareto_axis.values())
        global_x_axis = "request_latency" if all_request_latency else "tokens/s/user"
        maximize_x = not all_request_latency
        plt.title(f"{first_task.primary_model_path} tokens/s/gpu vs {global_x_axis}")

        # Define markers for backends and colors for serving modes
        backend_markers = {
            "trtllm": "o",  # circle
            "vllm": "s",  # square
            "sglang": "^",  # triangle
        }
        serving_mode_colors = {
            "agg": "#1f77b4",  # blue
            "disagg": "#ff7f0e",  # orange
        }
        # Fallback colors for non-standard experiment names
        exp_colors = [
            "blue",
            "red",
            "green",
            "purple",
            "orange",
            "brown",
            "pink",
            "gray",
            "cyan",
            "magenta",
        ]
        color_idx = 0

        for exp_name, pareto_df in display_pareto_fronts.items():
            if pareto_df is None or pareto_df.empty:
                continue
            if pareto_axis.get(exp_name, global_x_axis) != global_x_axis:
                continue

            # Check if this is multi-backend mode (pareto_df has "backend" column)
            if "backend" in pareto_df.columns:
                # Plot each backend with different marker, color by serving mode (agg/disagg)
                # Note: pareto_df is already the combined Pareto frontier, so we just plot points
                # grouped by backend, without recomputing Pareto per backend
                color = serving_mode_colors.get(exp_name, exp_colors[color_idx % len(exp_colors)])
                for backend_name in pareto_df["backend"].unique():
                    backend_df = pareto_df[pareto_df["backend"] == backend_name].sort_values(by=global_x_axis)
                    marker = backend_markers.get(backend_name, "o")
                    label = f"{exp_name} ({backend_name})"
                    # Plot directly without recomputing Pareto
                    ax.plot(
                        backend_df[global_x_axis],
                        backend_df["tokens/s/gpu"],
                        color=color,
                        marker=marker,
                        label=label,
                        linestyle="-",
                        markersize=8,
                    )
                color_idx += 1
            else:
                # Single backend mode
                pareto_analysis.draw_pareto(
                    pareto_df,
                    global_x_axis,
                    "tokens/s/gpu",
                    ax,
                    exp_colors[color_idx % len(exp_colors)],
                    exp_name,
                    maximize_x=maximize_x,
                )
                color_idx += 1

        # Add axis labels and legend
        ax.set_xlabel(global_x_axis)
        ax.set_ylabel("tokens/s/gpu")
        ax.legend()

        plt.savefig(os.path.join(safe_result_dir, "pareto_frontier.png"))
        plt.close()

        # Save each experiment's results in its own subdirectory
        for exp_name, pareto_df in display_pareto_fronts.items():
            exp_dir = os.path.join(safe_result_dir, exp_name)
            safe_mkdir(exp_dir, exist_ok=True)

            # 1. Save best config dataframe (display copy carries inclusive TPOT if flag set)
            #    Strip the object-typed _per_ops_source column before CSV write; it is
            #    saved as one per_ops_source.json per topN/ subdir below.
            best_config_df = display_best_configs.get(exp_name)  # top n configs
            best_config_per_ops_source: list[dict | None] = []
            best_config_moe_comm_fallbacks: list[tuple | None] = []
            if best_config_df is not None:
                if "_per_ops_source" in best_config_df.columns:
                    best_config_per_ops_source = best_config_df["_per_ops_source"].tolist()
                if MOE_COMM_FALLBACKS_COLUMN in best_config_df.columns:
                    best_config_moe_comm_fallbacks = best_config_df[MOE_COMM_FALLBACKS_COLUMN].tolist()
                best_config_df = best_config_df.drop(
                    columns=["_per_ops_source", MOE_COMM_FALLBACKS_COLUMN, "_task_key"],
                    errors="ignore",
                )
                best_config_df.to_csv(os.path.join(exp_dir, "best_config_topn.csv"), index=False)

            # 2. Save all pareto dataframe (also stripped of _per_ops_source)
            if pareto_df is not None:
                pareto_csv_df = pareto_df.drop(
                    columns=["_per_ops_source", MOE_COMM_FALLBACKS_COLUMN, "_task_key"],
                    errors="ignore",
                )
                pareto_csv_df.to_csv(os.path.join(exp_dir, "pareto.csv"), index=False)

            # 3. Save the config for this experiment
            if backend != "auto":
                exp_task = tasks[exp_name]
                backend_version_str = exp_task.primary_backend_version
            else:
                # There could be multiple backends in the same experiment if backend == "auto" as the result is merged
                exp_tasks = _auto_result_tasks(
                    exp_name,
                    tasks,
                    best_configs.get(exp_name),
                    pareto_fronts.get(exp_name),
                )
                actual_backend_versions = {
                    task.primary_backend_name: task.primary_backend_version for task in exp_tasks.values()
                }
                backend_version_str = ", ".join(
                    f"({backend_name}){backend_version}"
                    for backend_name, backend_version in actual_backend_versions.items()
                )
                # generated backend versions for each backend, empty unless --generator-dynamo-version is provided
                generated_backend_versions = {}

            # Search / perf-DB version echo: the performance data the sweep ran
            # against (search fidelity). This is distinct from the generated /
            # deployed config version shown in the box below -- the two axes are
            # decoupled (set via --perf-db-version; default: latest).
            logger.warning(
                "\n" + "=" * 80 + "\n"
                "  🔍  Search / perf-DB version (simulation fidelity)\n" + "=" * 80 + "\n"
                "  Experiment: %s\n"
                "  Perf-DB version: %s   (--perf-db-version; default: latest)\n"
                "  This is what the search simulated against; it may differ from the\n"
                "  generated/deployed config version shown next.\n" + "=" * 80,
                exp_name,
                backend_version_str or "latest",
            )

            # case #1: --generated-config-version is provided
            if generated_backend_version:
                effective_generated_version = generated_backend_version
                logger.warning(
                    "\n" + "=" * 80 + "\n"
                    "  🟢  IMPORTANT: Config Generation Version\n" + "=" * 80 + "\n"
                    "  Experiment: %s\n"
                    "  Using generated-config-version: %s\n"
                    "\n"
                    "  Config formats differ across backend releases. Please ensure you pass\n"
                    "  the correct --generated-config-version to match your deployment target!\n" + "=" * 80,
                    exp_name,
                    generated_backend_version,
                )
            # case #2: --generator_dynamo_version is provided, generating config matching the dynamo version,
            # but the data used for prediction may not match dynamo version due to imperfect coverage.
            elif dynamo_version := (generator_overrides or {}).get("generator_dynamo_version"):
                if backend != "auto":
                    try:
                        effective_generated_version = resolve_backend_version_for_dynamo(
                            dynamo_version,
                            exp_task.primary_backend_name,
                        )
                        backend_version_str = f"({exp_task.primary_backend_name}){effective_generated_version}"
                    except ValueError as exc:
                        logger.exception(
                            "Failed to resolve backend version for generator_dynamo_version=%s.",
                            dynamo_version,
                        )
                        raise SystemExit(2) from exc
                else:
                    generated_backend_versions = resolve_backend_version_for_dynamo(dynamo_version)
                    backend_version_str = ", ".join(
                        f"({backend_name}){backend_version}"
                        for backend_name, backend_version in generated_backend_versions.items()
                    )
                logger.warning(
                    "\n" + "=" * 80 + "\n"
                    "  🟢  IMPORTANT: Config Generation Version\n" + "=" * 80 + "\n"
                    "  Experiment: %s\n"
                    "  Using generator_dynamo_version: %s\n"
                    "  Generated backend version: %s\n"
                    "\n"
                    "  Config formats differ across backend releases. Ensure the Dynamo version\n"
                    "  matches your deployment target!\n" + "=" * 80,
                    exp_name,
                    dynamo_version,
                    backend_version_str,
                )
            # case #3: no override is provided, use the default backend version mapping
            else:
                deployment_target = getattr(args, "deployment_target", "dynamo-j2")
                default_dynamo_version, default_backend_versions = get_default_dynamo_version_mapping()
                if backend != "auto":
                    effective_generated_version = default_backend_versions.get(exp_task.primary_backend_name)
                    if effective_generated_version is None:
                        raise ValueError(
                            "No default backend version mapping for backend "
                            f"'{exp_task.primary_backend_name}' in dynamo '{default_dynamo_version}'."
                        )
                    backend_version_str = f"({exp_task.primary_backend_name}){effective_generated_version}"
                else:
                    generated_backend_versions = dict(default_backend_versions)
                    backend_version_str = ", ".join(
                        f"({backend_name}){backend_version}"
                        for backend_name, backend_version in generated_backend_versions.items()
                    )

                # Set version source based on deployment target
                if deployment_target == "llm-d-helm":
                    version_source = "template defaults"
                else:
                    version_source = f"dynamo {default_dynamo_version}"

                logger.warning(
                    "\n" + "=" * 80 + "\n"
                    "  🟢  IMPORTANT: Config Generation Version Not Specified\n" + "=" * 80 + "\n"
                    "  Experiment: %s\n"
                    "  --generated-config-version NOT provided\n"
                    "  Defaulting to backend version from %s: %s\n"
                    "\n"
                    "  Config formats differ across backend releases. If you are targeting\n"
                    "  a different version, please pass --generated-config-version explicitly!\n" + "=" * 80,
                    exp_name,
                    version_source,
                    backend_version_str,
                )

            # Save the experiment config for future aic repro
            if backend != "auto":
                with open(os.path.join(exp_dir, "exp_config.yaml"), "w") as f:
                    f.write(exp_task.to_yaml())
            else:
                for exp_task in exp_tasks.values():
                    exp_cfg_name = f"{exp_task.primary_backend_name}_exp_config.yaml"
                    with open(os.path.join(exp_dir, exp_cfg_name), "w") as f:
                        f.write(exp_task.to_yaml())

            # 4. Save the generated config for this experiment, sub-directory for each best config
            # Use original (non-display) data so --inclusive-tpot does not affect deployment artifacts.
            artifact_config_df = best_configs.get(exp_name)
            if artifact_config_df is not None:
                for i, (idx, result_df) in enumerate(artifact_config_df.iterrows()):
                    # For multi-backend mode, get the task for this row's backend
                    if backend == "auto" and "backend" in result_df:
                        row_backend = result_df["backend"]
                        row_task = _task_for_result_row(exp_name, result_df, exp_tasks)
                        row_backend_version = generated_backend_versions.get(
                            row_backend, row_task.primary_backend_version
                        )
                    else:
                        row_task = exp_task
                        row_backend_version = effective_generated_version

                    top_config_dir = os.path.join(exp_dir, f"top{i + 1}")
                    safe_mkdir(top_config_dir, exist_ok=True)

                    # Per-op PerformanceResult.source breakdown, pulled through
                    # the InferenceSummary.
                    # Same nested shape as per_ops_data, populated only when the row
                    # carried it through the pareto search.
                    if i < len(best_config_per_ops_source) and best_config_per_ops_source[i] is not None:
                        with open(os.path.join(top_config_dir, "per_ops_source.json"), "w") as f:
                            json.dump(best_config_per_ops_source[i], f, indent=2, sort_keys=True)

                    fallback_records = merge_moe_comm_fallbacks(
                        best_config_moe_comm_fallbacks[i] if i < len(best_config_moe_comm_fallbacks) else ()
                    )
                    fallback_payload = moe_comm_fallbacks_to_dicts(fallback_records)
                    if fallback_payload:
                        sidecar_path = os.path.join(top_config_dir, "moe_comm_fallbacks.json")
                        with open(sidecar_path, "w") as f:
                            json.dump(fallback_payload, f, indent=2, sort_keys=True)
                        logger.warning(
                            "%s top%d uses estimated MoE communication latency from substitute silicon data: %s. "
                            "Requested-versus-measurement provenance saved to %s.",
                            exp_name,
                            i + 1,
                            "; ".join(format_moe_comm_fallback(record) for record in fallback_records),
                            sidecar_path,
                        )

                    enc_workers = result_df.get("(e)workers", 0)
                    if pd.notna(enc_workers) and enc_workers > 0:
                        logger.warning(
                            "%s top%d is an EPD row ((e)workers=%d): generator artifacts skipped -- "
                            "the generator bridge does not map the dedicated encode pool yet, and the "
                            "emitted deploy configs would contradict the recommendation.",
                            exp_name,
                            i + 1,
                            int(enc_workers),
                        )
                        continue

                    result_df = result_df.drop(
                        labels=["_task_key", MOE_COMM_FALLBACKS_COLUMN],
                        errors="ignore",
                    )
                    cfg = task_config_to_generator_config(
                        task_config=row_task,
                        result_df=result_df,
                        generator_overrides=generator_overrides,
                    )

                    generator_config_yaml = yaml.safe_dump(cfg, sort_keys=False)
                    with open(os.path.join(top_config_dir, "generator_config.yaml"), "w") as f:
                        f.write(generator_config_yaml)

                    try:
                        deployment_target = getattr(args, "deployment_target", "dynamo-j2")
                        # Render through the typed request path. `cfg` (dumped to
                        # generator_config.yaml above) is the dict bridge output;
                        # lowering its request reproduces byte-identical artifacts
                        # (the request round-trip gate), so this is output-neutral.
                        req = from_legacy_params(cfg, backend=row_task.primary_backend_name)
                        req = dataclasses.replace(
                            req,
                            backend=dataclasses.replace(req.backend, generated_config_version=row_backend_version),
                            emit=dataclasses.replace(
                                req.emit,
                                deployment_target=deployment_target,
                                output_dir=top_config_dir,
                            ),
                        )
                        generate_from_request(req)
                    except Exception as exc:
                        logger.warning(
                            "Failed to generate backend config from aic generator: %s, %s",
                            exc,
                            traceback.format_exc(),
                        )

    except Exception:
        logger.exception("Failed to save results")
        raise
