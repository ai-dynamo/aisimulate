# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Typed traffic input for prediction and recommendation."""

from __future__ import annotations

import math
from typing import Annotated, Literal

from pydantic import Field, field_validator, model_serializer, model_validator

from .common import Choices, IntegerRange, NumericRange, StrictModel

PositiveInt = Annotated[int, Field(strict=True, gt=0)]
PositiveFloat = Annotated[float, Field(strict=True, gt=0, allow_inf_nan=False)]
NonNegativeInt = Annotated[int, Field(strict=True, ge=0)]
NonNegativeFloat = Annotated[float, Field(strict=True, ge=0, allow_inf_nan=False)]
Ratio = Annotated[float, Field(strict=True, ge=0, le=1, allow_inf_nan=False)]


class ImagePool(StrictModel):
    """Requests draw their images from a fixed pool, so embeddings can be reused."""

    pool: PositiveInt


class ImageInput(StrictModel):
    """Fixed image dimensions and count on every synthetic request."""

    height: PositiveInt
    width: PositiveInt
    count: PositiveInt = 1
    encoding: Literal["png", "jpeg"] = "png"
    identity: Literal["unique"] | ImagePool = "unique"
    min_pixels: PositiveInt | None = Field(
        default=None, description="Processor rescale lower bound; defaults to the checkpoint's preprocessor value."
    )
    max_pixels: PositiveInt | None = Field(
        default=None, description="Processor rescale upper bound; defaults to the checkpoint's preprocessor value."
    )

    @model_validator(mode="after")
    def _validate_pixel_bounds(self) -> ImageInput:
        if self.min_pixels is not None and self.max_pixels is not None and self.min_pixels > self.max_pixels:
            raise ValueError("images.min_pixels cannot exceed images.max_pixels")
        return self


class SyntheticSource(StrictModel):
    type: Literal["synthetic"] = "synthetic"
    input_tokens: PositiveInt = 1024
    output_tokens: PositiveInt = 128
    images: ImageInput | None = None
    cached_prefix_tokens: NonNegativeInt = 0

    @model_validator(mode="after")
    def _validate_cached_prefix(self):
        if self.cached_prefix_tokens > self.input_tokens:
            raise ValueError("cached_prefix_tokens cannot exceed input_tokens")
        return self


class SessionShape(StrictModel):
    turns: int = Field(default=4, strict=True, ge=2)
    shared_prefix_ratio: Ratio = 0.0
    prefix_groups: NonNegativeInt = 0
    inter_turn_delay_ms: NonNegativeFloat = 0.0

    @model_validator(mode="after")
    def _validate_prefix_groups(self) -> SessionShape:
        if self.shared_prefix_ratio > 0.0 and self.prefix_groups == 0:
            raise ValueError("prefix_groups must be positive when shared_prefix_ratio is positive")
        return self


class SyntheticSessionSource(StrictModel):
    type: Literal["synthetic-session"]
    new_input_tokens_per_turn: PositiveInt = 1024
    output_tokens_per_turn: PositiveInt = 128
    session: SessionShape


TraceFormat = Literal[
    "mooncake",
    "mooncake-delta",
    "agentic_mooncake",
    "applied_compute_agentic",
    "dynamo",
    "weka",
]
WekaNestedTimestampBasis = Literal["auto", "absolute", "relative"]
WekaClient = Literal["recorded", "agentx"]


class TraceSource(StrictModel):
    type: Literal["trace"]
    paths: list[str]
    format: TraceFormat = "mooncake"
    block_size: PositiveInt | None = None
    nested_timestamp_basis: WekaNestedTimestampBasis | None = None
    client: WekaClient | None = None

    @field_validator("paths")
    @classmethod
    def _validate_paths(cls, paths: list[str]) -> list[str]:
        if not paths or any(not path for path in paths):
            raise ValueError("trace paths must contain at least one nonempty path")
        return paths

    @model_validator(mode="after")
    def _validate_path_count(self) -> TraceSource:
        if self.format != "dynamo" and len(self.paths) != 1:
            raise ValueError(f"trace format {self.format!r} requires exactly one path")
        if self.format not in {"dynamo", "weka"} and self.block_size is None:
            self.block_size = 512
        if self.nested_timestamp_basis is not None and self.format != "weka":
            raise ValueError("nested_timestamp_basis is only valid for trace format 'weka'")
        if self.client is not None and self.format != "weka":
            raise ValueError("client is only valid for trace format 'weka'")
        return self


TrafficSource = Annotated[
    SyntheticSource | SyntheticSessionSource | TraceSource,
    Field(discriminator="type"),
]


class TrafficStop(StrictModel):
    requests: PositiveInt | None = None
    requests_per_load_unit: PositiveFloat | None = None
    sessions: PositiveInt | None = None
    sessions_per_load_unit: PositiveFloat | None = None
    max_virtual_time_seconds: PositiveFloat | None = None


class AgenticSnapshotSelection(StrictModel):
    """An exact reference-selected initial cut, in lane order."""

    source_play_id: str = Field(strict=True, min_length=1)
    t_star_ms: NonNegativeFloat


class AgenticSnapshotOptions(StrictModel):
    """Seed for deterministic initial AgentX request-boundary snapshots."""

    seed: int = Field(strict=True, ge=0, le=0xFFFF_FFFF_FFFF_FFFF)
    initial_selections: list[AgenticSnapshotSelection] | None = Field(default=None, min_length=1)
    corpus_cursor: int | None = Field(default=None, strict=True, ge=0, le=0xFFFF_FFFF_FFFF_FFFF)

    @model_validator(mode="after")
    def _validate_reference_selection(self):
        if (self.initial_selections is None) != (self.corpus_cursor is None):
            raise ValueError("initial_selections and corpus_cursor must be specified together")
        if self.initial_selections is not None and self.corpus_cursor < len(self.initial_selections):
            raise ValueError("corpus_cursor cannot precede the initial lane draws")
        return self

    @model_serializer(mode="wrap")
    def _serialize(self, handler):
        result = handler(self)
        # Keep legacy seed-only saved configurations byte-for-byte compatible.
        return {key: value for key, value in result.items() if value is not None}


class AgenticProfileOptions(StrictModel):
    """Continuous agentic replay measured from the preparation barrier."""

    duration_seconds: PositiveFloat = 3600.0
    response_grace_seconds: NonNegativeFloat = 30.0
    cancel_drain_seconds: NonNegativeFloat = 10.0
    tree_idle_cap_seconds: PositiveFloat = 300.0
    global_idle_cap_seconds: PositiveFloat = 10.0

    @model_validator(mode="after")
    def _validate_millisecond_deadlines(self) -> AgenticProfileOptions:
        values = self.model_dump()
        if any(not math.isfinite(value * 1000.0) for value in values.values()) or not math.isfinite(
            (self.duration_seconds + self.response_grace_seconds + self.cancel_drain_seconds) * 1000.0
        ):
            raise ValueError("agentic_profile deadlines overflow")
        return self


class TrafficPredictionLoad(StrictModel):
    agentic_warmup_policy: Literal["repeated_prefixes", "live_trajectory_v1", "primers_only"] = "repeated_prefixes"

    @model_serializer(mode="wrap")
    def _omit_default_warmup_policy(self, handler):
        result = handler(self)
        if self.agentic_warmup_policy == "repeated_prefixes":
            result.pop("agentic_warmup_policy", None)
        return result

    type: Literal[
        "concurrency",
        "poisson",
        "constant_rate",
        "trace_timestamps",
    ] = "concurrency"
    concurrency: PositiveInt | None = None
    requests_per_second: PositiveFloat | None = None
    sessions_per_second: PositiveFloat | None = None
    seed: NonNegativeInt | None = None
    speedup: PositiveFloat | None = None
    agentic_lanes: PositiveInt | None = None
    agentic_snapshot: AgenticSnapshotOptions | None = None
    agentic_warmup: bool = Field(default=False, strict=True)
    agentic_profile: AgenticProfileOptions | None = None

    @model_validator(mode="before")
    @classmethod
    def _default_concurrency(cls, value):
        if isinstance(value, dict) and value.get("type", "concurrency") == "concurrency":
            value = dict(value)
            value.setdefault("concurrency", 10)
        return value

    @model_validator(mode="after")
    def _validate_fields_for_type(self) -> TrafficPredictionLoad:
        _validate_load_fields(self)
        return self


class TrafficRecommendationLoad(StrictModel):
    agentic_warmup_policy: Literal["repeated_prefixes", "live_trajectory_v1", "primers_only"] = "repeated_prefixes"

    @model_serializer(mode="wrap")
    def _omit_default_warmup_policy(self, handler):
        result = handler(self)
        if self.agentic_warmup_policy == "repeated_prefixes":
            result.pop("agentic_warmup_policy", None)
        return result

    type: Literal[
        "concurrency",
        "poisson",
        "constant_rate",
        "kv_capacity_fraction",
        "trace_timestamps",
    ] = "concurrency"
    concurrency: PositiveInt | Choices[PositiveInt] | IntegerRange | None = None
    requests_per_second: PositiveFloat | Choices[PositiveFloat] | NumericRange | None = None
    sessions_per_second: PositiveFloat | Choices[PositiveFloat] | NumericRange | None = None
    seed: NonNegativeInt | None = None
    fraction: PositiveFloat | Choices[PositiveFloat] | NumericRange | None = None
    speedup: PositiveFloat | Choices[PositiveFloat] | NumericRange | None = None
    agentic_lanes: PositiveInt | None = None
    agentic_snapshot: AgenticSnapshotOptions | None = None
    agentic_warmup: bool = Field(default=False, strict=True)
    agentic_profile: AgenticProfileOptions | None = None

    @model_validator(mode="before")
    @classmethod
    def _default_concurrency(cls, value):
        if isinstance(value, dict) and value.get("type", "concurrency") == "concurrency":
            value = dict(value)
            value.setdefault("concurrency", 10)
        return value

    @model_validator(mode="after")
    def _validate_fields_for_type(self) -> TrafficRecommendationLoad:
        _validate_load_fields(self)
        for name in (
            "concurrency",
            "requests_per_second",
            "sessions_per_second",
            "fraction",
            "speedup",
            "agentic_lanes",
        ):
            value = getattr(self, name)
            if isinstance(value, (IntegerRange, NumericRange)) and value.range.min <= 0:
                raise ValueError(f"traffic.load.{name} range requires min > 0")
        return self


def _validate_load_fields(load) -> None:
    used = {
        name
        for name in (
            "concurrency",
            "requests_per_second",
            "sessions_per_second",
            "seed",
            "fraction",
            "speedup",
            "agentic_lanes",
            "agentic_snapshot",
            "agentic_profile",
        )
        if getattr(load, name, None) is not None
    }
    if load.agentic_warmup:
        used.add("agentic_warmup")
    if load.agentic_warmup_policy != "repeated_prefixes":
        used.add("agentic_warmup_policy")
    allowed = {
        "concurrency": {"concurrency"},
        "poisson": {"requests_per_second", "sessions_per_second", "seed"},
        "constant_rate": {"requests_per_second", "sessions_per_second"},
        "kv_capacity_fraction": {"fraction"},
        "trace_timestamps": {
            "speedup",
            "agentic_lanes",
            "agentic_snapshot",
            "agentic_warmup",
            "agentic_warmup_policy",
            "agentic_profile",
        },
    }[load.type]
    unexpected = used - allowed
    if unexpected:
        raise ValueError(f"traffic.load.type={load.type!r} does not accept {sorted(unexpected)}")
    required = {
        "concurrency": ("concurrency",),
        "poisson": (),
        "constant_rate": (),
        "kv_capacity_fraction": ("fraction",),
        "trace_timestamps": (),
    }[load.type]
    missing = [name for name in required if getattr(load, name, None) is None]
    if missing:
        raise ValueError(f"traffic.load.type={load.type!r} requires {', '.join(missing)}")


class _TrafficConfigBase(StrictModel):
    source: TrafficSource
    stop: TrafficStop | None = None

    def _validate_source_load_stop(self, load) -> None:
        source = self.source
        stop = self.stop
        if load.agentic_profile is not None:
            if load.agentic_snapshot is None:
                raise ValueError("agentic_profile requires agentic_snapshot")
            if stop is not None and stop.max_virtual_time_seconds is not None:
                raise ValueError("agentic_profile cannot be combined with max_virtual_time_seconds")
        if load.agentic_warmup and load.agentic_snapshot is None:
            raise ValueError("agentic_warmup requires agentic_snapshot")
        if load.agentic_warmup_policy == "live_trajectory_v1" and (
            not load.agentic_warmup or load.agentic_profile is None
        ):
            raise ValueError("live_trajectory_v1 requires agentic_warmup and agentic_profile")
        if load.agentic_warmup_policy == "primers_only" and not load.agentic_warmup:
            raise ValueError("primers_only requires agentic_warmup")
        if load.agentic_snapshot is not None and load.agentic_lanes is None:
            raise ValueError("agentic_snapshot requires positive agentic_lanes")
        if (
            load.agentic_snapshot is not None
            and load.agentic_snapshot.initial_selections is not None
            and len(load.agentic_snapshot.initial_selections) != load.agentic_lanes
        ):
            raise ValueError("initial_selections must contain exactly one selection per lane")
        if isinstance(source, TraceSource):
            if load.type not in {"trace_timestamps", "concurrency"}:
                raise ValueError("trace traffic requires trace_timestamps or concurrency load")
            if stop is not None and any(
                getattr(stop, name) is not None
                for name in (
                    "requests",
                    "requests_per_load_unit",
                    "sessions",
                    "sessions_per_load_unit",
                )
            ):
                raise ValueError("trace traffic only accepts max_virtual_time_seconds")
            agentic = source.format in {"agentic_mooncake", "weka"}
            if agentic and load.type != "trace_timestamps":
                raise ValueError(f"{source.format} requires trace_timestamps load")
            if source.format == "applied_compute_agentic" and load.type != "concurrency":
                raise ValueError("applied_compute_agentic requires concurrency load")
            if agentic and stop is not None and stop.max_virtual_time_seconds is not None:
                raise ValueError(f"{source.format} does not support max_virtual_time_seconds")
            if load.agentic_lanes is not None and not agentic and source.format != "dynamo":
                raise ValueError("agentic_lanes requires weka, agentic_mooncake, or agentic dynamo input")
            return

        if load.type == "trace_timestamps":
            raise ValueError("synthetic traffic does not accept trace_timestamps load")
        if load.agentic_lanes is not None:
            raise ValueError("synthetic traffic does not accept agentic_lanes")
        rate = load.requests_per_second if isinstance(source, SyntheticSource) else load.sessions_per_second
        wrong_rate = load.sessions_per_second if isinstance(source, SyntheticSource) else load.requests_per_second
        if load.type in {"poisson", "constant_rate"} and rate is None:
            unit = "requests_per_second" if isinstance(source, SyntheticSource) else "sessions_per_second"
            raise ValueError(f"{load.type} synthetic traffic requires {unit}")
        if wrong_rate is not None:
            raise ValueError("traffic load rate unit does not match source type")
        if stop is None:
            raise ValueError("synthetic traffic requires a stop condition")
        if stop.max_virtual_time_seconds is not None:
            raise ValueError("max_virtual_time_seconds is trace-only")
        request_stop = stop.requests is not None or stop.requests_per_load_unit is not None
        session_stop = stop.sessions is not None or stop.sessions_per_load_unit is not None
        if isinstance(source, SyntheticSource):
            if not request_stop or session_stop:
                raise ValueError("synthetic request traffic requires a request stop")
        elif not session_stop or request_stop:
            raise ValueError("synthetic session traffic requires a session stop")
        if (
            sum(
                value is not None
                for value in (
                    stop.requests,
                    stop.requests_per_load_unit,
                    stop.sessions,
                    stop.sessions_per_load_unit,
                )
            )
            != 1
        ):
            raise ValueError("traffic.stop requires exactly one count condition")


class TrafficPredictionConfig(_TrafficConfigBase):
    load: TrafficPredictionLoad

    @classmethod
    def default(cls) -> TrafficPredictionConfig:
        return cls(
            source=SyntheticSource(),
            load=TrafficPredictionLoad(type="concurrency", concurrency=10),
            stop=TrafficStop(requests=100),
        )

    @model_validator(mode="after")
    def _validate_traffic(self) -> TrafficPredictionConfig:
        self._validate_source_load_stop(self.load)
        return self


class TrafficRecommendationConfig(_TrafficConfigBase):
    load: TrafficRecommendationLoad

    @model_validator(mode="after")
    def _validate_traffic(self) -> TrafficRecommendationConfig:
        self._validate_source_load_stop(self.load)
        return self
