# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Terminal setup and local planning for FPM onboarding."""

from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import sys
import tempfile
from copy import deepcopy
from fractions import Fraction
from pathlib import Path
from typing import Any, get_args

import yaml
from pydantic import ValidationError

from aisimulate.config.common import load_yaml

from .config_profile import (
    CHECKED_GEOMETRY,
    FIELD_CHOICES,
    INTEGER_FIELDS,
    LAYOUT_NOTES,
    OVERRIDE_FIELDS,
    ModelConfig,
    ProfileDraft,
    ProfileRequestError,
    derive_profile,
    load_model_config,
    validate_overrides,
)
from .fpm import run_fpm
from .plan import MEMORY_OBSERVATION_VERSIONS, create_plan, request_id
from .schema import (
    AGENTX_REFERENCE_CONTEXT,
    CUDAGRAPH_MODES,
    CollectionSpec,
    FPMDeployment,
    SearchProfile,
    SloSpec,
    SupportIdentity,
    SupportRequest,
    WorkloadSpec,
)
from .topology import TopologySuggestions, suggest_topologies


def add_support_parser(subparsers: Any) -> None:
    onboard = subparsers.add_parser(
        "onboard",
        help="Onboard a model for FPM simulation on a target hardware platform.",
        description=(
            "Onboard a model for FPM simulation on a target hardware platform. "
            "Declare the model and hardware, generate a plan, and preview or execute FPM collection."
        ),
    )
    actions = onboard.add_subparsers(dest="support_action", required=True)
    from .checkpoint import add_checkpoint_parsers

    add_checkpoint_parsers(actions)
    init = actions.add_parser(
        "init",
        help="Declare a model, target hardware, worker topology, and FPM collection limits.",
        description=(
            "Use --interactive for terminal prompts. --model-config derives supported local model metadata; "
            "supply unresolved profile fields with --resource-overrides. Otherwise scripted setup requires "
            "--model, --model-revision, --model-kind, --gpu, and --interconnect. "
            "Cache layouts that config.json cannot establish, such as linear-attention or recurrent state, or that "
            "belong to an architecture intake does not recognize, are resolved by onboard probe-runtime: setup stops "
            "with guidance and writes nothing. onboard import-observations checks a cache geometry override for such "
            "a layout against the probe's measurement. "
            "Collection GPUs are derived from the selected topology. Model-config setup suggests model/hardware-aware "
            "topologies; other routes default to TP1. AISimulate launches benchmark workers when collection is "
            "executed; no separately launched HTTP server is required. An existing vLLM launch configuration is "
            "optional evidence for reviewing settings, not a required input or automatically imported file. "
            "AISimulate sets runtime limits and optional capture overrides; Dynamo self-benchmark combines them "
            "with image sampling defaults and runtime "
            "feasibility checks to generate the exact grid. A complete grid does not establish query coverage. "
            "Synthetic workload and SLA options customize optional validation examples only. "
            "Set deployment replicas and GPU budgets in ordinary predict/recommend configs."
        ),
    )
    init.add_argument(
        "--interactive",
        action="store_true",
        help="Guide setup with terminal prompts; review and accept config-based profiles before saving.",
    )
    init.add_argument("--profile", choices=("onboarding",), help="Optional alias; all setup uses onboarding.")
    init.add_argument("--model")
    init.add_argument("--model-revision", help="Pinned model revision; moving labels such as main are unsupported.")
    init.add_argument("--model-kind", choices=("dense", "moe"))
    init.add_argument("--framework", choices=("vllm",), help="Collection runtime (default: vllm).")
    init.add_argument(
        "--framework-version",
        help="Backend data version label (custom strings accepted); omitted: detect in the collection image.",
    )
    init.add_argument("--gpu", help="Target GPU system name, for example h200_sxm.")
    init.add_argument("--interconnect", help="Interconnect, for example nvswitch, pcie, or none.")
    init.add_argument(
        "--worker-type",
        choices=("aggregated", "prefill", "decode"),
        help="Serving role: prefill/decode collect independently for P/D disaggregation; "
        "aggregated probes both phases.",
    )
    init.add_argument("--sm", type=int, help="GPU SM version override.")
    init.add_argument("--tokenizer-revision")
    init.add_argument("--chat-template-revision")
    init.add_argument("--aisimulate-revision", help="Optional pinned AISimulate source revision.")
    init.add_argument(
        "--tensor-parallel", type=int, help="Attention tensor-parallel size; bypasses model-config suggestions."
    )
    init.add_argument("--attention-data-parallel", type=int, help="Attention data-parallel size (default: 1).")
    init.add_argument("--moe-tensor-parallel", type=int, help="Expert tensor-parallel size (default: TP for MoE).")
    init.add_argument("--moe-expert-parallel", type=int, help="Expert-parallel size (default: 1).")
    profile_source = init.add_mutually_exclusive_group()
    profile_source.add_argument(
        "--fpm-profile", help="JSON/YAML identity and resource profile for class-independent FPM."
    )
    profile_source.add_argument("--model-config", metavar="PATH", help="Local Hugging Face-style config.json.")
    init.add_argument(
        "--resource-overrides",
        metavar="PATH",
        help="JSON/YAML profile field overrides, including cache_groups/cache_block_sizes; "
        "requires --model-config. Resource bytes are per rank.",
    )
    init.add_argument(
        "--suggest-parallel",
        action="store_true",
        help="Preview model-config topology suggestions as JSON; no prompts or writes, including to --output.",
    )
    init.add_argument(
        "--parallel-configs",
        metavar="PATH",
        help="JSON/YAML list of parallel configurations with optional worker_type, collection and resource_overrides; "
        "requires --model-config and --output-dir; conflicts with topology flags and --suggest-parallel.",
    )
    init.add_argument("--input-tokens", type=int, help="Synthetic validation input tokens (default: 1024).")
    init.add_argument("--output-tokens", type=int, help="Synthetic validation output tokens (default: 128).")
    init.add_argument("--concurrency", type=int, help="Synthetic validation concurrency (default: 1).")
    init.add_argument("--request-count", type=int, help="Synthetic validation request count (default: 4).")
    init.add_argument(
        "--context-length",
        type=int,
        help="Runtime per-request context limit; defaults to min(model/profile context, AgentX reference 256000).",
    )
    init.add_argument(
        "--max-num-tokens", type=int, help="Rank-local scheduled token budget; profile bound or initial policy 8192."
    )
    init.add_argument(
        "--max-batch-size",
        type=int,
        help="Rank-local scheduler sequence bound; profile bound or initial policy 256. "
        "Does not request every prefill batch.",
    )
    init.add_argument(
        "--prefill-cudagraph-policy",
        choices=("runtime", "explicit"),
        help="Prefill CUDA graphs: runtime selection (new setup default), or explicit capture override.",
    )
    init.add_argument(
        "--max-prefill-cudagraph-size",
        type=int,
        help="Select explicit capture with this limit; explicit policy without a limit uses 2048. "
        "Conflicts with runtime policy; match the serving target.",
    )
    init.add_argument(
        "--gpu-memory-utilization",
        type=float,
        help="Fraction of total GPU memory for collection and simulation, in (0, 1] (initial policy: 0.90).",
    )
    init.add_argument(
        "--cudagraph-mode", choices=CUDAGRAPH_MODES, help="vLLM graph policy for this explicit worker role."
    )
    init.add_argument(
        "--cudagraph-capture-sizes",
        type=int,
        nargs="+",
        metavar="TOKENS",
        help="Increasing, distinct vLLM capture sizes for this role; requires runtime prefill policy.",
    )
    init.add_argument(
        "--max-cudagraph-capture-size",
        type=int,
        help="vLLM capture limit for this role; aggregated applies it to both launches. "
        "Requires runtime prefill policy.",
    )
    init.add_argument("--ttft-ms", type=float, help="Synthetic validation TTFT target in ms (default: 1000).")
    init.add_argument("--tpot-ms", type=float, help="Synthetic validation TPOT target in ms (default: 100).")
    init.add_argument(
        "--objective",
        choices=get_args(SearchProfile.model_fields["objective"].annotation),
        help="Recommendation objective (default: throughput).",
    )
    init.add_argument("--seed", type=int, help="Recommendation search seed (default: 42).")
    output = init.add_mutually_exclusive_group()
    output.add_argument(
        "--output", default="support-request.yaml", help="Save one request (default: support-request.yaml)."
    )
    output.add_argument(
        "--output-dir",
        metavar="ROOT",
        help="Save a request and FPM profile for each selected configuration in a fresh directory; "
        "requires --model-config. Interactive suggestions accept comma-separated choices.",
    )
    init.add_argument(
        "--overwrite", action="store_true", help="Allow replacement of --output; unsupported with --output-dir."
    )

    plan = actions.add_parser(
        "plan", help="Plan FPM collection and write predict/recommend configs for the target hardware."
    )
    plan.add_argument("-c", "--config", required=True)
    plan.add_argument("--output-dir", default="./aisimulate-support")
    plan.add_argument("--overwrite", action="store_true")
    plan.add_argument("--format", choices=("table", "json"), default="table")

    collect = actions.add_parser(
        "collect-fpm", help="Preview FPM collection on the target hardware, or run with --execute."
    )
    collect.add_argument("-c", "--config", required=True)
    collect.add_argument("--output-dir", default="./aisimulate-support")
    collect.add_argument(
        "--execute", action="store_true", help="Execute collection using a matching saved onboarding plan."
    )
    collect.add_argument(
        "--check-readiness",
        action="store_true",
        help="Inspect saved native timing evidence as JSON without GPU work or writes.",
    )
    collect.add_argument(
        "--smoke",
        action="store_true",
        help="Bounded collection of every selected cell, including both phases; no formal publication.",
    )
    collect.add_argument(
        "--limit", type=int, help="Limit diagnostic cases; requires --smoke, no formal data publication."
    )
    collect.add_argument("--resume", action="store_true", help="Resume the existing collector checkpoint.")
    collect.add_argument("--checkpoint-dir", help="Checkpoint directory inside the plan's fpm-checkpoint directory.")
    add_deployment_arguments(collect)
    from .finalization import add_finalization_parser
    from .runtime import add_runtime_parsers
    from .validation import add_validation_parser
    from .validation_workflow import add_quality_parsers

    add_validation_parser(actions)
    add_quality_parsers(actions)
    add_finalization_parser(actions)
    add_runtime_parsers(actions)


def add_deployment_arguments(parser: Any, *, default_executor: str | None = "kubernetes") -> None:
    deployment = parser.add_argument_group("Collector deployment")
    deployment.add_argument(
        "--executor",
        choices=("kubernetes", "slurm"),
        default=default_executor,
        help="Collection executor (default: kubernetes); Slurm uses an existing sbatch/salloc allocation.",
    )
    deployment.add_argument("--dynamo-version", help="Optional Dynamo version metadata; does not select templates.")
    deployment.add_argument(
        "--image", help="Collector container image; required for Slurm. Prefer an immutable digest."
    )
    deployment.add_argument(
        "--container-mount",
        action="append",
        metavar="SRC[:DST[:FLAGS]]",
        help="Slurm/Pyxis container mount; repeat for several mounts. Kubernetes uses --model-cache.",
    )
    deployment.add_argument("--namespace", help="Kubernetes namespace for collector resources.")
    deployment.add_argument(
        "--cpus-per-task",
        type=int,
        help="Slurm CPUs for each node's shared worker/scheduler pool (new campaigns: 16).",
    )
    deployment.add_argument(
        "--cpu-bind",
        choices=("cores", "none"),
        help="Slurm node-task binding (new campaigns: cores); does not pin individual ranks.",
    )
    deployment.add_argument("--model-cache", metavar="NAME[:MOUNT[:SUBPATH]]", help="Model-cache PVC and mount.")
    deployment.add_argument(
        "--transport", choices=("nvlink", "ib", "efa"), help="GPU networking transport, independent of the executor."
    )
    deployment.add_argument("--image-pull-secret", help="Kubernetes secret for pulling the collector image.")


def _values(args: argparse.Namespace, model: Any) -> dict[str, Any]:
    return {name: getattr(args, name) for name in model.model_fields if getattr(args, name, None) is not None}


def _request_from_args(args: argparse.Namespace) -> SupportRequest:
    collection = _values(args, CollectionSpec)
    collection.setdefault(
        "prefill_cudagraph_policy", "explicit" if "max_prefill_cudagraph_size" in collection else "runtime"
    )
    payload = {
        "identity": _values(args, SupportIdentity),
        "workload": {**_values(args, WorkloadSpec), "slo": _values(args, SloSpec)},
        "search": _values(args, SearchProfile),
        "collection": collection,
        **({"worker_type": args.worker_type} if getattr(args, "worker_type", None) is not None else {}),
        **({"fpm_profile": load_yaml(args.fpm_profile)} if getattr(args, "fpm_profile", None) else {}),
    }
    request = SupportRequest.model_validate(payload)
    if getattr(args, "context_length", None) is None and not getattr(args, "fpm_profile", None):
        raise ValueError("--context-length is required when no model config or FPM profile provides a context limit")
    deployment = request.profile_deployment()
    runtime = deployment.resources.runtime_memory if deployment is not None else None
    if runtime is not None:
        payload["search"].setdefault("context_length", min(request.search.context_length, runtime.max_model_len))
        collection.setdefault("gpu_memory_utilization", runtime.gpu_memory_utilization)
        if payload["search"]["context_length"] > runtime.max_model_len:
            raise ValueError("context_length exceeds the observed runtime memory max_model_len")
        if collection["gpu_memory_utilization"] != runtime.gpu_memory_utilization:
            raise ValueError("gpu_memory_utilization must match the observed runtime memory")
    else:
        collection.setdefault("gpu_memory_utilization", 0.9)
    return SupportRequest.model_validate(payload)


def _request_target(path: str | Path, *, overwrite: bool) -> Path:
    target = Path(path).expanduser().absolute()
    if target.exists() and not target.is_file():
        raise ValueError(f"onboarding request {target} must be a file path")
    if (target.exists() or target.is_symlink()) and not overwrite:
        raise ValueError(f"onboarding request {target} exists; pass --overwrite to replace it")
    parent = target.parent
    while not parent.exists() and not parent.is_symlink():
        parent = parent.parent
    if not parent.is_dir() or not os.access(parent, os.W_OK):
        raise ValueError(f"onboarding request parent {parent} must be a writable directory")
    return target


def _write_request(request: SupportRequest, path: str | Path, *, overwrite: bool) -> Path:
    request.scheduler_limits()
    target = _request_target(path, overwrite=overwrite)
    payload = yaml.safe_dump(request.model_dump(mode="json", exclude_none=True), sort_keys=False)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(payload)
        if overwrite:
            os.replace(temporary, target)
        else:
            os.link(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return target


def _print(value: dict[str, Any], output_format: str = "table") -> None:
    if output_format == "json":
        print(json.dumps(value, sort_keys=True))
        return
    for key, item in value.items():
        rendered = json.dumps(item, sort_keys=True) if isinstance(item, (dict, list)) else str(item)
        print(f"{key}: {rendered}")


_PROMPTS = {
    "model": ("Model name or path", str),
    "model_revision": ("Pinned model revision (not main/latest)", str),
    "model_kind": ("Model kind (dense/moe)", str),
    "gpu": ("Target GPU system name (for example h200_sxm)", str),
    "interconnect": ("GPU interconnect (for example nvswitch, pcie, or none)", str),
    "tensor_parallel": ("Attention tensor-parallel size", int),
}
_CORRECTION_PROMPTS = {
    **_PROMPTS,
    "framework_version": ("Backend data version label", str),
    "input_tokens": ("Input tokens per request", int),
    "output_tokens": ("Output tokens per request", int),
    "concurrency": ("Concurrent requests", int),
    "context_length": ("Runtime per-request context limit in tokens", int),
    "ttft_ms": ("Target time to first token (ms)", float),
    "tpot_ms": ("Target time per output token (ms)", float),
    "max_num_tokens": ("Rank-local scheduled token budget", int),
    "max_batch_size": ("Rank-local scheduler sequence bound", int),
    "max_prefill_cudagraph_size": ("Prefill CUDA graph capture limit", int),
    "prefill_cudagraph_policy": ("Prefill CUDA graph policy (runtime/explicit)", str),
    "gpu_memory_utilization": ("Fraction of total GPU memory (0 < value <= 1)", float),
    "worker_type": ("Serving role (aggregated/prefill/decode)", str),
    "cudagraph_mode": ("vLLM CUDA graph mode", str),
    "cudagraph_capture_sizes": (
        "CUDA graph capture sizes (space-separated integers)",
        lambda value: [int(x) for x in value.split()],
    ),
    "max_cudagraph_capture_size": ("CUDA graph capture limit for this role", int),
    "framework": ("Runtime (vllm)", str),
    "tokenizer_revision": ("Pinned tokenizer revision", str),
    "chat_template_revision": ("Pinned chat-template revision", str),
    "aisimulate_revision": ("Pinned AISimulate revision", str),
    "sm": ("GPU SM version", int),
    "request_count": ("Number of synthetic requests", int),
    "objective": ("Recommendation objective", str),
    "seed": ("Recommendation search seed", int),
    "attention_data_parallel": ("Attention data-parallel size", int),
    "moe_tensor_parallel": ("Expert tensor-parallel size", int),
    "moe_expert_parallel": ("Expert-parallel size", int),
}


def _prompt(args: argparse.Namespace, name: str) -> None:
    label, convert = _CORRECTION_PROMPTS[name]
    default = getattr(args, name)
    if default is None and name != "context_length":
        for model in (SupportIdentity, WorkloadSpec, SloSpec, SearchProfile, CollectionSpec):
            field = model.model_fields.get(name)
            if field is not None and not field.is_required():
                default = field.default
    while True:
        answer = input(f"{label}{f' [{default}]' if default is not None else ''}: ").strip()
        if not answer and default is None:
            print("A value is required.")
            continue
        try:
            value = convert(answer) if answer else default
        except ValueError:
            print(f"Enter a valid {'integer' if convert is int else 'number'}.")
            continue
        setattr(args, name, value)
        if name == "prefill_cudagraph_policy" and value == "runtime":
            args.max_prefill_cudagraph_size = None
        elif name == "max_prefill_cudagraph_size":
            args.prefill_cudagraph_policy = "explicit"
        return


def _require_terminal() -> None:
    if not sys.stdin.isatty():
        raise ValueError(
            "--interactive requires a terminal; for automation supply options (aisimulate onboard init --help)"
        )


def _guided_request(args: argparse.Namespace, *, skip_topology: bool = False) -> SupportRequest:
    _require_terminal()
    print("Onboard a model for FPM simulation on a target hardware platform.")
    selection = "one or more" if getattr(args, "output_dir", None) is not None else "one"
    print(f"Select {selection} TP, DEP, or TEP worker configurations and review collection limits for vLLM.")
    print("AISimulate launches benchmark workers during collection; you do not need to start an HTTP server.")
    print("An existing vLLM launch configuration is optional evidence for reviewing these settings.")
    print("Enter accepts a displayed default. Ctrl-C cancels without saving. Supplied options skip their prompts.")
    for name in _PROMPTS:
        if skip_topology and name == "tensor_parallel":
            continue
        if getattr(args, name) is None:
            _prompt(args, name)
    if args.context_length is None and not args.fpm_profile:
        _prompt(args, "context_length")
    return _validate_guided_request(args)


def _correct_option(args: argparse.Namespace, exc: ValueError, *, require_known_field: bool = False) -> None:
    name, message = None, str(exc)
    if isinstance(exc, ProfileRequestError):
        name = exc.field
    if isinstance(exc, ValidationError):
        error = exc.errors(include_url=False)[0]
        name = error["loc"][-1] if error["loc"] else None
        message = error["msg"]
    if name == "backend_version":
        name = "framework_version"
    if require_known_field and name not in _CORRECTION_PROMPTS:
        raise exc
    print(f"{name or 'Request'}: {message}")
    while name not in _CORRECTION_PROMPTS:
        name = input("Option to correct (for example --tensor-parallel): ").strip().removeprefix("--").replace("-", "_")
        if name not in _CORRECTION_PROMPTS:
            print("Choose one of: " + ", ".join(key.replace("_", "-") for key in _CORRECTION_PROMPTS))
    _prompt(args, name)


def _validate_guided_request(args: argparse.Namespace) -> SupportRequest:
    while True:
        try:
            return _request_from_args(args)
        except ValidationError as exc:
            _correct_option(args, exc)


class _ResourceOverridesLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        values = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            if not isinstance(key, str):
                raise ValueError("resource override field names must be strings")
            if key in values:
                raise ValueError(f"duplicate resource override field: {key}")
            values[key] = self.construct_object(value_node, deep=deep)
        return values


def _load_resource_overrides(path: str | None) -> dict[str, Any]:
    if path is None:
        return {}
    source = Path(path).expanduser()
    try:
        values = yaml.load(source.read_text(encoding="utf-8"), Loader=_ResourceOverridesLoader)
    except yaml.YAMLError as exc:
        raise ValueError(f"malformed resource overrides in {source}: {exc}") from exc
    if not isinstance(values, dict):
        raise ValueError(f"resource overrides in {source} must be a flat JSON/YAML mapping")
    return values


def _memory_field(name: str) -> bool:
    return name.endswith("_bytes") or name == "kv_bytes_per_token"


def _resource_answer(name: str, answer: str) -> Any:
    if name in {"cache_groups", "cache_block_sizes"}:
        try:
            return yaml.load(answer, Loader=_ResourceOverridesLoader)
        except yaml.YAMLError as exc:
            raise ValueError(f"enter a valid JSON {'list' if name == 'cache_groups' else 'object'}") from exc
    if name not in INTEGER_FIELDS:
        return answer
    if _memory_field(name):
        units = {"B": 1, **{f"{prefix}B": 1000**power for power, prefix in enumerate("KMGT", 1)}}
        units.update({f"{prefix}IB": 1024**power for power, prefix in enumerate("KMGT", 1)})
        match = re.fullmatch(r"([+-]?\d+(?:\.\d+)?)\s*([KMGT]i?B|B)", answer, re.IGNORECASE)
        if match:
            value = Fraction(match[1]) * units[match[2].upper()]
            if value.denominator != 1:
                raise ValueError("memory quantities must resolve to a whole number of bytes")
            return value.numerator
        try:
            return int(answer)
        except ValueError as exc:
            raise ValueError("enter integer bytes or an explicit unit, for example 70 GiB or 512 MiB") from exc
    try:
        return int(answer)
    except ValueError as exc:
        raise ValueError("enter a valid integer") from exc


def _read_profile_value(name: str) -> dict[str, Any]:
    choices = f" ({', '.join(FIELD_CHOICES[name])})" if name in FIELD_CHOICES else ""
    if _memory_field(name):
        choices += " (per rank; integer bytes or units such as GiB/MiB)"
    elif name == "cache_groups":
        choices += " (JSON list; page_size_bytes includes every group layer and runtime padding per rank)"
    elif name == "cache_block_sizes":
        choices += " (JSON object mapping displayed group names to runtime tokens per block)"
    while True:
        answer = input(f"{name}{choices}: ").strip()
        if not answer:
            print("A value is required.")
            continue
        try:
            return validate_overrides({name: _resource_answer(name, answer)})
        except ValueError as exc:
            print(f"{name}: {exc}")


def _prompt_profile_value(
    config: ModelConfig,
    request: SupportRequest | None,
    overrides: dict[str, Any],
    draft: ProfileDraft,
    name: str,
) -> tuple[dict[str, Any], ProfileDraft]:
    print(f"{name}: {draft.missing[name]}")
    # Retain a valid answer if final profile validation asks for an identity
    # correction. Other derivation failures cannot be repaired by repeating
    # this answer, so let the caller report the actual error.
    answer = _read_profile_value(name)
    if name == "cache_block_sizes":
        answer[name] = {**overrides.get(name, {}), **answer[name]}
    overrides.update(answer)
    updated = derive_profile(config, request, overrides)
    if name in updated.resolved:
        print(f"  {name}: {updated.resolved[name]} (source: {updated.sources[name]})")
    else:
        print(f"  {name}: {updated.missing[name]}")
    return overrides, updated


def _review_config_profile(
    config: ModelConfig,
    request: SupportRequest,
    overrides: dict[str, Any],
    draft: ProfileDraft,
    *,
    directory_output: bool = False,
) -> SupportRequest:
    while True:
        identity = request.identity
        print("Review FPM profile before saving:")
        print(f"  Modeling scope: {config.notes['modeling_scope']}")
        print(
            f"  Target: {identity.model} ({identity.model_kind}) @ {identity.model_revision}; "
            f"{identity.framework} {identity.framework_version}; "
            f"{identity.gpu}; {identity.interconnect}"
        )
        print(f"  Parallelism: {request.parallelism()}")
        if request.worker_type is not None:
            print(f"  Serving role: {request.worker_type}; collection phases: {', '.join(request.collection_phases)}.")
            if request.worker_type != "aggregated":
                print("  P/D disaggregation: this role has its own accepted settings, memory and collection evidence.")
                print("  The other role is onboarded independently; collection does not require actual P/D transfer.")
        print(f"  Collection GPUs required: {request.worker_gpus} for one selected worker; availability is unchecked.")
        settings = request.collection_settings()
        print(f"  Runtime context limit: {request.search.context_length} tokens per request.")
        print(f"  Collection: {json.dumps(settings, sort_keys=True)}")
        print("  AISimulate launches and manages benchmark workers when collection is executed.")
        print("  vLLM loads the model and allocates caches; Dynamo self-benchmark generates and measures the grid.")
        print("  AISimulate supplies runtime limits and collection policies; no HTTP server is needed beforehand.")
        print(
            "  Dynamo combines them with image sampling defaults and runtime feasibility checks to generate the grid."
        )
        if any(
            getattr(request.collection, name) is not None
            for name in ("cudagraph_mode", "cudagraph_capture_sizes", "max_cudagraph_capture_size")
        ):
            print("  Reviewed role CUDA graph settings configure the selected launch; verify the resolved runtime.")
        elif request.collection.prefill_cudagraph_policy == "runtime":
            print("  CUDA graph sizes resolve in the initialized runtime; no explicit capture override is proposed.")
        elif request.worker_type == "aggregated":
            print("  The reviewed capture override configures both aggregated probe launches.")
        else:
            print("  Prefill capture overrides configure the engine; match the serving target.")
        print("  The sequence bound does not request every prefill batch; total KV capacity resolves at runtime.")
        print("  A complete generated grid does not establish AgentX/direct-FPM query coverage.")
        print("  Synthetic validation traffic and SLAs do not determine these collection limits.")
        print("  Resource *_bytes values are bytes per rank; kv_bytes_per_token is bytes per cached token per rank.")
        if draft.resolved.get("cache_layout") == "grouped":
            print("  Grouped pages retain full history or the declared window, with separate convolution state.")
            print("  Group page_size_bytes sums every group layer per rank; verify runtime block sizes and padding.")
            print(
                "  Config-derived pages are minimum packed tensor estimates; edit cache_groups for runtime allocation."
            )
            print("  Logical context determines FPM timing queries; retained cache length is only memory accounting.")
        print("  max_num_tokens/max_batch_size are per-rank scheduler limits. Estimates require runtime verification.")
        memory = request.profile_deployment().resources
        print(f"  Memory source: {memory.memory_source}.")
        if not memory.memory_ready:
            print("  No activation or non-KV byte estimate is required.")
            print("  Displayed byte estimates are planning evidence. Finalize the collected memory before simulation.")
            if request.identity.framework_version in MEMORY_OBSERVATION_VERSIONS:
                print(f"  Memory is observed during initialized vLLM {request.identity.framework_version} collection.")
                print(
                    "  Collection policy: synchronous scheduling in both phases, "
                    "matching supported prefill benchmarking."
                )
            else:
                print(
                    f"  Memory observation currently supports vLLM {', '.join(MEMORY_OBSERVATION_VERSIONS)}; "
                    "this version can collect timings only."
                )
        for name, value in draft.resolved.items():
            print(f"  {name}: {value} (source: {draft.sources[name]})")
        if draft.resolved.get("comm_quant_mode") != "half":
            print(
                "  Collection compatibility: this collector currently supports comm_quant_mode=half. "
                "Your override is retained, but new collection will reject a mismatched identity."
            )
        if "provenance" not in draft.resolved:
            print(
                "  Provenance records the config SHA-256, deployment, values and sources; "
                "edit provenance to add a note."
            )
        if directory_output:
            print("Nothing has been saved. All selected profiles must be accepted before any files are saved.")
            print("Accept keeps this profile; edit changes a profile field. Ctrl-C cancels setup.")
        else:
            print(
                "Nothing has been saved. Accept saves these values; edit changes a profile field. Ctrl-C cancels setup."
            )
        while True:
            action = input("Review action (accept/edit/cancel): ").strip().lower()
            if action in ("accept", "edit", "cancel"):
                break
            print("Enter accept, edit, or cancel. Explicit acceptance is required to save.")
        if action == "accept":
            return request
        if action == "cancel":
            raise KeyboardInterrupt
        collection_fields = {
            "runtime_context_length",
            "max_prefill_cudagraph_size",
            "prefill_cudagraph_policy",
            "gpu_memory_utilization",
            "worker_type",
            "cudagraph_mode",
            "cudagraph_capture_sizes",
            "max_cudagraph_capture_size",
        }
        print("Editable fields: " + ", ".join(sorted(OVERRIDE_FIELDS | collection_fields)))
        while True:
            name = input("Field to edit: ").strip()
            if name in OVERRIDE_FIELDS | collection_fields:
                break
            print("Choose an editable field by its displayed name.")
        # Derive from explicit inputs again so inferred dependents can change.
        # Only publish the staged values after the entire request validates.
        staged = deepcopy(overrides)
        payload = request.model_dump(exclude={"fpm_profile"})
        if name in collection_fields:
            if name in {"worker_type", "cudagraph_mode"}:
                choices = ("aggregated", "prefill", "decode") if name == "worker_type" else (*CUDAGRAPH_MODES, "clear")
                while (value := input(f"{name} ({'/'.join(choices)}): ").strip()) not in choices:
                    print("Enter one of: " + ", ".join(choices))
                if value == "clear":
                    value = None
            elif name == "cudagraph_capture_sizes":
                while True:
                    try:
                        answer = input(f"{name} (space-separated positive integers, or clear): ").strip()
                        if answer == "clear":
                            value = None
                            break
                        value = [int(item) for item in answer.split()]
                        if not value or min(value) <= 0 or value != sorted(set(value)):
                            raise ValueError
                        break
                    except ValueError:
                        print("Enter increasing, distinct positive integers.")
            elif name == "prefill_cudagraph_policy":
                while (value := input(f"{name} (runtime/explicit): ").strip()) not in {"runtime", "explicit"}:
                    print("Enter runtime or explicit.")
                if value == "runtime":
                    payload["collection"]["max_prefill_cudagraph_size"] = None
            elif name == "gpu_memory_utilization":
                while True:
                    try:
                        value = float(input(f"{name} (0 < fraction <= 1): ").strip())
                        if not 0 < value <= 1:
                            raise ValueError
                        break
                    except ValueError:
                        print("Enter a finite fraction greater than 0 and at most 1.")
            else:
                while True:
                    try:
                        clear = ", or clear" if name == "max_cudagraph_capture_size" else ""
                        answer = input(f"{name} (positive integer{clear}): ").strip()
                        if clear and answer == "clear":
                            value = None
                            break
                        value = int(answer)
                        if value <= 0:
                            raise ValueError
                        break
                    except ValueError:
                        print("Enter a positive integer.")
            if name == "runtime_context_length":
                payload["search"]["context_length"] = value
            elif name == "worker_type":
                payload["worker_type"] = value
            else:
                payload["collection"][name] = value
                if name == "max_prefill_cudagraph_size":
                    payload["collection"]["prefill_cudagraph_policy"] = "explicit"
        else:
            staged.update(_read_profile_value(name))
            if name in {"max_num_tokens", "max_batch_size"}:
                payload["collection"][name] = staged[name]
        try:
            edited_request = SupportRequest.model_validate(payload)
            updated = derive_profile(config, edited_request, staged)
            while updated.missing and not updated.pending_runtime:
                field = min(updated.missing, key=_memory_field)
                staged, updated = _prompt_profile_value(config, edited_request, staged, updated, field)
            if updated.pending_runtime:
                raise ValueError(
                    "Cache geometry: pending runtime probe, so init cannot save this profile; "
                    f"{updated.pending_runtime['cache_geometry']} (guide: {_PROBE_GUIDE})"
                )
            if updated.profile is None:
                raise ValueError("model config did not produce a complete FPM profile")
            validated = SupportRequest.model_validate({**edited_request.model_dump(), "fpm_profile": updated.profile})
        except ValueError as exc:
            print(f"Edit rejected: {exc}. Previous profile values retained.")
            continue
        overrides, draft, request = staged, updated, validated


_TOPOLOGY_OPTIONS = ("tensor_parallel", "attention_data_parallel", "moe_tensor_parallel", "moe_expert_parallel")


def _explicit_topology(args: argparse.Namespace) -> bool:
    return any(getattr(args, name) is not None for name in _TOPOLOGY_OPTIONS)


def _config_inputs(args: argparse.Namespace) -> tuple[ModelConfig, dict[str, Any], SupportRequest]:
    config = load_model_config(args.model_config)
    overrides = _load_resource_overrides(args.resource_overrides)
    preview = derive_profile(config, None, overrides)
    if not args.suggest_parallel:
        print(f"Model config source: {Path(args.model_config).expanduser()} (SHA-256 {config.sha256}).")
        for name, note in preview.notes.items():
            if name not in LAYOUT_NOTES:
                print(f"Config {name}: {note}")
        for name in ("architecture", "context_length", "num_experts"):
            if name in preview.resolved:
                print(f"{name}: {preview.resolved[name]} (source: {preview.sources[name]})")
    if args.interactive:
        _require_terminal()
        for name in ("architecture", "context_length", "num_experts"):
            if name in preview.missing:
                overrides, preview = _prompt_profile_value(config, None, overrides, preview, name)
    if not args.suggest_parallel:
        # Printed after any architecture answer, so they describe the classification derive_profile now uses.
        for name in LAYOUT_NOTES:
            if name in preview.notes:
                print(f"Config {name}: {preview.notes[name]}")
    if args.model is None:
        args.model = config.suggestions.get("model")
    if args.model_kind is None:
        experts = preview.resolved.get("num_experts")
        args.model_kind = (
            ("moe" if experts > 0 else "dense") if experts is not None else config.suggestions.get("model_kind")
        )
    if args.context_length is None and "context_length" in preview.resolved:
        args.context_length = min(preview.resolved["context_length"], AGENTX_REFERENCE_CONTEXT)
    if args.interactive:
        request = _guided_request(args, skip_topology=not _explicit_topology(args))
    else:
        try:
            request = _request_from_args(args)
        except ValidationError as exc:
            details = []
            for error in exc.errors(include_url=False):
                name = error["loc"][-1] if error["loc"] else None
                option = "--" + name.replace("_", "-") if name in _CORRECTION_PROMPTS else "request"
                details.append(f"  {option}: {error['msg']}")
            raise ValueError(
                "Complete target identity and collection options before dependent profile derivation:\n"
                + "\n".join(details)
                + "\nThen supply unresolved profile fields with --resource-overrides PATH (flat JSON/YAML), "
                "or use --interactive."
            ) from exc
    return config, overrides, request


def _topology_summary(suggestions: TopologySuggestions, *, missing: bool = True) -> str:
    """Shortlist text; ``missing=False`` leaves out inputs that the caller already lists."""
    lines = [
        "Suggested worker topologies (collection starting points, not a performance ranking):",
        f"  Hardware: {suggestions.hardware.source}; {suggestions.hardware.assumption}",
    ]
    candidates = suggestions.candidates
    # An input every candidate lacks is listed once, after the candidates; other gaps stay with their candidate.
    shared = []
    if missing and candidates:
        shared = [item for item in candidates[0].missing.items() if all(item in c.missing.items() for c in candidates)]
    for number, candidate in enumerate(candidates, 1):
        default = " (default)" if candidate == suggestions.default else ""
        lines.append(
            f"  {number}. {candidate.family}, {candidate.required_gpus} GPUs, {candidate.status}{default}: "
            + shlex.join(candidate.cli_flags)
        )
        lines.extend(f"     {reason}" for reason in candidate.reasons)
        if missing:
            lines.extend(
                f"     Missing {name}: {reason}"
                for name, reason in candidate.missing.items()
                if (name, reason) not in shared
            )
    subject = "The candidate" if len(candidates) == 1 else "Every candidate"
    lines.extend(f"  {subject} is missing {name}: {reason}" for name, reason in shared)
    if not suggestions.candidates:
        lines.append("  No eligible topology remains in the automatic hardware domain.")
        for candidate in suggestions.rejected_candidates:
            lines.append(
                f"  Rejected {candidate.family}, {candidate.required_gpus} GPUs: " + "; ".join(candidate.reasons)
            )
    lines.append("Runtime compatibility, actual GPU availability and measured performance remain unchecked.")
    return "\n".join(lines)


def _print_profile_inputs(draft: ProfileDraft, *, skip: tuple[str, ...] = ()) -> None:
    print("Profile inputs (resource bytes per rank; estimates require runtime verification):")
    for name, value in draft.resolved.items():
        if name not in skip:
            print(f"  {name}: {value} (source: {draft.sources[name]})")


_PROBE_GUIDE = "docs/perf-model/fpm-self-service/implementation.md#cache-geometry-pending-the-runtime-probe"


def _probe_guidance(draft: ProfileDraft, shortlist: str | None = None, *, starting_points: bool = True) -> str:
    """Stop message for a layout whose cache geometry only the runtime probe measures.

    ``starting_points`` says whether the shortlist kept any candidate. The message never asks for geometry.
    """
    lines = []
    if draft.missing:
        lines += [
            "Unresolved profile fields for this deployment:",
            *(f"  {name}: {reason}" for name, reason in draft.missing.items()),
            "Supply them in --resource-overrides PATH (JSON/YAML), or use --interactive.",
        ]
    lines += ["Cache geometry: pending runtime probe", f"  {draft.pending_runtime['cache_geometry']}"]
    # A pending draft holds cache geometry only from overrides; nothing derives it for such a layout.
    if any(name in draft.resolved for name in CHECKED_GEOMETRY):
        lines.append(
            "  onboard import-observations checks each cache geometry override against the probe's measurement."
        )
    if shortlist is not None:
        lines.append(shortlist)
    lines.append(
        "Next step: record the deployment, the model config path and the five precision values (gemm_quant_mode, "
        "moe_quant_mode, fmha_quant_mode, comm_quant_mode and kv_cache_dtype) in the onboarding checkpoint "
        "(onboard checkpoint), then run onboard probe-runtime --checkpoint PATH --output-dir DIR "
        f"(guide: {_PROBE_GUIDE})."
    )
    if shortlist is not None:
        lines.append(
            "The probe takes an explicit topology: record one of the starting points above, or your own."
            if starting_points
            else "No usable starting point exists. The probe takes an explicit topology: record your own."
        )
    # A marker declares a cache group other than full or sliding attention, such as recurrent state. An unrecognized
    # architecture alone does not declare one. Without a declared window, the probe reports attention groups, and a
    # matching per-token size then gives back a linear profile.
    if draft.layout_markers:
        lines.append(
            "Importing cache groups other than full or sliding attention (for example recurrent state) is not "
            "supported yet. Import reports such probes as incomplete."
        )
    elif not draft.declares_window:
        lines.append(
            "If you keep kv_bytes_per_token in the configuration's resource_overrides in the checkpoint, "
            "onboard import-observations checks it, and when it matches, import writes a linear profile."
        )
    lines.append("Nothing was saved.")
    return "\n".join(lines)


def _resolve_shared_profile_inputs(
    config: ModelConfig, shared: dict[str, Any], entry_overrides: list[dict[str, Any]]
) -> None:
    while True:
        for overrides in entry_overrides:
            draft = derive_profile(config, None, {**shared, **overrides})
            pending = [
                name
                for name in draft.missing
                if not _memory_field(name) and name not in {"cache_groups", "cache_block_sizes"}
            ]
            if pending:
                name = pending[0]
                print(f"{name}: {draft.missing[name]}")
                shared.update(_read_profile_value(name))
                break
        else:
            return


def _select_topologies(
    args: argparse.Namespace,
    config: ModelConfig,
    overrides: dict[str, Any],
    request: SupportRequest,
    *,
    multiple: bool = False,
) -> list[SupportRequest]:
    while True:
        try:
            suggestions = suggest_topologies(config, request, overrides)
            if args.interactive and suggestions.candidates:
                _resolve_shared_profile_inputs(config, overrides, [{}])
                suggestions = suggest_topologies(config, request, overrides)
            break
        except (ProfileRequestError, ValidationError) as exc:
            if not args.interactive:
                raise
            _correct_option(args, exc, require_known_field=True)
            request = _validate_guided_request(args)
    # Pending geometry is topology-independent: no candidate can be chosen into a saved request.
    if (pending := derive_profile(config, None, overrides)).pending_runtime:
        # This preview has no request, so its scheduler limits are policy defaults, not the user's bounds.
        _print_profile_inputs(pending, skip=("max_num_tokens", "max_batch_size"))
        # The guidance lists the unresolved inputs, so the shortlist does not repeat them.
        shortlist = _topology_summary(suggestions, missing=False)
        raise ValueError(_probe_guidance(pending, shortlist, starting_points=bool(suggestions.candidates)))
    summary = _topology_summary(suggestions)
    if not suggestions.candidates or (not args.interactive and suggestions.default is None):
        raise ValueError(
            "No fully assessed topology default is available.\n"
            + summary
            + "\nSupply shared precision/layout inputs with --resource-overrides or use --interactive. "
            "When planning estimates are unavailable, select an exact topology with the displayed flags. "
            "Explicit topology may be outside the automatic shortlist."
        )
    print(summary)
    selected = [suggestions.default] if suggestions.default is not None else []
    if args.interactive:
        default = suggestions.candidates.index(selected[0]) + 1 if selected else None
        if default is None:
            print("Memory fit is unresolved; select a candidate explicitly. Memory will be observed during collection.")
        while True:
            answer = input(
                f"Choose {'topologies' if multiple else 'topology'} 1-{len(suggestions.candidates)}"
                + (f" [{default}]" if default is not None else "")
                + (" (comma-separated, or cancel): " if multiple else " (or cancel): ")
            ).strip()
            if answer.lower() == "cancel":
                raise KeyboardInterrupt
            if not answer and default is not None:
                break
            choices = [value.strip() for value in answer.split(",")] if multiple else [answer]
            if all(value.isdecimal() and 1 <= int(value) <= len(suggestions.candidates) for value in choices) and len(
                {int(value) for value in choices}
            ) == len(choices):
                selected = [suggestions.candidates[int(value) - 1] for value in choices]
                break
            numbers = "unique comma-separated candidate numbers" if multiple else "a displayed candidate number"
            print(f"Enter {numbers} or cancel. Enter accepts only a fully assessed default.")
    for candidate in selected:
        print(
            f"Selected {candidate.family} with {candidate.required_gpus} collection GPUs: "
            + shlex.join(candidate.cli_flags)
        )
    return [candidate.apply(request) for candidate in selected]


def _topology_values(request: SupportRequest) -> dict[str, int]:
    parallel = request.parallelism()
    return dict(
        zip(
            _TOPOLOGY_OPTIONS,
            (parallel[name] for name in ("tensor", "attention_data", "moe_tensor", "moe_expert")),
            strict=True,
        )
    )


def _config_request(args: argparse.Namespace) -> SupportRequest:
    automatic = not _explicit_topology(args)
    config, overrides, request = _config_inputs(args)
    if automatic:
        request = _select_topologies(args, config, overrides, request)[0]
        for name, value in _topology_values(request).items():
            setattr(args, name, value)
    return _complete_config_request(args, config, overrides, request)


def _complete_config_request(
    args: argparse.Namespace, config: ModelConfig, overrides: dict[str, Any], request: SupportRequest
) -> SupportRequest:
    while True:
        try:
            draft = derive_profile(config, request, overrides)
        except (ProfileRequestError, ValidationError) as exc:
            if not args.interactive:
                raise
            _correct_option(args, exc, require_known_field=True)
            request = _validate_guided_request(args)
            continue
        _print_profile_inputs(draft)
        if draft.pending_runtime and not args.interactive:
            raise ValueError(_probe_guidance(draft))
        if draft.missing and not args.interactive:
            raise ValueError(
                "Unresolved profile fields for this deployment:\n"
                + "\n".join(f"  {name}: {reason}" for name, reason in draft.missing.items())
                + "\nInspect the pinned runtime and checkpoint metadata for unresolved precision/layout facts. "
                "An existing launch configuration is optional evidence; values not established locally remain "
                "explicit inputs. Supply them in --resource-overrides PATH (JSON/YAML; bytes per rank), "
                "or use --interactive."
            )
        try:
            while draft.missing:
                # Resolve dtype/layout/envelope inputs before asking for dependent memory amounts.
                name = min(draft.missing, key=_memory_field)
                overrides, draft = _prompt_profile_value(config, request, overrides, draft, name)
        except (ProfileRequestError, ValidationError) as exc:
            _correct_option(args, exc, require_known_field=True)
            request = _validate_guided_request(args)
            continue
        if draft.pending_runtime:
            raise ValueError(_probe_guidance(draft))
        if draft.profile is None:
            raise ValueError("model config did not produce a complete FPM profile")
        try:
            completed = SupportRequest.model_validate({**request.model_dump(), "fpm_profile": draft.profile})
        except ValidationError as exc:
            if not args.interactive:
                raise
            _correct_option(args, exc)
            request = _validate_guided_request(args)
            continue
        return (
            _review_config_profile(
                config, completed, overrides, draft, directory_output=getattr(args, "output_dir", None) is not None
            )
            if args.interactive
            else completed
        )


def _load_parallel_configs(path: str) -> list[dict[str, Any]]:
    source = Path(path).expanduser()
    try:
        entries = yaml.load(source.read_text(encoding="utf-8"), Loader=_ResourceOverridesLoader)
    except yaml.YAMLError as exc:
        raise ValueError(f"malformed parallel configurations in {source}: {exc}") from exc
    if not isinstance(entries, list) or not entries:
        raise ValueError("--parallel-configs must contain a nonempty JSON/YAML list of objects")
    for number, entry in enumerate(entries, 1):
        if not isinstance(entry, dict):
            raise ValueError(f"parallel configuration {number} must be an object")
        unknown = entry.keys() - {*_TOPOLOGY_OPTIONS, "resource_overrides", "worker_type", "collection"}
        if unknown:
            raise ValueError(f"parallel configuration {number} has unknown fields: {', '.join(sorted(unknown))}")
        if "tensor_parallel" not in entry:
            raise ValueError(f"parallel configuration {number} requires tensor_parallel")
        for name in entry.keys() & set(_TOPOLOGY_OPTIONS):
            if type(entry[name]) is not int or entry[name] < 1:
                raise ValueError(f"parallel configuration {number}: {name} must be a positive integer")
        overrides = entry.get("resource_overrides", {})
        if not isinstance(overrides, dict):
            raise ValueError(f"parallel configuration {number}: resource_overrides must be a mapping")
        entry["resource_overrides"] = validate_overrides(overrides)
        if "worker_type" in entry and entry["worker_type"] not in {"aggregated", "prefill", "decode"}:
            raise ValueError(f"parallel configuration {number}: worker_type must be aggregated, prefill or decode")
        if "collection" in entry and not isinstance(entry["collection"], dict):
            raise ValueError(f"parallel configuration {number}: collection must be a mapping")
    return entries


def _check_unique_topologies(requests: list[SupportRequest]) -> None:
    seen = set()
    for request in requests:
        topology = _topology_values(request)
        key = (request.worker_type, *topology.values())
        if key in seen:
            raise ValueError(f"duplicate resolved parallel configuration: {topology}")
        seen.add(key)


def _config_requests(args: argparse.Namespace) -> list[SupportRequest]:
    entries = _load_parallel_configs(args.parallel_configs) if args.parallel_configs is not None else None
    automatic = not _explicit_topology(args) and entries is None
    implicit_context = args.context_length is None
    shared_graph_settings = {}
    if entries is not None:
        # Validate generic graph settings with each entry's role and overrides.
        args = deepcopy(args)
        for name in ("cudagraph_mode", "cudagraph_capture_sizes", "max_cudagraph_capture_size"):
            value = getattr(args, name)
            if value is not None:
                shared_graph_settings[name] = value
                setattr(args, name, None)
    config, shared, request = _config_inputs(args)
    if entries is not None:
        selected = []
        for entry in entries:
            payload = request.model_dump()
            payload["search"].update({name: entry[name] for name in _TOPOLOGY_OPTIONS if name in entry})
            if "worker_type" in entry:
                payload["worker_type"] = entry["worker_type"]
            payload["collection"].update(shared_graph_settings)
            payload["collection"].update(entry.get("collection", {}))
            selected.append(SupportRequest.model_validate(payload))
    else:
        selected = _select_topologies(args, config, shared, request, multiple=True) if automatic else [request]
    _check_unique_topologies(selected)
    if len(selected) > 1 and (
        rank_fields := [name for name in shared if _memory_field(name) or name == "cache_groups"]
    ):
        raise ValueError(
            "Multiple configurations cannot share rank-local resource overrides: "
            + ", ".join(sorted(rank_fields))
            + ". Put them in each --parallel-configs entry's resource_overrides or edit each profile interactively."
        )
    if args.interactive and not automatic:
        _resolve_shared_profile_inputs(
            config, shared, [entry["resource_overrides"] for entry in entries] if entries is not None else [{}]
        )
    completed = []
    for number, candidate in enumerate(selected, 1):
        # Corrections, nested resource inputs and review edits belong only to
        # this tuple. Start every profile from the original shared intake.
        candidate_args = deepcopy(args)
        candidate = candidate.model_copy(deep=True)
        candidate_args.worker_type = candidate.worker_type
        for name in CollectionSpec.model_fields:
            setattr(candidate_args, name, getattr(candidate.collection, name))
        for name, value in _topology_values(candidate).items():
            setattr(candidate_args, name, value)
        overrides = deepcopy(shared)
        if entries is not None:
            overrides.update(deepcopy(entries[number - 1]["resource_overrides"]))
        if implicit_context:
            context = derive_profile(config, None, overrides).resolved.get("context_length")
            if context is not None:
                candidate_args.context_length = min(context, AGENTX_REFERENCE_CONTEXT)
                candidate.search.context_length = candidate_args.context_length
        print(f"Configuration {number}/{len(selected)}: {_topology_values(candidate)}")
        completed.append(_complete_config_request(candidate_args, config, overrides, candidate))
        _check_unique_topologies(completed)
    return completed


def _onboarding_target(path: str | Path) -> Path:
    if not str(path):
        raise ValueError("onboarding output directory must be a nonempty path")
    target = Path(path).expanduser().absolute()
    for parent in (target, *target.parents):
        if parent.is_symlink():
            raise ValueError(f"onboarding output path must not contain symlinks: {parent}")
    if target.exists() and (not target.is_dir() or any(target.iterdir())):
        raise ValueError(
            f"onboarding output directory {target} must be new or empty; collection results cannot be replaced"
        )
    parent = target.parent
    while not parent.exists():
        parent = parent.parent
    if not parent.is_dir() or not os.access(parent, os.W_OK):
        raise ValueError(f"onboarding output parent {parent} must be a writable directory")
    return target


def _write_onboarding(requests: list[SupportRequest], root: Path) -> dict[str, Any]:
    _check_unique_topologies(requests)
    for request in requests:
        request.scheduler_limits()
    root = _onboarding_target(root)
    root.parent.mkdir(parents=True, exist_ok=True)
    index = {"schema_version": "aisimulate-onboarding/v1", "configurations": []}
    with tempfile.TemporaryDirectory(prefix=f".{root.name}-", dir=root.parent) as temporary:
        staged = Path(temporary)
        for request in requests:
            topology = _topology_values(request)
            tp, dp, mtp, ep = topology.values()
            name = f"tp{tp}-dp{dp}-moe-tp{mtp}-moe-ep{ep}"
            if request.worker_type is not None:
                name = f"{request.worker_type}-{name}"
            final = root / name
            _write_request(request, staged / name / "request.yaml", overwrite=False)
            profile = request.fpm_profile
            assert profile is not None
            (staged / name / "fpm-profile.json").write_text(profile.model_dump_json(indent=2) + "\n", encoding="utf-8")
            index["configurations"].append(
                {
                    **({"worker_type": request.worker_type} if request.worker_type is not None else {}),
                    "topology": topology,
                    "collection_gpus_required": request.worker_gpus,
                    "request_id": request_id(request),
                    "request": str(final / "request.yaml"),
                    "fpm_profile": str(final / "fpm-profile.json"),
                    "collection_dir": str(final / "collection"),
                    "plan_command": shlex.join(
                        [
                            "aisimulate",
                            "onboard",
                            "plan",
                            "--config",
                            str(final / "request.yaml"),
                            "--output-dir",
                            str(final / "collection"),
                        ]
                    ),
                }
            )
        (staged / "onboarding.json").write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
        # Recheck after all reviews and serialization. Rename publishes only a
        # complete directory and cannot replace a nonempty collection directory.
        _onboarding_target(root)
        staged.rename(root)
    return index


def _init(args: argparse.Namespace) -> int:
    if args.resource_overrides and not args.model_config:
        raise ValueError("--resource-overrides requires --model-config")
    if args.parallel_configs is not None:
        if not args.model_config or args.output_dir is None:
            raise ValueError("--parallel-configs requires --model-config and --output-dir")
        if _explicit_topology(args):
            raise ValueError("--parallel-configs cannot be combined with explicit topology flags")
    if args.output_dir is not None:
        if not args.model_config:
            raise ValueError("--output-dir requires --model-config")
        if args.overwrite:
            raise ValueError("--output-dir cannot be combined with --overwrite; use a fresh output directory")
    if args.suggest_parallel:
        if not args.model_config:
            raise ValueError("--suggest-parallel requires --model-config")
        if (
            args.interactive
            or args.fpm_profile
            or args.profile
            or _explicit_topology(args)
            or args.output_dir is not None
            or args.parallel_configs is not None
        ):
            raise ValueError(
                "--suggest-parallel cannot be combined with --interactive, profiles, explicit topology flags, "
                "--output-dir, or --parallel-configs"
            )
        config, overrides, request = _config_inputs(args)
        _print(suggest_topologies(config, request, overrides).to_dict(), "json")
        return 0
    if args.output_dir is not None:
        root = _onboarding_target(args.output_dir)
        try:
            index = _write_onboarding(_config_requests(args), root)
        except (EOFError, KeyboardInterrupt):
            print("Setup cancelled.", file=sys.stderr)
            return 130
        print(
            "Requests and profiles saved. Runtime compatibility and FPM data are unchecked; "
            "setup has not launched GPU work."
        )
        print("Separate collection plan commands are ready; the same GPUs may be reused across separate runs.")
        _print({"onboarding_index": str(root / "onboarding.json"), **index})
        return 0
    _request_target(args.output, overwrite=args.overwrite)
    try:
        if args.model_config:
            request = _config_request(args)
        else:
            request = _guided_request(args) if args.interactive else _request_from_args(args)
        path = _write_request(request, args.output, overwrite=args.overwrite)
    except (EOFError, KeyboardInterrupt):
        print("Setup cancelled.", file=sys.stderr)
        return 130
    print(
        f"Scope: FPM simulation for {request.identity.model} ({request.identity.model_kind}), "
        f"vLLM {request.identity.framework_version}, "
        f"{request.identity.gpu}; {request.identity.interconnect}; "
        f"{request.parallel_preset} {request.parallelism()}; runtime context {request.search.context_length} tokens."
    )
    print("Collection settings: " + json.dumps(request.collection_settings(), sort_keys=True))
    print(f"Collection GPUs required: {request.worker_gpus} for one selected worker; availability is unchecked.")
    if args.model_config:
        print(
            f"Request saved with FPM metadata; memory source: {request.profile_deployment().resources.memory_source}. "
            "Runtime compatibility and FPM data are unchecked; accuracy is not assessed. "
            "Setup has not launched GPU work."
        )
    else:
        print(
            "Request saved. Model metadata/resources, runtime compatibility and FPM data are unchecked; "
            "accuracy is not assessed. Setup has not launched GPU work."
        )
    _print(
        {
            "request_id": request_id(request),
            "request": str(path),
            "next": shlex.join(["aisimulate", "onboard", "plan", "--config", str(path)]),
        }
    )
    return 0


def _plan(args: argparse.Namespace) -> int:
    request = SupportRequest.from_yaml(args.config)
    root = Path(args.output_dir).expanduser().resolve()
    plan = create_plan(request, root, overwrite=args.overwrite)
    _print(
        {
            "request_id": plan["request_id"],
            "candidate_count": plan.get("search", {}).get("candidate_count", 0),
            **({"status": plan["status"]} if "status" in plan else {}),
            "collection_gpus_required": request.worker_gpus,
            "plan": str(root / "support-plan.json"),
            "commands": plan["outputs"]["commands"],
            "prerequisites": "runtime_and_fpm_data_unchecked" if request.fpm_profile is not None else "unchecked",
            **(
                {"resources": request.profile_deployment().resources.memory_source}
                if request.fpm_profile is not None
                else {}
            ),
            "accuracy": "not assessed",
            "next": shlex.join(
                [
                    "aisimulate",
                    "onboard",
                    "collect-fpm",
                    "--config",
                    plan["outputs"]["request"],
                    "--output-dir",
                    str(root),
                ]
            ),
        },
        args.format,
    )
    return 0


def run_support_command(args: argparse.Namespace) -> int:
    if args.support_action in {"probe-runtime", "import-observations"}:
        from .runtime import run_runtime_command

        return run_runtime_command(args)
    if args.support_action in {"validate-collection", "validate-serving"}:
        from .validation_workflow import validate_collection, validate_serving

        return validate_collection(args) if args.support_action == "validate-collection" else validate_serving(args)
    if args.support_action == "finalize":
        from .finalization import run_finalization

        return run_finalization(args)
    if args.support_action in {"checkpoint", "resume"}:
        from .checkpoint import run_checkpoint_command

        return run_checkpoint_command(args)
    if args.support_action == "validate-fpm":
        from .validation import run_validation

        return run_validation(args)
    if args.support_action == "init":
        return _init(args)
    if args.support_action == "plan":
        return _plan(args)
    if args.support_action == "collect-fpm":
        return run_fpm(
            SupportRequest.from_yaml(args.config),
            output_dir=args.output_dir,
            execute=args.execute,
            check_readiness=args.check_readiness,
            smoke=args.smoke,
            limit=args.limit,
            resume=args.resume,
            checkpoint_dir=args.checkpoint_dir,
            deployment=FPMDeployment(**_values(args, FPMDeployment)),
        )
    raise AssertionError(f"unhandled onboarding action {args.support_action!r}")
