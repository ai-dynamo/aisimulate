# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Resolve exact per-role Sweeper forward-pass estimator contracts."""

from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from typing import Any

from aisimulate_core.sdk import (
    ForwardPassPerfModelConfig,
    RustForwardPassPerfModel,
)
from aisimulate_core.sdk.rust_engine_step import UNKNOWN_IDENTITY

from ..estimator_readiness import unready_estimator_message
from .config import ENGINE_MODEL_CONTROL_FIELDS, SearchSpace
from .deploy import _role_hardware_sku
from .replay import ForwardPassEstimatorSpec


class ForwardPassEstimatorResolutionError(ValueError):
    """A configured forward-pass estimator identity cannot be resolved exactly."""


def resolve_systems_paths(configured: list[str] | None, *, require_directories: bool = True) -> tuple[str, ...]:
    """Expand and validate request-scoped system roots without setting globals."""

    from aisimulate_core.sdk.rust_engine_step import _resolve_forward_pass_systems_paths

    return tuple(_resolve_forward_pass_systems_paths(tuple(configured or ()), require_directories=require_directories))


def resolve_afd_backend_version(
    backend: str, requested: str | None, systems: tuple[tuple[str, tuple[str, ...]], ...]
) -> str:
    """Pin one version across the actual A/F and ordinary role data roots."""
    if requested is not None and requested not in {"current", "previous", "next"}:
        # Each pool's canonical constructor validates literal availability.
        return requested
    from aisimulate_core.sdk.perf_database import resolve_query_version

    from .kv_estimate import resolve_backend_version

    versions = {
        resolve_query_version(system, backend, requested, systems_paths=list(roots))
        if requested is not None
        else resolve_backend_version(system, backend, systems_paths=list(roots))
        for system, roots in systems
    }
    if len(versions) != 1:
        raise ForwardPassEstimatorResolutionError(
            "backend version alias or defaults resolve differently across AFD/P/D hardware; "
            "specify one common literal engine.backend_version"
        )
    return versions.pop()


_DEFAULT_BLOCK_SIZE = {"vllm": 64, "sglang": 1, "trtllm": 32}


def _role_prefix(role: str) -> str:
    return "" if role == "agg" else f"{role}_"


class ForwardPassEstimatorResolver:
    """Resolve and cache Core-owned estimator identities for concrete roles.

    The search-space request alone is not an estimator identity: whole-forward
    FPM cells include topology and backend block size. ``resolve_candidate`` is
    called after a suggestion has been unrolled but before its ``ReplaySpec``
    reaches a runner. Every exact role request crosses the canonical Core
    constructor, and the returned config/provenance is carried unchanged.
    """

    def __init__(self, search_space: SearchSpace) -> None:
        self._search_space = search_space
        self._resolved: dict[str, ForwardPassEstimatorSpec] = {}
        self._afd_versions: dict[tuple, str] = {}

    def resolve_afd_version(self, sample: dict[str, Any], resolved: dict[str, ForwardPassEstimatorSpec]) -> str:
        """Resolve pool aliases once per hardware/root identity, before replay."""
        space = self._search_space
        backend = sample["backend"]
        requested = space.requested_backend_version(backend)
        systems = set()
        roles = ("aggregated",) if sample["deployment_mode"] == "agg" else ("prefill", "decode")
        for role in roles:
            if role in sample["afd_roles"]:
                topology = sample["afd_roles"][role]
                settings = sample.get("afd_worker_settings", {}).get(role, {})
                roots = resolve_systems_paths(
                    (settings.get("timing") or {}).get("systems_paths") or space.systems_paths
                )
                systems.update(
                    (topology.get(name) or sample["hardware_sku"], roots) for name in ("a_system", "f_system")
                )
            else:
                legacy = "agg" if role == "aggregated" else role
                systems.add(
                    (_role_hardware_sku(sample, legacy), resolve_systems_paths(space.systems_paths_for(legacy)))
                )
        key = (backend, requested, tuple(sorted(systems)))
        if key not in self._afd_versions:
            self._afd_versions[key] = resolve_afd_backend_version(backend, requested, key[2])
        version = self._afd_versions[key]
        if any(spec.backend_version != version for spec in resolved.values()):
            raise ForwardPassEstimatorResolutionError(
                "Core resolved inconsistent backend versions across AFD/P/D roles"
            )
        return version

    def _request(self, sample: dict[str, Any], role: str) -> ForwardPassPerfModelConfig:
        backend = str(sample["backend"])
        prefix = _role_prefix(role)
        moe_tp = int(sample[f"{prefix}moe_tp"])
        moe_ep = int(sample[f"{prefix}moe_ep"])
        # Context-parallel knobs are optional columns (the compiler spells them
        # out only when != 1); keep 1 out of the identity so pre-CP candidates
        # resolve to the same estimator as before.
        cp_size = int(sample.get(f"{prefix}cp") or 1)
        block_size = sample[f"{role}_block_size"]
        if block_size is None:
            block_size = _DEFAULT_BLOCK_SIZE[backend]
        transfer_policy: Any = self._search_space.transfer_policy
        if isinstance(transfer_policy, list):
            transfer_policy = tuple(transfer_policy)
        controls = self._search_space.role_estimator_controls.get(role, {})
        nextn = sample.get("aic_nextn")
        if nextn is None:
            nextn = self._search_space.aic_nextn
        estimator_config = deepcopy(controls.get("estimator_config", self._search_space.estimator_config))
        path = sample.get(f"{role}_fpm_parquet_path")
        if path is not None:
            interpolation = estimator_config.setdefault("fpm_interpolation", {})
            if interpolation.get("fpm_parquet_path", path) != path:
                raise ValueError("conflicting fpm_parquet_path and estimator_config.fpm_interpolation.fpm_parquet_path")
            interpolation["fpm_parquet_path"] = path
        # A snapshot pins every estimator control; the candidate supplies the
        # engine identity, which restoration compares with the saved one.
        snapshot = self._search_space.state_snapshot_role(role)
        pinned = snapshot.estimator_controls() if snapshot is not None else {}
        if snapshot is not None:
            controls, estimator_config = pinned, pinned["estimator_config"]
        fields = dict(
            model=self._search_space.model_name,
            fpm_profile=self._search_space.fpm_profile,
            system=_role_hardware_sku(sample, role),
            backend=backend,
            worker_type="aggregated" if role == "agg" else role,
            backend_version=self._search_space.requested_backend_version(backend),
            tp=int(sample[f"{prefix}tp"]),
            pp=int(sample[f"{prefix}pp"]),
            attention_dp=int(sample[f"{prefix}attention_dp"]),
            dcp=sample.get(f"{prefix}dcp"),
            moe_tp_size=moe_tp if moe_tp * moe_ep > 1 else None,
            moe_ep_size=moe_ep if moe_tp * moe_ep > 1 else None,
            cp_size=cp_size if cp_size != 1 else None,
            nextn=int(nextn or 0),
            **{name: getattr(self._search_space, name) for name in ENGINE_MODEL_CONTROL_FIELDS},
            speculation=self._search_space.speculation.cost_config()
            if self._search_space.speculation is not None
            else None,
            kv_block_size=int(block_size),
            estimation_mode=controls.get("estimation_mode", self._search_space.estimation_mode),
            database_mode=controls.get("database_mode", self._search_space.database_mode),
            transfer_policy=controls.get("transfer_policy", transfer_policy),
            systems_paths=resolve_systems_paths(self._search_space.systems_paths_for(role)),
            fallback_policy=controls.get("fallback_policy", self._search_space.fallback_policy),
            estimator_config=estimator_config,
            # A language worker hosting the vision tower prices encoder calls too.
            encoder_parallel=(sample.get(f"{role}_vision") or {}).get("encoder_parallel"),
            **{
                name: pinned[name]
                for name in ("decoder_replay", "enable_shared_layer", "strict_provenance", "fpm_fmha_quant_mode")
                if name in pinned
            },
        )
        if snapshot is not None:
            fields.update(snapshot.saved_spellings(fields))
        return ForwardPassPerfModelConfig(**fields)

    def _resolve(self, request: ForwardPassPerfModelConfig, role: str) -> ForwardPassEstimatorSpec:
        # Bind an external file before caching so identical relative spellings
        # from different working directories cannot reuse another pair.
        interpolation = request.estimator_config.get("fpm_interpolation", {})
        path = interpolation.get("fpm_parquet_path")
        if isinstance(path, str) and path and not Path(path).is_absolute():
            estimator_config = deepcopy(request.estimator_config)
            estimator_config["fpm_interpolation"]["fpm_parquet_path"] = str(Path(path).absolute())
            request = replace(request, estimator_config=estimator_config)
        model: RustForwardPassPerfModel | None = None
        try:
            request_payload = RustForwardPassPerfModel.normalize_config(request)
            if request_payload.get("fpm_profile") is not None:
                from aisimulate_core.sdk.fpm_profile import _require_forward_pass_profile_memory

                _require_forward_pass_profile_memory(request_payload)
            cache_key = json.dumps(request_payload, sort_keys=True)
            cached = self._resolved.get(cache_key)
            if cached is not None:
                return deepcopy(cached)
            model = RustForwardPassPerfModel.best_available(request)
            diagnostics = model.diagnostics()
        except Exception as exc:
            raise ForwardPassEstimatorResolutionError(
                "Core cannot construct the exact forward-pass estimator for "
                f"role={role}, model={request.model}, system={request.system}, "
                f"backend={request.backend}, tp={request.tp}, pp={request.pp}, "
                f"attention_dp={request.attention_dp}, moe_tp={request.moe_tp_size}, "
                f"moe_ep={request.moe_ep_size}, kv_block_size={request.kv_block_size}: {exc}"
            ) from exc
        finally:
            if model is not None:
                model.close()

        provenance = diagnostics.get("provenance")
        if not isinstance(provenance, dict) or not isinstance(provenance.get("config"), dict):
            raise ForwardPassEstimatorResolutionError(
                f"Core returned no resolved provenance for {request.system}/{request.backend}/{role}"
            )
        resolved_config = dict(provenance["config"])
        if diagnostics.get("readiness") != "ready":
            raise ForwardPassEstimatorResolutionError(
                f"estimator for {role} is not ready: {unready_estimator_message(diagnostics)}"
            )
        if not resolved_config.get("backend_version"):
            raise ForwardPassEstimatorResolutionError(
                f"Core did not resolve an exact backend version for {request.system}/{request.backend}/{role}"
            )
        selected_root = provenance.get("selected_systems_root")
        if selected_root and resolved_config.get("systems_paths") != [str(selected_root)]:
            raise ForwardPassEstimatorResolutionError(
                "Core provenance must pin its selected systems root in the resolved config: "
                f"config={resolved_config.get('systems_paths')!r}, selected={selected_root!r}"
            )
        for field in (
            "model",
            "fpm_profile",
            "system",
            "backend",
            "tp",
            "pp",
            "attention_dp",
            "dcp",
            "moe_tp_size",
            "moe_ep_size",
            "nextn",
            "speculation",
            "kv_block_size",
            "worker_type",
            *ENGINE_MODEL_CONTROL_FIELDS,
        ):
            if resolved_config.get(field) != request_payload.get(field):
                raise ForwardPassEstimatorResolutionError(
                    f"Core changed exact candidate field {field!r}: "
                    f"requested={request_payload.get(field)!r}, resolved={resolved_config.get(field)!r}"
                )
        spec = ForwardPassEstimatorSpec(
            config=resolved_config,
            options=None,
            diagnostics=diagnostics,
        )
        self._resolved[cache_key] = deepcopy(spec)
        return spec

    def resolve_candidate(self, sample: dict[str, Any]) -> dict[str, ForwardPassEstimatorSpec]:
        """Resolve every concrete engine role before replay trial execution."""

        mode = sample["deployment_mode"]
        if mode not in {"agg", "disagg"} or self._search_space.encoder is not None:
            return {}
        roles = ("agg",) if mode == "agg" else ("prefill", "decode")
        roles = tuple(
            role for role in roles if ("aggregated" if role == "agg" else role) not in sample.get("afd_roles", {})
        )
        resolved = {
            role: self._resolve(self._request(sample, role), role)
            for role in roles
            if sample.get(f"{role}_timing_model") is None
        }
        # A regression or learned role may not know its version; the others agree.
        versions = {spec.backend_version for spec in resolved.values()} - {UNKNOWN_IDENTITY}
        if len(versions) > 1:
            raise ForwardPassEstimatorResolutionError(
                f"Core resolved inconsistent backend versions across candidate roles: {sorted(versions)}"
            )
        return resolved
