from pathlib import Path
import ast
import hashlib
import json

def native_dense_case(spec, call):
 backend=spec['backend']; source=Path('/Users/simonec/repo/aisimulate-pr664-cost-candidate/python/aisimulate/collector')/backend/'collect_attn.py'
 function=next(node for node in ast.parse(source.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='run_attention_torch')
 names=[argument.arg for argument in function.args.args if argument.arg!='exit_stack']
 values=ast.literal_eval(call['row']);bound=dict(zip(names,values))
 key={'batch_size':str(bound['batch_size']),'input_len':str(bound['input_len']),'num_heads':str(bound['num_heads']),'num_kv_heads':str(bound.get('num_kv_heads',bound.get('num_key_value_heads'))),'head_dim':str(bound['head_dim']),'window_size':str(bound.get('window_size',bound.get('attention_window_size',0)))}
 matches=[]
 for case in spec['cases']:
  if any(str(case.get(name))!=value for name,value in key.items()):continue
  if bool(bound.get('use_fp8_kv_cache',False)) != case.get('kv_cache_dtype','').startswith(('fp8','float8')):continue
  if 'use_fp8_context_fmha' in bound and bool(bound['use_fp8_context_fmha']) != case.get('attn_dtype','').startswith(('fp8','float8')):continue
  if case.get('dispatch') and case['dispatch']!=bound.get('attn_backend_name'):continue
  matches.append(case)
 if len(matches)!=1:raise ValueError(('native case identity not unique',backend,call['row'],matches))
 return matches[0]

def matches(case, row, operation):
    aliases = {'input_len': 'isl' if operation == 'attention_context' else 'step', 'num_kv_heads': 'num_key_value_heads'}
    names = ('batch_size','input_len','num_heads','num_kv_heads','head_dim','attn_dtype','kv_cache_dtype')
    return all(str(row.get(aliases.get(name,name))) == str(case[name]) for name in names) and (not case.get('dispatch') or row.get('kernel_source') == case['dispatch'])

def storage_map(events):
    result = {}
    for event in events:
        for tensor in event.get('tensors', []):
            result[tensor['storage_id']] = max(result.get(tensor['storage_id'], 0), tensor['storage_bytes'])
    return result

root = Path('/tmp/pr664-cost-results/raw')
records = []
groups = []
for path in sorted(root.glob('*/*features*/native-*/result.json')):
    data = json.loads(path.read_text())
    spec = data.get('spec', {})
    if not spec.get('observe_allocations') or not data.get('direct_benchmark_measurements'):
        continue
    passed = [call for call in data['calls'] if call['status'] == 'passed']
    forwards = data.get('forward_rows', [])
    if len(passed) != len(forwards):
        continue
    measurements = {measurement['native_call_index']: measurement for measurement in data['direct_benchmark_measurements']}
    group_id = path.parent.parent.name + ':' + path.parent.name
    point_ids = []
    for call, forward in zip(passed, forwards, strict=True):
        case = native_dense_case(spec, call)
        assert matches(case, forward, spec['op']), (path, call, case, forward)
        measurement = measurements[call['index']]
        phases = measurement['phase_seconds']
        execution = sum(phases[name] for name in ('eager_warmup','capture','graph_warmup','timed','cleanup'))
        events = [event for event in data['allocation_observations'] if event['native_call_index'] == call['index']]
        cache_events = [event for event in events if event['kind'] != 'forward_input_arguments']
        input_events = [event for event in events if event['kind'] == 'forward_input_arguments']
        cache = storage_map(cache_events)
        inputs = storage_map(input_events)
        overlap = sum(min(size, inputs[key]) for key,size in cache.items() if key in inputs)
        final_events = [event for event in cache_events if event['kind'] != 'vllm_initial_cache']
        sample_id = group_id + ':point:' + str(call['index'])
        point_ids.append(sample_id)
        record = {'sample_id': sample_id, 'status': 'passed', 'measurement_scope': 'point', 'system': spec['system'], 'backend': spec['backend'], 'operation': spec['op'], 'case': case, 'actual_kernel_source': forward['kernel_source'], 'native_parameters': call['row'], 'group_id': group_id, 'replicate': spec['replicate'], 'group_validation_role': spec['group_validation_role'], 'native_pass_index': call['native_pass_index'], 'pass_scope': call.get('pass_scope'), 'geometry_role': 'whole_geometry_holdout' if [int(case['num_heads']),int(case['num_kv_heads'])] == spec['whole_geometry_holdout'] else 'fit', 'collection_seconds': call['native_call_seconds'], 'preparation_seconds': call['native_call_seconds'] - execution, 'execution_seconds': execution, 'timed_seconds': phases['timed'], 'phase_seconds': phases, 'num_runs_executed': measurement['num_runs_executed'], 'requested_num_warmups': measurement['requested_warmups'], 'repeat_n': measurement['repeat_n'], 'effective_forward_count_observed': None, 'forward_count_scope': 'Observed timed repetitions only; total warm-up/capture/replay forward invocation count is not observed.', 'forward_latency_ms': measurement['forward_latency_ms'], 'allocation_observations': events, 'kv_unique_allocation_bytes': sum(cache.values()), 'kv_final_resident_bytes': sum(storage_map(final_events).values()), 'forward_input_unique_storage_bytes': sum(inputs.values()), 'kv_forward_storage_overlap_bytes': overlap, 'noncache_forward_input_bytes': sum(size for key,size in inputs.items() if key not in cache), 'allocation_feature_scope': 'Actual unique cache storage allocated during this native call; vLLM initial and final layout copies both counted when distinct. TRT forward input is packed argument only, not all transient source buffers.', 'runtime_protocol': data['runtime_protocol'], 'physical_gpu_uuid': data['gpu']['uuid'], 'source_commit': spec['collector_commit'], 'audit_driver_commit': data['audit_driver_commit_declared'], 'audit_driver_sha256': data['audit_driver_sha256'], 'observer_sha256': data['audit_observer_sha256'], 'participating_gpus': 1, 'allocation_seconds_included': False, 'source_artifact': str(path), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        assert record['preparation_seconds'] >= 0, record
        records.append(record)
    wrapper_path = path.parent.parent / (path.parent.name.replace('native-', 'wrapper-', 1)) / 'result.json'
    if wrapper_path.exists():
        wrapper = json.loads(wrapper_path.read_text())
        groups.append({'group_id': group_id, 'system': spec['system'], 'backend': spec['backend'], 'operation': spec['op'], 'replicate': spec['replicate'], 'status': wrapper['status'], 'native_status': data['status'], 'collection_seconds': wrapper['collection_seconds'], 'native_point_seconds': sum(call['native_call_seconds'] for call in passed), 'wrapper_residual_seconds': wrapper['collection_seconds'] - sum(call['native_call_seconds'] for call in passed), 'residual_scope': 'Startup/planning/audit progress I/O/teardown; not pure initialization or a normal one-pass forecast.', 'native_passes': 2, 'member_sample_ids': point_ids, 'participating_gpus': 1})
output = Path('/tmp/pr664-cost-results/dense-feature-samples.jsonl')
output.write_text(''.join(json.dumps(record, sort_keys=True) + '\n' for record in records))
output.with_name('dense-feature-groups.json').write_text(json.dumps(groups, indent=2) + '\n')
print(json.dumps({'records': len(records), 'groups': len(groups), 'output': str(output)}))
