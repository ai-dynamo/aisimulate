from pathlib import Path
import json,collections,statistics,csv,io,zipfile
b=Path('/Users/simonec/repo/aisimulate-pr664-cost-audit/benchmarks/evidence/collector/agentic-coverage-cost-2026-11');r=[json.loads(x) for x in open(b/'measured-samples.jsonl')];inv=json.load(open(b/'inventory-summary.json'))
pairs=collections.defaultdict(dict)
for x in r:
 if x['measurement_scope']=='group' and x.get('paired_group_id') and x['operation']=='moe' and 'validation' in x['paired_group_id']:
  pairs[x['system'],x['backend'],x['paired_group_id']][x['scenario']]=x
results=[]
for l in inv['lanes']:
 s,bk=l['system'],l['backend'];op=l['operations']['moe'];n=op['planned_tasks']['model'];items=[]
 for (ss,bb,k),p in sorted(pairs.items()):
  if (ss,bb)!=(s,bk) or not {'baseline','model'}<=p.keys():continue
  a,c=p['baseline'],p['model'];items.append({'pair':k,'baseline_status':a['status'],'expanded_status':c['status'],'wall_delta':c['collection_seconds']-a['collection_seconds'],'native_delta':(c['collection_seconds']-(c.get('setup_seconds') or 0))-(a['collection_seconds']-(a.get('setup_seconds') or 0)),'baseline':a['collection_seconds'],'expanded':c['collection_seconds'],'setup_delta':None if c.get('setup_seconds') is None or a.get('setup_seconds') is None else c['setup_seconds']-a['setup_seconds']})
 valid=[x for x in items if x['baseline_status']==x['expanded_status']=='passed'];d=[x['wall_delta'] for x in valid]
 z={'system':s,'backend':bk,'moe_groups':n,'pairs':items,'proxy_full_inventory_gpu_hours_median':None if not d else n*max(0,statistics.median(d))/3600,'proxy_full_inventory_gpu_hours_observed_range':None if not d else [n*max(0,min(d))/3600,n*max(0,max(d))/3600]}
 results.append(z)
 print(s,bk,n,'diffs',[(round(x['wall_delta'],3),x['baseline_status'],x['expanded_status']) for x in items],'h',z['proxy_full_inventory_gpu_hours_median'],z['proxy_full_inventory_gpu_hours_observed_range'])
Path('/tmp/pr664-planning-estimate/moe-proxy.json').write_text(json.dumps(results,indent=2)+'\n')
with zipfile.ZipFile(b/'frozen-plan-tables.zip') as z:
 for result in results:
  s,bk=result['system'],result['backend'];groups=[x for x in r if x['system']==s and x['backend']==bk and x['operation']=='moe' and x['measurement_scope']=='group' and x['scenario']=='model' and x['status']=='passed' and x.get('paired_group_id') and 'validation' in x['paired_group_id']]
  extra=[]
  for x in groups:
   m=x['direct_benchmark_measurements']
   if len(m)==29:extra.append(sum(sum(y.get('phase_seconds',{}).values()) for y in m[-2:]))
  result['added_native_benchmark_two_cells_seconds_median']=statistics.median(extra) if extra else None
  if extra:
   n=result['moe_groups'];floor=n*statistics.median(extra)/3600;result['unweighted_helper_component_gpu_hours_proxy']=floor
   d=[x['wall_delta'] for x in result['pairs'] if x['baseline_status']==x['expanded_status']=='passed'];center=max(statistics.median(d),statistics.median(extra));noise=max(abs(x) for x in d)
   result['unweighted_whole_group_planning_center_gpu_hours']=n*center/3600;result['unweighted_whole_group_planning_sensitivity_gpu_hours']=[floor,n*max(max(d),center+noise)/3600]
  print('MOE2',s,bk,'extra',result.get('added_native_benchmark_two_cells_seconds_median'),'hours',result.get('unweighted_whole_group_planning_center_gpu_hours'),result.get('unweighted_whole_group_planning_sensitivity_gpu_hours'))
 print('KDA')
 kda=[]
 for x in r:
  if x['measurement_scope']!='direct_call' or x['operation']!='kda' or x['status']!='passed':continue
  s,bk=x['system'],x['backend'];name=next(n for n in z.namelist() if n.startswith('model/'+s+'/'+bk+'/') and n.endswith('_kda.csv'));tasks=list(csv.DictReader(io.StringIO(z.read(name).decode())))
  def weight(c,batch):return batch*(int(c['d_model'])+128*(int(c['num_k_heads'])+int(c['num_v_heads'])))
  addedweight=sum(sum(weight(c,bb)*3 for bb in __import__('ast').literal_eval(c['batch_sizes'])) for c in tasks if c['phase']=='verify')
  task=x['case'];sampleweight=sum(weight(task,bb)*6 for bb in (1,32));groupscale=addedweight/sampleweight
  bench=x['direct_benchmark_measurements'];helper=sum(sum(v.get('phase_seconds',{}).values()) for v in bench)
  row={'system':s,'backend':bk,'added_cells':216,'whole_native_group_seconds':x['collection_seconds'],'benchmark_helper_seconds':helper,'physical_buffer_work_weight_ratio':groupscale,'buffer_weighted_helper_proxy_gpu_hours':helper*groupscale/3600,'buffer_weighted_inclusive_group_proxy_gpu_hours':x['collection_seconds']*groupscale/3600,'unweighted_inclusive_group_proxy_gpu_hours':x['collection_seconds']*216/12/3600};kda.append(row);print(row)
Path('/tmp/pr664-planning-estimate/moe-proxy.json').write_text(json.dumps(results,indent=2)+'\n');Path('/tmp/pr664-planning-estimate/kda-proxy.json').write_text(json.dumps(kda,indent=2)+'\n')
