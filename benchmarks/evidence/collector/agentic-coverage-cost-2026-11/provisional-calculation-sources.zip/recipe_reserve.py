import runpy,zipfile,io,csv,collections,json,statistics
from pathlib import Path
m=runpy.run_path('/tmp/pr664-planning-a/estimate.py');z=m['z'];pools=m['pools'];samples=m['samples'];est=m['estimate'];paths=m['paths']
out=[]
for backend,ops in {'vllm':['msa_context_module','msa_generation_module'],'sglang':['dsa_context_module_skip_indexer','dsa_generation_module','dsa_generation_module_skip_indexer'],'trtllm':['msa_context_module','msa_generation_module']}.items():
 for op in ops:
  filename=next(n.rsplit('/',1)[-1] for n in paths if n.startswith(f'model/b300_sxm/{backend}/') and n.endswith('_'+op+'.csv'))
  base=list(csv.DictReader(io.StringIO(z.read(f'baseline/b300_sxm/{backend}/{filename}').decode())));rows=list(csv.DictReader(io.StringIO(z.read(f'model/b300_sxm/{backend}/{filename}').decode())))
  keys={tuple(sorted(x.items())) for x in base};added=[x for x in rows if tuple(sorted(x.items())) not in keys]
  if backend=='sglang' and op.startswith('dsa_generation'):
   ss=[s for s in samples if s['system']=='b300_sxm' and s['backend']==backend and s['operation']==op and s['measurement_scope']=='point' and s['status']=='passed' and 'NVFP4' in s.get('case',{}).get('model_path','')]
   kind='NVFP4 recipe override, not canonical BF16 estimate';proxy_op=op
  else:
   # Operational reserve only: use native DSA timing as analogous sparse family, NOT measurement of absent MSA/skip implementation.
   proxy_op=op.replace('msa_','dsa_').replace('_skip_indexer','');ss=pools.get(('b300_sxm',backend,proxy_op),[]);kind='operational reserve via same-framework analogous DSA; unsupported route not certified'
  vals={str(f):sum(est(c,proxy_op,ss,f) for c in added)/3600 if ss else None for f in [0,.5]}
  out.append(dict(backend=backend,operation=op,added=len(added),kind=kind,native_anchor_count=len(ss),prep_sensitivity_gpuh=vals,proxy_operation=proxy_op))
Path('/tmp/pr664-planning-a/recipe-reserve.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
