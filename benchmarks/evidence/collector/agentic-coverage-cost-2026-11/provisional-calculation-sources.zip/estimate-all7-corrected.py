import csv,io,json,zipfile,math,statistics,collections
from pathlib import Path
P=Path('/Users/simonec/repo/aisimulate-pr664-cost-artifacts-final/benchmarks/evidence/collector/agentic-coverage-cost-2026-11')
z=zipfile.ZipFile(P/'fit-inputs-1018-final.zip'); samples=[json.loads(x) for x in z.read('fit-inputs/samples-1018-final.jsonl').splitlines()]
# Timing proxy deliberately planning-only. No cross-system or cross-framework rates.
pools=collections.defaultdict(list)
for s in samples:
 if s['measurement_scope']=='point' and s['status']=='passed' and (s.get('native_forward_rows') or s.get('forward_latency_ms') is not None or str(s.get('evidence_level','')).startswith('Qwen local')):
  if s.get('canonical_bf16_transfer_allowed') is False or 'NVFP4' in s.get('case',{}).get('model_path',''):continue
  if s['operation'].startswith(('attention_','dsa_','msa_','mla_')):pools[s['system'],s['backend'],s['operation']].append(s)
def f(c,k,d=1):
 try:return float(c.get(k,d))
 except:return d
def dtype_bytes(name):
 return 1 if any(x in str(name).lower() for x in ['fp8','int8']) else .5 if 'fp4' in str(name).lower() else 4 if 'float32' in str(name).lower() else 2
def features(c,op):
 b=f(c,'batch_size'); l=f(c,'input_len',f(c,'seq_len')); pre=f(c,'prefix_len',0);q=f(c,'num_heads',4);kv=f(c,'num_kv_heads',1);d=f(c,'head_dim',128)
 context='context' in op
 if op.startswith('attention'):
  window=f(c,'window_size',0); active=min(l,window) if window>0 else l
  mem=b*l*kv*d*dtype_bytes(c.get('kv_cache_dtype')) + b*(l if context else 1)*q*d*dtype_bytes(c.get('attn_dtype'))
  work=b*q*d*(l*active if context else active)
 else:
  mem=b*(l+pre)*dtype_bytes(c.get('kv_cache_dtype')); work=b*q*(l*(pre+l) if context else l)
 return max(mem,1),max(work,1),b,l,q,d
# Quantization coefficients are not imported from another GPU; unknown precision is a declared uncertainty.
def estimate(c,op,ss,fixed_prep):
 t=features(c,op);choices=[]
 for s in ss:
  a=features(s['case'],op)
  dist=sum(abs(math.log(max(x,1)/max(y,1))) for x,y in zip(t,a))
  dist+=3*(c.get('dispatch','')!=s['case'].get('dispatch',''))
  dist+=2*(c.get('kv_cache_dtype')!=s['case'].get('kv_cache_dtype'))
  dist+=2*(c.get('attn_dtype',c.get('compute_dtype'))!=s['case'].get('attn_dtype',s['case'].get('compute_dtype')))
  if 'model_path' in c:dist+=3*(c.get('model_path')!=s['case'].get('model_path'))
  prep=s.get('preparation_seconds'); exe=s.get('execution_seconds'); total=s['collection_seconds']
  if prep is None or exe is None:
   # Inclusive proxy: memory plus attention work, with a fixed input/dispatch floor.
   prep=total*.5;exe=total*.5
   pred=prep*(fixed_prep+(1-fixed_prep)*t[0]/a[0])+exe*(.1+.9*t[1]/a[1])
  else:
   # Half preparation is fixed task/input cost; half follows touched cache/input extent.
   pred=prep*(fixed_prep+(1-fixed_prep)*t[0]/a[0])+exe*(.1+.9*t[1]/a[1])
  choices.append((dist,pred))
 choices.sort();return statistics.median(x[1] for x in choices[:3])
z=zipfile.ZipFile(P/'frozen-plan-tables.zip');paths=z.namelist();out=[]
for system in ['l40s','h100_sxm','h200_sxm','b200_sxm','b300_sxm','gb200','gb300']:
 for backend in ['vllm','sglang','trtllm']:
  bfiles={n.rsplit('/',1)[-1]:n for n in paths if n.startswith(f'baseline/{system}/{backend}/')}
  for scenario in ['shared','model']:
   for filename,bpath in bfiles.items():
    op=filename.split('_',2)[-1][:-4] # backend_smNN_op.csv
    if not op.startswith(('attention_','dsa_','msa_','mla_')):continue
    n=f'{scenario}/{system}/{backend}/{filename}'
    if n not in paths:continue
    base=list(csv.DictReader(io.StringIO(z.read(bpath).decode())));rows=list(csv.DictReader(io.StringIO(z.read(n).decode())))
    keys=set(tuple(sorted(r.items())) for r in base);added=[r for r in rows if tuple(sorted(r.items())) not in keys]
    if not added:continue
    ss=pools.get((system,backend,op),[])
    values={str(fixed):sum(estimate(c,op,ss,fixed) for c in added)/3600 if ss else None for fixed in [0,.5]}
    value=values['0.5']
    out.append(dict(system=system,backend=backend,scenario=scenario,operation=op,added=len(added),planning_point_gpuh=value,prep_sensitivity_gpuh=values,anchors=len(ss)))
Path('/tmp/pr664-planning-a/results-all7-corrected.json').write_text(json.dumps(out,indent=2))
for system in ['l40s','h100_sxm','h200_sxm','b200_sxm','b300_sxm','gb200','gb300']:
 print(system)
 for scenario in ['shared','model']:
  rows=[x for x in out if x['system']==system and x['scenario']==scenario];known=[x for x in rows if x['planning_point_gpuh'] is not None]
  print(scenario,round(sum(x['planning_point_gpuh'] for x in known),2),'pricedcases',sum(x['added'] for x in known),'missingcases',sum(x['added'] for x in rows if x['planning_point_gpuh'] is None))
