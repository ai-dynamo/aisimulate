from pathlib import Path
import sys,json,hashlib,re
sys.path.insert(0,'/Users/simonec/repo/aisimulate-pr664-cost-audit/python/aisimulate')
from tools.perf_database.collection_cost import inner_cells
root=Path('/tmp/pr664-cost-results/raw');samples=[]
def forward_match(case,row,op):
 aliases={'input_len':'isl' if op=='attention_context' else 'step','num_kv_heads':'num_key_value_heads'}
 return all(str(row.get(aliases.get(k,k),''))==str(v) for k,v in case.items() if k in ('batch_size','input_len','num_heads','num_kv_heads','head_dim','attn_dtype','kv_cache_dtype'))
for native_path in root.glob('*/*/native-*/result.json'):
 data=json.loads(native_path.read_text());spec=data.get('spec',{});label=native_path.parent.name.removeprefix('native-');wrapper_path=native_path.parent.parent/('wrapper-'+label)/'result.json'
 if not wrapper_path.exists() or not spec:continue
 wrapper=json.loads(wrapper_path.read_text());gid=native_path.parent.parent.name+':'+label
 common={'system':spec['system'],'backend':spec['backend'],'operation':spec['op'],'source_commit':spec['collector_commit'],'scenario':spec.get('scenario','shared'),'group_id':gid,'participating_gpus':1,'allocation_seconds_included':False,'source_artifact':str(native_path),'source_sha256':hashlib.sha256(native_path.read_bytes()).hexdigest()}
 cases=spec['cases'];members=[c for task in cases for c in inner_cells(task)];pair=spec.get('pair_id')
 calls=data.get('calls',[]);passed=[c for c in calls if c.get('status') in ('passed','completed_restart_required')]
 group={**common,'sample_id':gid+':group','measurement_scope':'group','case':{},'status':wrapper['status'],'collection_seconds':wrapper['collection_seconds'],'setup_seconds':None,'group_member_cases':members,'role':spec.get('role','fit')}
 if pair:group['paired_group_id']=pair
 group['cache_scope_declared']=spec.get('cache_scope')
 group['pilot_splits_same_cache_proven']=not (spec['backend']=='sglang' and label=='moe-expanded' and '-followup-' in gid)
 if not group['pilot_splits_same_cache_proven']:group.pop('paired_group_id',None)
 # A group only qualifies if its native manifest finished too.
 if data.get('status')!='passed':group['status']=data.get('status','failed')
 if group['status']=='passed' and len(passed)==len(calls) and calls:
  group['setup_seconds']=wrapper['collection_seconds']-sum(c['native_call_seconds'] for c in calls)
 group['direct_benchmark_measurements']=data.get('direct_benchmark_measurements',[])
 samples.append(group)
 if spec['op'] in ('attention_context','attention_generation'):
  for call in passed:
   index=call['index'];case=cases[index];rows=[r for r in data.get('forward_rows',[]) if forward_match(case,r,spec['op'])]
   sample={**common,'sample_id':gid+':point:'+str(index),'measurement_scope':'point','case':case,'status':'passed','collection_seconds':call['native_call_seconds'],'setup_seconds':group['setup_seconds'] if group['status']=='passed' else None,'forward_latency_ms':float(rows[0]['latency']) if len(rows)==1 else None,'native_parameters':call.get('row'),'num_runs_executed':call.get('num_runs_executed'),'native_forward_rows':rows,'phase_seconds':call.get('phase_seconds',{}),'role':'holdout' if index in (1,6) else 'fit'}
   measurements=data.get('direct_benchmark_measurements',[])
   if len(measurements)==len(calls):
    sample.update({k:v for k,v in measurements[index].items() if k in ('num_runs_executed','phase_seconds','requested_warmups','repeat_n','forward_latency_ms')})
   phase_keys=('eager_warmup','capture','graph_warmup','timed','cleanup')
   if all(k in sample.get('phase_seconds',{}) for k in phase_keys):
    execution=sum(sample['phase_seconds'][k] for k in phase_keys)
    if execution <= sample['collection_seconds']:
     sample.update(execution_seconds=execution,preparation_seconds=sample['collection_seconds']-execution,component_definition='execution is the disjoint native benchmark helper phases including warm-up/capture/timed/cleanup; preparation is the measured native-call residual including input setup/synchronization/logging; group initialization separate')
   samples.append(sample)
 elif '_module' in spec['op']:
  timings=wrapper.get('native_point_timings',[]);points=[]
  for i,timing in enumerate(timings):
   log=timing['native_log'];match=re.search(r'b=(\d+), (?:kv|s)=(\d+)',log)
   if not match:continue
   batch,length=match.groups();matching=[c for c in cases if c.get('batch_size')==batch and c.get('seq_len')==length]
   if len(matching)!=1:continue
   case=matching[0];rows=[r for r in data.get('forward_rows',[]) if r.get('batch_size')==batch and r.get('step') in (length,str(int(length)-1))]
   if not rows:continue
   phases=timing['phase_seconds'];total=timing['inclusive_seconds']
   execution=phases.get('bench')
   if execution is not None:execution+=phases.get('prewarm',0)
   if execution is None and 'measure_full' in phases:
    execution=sum(phases.get(k,0) for k in ('dry_run','measure_full','measure_skip'))
   points.append({**common,'sample_id':gid+':point:'+str(i),'measurement_scope':'point','case':case,'status':'passed','collection_seconds':total,'setup_seconds':None,'execution_seconds':execution,'preparation_seconds':None if execution is None else total-execution,'phase_seconds':phases,'native_forward_rows':rows,'forward_latency_ms':float(rows[0]['latency']) if len(rows)==1 else None,'num_runs_executed':None,'source_checked_repetition_policy':spec.get('source_checked_subprocess_repetition_policy'),'role':'fit'})
  if len(points)==len(cases) and group['status']=='passed':
   group['setup_seconds']=wrapper['collection_seconds']-sum(x['collection_seconds'] for x in points)
   for point in points:point['setup_seconds']=group['setup_seconds']
  samples.extend(points)
 else:
  # One grouped MoE call covers 27/29 cells; never assign whole clock to each token.
  for call in calls:
   samples.append({**common,'sample_id':gid+':direct:'+str(call['index']),'measurement_scope':'direct_call','case':cases[min(call['index'],len(cases)-1)],'status':call['status'],'collection_seconds':call.get('native_call_seconds'),'setup_seconds':None,'forward_latency_ms':None,'direct_benchmark_measurements':data.get('direct_benchmark_measurements',[]),'native_forward_rows':data.get('forward_rows',[]),'phase_seconds':call.get('phase_seconds',{}),'role':spec.get('role','fit')})
known_groups={s['group_id'] for s in samples if s['measurement_scope']=='group'}
for wrapper_path in root.glob('*/*/wrapper-*/result.json'):
 wrapper=json.loads(wrapper_path.read_text());label=wrapper_path.parent.name.removeprefix('wrapper-');gid=wrapper_path.parent.parent.name+':'+label
 if gid in known_groups:continue
 argv=wrapper.get('spec',{}).get('argv',[])
 if '--spec' not in argv:continue
 spec_path=wrapper_path.parent.parent/Path(argv[argv.index('--spec')+1]).name
 if not spec_path.exists():continue
 spec=json.loads(spec_path.read_text())
 samples.append({'sample_id':gid+':group','system':spec['system'],'backend':spec['backend'],'operation':spec['op'],'source_commit':spec['collector_commit'],'scenario':spec.get('scenario','shared'),'group_id':gid,'participating_gpus':1,'allocation_seconds_included':False,'measurement_scope':'group','case':{},'status':wrapper['status'],'collection_seconds':wrapper['collection_seconds'],'setup_seconds':None,'group_member_cases':spec['cases'],'role':'fit','source_artifact':str(wrapper_path),'source_sha256':hashlib.sha256(wrapper_path.read_bytes()).hexdigest(),'qualification':'censored or failed worker; no point timings available; collection cost retained, excluded from point fit'})
p=Path('/tmp/pr664-cost-results/samples.jsonl');p.write_text(''.join(json.dumps(s,sort_keys=True)+'\n' for s in samples))
print(json.dumps({'samples':len(samples),'groups':sum(s['measurement_scope']=='group' for s in samples),'points':sum(s['measurement_scope']=='point' for s in samples),'output':str(p)}))
