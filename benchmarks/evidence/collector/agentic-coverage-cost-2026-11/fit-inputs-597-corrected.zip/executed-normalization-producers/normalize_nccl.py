from pathlib import Path
import csv
import hashlib
import json

lanes = []
for system in ('a100_sxm', 'l40s', 'h100_sxm', 'h200_sxm', 'b200_sxm', 'b300_sxm', 'gb200', 'gb300'):
    ranks = []
    known = 0
    expected = 16 if system.startswith('gb') else 24
    for path in Path('/tmp/pr664-cost-results/raw', system).glob('*-nccl-*/native-r*/result.json'):
        result = json.loads(path.read_text())
        participants = result['participating_gpus']
        calls = result['calls']
        new = [call for call in calls if call['size_bytes'] == 1073741824 and call['status'] == 'passed']
        seconds = sum(call['collection_seconds'] for call in new)
        known += len(new)
        perf_path = path.parent / 'nccl_perf.txt'
        rows = list(csv.DictReader(perf_path.open())) if perf_path.exists() else []
        ranks.append({'participating_gpus': participants, 'completed_new_1GiB_cases': len(new), 'expected_new_cases': 8, 'measured_incremental_native_seconds': seconds, 'measured_incremental_collection_gpu_hours': seconds * participants / 3600, 'parent_import_setup_increment_seconds': None, 'complete_native_rank_group': result.get('status') == 'passed', 'source_artifact': str(path), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'calls': calls, 'native_forward_rows': rows, 'gpu_uuid_receipts': result['gpus'], 'nccl_version': result['nccl_version'], 'binary_linkage': result.get('binary_linkage'), 'pending_call': result.get('pending_call')})
    lanes.append({'system': system, 'expected_supported_local_new_cases': 0 if system == 'l40s' else expected, 'measured_new_cases': known, 'rank_groups': ranks, 'complete_system_extra_gpu_hours': None, 'measured_new_native_gpu_hours_component': sum(rank['measured_incremental_collection_gpu_hours'] for rank in ranks) if ranks else None, 'unknown_scope': 'No two-or-more local GPU topology on canonical L40S node' if system == 'l40s' else ('Eight local ranks unsupported on four-GPU Grace nodes; censored calls unknown' if system.startswith('gb') else 'Unmeasured or censored rank/dtype/collective calls unknown; parent setup increment unproven'), 'shared_framework_accounting': 'NCCL is per-system canonical TRT image; do not triple charge vLLM/SGLang/TRT'})
output = {'byte_sizes': [536870912, 1073741824], 'row_message_size_unit': 'elements = bytes / (2 for half, 1 for int8)', 'timing_scope': 'Native nccl_benchmark call includes nccl-tests process initialization, 40 warm-up and 60 timed large-message iterations, and latency logging. Parent Python imports outside per-call clocks. Allocation excluded.', 'lanes': lanes}
Path('/tmp/pr664-cost-results/nccl-cost-components.json').write_text(json.dumps(output, indent=2) + '\n')
for lane in lanes:
    print(lane['system'], lane['measured_new_cases'], lane['measured_new_native_gpu_hours_component'])
