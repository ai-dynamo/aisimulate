from pathlib import Path
import sys,json,hashlib,re
sys.path.insert(0,'/Users/simonec/repo/aisimulate-pr664-cost-audit/python/aisimulate')
from tools.perf_database.collection_cost import phase_timings
base=Path('/tmp/pr664-c-serving/1024142');samples=[]
for mode in ('indexer','skip_indexer'):
 p=base/'cases'/mode/'result.json';d=json.loads(p.read_text());timings=phase_timings(base/(mode+'.log'));op=d['op'];gid='c44-1024142:'+mode
 cases=[{'seq_len':str(s),'batch_size':str(b),'num_heads':'8','kv_cache_dtype':'fp8','compute_dtype':'bfloat16','gemm_type':'bfloat16','model_path':d['model_path'],'prefix_len':str(prefix),'dispatch':''} for b,s,prefix in d['requested_points']]
 common={'system':'b300_sxm','backend':'sglang','operation':op,'source_commit':d['collector_ref'],'scenario':'model','group_id':gid,'participating_gpus':1,'allocation_seconds_included':False,'budget_owner':'correctness; reused without recharging cost-audit quota','source_artifact':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 points=[]
 for i,timing in enumerate(timings):
  match=re.search(r'b=(\d+), kv=(\d+)',timing['native_log'])
  if not match:continue
  b,s=match.groups();case=next(c for c in cases if c['batch_size']==b and c['seq_len']==s);rows=[r for r in d['rows'] if r['batch_size']==b and r['step']==s]
  assert len(rows)==1,(mode,b,s,rows)
  phase=timing['phase_seconds'];execution=phase.get('bench',0)+phase.get('prewarm',0);total=timing['inclusive_seconds']
  points.append({**common,'sample_id':gid+':point:'+str(i),'measurement_scope':'point','case':case,'status':'passed','collection_seconds':total,'execution_seconds':execution,'preparation_seconds':total-execution,'phase_seconds':phase,'setup_seconds':None,'native_forward_rows':rows,'forward_latency_ms':float(rows[0]['latency']),'num_runs_executed':None,'role':'holdout' if i in (4,9,14,19) else 'fit','calibration_scope':'B52 chosen calibration frontier; not observed per-rank workload demand'})
 assert len(points)==22
 setup=d['collection_seconds']-sum(x['collection_seconds'] for x in points)
 for point in points:point['setup_seconds']=setup
 samples.append({**common,'sample_id':gid+':group','measurement_scope':'group','case':{},'status':'passed','collection_seconds':d['collection_seconds'],'setup_seconds':setup,'group_member_cases':cases,'role':'fit','boundary':'child-worker invocation includes child imports/model-init/prep/warm/forward; parent bootstrap/CPU plan excluded; allocation excluded'})
 samples.extend(points)
Path('/tmp/pr664-cost-results/c44-samples.jsonl').write_text(''.join(json.dumps(s,sort_keys=True)+'\n' for s in samples));print(len(samples))
