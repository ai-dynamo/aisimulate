"""Exercise the real collector under a CUDA allocator quota."""

import argparse
import contextlib
import inspect
import json
import subprocess
import sys
import types
from pathlib import Path

import torch

parser = argparse.ArgumentParser()
parser.add_argument("--expect-oom", action="store_true")
parser.add_argument("--limit-gib", type=int, default=26)
parser.add_argument("--shape", type=int, nargs=3, default=(1, 16384, 65536))
parser.add_argument("--copies", type=int, default=1)
args = parser.parse_args()
repo = Path.cwd()
sys.path.insert(0, str(repo / "python/aisimulate"))
from collector.vllm import collect_gemm

if args.expect_oom:
    source = subprocess.check_output(
        ["git", "show", "08c7fcb2:python/aisimulate/collector/vllm/collect_gemm.py"], text=True
    )
    original = types.ModuleType("original_collect_gemm")
    original.__file__ = collect_gemm.__file__
    exec(compile(source, original.__file__, "exec"), original.__dict__)
    collect_gemm = original

limit = args.limit_gib << 30
total = torch.cuda.get_device_properties(0).total_memory
torch.cuda.set_per_process_memory_fraction(limit / total, 0)
real_mem_get_info = torch.cuda.mem_get_info


def quota_mem_get_info(device=None):
    free, _ = real_mem_get_info(device)
    return min(free, max(0, limit - torch.cuda.memory_reserved(device))), limit


torch.cuda.mem_get_info = quota_mem_get_info
original_benchmark = collect_gemm.benchmark_with_power
observed = {}


@contextlib.contextmanager
def benchmark(**kwargs):
    ops = inspect.getclosurevars(kwargs["kernel_func"]).nonlocals["op_list"]
    observed["copies"] = len(ops)
    pointers = [op.weight.untyped_storage().data_ptr() for op in ops]
    assert len(set(pointers)) == len(ops)
    with original_benchmark(**kwargs) as result:
        observed.update(result)
        yield result


def publish(**kwargs):
    latency = kwargs["item_list"][0]["latency"]
    assert abs(latency * observed["copies"] - observed["latency_ms"]) < 1e-10
    assert observed["used_cuda_graph"] is True
    observed["kernel_source"] = kwargs["kernel_source"]
    observed["published_latency_ms"] = latency


collect_gemm.benchmark_with_power = benchmark
collect_gemm.log_perf = publish
try:
    with torch.inference_mode():
        collect_gemm.run_gemm("fp8_block", *args.shape, perf_filename="validation-only")
except torch.OutOfMemoryError:
    if not args.expect_oom:
        raise
    print(json.dumps({"result": "expected_oom", "limit_bytes": limit}))
else:
    assert not args.expect_oom, f"The original six-copy policy unexpectedly fit: {observed}"
    assert observed["copies"] == args.copies
    observed["peak_allocated_bytes"] = torch.cuda.max_memory_allocated()
    assert observed["peak_allocated_bytes"] <= limit
    print(json.dumps({"result": "passed", "limit_bytes": limit, **observed}, default=str))
