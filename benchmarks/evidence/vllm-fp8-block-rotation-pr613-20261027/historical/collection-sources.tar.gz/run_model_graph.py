"""Measure real vLLM model calls with real prefilled KV at frozen geometry.

No vLLM source is modified. An RPC installs an instance-local observer. A fresh
CUDA graph joins the serving model's forward call and its logits projection so
GPU-only full-forward timing excludes Python submission gaps. Original model
calls, weights, attention metadata, input tensors and KV allocations are reused.
"""
import argparse, hashlib, json, os, random, sys, time
from pathlib import Path
os.environ.setdefault('VLLM_ENABLE_V1_MULTIPROCESSING','0')
os.environ.setdefault('VLLM_USE_V2_MODEL_RUNNER','0')
os.environ.setdefault('VLLM_DEEP_GEMM_WARMUP','skip')
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('HF_HOME','/tmp/aisimulate-rotation-case/hf-cache')
import torch
from vllm import LLM, SamplingParams

OUT=Path('/tmp/aisimulate-rotation-case')
def install(worker):
    import torch, types
    from vllm.forward_context import get_forward_context
    runner=worker.model_runner
    original=runner._model_forward
    logits_fn=runner.model.compute_logits
    runner._ab_target=None
    runner._ab_rows=[]
    def observed(*args,**kwargs):
        target=runner._ab_target
        result=original(*args,**kwargs)
        if target is None: return result
        ctx=get_forward_context()
        n=runner.input_batch.num_reqs
        past=runner.input_batch.num_computed_tokens_cpu[:n].tolist()
        tokens=kwargs['input_ids'].numel()
        phase=target['phase']
        eligible=(n==target['batch'] and tokens==(n if phase=='decode' else n*target['context'])
                  and all(p==(target['context'] if phase=='decode' else 0) for p in past))
        if not eligible: return result
        runner._ab_target=None
        # Match the serving runner's last-token selection for prefill. Decode
        # batch sizes are captured exactly, so no padded rows enter the head.
        indices=torch.arange(n,device=result.device)*(target['context'] if phase=='prefill' else 1)
        if phase=='prefill': indices+=target['context']-1
        def forward_with_logits():
            h=original(*args,**kwargs)
            return logits_fn(h[indices])
        for _ in range(5): reference=forward_with_logits()
        torch.cuda.synchronize()
        g=torch.cuda.CUDAGraph()
        with torch.cuda.graph(g):
            # Capture the same callable that the native CUDA-graph wrapper captures.
            # PyTorch 2.11 disallows replaying a graph inside another capture.
            h=runner.model.runnable(*args,**kwargs)
            captured=logits_fn(h[indices])
        for _ in range(10): g.replay()
        torch.cuda.synchronize()
        finite=bool(torch.isfinite(captured).all())
        max_diff=float((captured-reference).abs().max())
        if not finite or max_diff>0.02: raise RuntimeError(f'Capture output mismatch finite={finite}, max_diff={max_diff}')
        samples=[]
        # Blocks contain ten full forwards, large enough to amortize event overhead.
        for block in range(30):
            start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(10): g.replay()
            end.record();end.synchronize()
            samples.append(start.elapsed_time(end)/10)
        row={**target,'actual_requests':n,'past_kv_lengths':past,'input_tokens':tokens,
             'native_cudagraph_mode':str(ctx.cudagraph_runtime_mode),'native_batch_descriptor':str(ctx.batch_descriptor),
             'gpu_full_forward_samples_ms':samples,'finite_logits':finite,'capture_max_abs_logit_difference':max_diff,
             'boundary':'embedding + all decoder layers + selected-token logits, joined CUDA graph',
             'replayed_current_token_kv':'overwritten identically; past KV seeded by real prefill',
             'attention_backends':sorted({type(layer.impl).__name__ for layer in runner.attn_groups[0][0].layers}) if False else None}
        # Profile the same complete graph used for uninstrumented timing.
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
            for _ in range(5): g.replay()
            torch.cuda.synchronize()
        prof.export_chrome_trace(str(OUT/f'graph-r{target["replicate"]}-b{n}-c{target["context"]}.json'))
        row['profiled_graph_replays']=5
        runner._ab_rows.append(row)
        g.reset()
        return result
    runner._model_forward=observed
    return {'model_type':str(type(runner.get_model())), 'config':str(runner.vllm_config),
            'model_weight_bytes':sum(p.numel()*p.element_size() for p in runner.get_model().parameters())}

def target(worker,value):
    worker.model_runner._ab_target=value

def drain(worker):
    r=worker.model_runner._ab_rows;worker.model_runner._ab_rows=[]
    return r

def main():
    p=argparse.ArgumentParser();p.add_argument('--replicate',type=int,required=True);p.add_argument('--smoke',action='store_true');args=p.parse_args()
    dest=OUT/f'forward-{args.replicate}{"-smoke" if args.smoke else ""}.jsonl'
    if dest.exists(): raise RuntimeError(f'Refusing overwrite {dest}')
    llm=LLM(model=str(OUT/'model'),dtype='bfloat16',tensor_parallel_size=1,
            max_model_len=4096,max_num_seqs=64,max_num_batched_tokens=131072,
            enable_chunked_prefill=True,enable_prefix_caching=False,
            gpu_memory_utilization=0.70,block_size=64,seed=7331,
            compilation_config={'mode':0,'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[1,4,16,64]},
            async_scheduling=False,disable_log_stats=True)
    identity=llm.collective_rpc(install)
    (OUT/f'runtime-{args.replicate}{"-smoke" if args.smoke else ""}.json').write_text(json.dumps(identity,indent=2,default=str))
    cases=[{'phase':'decode','batch':1,'context':128},{'phase':'decode','batch':16,'context':512}]
    random.Random(7331+args.replicate).shuffle(cases)
    for case in cases:
        prompts=[{'prompt_token_ids':[100+(j+i)%1000 for j in range(case['context'])]} for i in range(case['batch'])]
        params=SamplingParams(temperature=0,max_tokens=2,ignore_eos=True)
        # Actual request warmup; formal timed replay sees the real prefilled KV.
        llm.generate(prompts,params,use_tqdm=False)
        llm.collective_rpc(target,args=({**case,'replicate':args.replicate},))
        outputs=llm.generate(prompts,params,use_tqdm=False)
        rows=llm.collective_rpc(drain)[0]
        if len(rows)!=1: raise RuntimeError(f'Expected one matched point, got {len(rows)}: {case}')
        assert len(outputs)==case['batch'] and all(len(o.outputs[0].token_ids)==2 for o in outputs)
        with dest.open('a') as f:f.write(json.dumps(rows[0])+'\n')
        print('MEASURED',case,flush=True)
    del llm

if __name__=='__main__': main()
