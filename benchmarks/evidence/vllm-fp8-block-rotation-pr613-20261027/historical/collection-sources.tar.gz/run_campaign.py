import datetime,json,subprocess,sys
from pathlib import Path
p=Path('/tmp/aisimulate-rotation-case');receipts=[]
for rep in range(3):
    for kind,script in [('model','run_model_graph.py'),('ops','collect_graph_ops.py')]:
        start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (p/f'{kind}-{rep}.log').open('x') as log:
            result=subprocess.run([sys.executable,str(p/script),'--replicate',str(rep)],stdout=log,stderr=subprocess.STDOUT)
        receipts.append(dict(kind=kind,replicate=rep,started_utc=start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=result.returncode))
        (p/'terminal.json').write_text(json.dumps(receipts,indent=2)+'\n')
        if result.returncode:sys.exit(result.returncode)
