"""Cache-pool sweep and profiled CUDA-graph kernels using the checkout collector."""
import argparse, contextlib, ctypes, gzip, hashlib, json, math, os, random, statistics, sys, types
from pathlib import Path
import torch
ROOT=Path(os.environ['AISIM_REPO']);OUT=Path('/tmp/aisimulate-rotation-case')
sys.path.insert(0,str(ROOT/'python/aisimulate'))
from collector import helper
from collector.vllm import collect_gemm
parser=argparse.ArgumentParser();parser.add_argument('--replicate',type=int,required=True);args=parser.parse_args()
dest=OUT/f'ops-{args.replicate}.jsonl'
if dest.exists():raise RuntimeError(f'Refusing overwrite {dest}')
state={}
@contextlib.contextmanager
def benchmark(**kwargs):
    kwargs.update(num_warmups=25,num_runs=50,measure_power=False,repeat_n=72//state['copies'])
    observations=[]
    for block in range(5):
        with helper.benchmark_with_power(**kwargs) as result:observations.append(dict(result))
    state['per_op_samples_ms']=[r['latency_ms']/state['copies'] for r in observations]
    result=dict(observations[0]);result['latency_ms']=statistics.median(r['latency_ms'] for r in observations)
    g=torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):
        for _ in range(72//state['copies']):kwargs['kernel_func']()
    for _ in range(25):g.replay()
    torch.cuda.synchronize()
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
        for _ in range(5):g.replay()
        torch.cuda.synchronize()
    trace=OUT/f'op-r{args.replicate}-m{state["m"]}-n{state["n"]}-k{state["k"]}-copies{state["copies"]}.json'
    prof.export_chrome_trace(str(trace))
    raw=trace.read_bytes()
    with gzip.GzipFile(filename=str(trace)+'.gz',mode='wb',mtime=0) as f:f.write(raw)
    state['trace_file']=trace.name+'.gz';state['trace_json_sha256']=hashlib.sha256(raw).hexdigest()
    trace.unlink();g.reset()
    yield result

def record(**kwargs):
    row=dict(state);row.update({k:v for k,v in kwargs.items() if k!='power_stats'})
    with dest.open('a') as f:f.write(json.dumps(row)+'\n')
    print('DONE',args.replicate,state['m'],state['n'],state['k'],state['copies'],kwargs['item_list'],flush=True)
    return True

source=Path(collect_gemm.__file__).read_text()
needle='outside_loop_count = 1 if gemm_type in ("fp8_block", "nvfp4") else 6'
assert source.count(needle)==1
candidate=types.ModuleType('experimental_graph_gemm');candidate.__file__=collect_gemm.__file__
exec(compile(source.replace(needle,'outside_loop_count = _experiment_copies'),collect_gemm.__file__,'exec'),candidate.__dict__)
candidate.benchmark_with_power=benchmark;candidate.log_perf=record
lib=ctypes.CDLL('libcudart.so');l2=ctypes.c_int();assert lib.cudaDeviceGetAttribute(ctypes.byref(l2),38,0)==0
cases=[(m,n,k,c) for m in [1,16] for n,k in [(6144,2560),(2560,4096),(19456,2560),(2560,9728)] for c in [1,2,3,4,6,8,12,24]]
cases += [(16,12288,8192,c) for c in [1,2,4]]
random.Random(14231+args.replicate).shuffle(cases)
for m,n,k,copies in cases:
    torch.manual_seed(7331+args.replicate)
    state.clear();state.update(replicate=args.replicate,m=m,n=n,k=k,copies=copies,graph_ops=72,profiled_replays=5,
      l2_bytes=l2.value,weight_pool_bytes=copies*(n*k+math.ceil(n/128)*math.ceil(k/128)*4),source_sha256=hashlib.sha256(source.encode()).hexdigest())
    candidate._experiment_copies=copies
    with torch.inference_mode():candidate.run_gemm('fp8_block',m,n,k,perf_filename='experimental-rotation-graph')
